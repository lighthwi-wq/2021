import React, { useState, useEffect, useRef } from 'react';
import { Play, Save, Clock, Copy, AlertCircle, CheckCircle, Lightbulb, Sparkles, Info, BookOpen } from 'lucide-react';
import { AutocompleteItem } from '../types/autocomplete';
import { analyzeSQLContext, getContextualSuggestions, filterAndSortSuggestions } from '../utils/sqlContext';

interface SqlEditorProps {
  selectedTable: string | null;
  onQueryExecute: (query: string, results: any[]) => void;
  externalQuery?: string;
  onQueryChange?: (query: string) => void;
}

interface ValidationError {
  line: number;
  message: string;
  severity: 'error' | 'warning' | 'info';
}

export function SqlEditor({ selectedTable, onQueryExecute, externalQuery, onQueryChange }: SqlEditorProps) {
  const [query, setQuery] = useState('');
  const [naturalLanguageInput, setNaturalLanguageInput] = useState('');
  const [isConverting, setIsConverting] = useState(false);
  const [validationErrors, setValidationErrors] = useState<ValidationError[]>([]);
  const [isValid, setIsValid] = useState(true);
  const [autocompleteItems, setAutocompleteItems] = useState<AutocompleteItem[]>([]);
  const [showAutocomplete, setShowAutocomplete] = useState(false);
  const [autocompletePosition, setAutocompletePosition] = useState({ top: 0, left: 0 });
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [currentDatabase, setCurrentDatabase] = useState<'postgresql' | 'mysql' | 'mongodb' | 'all'>('all');
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const autocompleteRef = useRef<HTMLDivElement>(null);

  const sqlKeywords = [
    'SELECT', 'FROM', 'WHERE', 'INSERT', 'UPDATE', 'DELETE', 'JOIN', 'LEFT JOIN', 
    'RIGHT JOIN', 'INNER JOIN', 'OUTER JOIN', 'ON', 'GROUP BY', 'ORDER BY', 
    'HAVING', 'LIMIT', 'OFFSET', 'AS', 'AND', 'OR', 'NOT', 'IN', 'BETWEEN',
    'LIKE', 'IS NULL', 'IS NOT NULL', 'COUNT', 'SUM', 'AVG', 'MAX', 'MIN',
    'DISTINCT', 'CREATE TABLE', 'DROP TABLE', 'ALTER TABLE', 'TRUNCATE'
  ];

  const tables = ['users', 'products', 'orders', 'categories', 'payments', 'customers', 'inventory'];
  
  const columns: Record<string, string[]> = {
    users: ['id', 'username', 'email', 'created_at', 'status', 'last_login'],
    products: ['id', 'name', 'category', 'price', 'stock', 'created_at', 'description'],
    orders: ['id', 'user_id', 'product_id', 'quantity', 'total', 'status', 'order_date'],
    categories: ['id', 'name', 'description', 'item_count'],
    payments: ['id', 'order_id', 'method', 'amount', 'status', 'processed_at']
  };

  useEffect(() => {
    if (selectedTable) {
      setQuery(`SELECT * FROM ${selectedTable} LIMIT 100;`);
    }
  }, [selectedTable]);

  useEffect(() => {
    if (externalQuery) {
      setQuery(externalQuery);
    }
  }, [externalQuery]);

  useEffect(() => {
    const errors = validateSQL(query);
    setValidationErrors(errors);
    setIsValid(errors.filter(e => e.severity === 'error').length === 0);
  }, [query]);

  // 선택된 인덱스가 보이도록 스크롤
  useEffect(() => {
    if (showAutocomplete && autocompleteRef.current) {
      const selectedElement = autocompleteRef.current.children[selectedIndex] as HTMLElement;
      if (selectedElement) {
        selectedElement.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
      }
    }
  }, [selectedIndex, showAutocomplete]);

  const handleQueryChange = (value: string) => {
    setQuery(value);
    onQueryChange?.(value);

    const textarea = textareaRef.current;
    if (!textarea) return;

    const cursorPosition = textarea.selectionStart;
    
    // 컨텍스트 분석
    const context = analyzeSQLContext(value, cursorPosition);
    
    // 자동완성 트리거 조건
    if (context.lastWord.length >= 1 || value.trim() === '') {
      // 컨텍스트 기반 제안 가져오기
      const suggestions = getContextualSuggestions(context, currentDatabase);
      const filtered = filterAndSortSuggestions(suggestions, context.lastWord);
      
      if (filtered.length > 0) {
        setAutocompleteItems(filtered);
        setShowAutocomplete(true);
        setSelectedIndex(0);
        
        // 자동완성 위치 계산
        const textBeforeCursor = value.substring(0, cursorPosition);
        const lines = textBeforeCursor.split('\n');
        const currentLine = lines.length;
        const currentColumn = lines[lines.length - 1].length;
        
        setAutocompletePosition({
          top: Math.min(currentLine * 21 + 40, 400),
          left: Math.min(currentColumn * 8.5 + 60, 700)
        });
      } else {
        setShowAutocomplete(false);
      }
    } else {
      setShowAutocomplete(false);
    }
  };

  const insertAutocomplete = (item: AutocompleteItem) => {
    const textarea = textareaRef.current;
    if (!textarea) return;

    const cursorPosition = textarea.selectionStart;
    const textBeforeCursor = query.substring(0, cursorPosition);
    const textAfterCursor = query.substring(cursorPosition);
    
    // 현재 단어 시작 위치 찾기
    const context = analyzeSQLContext(query, cursorPosition);
    const lastWordStart = cursorPosition - context.lastWord.length;
    
    // 삽입할 텍스트 (insertText가 있으면 그것을 사용, 없으면 text 사용)
    const insertText = item.insertText || item.text;
    
    // 새 쿼리 생성
    const newQuery = 
      query.substring(0, lastWordStart) + 
      insertText + 
      (item.type === 'snippet' ? '\n' : ' ') + 
      textAfterCursor;
    
    setQuery(newQuery);
    onQueryChange?.(newQuery);
    setShowAutocomplete(false);

    // 커서 위치 설정 (cursorOffset이 있으면 그만큼 뒤로)
    setTimeout(() => {
      const basePosition = lastWordStart + insertText.length;
      const finalPosition = basePosition + (item.cursorOffset || 0);
      textarea.setSelectionRange(finalPosition, finalPosition);
      textarea.focus();
    }, 0);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (showAutocomplete && autocompleteItems.length > 0) {
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        setSelectedIndex(prev => Math.min(prev + 1, autocompleteItems.length - 1));
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        setSelectedIndex(prev => Math.max(prev - 1, 0));
      } else if (e.key === 'Enter') {
        e.preventDefault();
        if (autocompleteItems[selectedIndex]) {
          insertAutocomplete(autocompleteItems[selectedIndex]);
        }
      } else if (e.key === 'Tab') {
        if (autocompleteItems[selectedIndex]) {
          e.preventDefault();
          insertAutocomplete(autocompleteItems[selectedIndex]);
        }
      } else if (e.key === 'Escape') {
        e.preventDefault();
        setShowAutocomplete(false);
      }
    } else if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') {
      e.preventDefault();
      handleExecute();
    } else if (e.ctrlKey && e.key === ' ') {
      e.preventDefault();
      const cursorPosition = textareaRef.current?.selectionStart || 0;
      const context = analyzeSQLContext(query, cursorPosition);
      const suggestions = getContextualSuggestions(context, currentDatabase);
      if (suggestions.length > 0) {
        setAutocompleteItems(suggestions);
        setShowAutocomplete(true);
        setSelectedIndex(0);
      }
    }
  };

  const handleExecute = () => {
    if (!query.trim()) return;
    
    if (!isValid) {
      alert('쿼리 오류를 수정한 후 실행해주세요.');
      return;
    }

    const mockResults = generateMockData(selectedTable || 'table');
    onQueryExecute(query, mockResults);
  };

  // 자연어를 SQL로 변환하는 함수
  const convertNaturalLanguageToSQL = async (naturalLanguage: string): Promise<string> => {
    const input = naturalLanguage.toLowerCase().trim();
    
    // 패턴 매칭을 통한 자연어 → SQL 변환
    let sql = '';
    let table = 'users';
    let columns = '*';
    let conditions: string[] = [];
    let orderBy = '';
    let limit = '';
    let groupBy = '';
    let having = '';
    
    // 테이블 감지
    if (input.includes('사용자') || input.includes('유저') || input.includes('회원')) {
      table = 'users';
    } else if (input.includes('상품') || input.includes('제품') || input.includes('물건')) {
      table = 'products';
    } else if (input.includes('주문') || input.includes('구매')) {
      table = 'orders';
    } else if (input.includes('결제') || input.includes('지불')) {
      table = 'payments';
    } else if (input.includes('카테고리') || input.includes('분류')) {
      table = 'categories';
    }
    
    // 조회 컬럼 감지
    if (input.includes('이름') || input.includes('명') || input.includes('이름만')) {
      columns = table === 'users' ? 'username, email' : 'name';
    } else if (input.includes('아이디') || input.includes('id')) {
      columns = 'id';
    } else if (input.includes('이메일')) {
      columns = 'email';
    } else if (input.includes('가격') || input.includes('금액')) {
      columns = 'price';
    }
    
    // 날짜 조건
    if (input.includes('오늘') || input.includes('today')) {
      conditions.push(`created_at >= CURDATE()`);
    } else if (input.includes('어제') || input.includes('yesterday')) {
      conditions.push(`created_at >= DATE_SUB(CURDATE(), INTERVAL 1 DAY) AND created_at < CURDATE()`);
    } else if (input.includes('이번 주') || input.includes('금주')) {
      conditions.push(`created_at >= DATE_SUB(CURDATE(), INTERVAL WEEKDAY(CURDATE()) DAY)`);
    } else if (input.includes('지난 주') || input.includes('저번 주')) {
      conditions.push(`created_at >= DATE_SUB(CURDATE(), INTERVAL WEEKDAY(CURDATE())+7 DAY) AND created_at < DATE_SUB(CURDATE(), INTERVAL WEEKDAY(CURDATE()) DAY)`);
    } else if (input.includes('이번 달') || input.includes('금월')) {
      conditions.push(`MONTH(created_at) = MONTH(CURDATE()) AND YEAR(created_at) = YEAR(CURDATE())`);
    } else if (input.includes('지난 달') || input.includes('저번 달')) {
      conditions.push(`MONTH(created_at) = MONTH(DATE_SUB(CURDATE(), INTERVAL 1 MONTH)) AND YEAR(created_at) = YEAR(DATE_SUB(CURDATE(), INTERVAL 1 MONTH))`);
    } else if (input.includes('최근 30일')) {
      conditions.push(`created_at >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)`);
    } else if (input.includes('최근 7일')) {
      conditions.push(`created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)`);
    } else if (input.includes('올해') || input.includes('금년')) {
      conditions.push(`YEAR(created_at) = YEAR(CURDATE())`);
    }
    
    // 상태 조건
    if (input.includes('활성')) {
      conditions.push(`status = '활성'`);
    } else if (input.includes('비활성')) {
      conditions.push(`status = '비활성'`);
    } else if (input.includes('완료')) {
      conditions.push(`status = '완료'`);
    } else if (input.includes('대기')) {
      conditions.push(`status = '대기'`);
    }
    
    // 금액 조건
    const priceMatch = input.match(/(\d+)만원\s*(이상|초과|이하|미만)/);
    if (priceMatch) {
      const amount = parseInt(priceMatch[1]) * 10000;
      const operator = priceMatch[2];
      const column = table === 'products' ? 'price' : table === 'orders' ? 'total' : 'amount';
      
      if (operator === '이상') {
        conditions.push(`${column} >= ${amount}`);
      } else if (operator === '초과') {
        conditions.push(`${column} > ${amount}`);
      } else if (operator === '이하') {
        conditions.push(`${column} <= ${amount}`);
      } else if (operator === '미만') {
        conditions.push(`${column} < ${amount}`);
      }
    }
    
    // 숫자 조건
    const numberMatch = input.match(/(\d+)\s*(개|명)\s*(이상|초과|이하|미만)/);
    if (numberMatch) {
      const count = parseInt(numberMatch[1]);
      const operator = numberMatch[3];
      const column = table === 'products' ? 'stock' : 'quantity';
      
      if (operator === '이상') {
        conditions.push(`${column} >= ${count}`);
      } else if (operator === '초과') {
        conditions.push(`${column} > ${count}`);
      } else if (operator === '이하') {
        conditions.push(`${column} <= ${count}`);
      } else if (operator === '미만') {
        conditions.push(`${column} < ${count}`);
      }
    }
    
    // 정렬
    if (input.includes('최신순') || input.includes('최근순')) {
      orderBy = `ORDER BY created_at DESC`;
    } else if (input.includes('오래된순') || input.includes('과거순')) {
      orderBy = `ORDER BY created_at ASC`;
    } else if (input.includes('가격순') || input.includes('금액순')) {
      const column = table === 'products' ? 'price' : table === 'orders' ? 'total' : 'amount';
      if (input.includes('높은')) {
        orderBy = `ORDER BY ${column} DESC`;
      } else {
        orderBy = `ORDER BY ${column} ASC`;
      }
    } else if (input.includes('이름순')) {
      const column = table === 'users' ? 'username' : 'name';
      orderBy = `ORDER BY ${column} ASC`;
    }
    
    // 개수 제한
    if (input.includes('상위')) {
      const topMatch = input.match(/상위\s*(\d+)/);
      if (topMatch) {
        limit = `LIMIT ${topMatch[1]}`;
      } else {
        limit = `LIMIT 10`;
      }
    } else if (input.includes('처음')) {
      const firstMatch = input.match(/처음\s*(\d+)/);
      if (firstMatch) {
        limit = `LIMIT ${firstMatch[1]}`;
      } else {
        limit = `LIMIT 10`;
      }
    } else if (!input.includes('전체') && !input.includes('모든')) {
      limit = `LIMIT 100`;
    }
    
    // 집계 함수
    if (input.includes('개수') || input.includes('수') || input.includes('몇')) {
      columns = 'COUNT(*) as count';
    } else if (input.includes('합계') || input.includes('총합')) {
      const column = table === 'orders' ? 'total' : 'price';
      columns = `SUM(${column}) as total_sum`;
    } else if (input.includes('평균')) {
      const column = table === 'orders' ? 'total' : 'price';
      columns = `AVG(${column}) as average`;
    } else if (input.includes('최댓값') || input.includes('최대')) {
      const column = table === 'orders' ? 'total' : 'price';
      columns = `MAX(${column}) as max_value`;
    } else if (input.includes('최솟값') || input.includes('최소')) {
      const column = table === 'orders' ? 'total' : 'price';
      columns = `MIN(${column}) as min_value`;
    }
    
    // 그룹화
    if (input.includes('별로') || input.includes('그룹') || input.includes('분류')) {
      if (input.includes('상태별') || input.includes('status')) {
        groupBy = 'GROUP BY status';
        if (columns === '*') columns = 'status, COUNT(*) as count';
      } else if (input.includes('카테고리별') || input.includes('category')) {
        groupBy = 'GROUP BY category';
        if (columns === '*') columns = 'category, COUNT(*) as count';
      } else if (input.includes('날짜별') || input.includes('일별')) {
        groupBy = 'GROUP BY DATE(created_at)';
        if (columns === '*') columns = 'DATE(created_at) as date, COUNT(*) as count';
      } else if (input.includes('월별')) {
        groupBy = 'GROUP BY YEAR(created_at), MONTH(created_at)';
        if (columns === '*') columns = 'YEAR(created_at) as year, MONTH(created_at) as month, COUNT(*) as count';
      }
    }
    
    // SQL 조립
    sql = `SELECT ${columns}\nFROM ${table}`;
    
    if (conditions.length > 0) {
      sql += `\nWHERE ${conditions.join(' AND ')}`;
    }
    
    if (groupBy) {
      sql += `\n${groupBy}`;
    }
    
    if (having) {
      sql += `\n${having}`;
    }
    
    if (orderBy) {
      sql += `\n${orderBy}`;
    }
    
    if (limit) {
      sql += `\n${limit}`;
    }
    
    sql += ';';
    
    return sql;
  };

  // 자연어 변환 버튼 핸들러
  const handleNaturalLanguageConvert = async () => {
    if (!naturalLanguageInput.trim()) {
      return;
    }
    
    setIsConverting(true);
    
    // 변환 시뮬레이션 (실제로는 API 호출)
    setTimeout(async () => {
      const generatedSQL = await convertNaturalLanguageToSQL(naturalLanguageInput);
      setQuery(generatedSQL);
      onQueryChange?.(generatedSQL);
      setIsConverting(false);
      
      // 포커스를 SQL 에디터로 이동
      textareaRef.current?.focus();
    }, 800);
  };

  // 빠른 템플릿 핸들러
  const handleQuickTemplate = (templateType: string) => {
    let template = '';
    
    switch (templateType) {
      case '전체 조회':
        template = '모든 사용자 목록';
        break;
      case '최근 30일':
        template = '최근 30일 동안 등록된 사용자';
        break;
      case '집계 쿼리':
        template = '상태별 사용자 개수';
        break;
    }
    
    setNaturalLanguageInput(template);
  };

  return (
    <div className="flex flex-col border-b border-gray-300 bg-white">
      {/* Natural Language Input */}
      <div className="p-4 bg-gradient-to-r from-purple-50 via-blue-50 to-purple-50 border-b border-gray-300 relative overflow-hidden">
        {/* 배경 애니메이션 효과 */}
        <div className="absolute inset-0 bg-gradient-to-r from-purple-400/5 via-blue-400/5 to-purple-400/5 animate-pulse"></div>
        
        <div className="relative z-10">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-blue-500 flex items-center justify-center">
                <Sparkles className="w-4 h-4 text-white" />
              </div>
              <span className="text-gray-900">자연어 SQL 변환</span>
            </div>
            <button className="text-xs text-gray-500 hover:text-gray-700 transition-colors flex items-center gap-1 px-2 py-1 hover:bg-gray-100 rounded">
              <Info className="w-3.5 h-3.5" />
              도움말
            </button>
          </div>
          
          <div className="flex gap-2 mb-3">
            <div className="flex-1 relative">
              <input
                type="text"
                placeholder="예: 지난 주 매출이 100만원 이상인 사용자 목록 조회"
                className="w-full px-4 py-2.5 bg-white text-gray-900 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 placeholder-gray-400 transition-all"
                value={naturalLanguageInput}
                onChange={(e) => setNaturalLanguageInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleNaturalLanguageConvert();
                  }
                }}
                disabled={isConverting}
              />
              <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-1">
                {isConverting && (
                  <div className="animate-spin rounded-full h-4 w-4 border-2 border-blue-500 border-t-transparent"></div>
                )}
                {!isConverting && (
                  <button className="p-1 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded transition-colors" title="최근 검색">
                    <Clock className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>
            
            <button 
              className="px-5 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed" 
              onClick={handleNaturalLanguageConvert}
              disabled={isConverting || !naturalLanguageInput.trim()}
            >
              {isConverting ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent"></div>
                  <span>변환 중...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>생성</span>
                </>
              )}
            </button>
          </div>

          {/* 빠른 예시 버튼들 */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-hide">
            <span className="text-xs text-gray-500 whitespace-nowrap">빠른 템플릿</span>
            {[
              { icon: Play, text: '전체 조회' },
              { icon: Clock, text: '최근 30일' },
              { icon: Save, text: '집계 쿼리' }
            ].map((example, idx) => {
              const Icon = example.icon;
              return (
                <button
                  key={idx}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-gray-300 rounded-lg text-xs text-gray-700 hover:border-blue-500 hover:text-blue-600 hover:bg-blue-50 transition-all whitespace-nowrap"
                  onClick={() => handleQuickTemplate(example.text)}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{example.text}</span>
                </button>
              );
            })}
          </div>

          {/* 실시간 상태 표시 */}
          <div className="mt-3 flex items-center justify-between text-xs text-gray-500">
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-1.5">
                <div className="w-1.5 h-1.5 bg-green-500 rounded-full"></div>
                <span>연결됨</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle className="w-3.5 h-3.5 text-green-600" />
                <span>한국어 지원</span>
              </div>
            </div>
          </div>
        </div>

        {/* 스타일 태그 추가 */}
        <style>{`
          @keyframes shimmer {
            0% { background-position: -1000px 0; }
            100% { background-position: 1000px 0; }
          }
          .scrollbar-hide::-webkit-scrollbar {
            display: none;
          }
          .scrollbar-hide {
            -ms-overflow-style: none;
            scrollbar-width: none;
          }
        `}</style>
      </div>

      {/* Toolbar */}
      <div className="flex items-center justify-between px-4 py-2 border-b border-gray-300 bg-gray-50">
        <div className="flex items-center gap-2">
          <button
            onClick={handleExecute}
            disabled={!isValid}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Play className="w-4 h-4" />
            <span className="text-sm">실행</span>
          </button>
          <button className="flex items-center gap-2 px-3 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors text-gray-700">
            <Save className="w-4 h-4" />
            <span className="text-sm">저장</span>
          </button>
          <button className="flex items-center gap-2 px-3 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors text-gray-700">
            <Copy className="w-4 h-4" />
            <span className="text-sm">복사</span>
          </button>
          <button className="flex items-center gap-2 px-3 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors text-gray-700">
            <Clock className="w-4 h-4" />
            <span className="text-sm">기록</span>
          </button>
          
          <div className="ml-4 flex items-center gap-2">
            {isValid ? (
              <div className="flex items-center gap-1 text-green-600">
                <CheckCircle className="w-4 h-4" />
                <span className="text-sm">유효한 SQL</span>
              </div>
            ) : (
              <div className="flex items-center gap-1 text-red-600">
                <AlertCircle className="w-4 h-4" />
                <span className="text-sm">{validationErrors.filter(e => e.severity === 'error').length}개 오류</span>
              </div>
            )}
          </div>
        </div>
        
        <div className="text-sm text-gray-500">
          <kbd className="px-2 py-1 bg-white border border-gray-300 rounded text-gray-700">Ctrl+Enter</kbd> 실행 | 
          <kbd className="px-2 py-1 bg-white border border-gray-300 rounded ml-2 text-gray-700">Ctrl+Space</kbd> 자동완성
        </div>
      </div>

      {/* Editor */}
      <div className="p-4 relative">
        <div className="relative overflow-hidden">
          <textarea
            ref={textareaRef}
            value={query}
            onChange={(e) => handleQueryChange(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="-- SQL 쿼리를 입력하세요&#10;SELECT * FROM table_name;"
            className={`w-full h-[512px] p-4 pl-16 font-mono text-sm bg-gray-50 text-gray-900 border rounded-lg focus:outline-none focus:ring-2 resize-none overflow-y-auto ${
              isValid ? 'border-gray-300 focus:ring-blue-500' : 'border-red-500 focus:ring-red-500'
            } placeholder-gray-400`}
            spellCheck={false}
            style={{ lineHeight: '1.5' }}
          />
          
          {/* Line numbers */}
          <div 
            className="absolute left-2 top-4 text-gray-400 font-mono text-sm pointer-events-none select-none overflow-hidden" 
            style={{ 
              lineHeight: '1.5', 
              width: '40px', 
              textAlign: 'right', 
              paddingRight: '8px',
              maxHeight: 'calc(512px - 32px)' 
            }}
          >
            {query.split('\n').map((_, i) => (
              <div key={i} className="h-[21px]">
                {i + 1}
              </div>
            ))}
          </div>

          {/* Autocomplete Dropdown */}
          {showAutocomplete && autocompleteItems.length > 0 && (
            <div
              ref={autocompleteRef}
              className="absolute bg-white border-2 border-blue-500 rounded-lg shadow-2xl z-50 overflow-y-auto"
              style={{
                top: `${autocompletePosition.top}px`,
                left: `${autocompletePosition.left}px`,
                minWidth: '380px',
                maxWidth: '500px',
                maxHeight: '400px'
              }}
            >
              <div className="sticky top-0 bg-gradient-to-r from-blue-500 to-purple-500 text-white px-3 py-2 text-xs border-b border-blue-600">
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5" />
                    컨텍스트 기반 제안 ({autocompleteItems.length})
                  </span>
                  <span className="flex items-center gap-2 opacity-80">
                    <kbd className="px-1.5 py-0.5 bg-white/20 rounded text-[10px]">↑↓</kbd>
                    <kbd className="px-1.5 py-0.5 bg-white/20 rounded text-[10px]">Enter</kbd>
                    <kbd className="px-1.5 py-0.5 bg-white/20 rounded text-[10px]">Esc</kbd>
                  </span>
                </div>
              </div>
              
              {autocompleteItems.map((item, index) => {
                const getTypeIcon = () => {
                  switch (item.type) {
                    case 'keyword': return { icon: 'K', bg: 'bg-purple-600', label: '키워드' };
                    case 'table': return { icon: 'T', bg: 'bg-blue-600', label: '테이블' };
                    case 'column': return { icon: 'C', bg: 'bg-green-600', label: '컬럼' };
                    case 'function': return { icon: 'F', bg: 'bg-orange-600', label: '함수' };
                    case 'snippet': return { icon: 'S', bg: 'bg-pink-600', label: '스니펫' };
                    case 'operator': return { icon: 'O', bg: 'bg-indigo-600', label: '연산자' };
                    default: return { icon: '?', bg: 'bg-gray-600', label: '기타' };
                  }
                };
                
                const typeInfo = getTypeIcon();
                const isSelected = index === selectedIndex;
                
                return (
                  <div
                    key={index}
                    onClick={() => insertAutocomplete(item)}
                    className={`px-3 py-2.5 cursor-pointer border-b border-gray-100 last:border-b-0 transition-all ${
                      isSelected 
                        ? 'bg-gradient-to-r from-blue-600 to-blue-700 text-white' 
                        : 'text-gray-700 hover:bg-blue-50'
                    }`}
                  >
                    <div className="flex items-start gap-2.5">
                      <span className={`w-7 h-7 rounded flex items-center justify-center text-xs flex-shrink-0 ${
                        isSelected ? 'bg-white/20' : typeInfo.bg
                      } text-white shadow-sm`}>
                        {typeInfo.icon}
                      </span>
                      
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-0.5">
                          <span className="font-mono truncate">{item.text}</span>
                          {item.category && (
                            <span className={`text-[10px] px-1.5 py-0.5 rounded ${
                              isSelected 
                                ? 'bg-white/20 text-white' 
                                : 'bg-gray-200 text-gray-600'
                            }`}>
                              {item.category}
                            </span>
                          )}
                        </div>
                        
                        {item.description && (
                          <div className={`text-xs mb-1 ${
                            isSelected ? 'text-blue-100' : 'text-gray-500'
                          }`}>
                            {item.description}
                          </div>
                        )}
                        
                        {item.example && (
                          <div className={`text-[11px] font-mono mt-1 ${
                            isSelected 
                              ? 'text-white/80' 
                              : 'text-gray-600'
                          }`}>
                            💡 {item.example}
                          </div>
                        )}
                      </div>
                      
                      {isSelected && (
                        <div className="flex items-center gap-1 text-xs text-white/80 flex-shrink-0">
                          <BookOpen className="w-3 h-3" />
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
              
              <div className="sticky bottom-0 bg-gray-50 px-3 py-2 text-[10px] text-gray-500 border-t border-gray-200">
                <div className="flex items-center justify-between">
                  <span>Ctrl+Space로 강제 실행</span>
                  <span className="flex items-center gap-1">
                    <Info className="w-3 h-3" />
                    AI 기반 스마트 제안
                  </span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Validation Messages */}
        {validationErrors.length > 0 && (
          <div className="mt-3 space-y-2">
            {validationErrors.map((error, index) => (
              <div
                key={index}
                className={`flex items-start gap-2 p-2 rounded-lg border ${
                  error.severity === 'error'
                    ? 'bg-red-50 border-red-200'
                    : error.severity === 'warning'
                    ? 'bg-yellow-50 border-yellow-200'
                    : 'bg-blue-50 border-blue-200'
                }`}
              >
                <AlertCircle
                  className={`w-4 h-4 mt-0.5 ${
                    error.severity === 'error'
                      ? 'text-red-600'
                      : error.severity === 'warning'
                      ? 'text-yellow-600'
                      : 'text-blue-600'
                  }`}
                />
                <div className="flex-1">
                  <span className="text-sm text-gray-700">
                    <strong>라인 {error.line}:</strong> {error.message}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {selectedTable && (
        <div className="px-4 pb-3">
          <div className="flex items-center gap-2 px-3 py-2 bg-blue-50 border border-blue-200 rounded-lg">
            <span className="text-sm text-blue-700">
              선택된 테이블: <strong>{selectedTable}</strong>
            </span>
          </div>
        </div>
      )}
    </div>
  );
}

function validateSQL(query: string): ValidationError[] {
  const errors: ValidationError[] = [];
  const lines = query.split('\n');
  const queryUpper = query.toUpperCase();

  if (!query.trim()) return errors;

  const hasSelect = queryUpper.includes('SELECT');
  const hasInsert = queryUpper.includes('INSERT');
  const hasUpdate = queryUpper.includes('UPDATE');
  const hasDelete = queryUpper.includes('DELETE');
  const hasCreate = queryUpper.includes('CREATE');

  if (!hasSelect && !hasInsert && !hasUpdate && !hasDelete && !hasCreate) {
    errors.push({
      line: 1,
      message: '유효한 SQL 키워드로 시작해야 합니다 (SELECT, INSERT, UPDATE, DELETE, CREATE)',
      severity: 'error'
    });
  }

  if (hasSelect && !queryUpper.includes('FROM')) {
    const selectLine = lines.findIndex(line => line.toUpperCase().includes('SELECT')) + 1;
    errors.push({
      line: selectLine,
      message: 'SELECT 문에 FROM 절이 필요합니다',
      severity: 'error'
    });
  }

  if (!query.trim().endsWith(';')) {
    errors.push({
      line: lines.length,
      message: '쿼리는 세미콜론(;)으로 끝나야 합니다',
      severity: 'warning'
    });
  }

  if (queryUpper.includes('SELECT *')) {
    const selectLine = lines.findIndex(line => line.toUpperCase().includes('SELECT *')) + 1;
    errors.push({
      line: selectLine,
      message: '성능을 위해 SELECT * 대신 컬럼명을 명시하는 것을 권장합니다',
      severity: 'info'
    });
  }

  if ((hasUpdate || hasDelete) && !queryUpper.includes('WHERE')) {
    const line = lines.findIndex(l => l.toUpperCase().includes('UPDATE') || l.toUpperCase().includes('DELETE')) + 1;
    errors.push({
      line: line,
      message: 'WHERE 절이 없는 UPDATE/DELETE는 모든 행에 영향을 줍니다!',
      severity: 'warning'
    });
  }

  const openParens = (query.match(/\(/g) || []).length;
  const closeParens = (query.match(/\)/g) || []).length;
  if (openParens !== closeParens) {
    errors.push({
      line: lines.length,
      message: `괄호가 일치하지 않습니다: ${openParens}개 열림, ${closeParens}개 닫힘`,
      severity: 'error'
    });
  }

  return errors;
}

function generateMockData(tableName: string): any[] {
  const mockDataMap: Record<string, any[]> = {
    users: [
      { id: 1, username: 'john_doe', email: 'john@example.com', created_at: '2024-01-15', status: '활성' },
      { id: 2, username: 'jane_smith', email: 'jane@example.com', created_at: '2024-01-20', status: '활성' },
      { id: 3, username: 'bob_wilson', email: 'bob@example.com', created_at: '2024-02-01', status: '비활성' },
      { id: 4, username: 'alice_brown', email: 'alice@example.com', created_at: '2024-02-10', status: '활성' },
      { id: 5, username: 'charlie_davis', email: 'charlie@example.com', created_at: '2024-02-15', status: '활성' },
    ],
    products: [
      { id: 1, name: '노트북 Pro', category: '전자기기', price: 1299000, stock: 45, created_at: '2024-01-10' },
      { id: 2, name: '무선 마우스', category: '액세서리', price: 29900, stock: 150, created_at: '2024-01-12' },
      { id: 3, name: 'USB-C 케이블', category: '액세서리', price: 12900, stock: 200, created_at: '2024-01-15' },
      { id: 4, name: '모니터 27"', category: '전자기기', price: 399000, stock: 30, created_at: '2024-01-18' },
      { id: 5, name: '기계식 키보드', category: '액세서리', price: 89900, stock: 75, created_at: '2024-01-20' },
    ],
    orders: [
      { id: 1001, user_id: 1, product_id: 1, quantity: 1, total: 1299000, status: '완료', order_date: '2024-03-01' },
      { id: 1002, user_id: 2, product_id: 2, quantity: 2, total: 59800, status: '완료', order_date: '2024-03-02' },
      { id: 1003, user_id: 3, product_id: 4, quantity: 1, total: 399000, status: '대기', order_date: '2024-03-05' },
      { id: 1004, user_id: 1, product_id: 5, quantity: 1, total: 89900, status: '배송중', order_date: '2024-03-07' },
      { id: 1005, user_id: 4, product_id: 3, quantity: 3, total: 38700, status: '완료', order_date: '2024-03-10' },
    ],
  };

  return mockDataMap[tableName] || [
    { id: 1, column1: '샘플 데이터', column2: '값 1', column3: 100 },
    { id: 2, column1: '예시 행', column2: '값 2', column3: 200 },
    { id: 3, column1: '테스트 항목', column2: '값 3', column3: 300 },
  ];
}