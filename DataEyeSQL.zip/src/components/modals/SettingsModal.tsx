import React, { useState } from 'react';
import { X, Monitor, Moon, Sun, Type, Code, Clock, Database, Globe } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Settings } from '../../types';
import { useLocalStorage } from '../../hooks/useLocalStorage';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const DEFAULT_SETTINGS: Settings = {
  theme: 'dark',
  fontSize: 14,
  editorTheme: 'vs-dark',
  autoComplete: true,
  syntaxHighlight: true,
  lineNumbers: true,
  minimap: false,
  wordWrap: true,
  tabSize: 2,
  queryTimeout: 30,
  maxRows: 1000,
  dateFormat: 'YYYY-MM-DD HH:mm:ss',
  language: 'ko'
};

export function SettingsModal({ isOpen, onClose }: SettingsModalProps) {
  const [settings, setSettings] = useLocalStorage<Settings>('dataeye-settings', DEFAULT_SETTINGS);
  const [activeTab, setActiveTab] = useState<'appearance' | 'editor' | 'query' | 'advanced'>('appearance');

  const handleSave = () => {
    onClose();
  };

  const handleReset = () => {
    if (confirm('모든 설정을 초기화하시겠습니까?')) {
      setSettings(DEFAULT_SETTINGS);
    }
  };

  const updateSetting = <K extends keyof Settings>(key: K, value: Settings[K]) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  if (!isOpen) return null;

  const tabs = [
    { id: 'appearance', label: '외관', icon: <Monitor className="w-4 h-4" /> },
    { id: 'editor', label: '에디터', icon: <Code className="w-4 h-4" /> },
    { id: 'query', label: '쿼리', icon: <Database className="w-4 h-4" /> },
    { id: 'advanced', label: '고급', icon: <Globe className="w-4 h-4" /> }
  ] as const;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.95, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.95, opacity: 0 }}
          transition={{ type: "spring", stiffness: 300, damping: 30 }}
          className="bg-white dark:bg-[#252526] rounded-xl shadow-2xl w-full max-w-4xl max-h-[85vh] overflow-hidden"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
            <div>
              <h2 className="text-xl text-gray-900 dark:text-gray-100">설정</h2>
              <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                DataEye SQL의 환경을 설정합니다
              </p>
            </div>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 dark:hover:bg-[#2d2d30] rounded-lg transition-colors"
            >
              <X className="w-5 h-5 text-gray-600 dark:text-gray-400" />
            </button>
          </div>

          <div className="flex h-[calc(85vh-180px)]">
            {/* Sidebar */}
            <div className="w-48 border-r border-gray-200 dark:border-gray-700 p-3">
              {tabs.map((tab) => (
                <motion.button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-left mb-1 transition-colors ${
                    activeTab === tab.id
                      ? 'bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400'
                      : 'hover:bg-gray-100 dark:hover:bg-[#2d2d30] text-gray-700 dark:text-gray-300'
                  }`}
                  whileHover={{ x: 4 }}
                  whileTap={{ scale: 0.98 }}
                >
                  {tab.icon}
                  <span className="text-sm">{tab.label}</span>
                </motion.button>
              ))}
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto p-6">
              {activeTab === 'appearance' && (
                <div className="space-y-6">
                  <SettingSection title="테마" icon={<Sun className="w-5 h-5" />}>
                    <div className="grid grid-cols-3 gap-3">
                      {[
                        { value: 'light', label: '라이트', icon: <Sun className="w-4 h-4" /> },
                        { value: 'dark', label: '다크', icon: <Moon className="w-4 h-4" /> },
                        { value: 'auto', label: '자동', icon: <Monitor className="w-4 h-4" /> }
                      ].map((theme) => (
                        <button
                          key={theme.value}
                          onClick={() => updateSetting('theme', theme.value as any)}
                          className={`p-4 rounded-lg border-2 transition-all ${
                            settings.theme === theme.value
                              ? 'border-blue-600 dark:border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                              : 'border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600'
                          }`}
                        >
                          <div className="flex flex-col items-center gap-2">
                            {theme.icon}
                            <span className="text-sm text-gray-900 dark:text-gray-100">{theme.label}</span>
                          </div>
                        </button>
                      ))}
                    </div>
                  </SettingSection>

                  <SettingSection title="폰트 크기" icon={<Type className="w-5 h-5" />}>
                    <div className="flex items-center gap-4">
                      <input
                        type="range"
                        min="12"
                        max="18"
                        value={settings.fontSize}
                        onChange={(e) => updateSetting('fontSize', parseInt(e.target.value))}
                        className="flex-1"
                      />
                      <span className="text-sm text-gray-600 dark:text-gray-400 w-12 text-right">
                        {settings.fontSize}px
                      </span>
                    </div>
                  </SettingSection>
                </div>
              )}

              {activeTab === 'editor' && (
                <div className="space-y-6">
                  <SettingSection title="에디터 테마" icon={<Code className="w-5 h-5" />}>
                    <select
                      value={settings.editorTheme}
                      onChange={(e) => updateSetting('editorTheme', e.target.value as any)}
                      className="w-full px-3 py-2 bg-gray-50 dark:bg-[#2d2d30] border border-gray-300 dark:border-gray-600 rounded-lg text-gray-900 dark:text-gray-100"
                    >
                      <option value="vs-dark">다크</option>
                      <option value="vs-light">라이트</option>
                    </select>
                  </SettingSection>

                  <SettingSection title="탭 크기" icon={<Code className="w-5 h-5" />}>
                    <div className="flex items-center gap-4">
                      <input
                        type="range"
                        min="2"
                        max="8"
                        step="2"
                        value={settings.tabSize}
                        onChange={(e) => updateSetting('tabSize', parseInt(e.target.value))}
                        className="flex-1"
                      />
                      <span className="text-sm text-gray-600 dark:text-gray-400 w-12 text-right">
                        {settings.tabSize}칸
                      </span>
                    </div>
                  </SettingSection>

                  <div className="space-y-3">
                    <ToggleSetting
                      label="자동 완성"
                      description="SQL 키워드 및 테이블명 자동완성"
                      checked={settings.autoComplete}
                      onChange={(checked) => updateSetting('autoComplete', checked)}
                    />
                    <ToggleSetting
                      label="구문 강조"
                      description="SQL 키워드 색상 강조"
                      checked={settings.syntaxHighlight}
                      onChange={(checked) => updateSetting('syntaxHighlight', checked)}
                    />
                    <ToggleSetting
                      label="줄 번호"
                      description="에디터 줄 번호 표시"
                      checked={settings.lineNumbers}
                      onChange={(checked) => updateSetting('lineNumbers', checked)}
                    />
                    <ToggleSetting
                      label="미니맵"
                      description="코드 미니맵 표시"
                      checked={settings.minimap}
                      onChange={(checked) => updateSetting('minimap', checked)}
                    />
                    <ToggleSetting
                      label="자동 줄바꿈"
                      description="긴 줄 자동 줄바꿈"
                      checked={settings.wordWrap}
                      onChange={(checked) => updateSetting('wordWrap', checked)}
                    />
                  </div>
                </div>
              )}

              {activeTab === 'query' && (
                <div className="space-y-6">
                  <SettingSection title="쿼리 타임아웃" icon={<Clock className="w-5 h-5" />}>
                    <div className="flex items-center gap-4">
                      <input
                        type="range"
                        min="10"
                        max="120"
                        step="10"
                        value={settings.queryTimeout}
                        onChange={(e) => updateSetting('queryTimeout', parseInt(e.target.value))}
                        className="flex-1"
                      />
                      <span className="text-sm text-gray-600 dark:text-gray-400 w-12 text-right">
                        {settings.queryTimeout}초
                      </span>
                    </div>
                  </SettingSection>

                  <SettingSection title="최대 조회 행" icon={<Database className="w-5 h-5" />}>
                    <select
                      value={settings.maxRows}
                      onChange={(e) => updateSetting('maxRows', parseInt(e.target.value))}
                      className="w-full px-3 py-2 bg-gray-50 dark:bg-[#2d2d30] border border-gray-300 dark:border-gray-600 rounded-lg text-gray-900 dark:text-gray-100"
                    >
                      <option value="100">100행</option>
                      <option value="500">500행</option>
                      <option value="1000">1,000행</option>
                      <option value="5000">5,000행</option>
                      <option value="10000">10,000행</option>
                    </select>
                  </SettingSection>

                  <SettingSection title="날짜 형식" icon={<Clock className="w-5 h-5" />}>
                    <select
                      value={settings.dateFormat}
                      onChange={(e) => updateSetting('dateFormat', e.target.value)}
                      className="w-full px-3 py-2 bg-gray-50 dark:bg-[#2d2d30] border border-gray-300 dark:border-gray-600 rounded-lg text-gray-900 dark:text-gray-100"
                    >
                      <option value="YYYY-MM-DD HH:mm:ss">YYYY-MM-DD HH:mm:ss</option>
                      <option value="YYYY/MM/DD HH:mm:ss">YYYY/MM/DD HH:mm:ss</option>
                      <option value="DD-MM-YYYY HH:mm:ss">DD-MM-YYYY HH:mm:ss</option>
                      <option value="MM/DD/YYYY HH:mm:ss">MM/DD/YYYY HH:mm:ss</option>
                    </select>
                  </SettingSection>
                </div>
              )}

              {activeTab === 'advanced' && (
                <div className="space-y-6">
                  <SettingSection title="언어" icon={<Globe className="w-5 h-5" />}>
                    <select
                      value={settings.language}
                      onChange={(e) => updateSetting('language', e.target.value as any)}
                      className="w-full px-3 py-2 bg-gray-50 dark:bg-[#2d2d30] border border-gray-300 dark:border-gray-600 rounded-lg text-gray-900 dark:text-gray-100"
                    >
                      <option value="ko">한국어</option>
                      <option value="en">English</option>
                    </select>
                  </SettingSection>

                  <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-lg p-4">
                    <h4 className="text-sm text-amber-800 dark:text-amber-400 mb-2">위험 구역</h4>
                    <button
                      onClick={handleReset}
                      className="px-4 py-2 bg-white dark:bg-[#2d2d30] border border-amber-300 dark:border-amber-700 text-amber-700 dark:text-amber-400 rounded-lg text-sm hover:bg-amber-50 dark:hover:bg-amber-900/30 transition-colors"
                    >
                      모든 설정 초기화
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Footer */}
          <div className="flex items-center justify-end gap-3 p-6 border-t border-gray-200 dark:border-gray-700">
            <button
              onClick={onClose}
              className="px-4 py-2 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-[#2d2d30] rounded-lg transition-colors"
            >
              취소
            </button>
            <motion.button
              onClick={handleSave}
              className="px-4 py-2 bg-blue-700 dark:bg-blue-800 text-white rounded-lg transition-colors"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              저장
            </motion.button>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}

function SettingSection({ title, icon, children }: { title: string; icon: React.ReactNode; children: React.ReactNode }) {
  return (
    <div>
      <div className="flex items-center gap-2 mb-3">
        <span className="text-gray-600 dark:text-gray-400">{icon}</span>
        <h3 className="text-sm text-gray-900 dark:text-gray-100">{title}</h3>
      </div>
      {children}
    </div>
  );
}

function ToggleSetting({ label, description, checked, onChange }: { 
  label: string; 
  description: string; 
  checked: boolean; 
  onChange: (checked: boolean) => void;
}) {
  return (
    <div className="flex items-center justify-between p-3 rounded-lg hover:bg-gray-50 dark:hover:bg-[#2d2d30] transition-colors">
      <div>
        <div className="text-sm text-gray-900 dark:text-gray-100">{label}</div>
        <div className="text-xs text-gray-500 dark:text-gray-400">{description}</div>
      </div>
      <button
        onClick={() => onChange(!checked)}
        className={`relative w-11 h-6 rounded-full transition-colors ${
          checked ? 'bg-blue-600' : 'bg-gray-300 dark:bg-gray-600'
        }`}
      >
        <motion.div
          className="absolute top-1 w-4 h-4 bg-white rounded-full"
          animate={{ left: checked ? '22px' : '4px' }}
          transition={{ type: "spring", stiffness: 500, damping: 30 }}
        />
      </button>
    </div>
  );
}
