import React, { useState, useRef, useEffect } from 'react';
import { Bot, Send, X, Minimize2, Copy, Sparkles } from 'lucide-react';
import { motion } from 'framer-motion';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  query?: string;
  timestamp: Date;
}

interface FloatingAIChatBotProps {
  onQueryInsert: (query: string) => void;
}

export function FloatingAIChatBot({ onQueryInsert }: FloatingAIChatBotProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'assistant',
      content: '안녕하세요! SQL 쿼리 작성을 도와드리겠습니다. 무엇을 도와드릴까요?',
      timestamp: new Date()
    }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);

    // Simulate AI response
    setTimeout(() => {
      const aiResponse = generateAIResponse(input);
      setMessages(prev => [...prev, aiResponse]);
      setIsTyping(false);
    }, 1000 + Math.random() * 1000);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const copyQuery = (query: string) => {
    navigator.clipboard.writeText(query);
  };

  const insertQuery = (query: string) => {
    onQueryInsert(query);
    setIsOpen(false);
  };

  return (
    <>
      {/* Floating Button */}
      {!isOpen && (
        <motion.button
          onClick={() => setIsOpen(true)}
          className="fixed bottom-6 right-6 w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full shadow-2xl hover:scale-110 transition-transform flex items-center justify-center group z-50"
          animate={{
            y: [0, -10, 0],
            scale: [1, 1.05, 1]
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        >
          <motion.div
            animate={{
              rotate: [0, 10, -10, 0]
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          >
            <Bot className="w-8 h-8 text-white" />
          </motion.div>
          
          {/* Tooltip */}
          <div className="absolute bottom-full right-0 mb-2 px-3 py-2 bg-gray-900 text-white text-sm rounded-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">
            SQL 도우미
            <div className="absolute top-full right-4 w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-gray-900"></div>
          </div>
        </motion.button>
      )}

      {/* Chat Window */}
      {isOpen && (
        <div className="fixed bottom-6 right-6 w-[420px] h-[600px] bg-white rounded-2xl shadow-2xl flex flex-col z-50 border border-gray-200">
          {/* Header */}
          <div className="px-4 py-3 bg-gradient-to-r from-blue-500 to-purple-500 rounded-t-2xl flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center">
                <Bot className="w-5 h-5 text-white" />
              </div>
              <div>
                <div className="text-white">SQL 도우미</div>
                <div className="text-xs text-blue-50">온라인</div>
              </div>
            </div>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setIsOpen(false)}
                className="p-1.5 hover:bg-white/20 rounded transition-colors"
              >
                <Minimize2 className="w-4 h-4 text-white" />
              </button>
              <button
                onClick={() => setIsOpen(false)}
                className="p-1.5 hover:bg-white/20 rounded transition-colors"
              >
                <X className="w-4 h-4 text-white" />
              </button>
            </div>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex gap-3 ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                {message.role === 'assistant' && (
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center flex-shrink-0">
                    <Bot className="w-5 h-5 text-white" />
                  </div>
                )}
                <div
                  className={`max-w-[80%] rounded-lg p-3 ${
                    message.role === 'user'
                      ? 'bg-blue-600 text-white'
                      : 'bg-white text-gray-800 border border-gray-200 shadow-sm'
                  }`}
                >
                  <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                  
                  {message.query && (
                    <div className="mt-3 pt-3 border-t border-gray-200">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs text-gray-600">생성된 SQL:</span>
                        <div className="flex gap-1">
                          <button
                            onClick={() => copyQuery(message.query!)}
                            className="p-1 hover:bg-gray-100 rounded transition-colors"
                            title="복사"
                          >
                            <Copy className="w-3 h-3 text-gray-600" />
                          </button>
                          <button
                            onClick={() => insertQuery(message.query!)}
                            className="px-2 py-1 bg-blue-600 text-white text-xs rounded hover:bg-blue-700 transition-colors"
                          >
                            삽입
                          </button>
                        </div>
                      </div>
                      <pre className="text-xs bg-gray-900 text-green-400 p-2 rounded overflow-x-auto">
                        {message.query}
                      </pre>
                    </div>
                  )}
                </div>
                {message.role === 'user' && (
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center flex-shrink-0 text-white text-xs">
                    나
                  </div>
                )}
              </div>
            ))}
            
            {isTyping && (
              <div className="flex gap-3">
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
                  <Bot className="w-5 h-5 text-white" />
                </div>
                <div className="bg-white border border-gray-200 shadow-sm rounded-lg p-3">
                  <div className="flex gap-1">
                    <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                    <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                    <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Quick Actions */}
          <div className="px-4 pb-2 bg-white border-t border-gray-200">
            <div className="flex items-center gap-2 mb-2">
              <Sparkles className="w-4 h-4 text-purple-500" />
              <span className="text-xs text-gray-600">빠른 질문:</span>
            </div>
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => setInput('활성 사용자 목록 보여줘')}
                className="px-3 py-1 bg-blue-50 text-blue-700 text-xs rounded-full border border-blue-200 hover:bg-blue-100 transition-colors"
              >
                활성 사용자 조회
              </button>
              <button
                onClick={() => setInput('재고가 적은 상품 찾아줘')}
                className="px-3 py-1 bg-blue-50 text-blue-700 text-xs rounded-full border border-blue-200 hover:bg-blue-100 transition-colors"
              >
                재고 부족 상품
              </button>
              <button
                onClick={() => setInput('카테고리별 매출 집계')}
                className="px-3 py-1 bg-blue-50 text-blue-700 text-xs rounded-full border border-blue-200 hover:bg-blue-100 transition-colors"
              >
                매출 분석
              </button>
            </div>
          </div>

          {/* Input */}
          <div className="p-4 border-t border-gray-200 bg-white">
            <div className="flex gap-2">
              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="SQL이나 데이터베이스에 대해 물어보세요..."
                className="flex-1 px-3 py-2 bg-white text-gray-800 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none placeholder-gray-400"
                rows={2}
              />
              <button
                onClick={handleSend}
                disabled={!input.trim()}
                className="px-4 bg-gradient-to-r from-blue-500 to-purple-500 text-white rounded-lg hover:from-blue-600 hover:to-purple-600 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Send className="w-5 h-5" />
              </button>
            </div>
            <p className="text-xs text-gray-500 mt-2">Enter로 전송, Shift+Enter로 줄바꿈</p>
          </div>
        </div>
      )}
    </>
  );
}

function generateAIResponse(userInput: string): Message {
  const input = userInput.toLowerCase();
  
  if (input.includes('활성') && input.includes('사용자')) {
    return {
      id: Date.now().toString(),
      role: 'assistant',
      content: '활성 사용자를 조회하는 쿼리를 생성했습니다. 이번 달에 가입한 활성 사용자를 최근 가입일 순으로 정렬합니다.',
      query: "SELECT id, username, email, created_at, status\nFROM users\nWHERE status = 'active'\n  AND created_at >= DATE_TRUNC('month', CURRENT_DATE)\nORDER BY created_at DESC;",
      timestamp: new Date()
    };
  }
  
  if (input.includes('재고') || input.includes('상품')) {
    return {
      id: Date.now().toString(),
      role: 'assistant',
      content: '재고가 부족한 상품을 조회하는 쿼리입니다. 재고가 10개 미만인 상품을 재고 순으로 정렬합니다.',
      query: "SELECT id, name, category, price, stock\nFROM products\nWHERE stock < 10\nORDER BY stock ASC, name ASC;",
      timestamp: new Date()
    };
  }
  
  if (input.includes('매출') || input.includes('카테고리')) {
    return {
      id: Date.now().toString(),
      role: 'assistant',
      content: '카테고리별 매출을 집계하는 쿼리를 만들었습니다. 주문 수, 총 매출, 평균 주문 금액을 계산합니다.',
      query: "SELECT p.category,\n       COUNT(DISTINCT o.id) as 주문수,\n       SUM(o.quantity * p.price) as 총매출,\n       AVG(o.quantity * p.price) as 평균주문금액\nFROM orders o\nJOIN products p ON o.product_id = p.id\nWHERE o.status = 'completed'\nGROUP BY p.category\nORDER BY 총매출 DESC;",
      timestamp: new Date()
    };
  }
  
  if (input.includes('조인') || input.includes('join')) {
    return {
      id: Date.now().toString(),
      role: 'assistant',
      content: '사용자와 주문을 조인하는 쿼리 예시입니다. 고객별 구매 이력을 확인할 수 있습니다.',
      query: "SELECT u.username, u.email,\n       COUNT(o.id) as 총주문수,\n       SUM(o.total) as 총구매액\nFROM users u\nLEFT JOIN orders o ON u.id = o.user_id\nGROUP BY u.id, u.username, u.email\nORDER BY 총구매액 DESC;",
      timestamp: new Date()
    };
  }
  
  if (input.includes('최적화') || input.includes('성능')) {
    return {
      id: Date.now().toString(),
      role: 'assistant',
      content: '쿼리 최적화를 위한 팁:\n\n1. 인덱스를 자주 조회하는 컬럼에 추가\n2. SELECT *보다 필요한 컬럼만 명시\n3. WHERE 절로 결과 제한\n4. EXPLAIN으로 실행 계획 분석\n5. JOIN보다 서브쿼리 피하기\n\n특정 쿼리를 최적화하고 싶으신가요?',
      timestamp: new Date()
    };
  }
  
  return {
    id: Date.now().toString(),
    role: 'assistant',
    content: '다음과 같은 도움을 드릴 수 있습니다:\n\n• SQL 쿼리 작성 (SELECT, INSERT, UPDATE, DELETE)\n• 테이블 조인 및 복잡한 쿼리\n• 쿼리 최적화 및 성능 개선\n• SQL 개념 설명\n• 데이터베이스 설계 제안\n\n무엇을 도와드릴까요?',
    timestamp: new Date()
  };
}