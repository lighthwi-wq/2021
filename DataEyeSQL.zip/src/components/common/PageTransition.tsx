import React, { ReactNode } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { pageVariants } from '../../lib/animations/variants';

interface PageTransitionProps {
  children: ReactNode;
  viewKey: string;
}

export const PageTransition = React.memo(function PageTransition({
  children,
  viewKey,
}: PageTransitionProps) {
  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={viewKey}
        variants={pageVariants}
        initial="initial"
        animate="animate"
        exit="exit"
        className="flex-1 overflow-hidden"
      >
        {children}
      </motion.div>
    </AnimatePresence>
  );
});
