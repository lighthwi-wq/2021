import { Query, SearchResult } from '../types';

export const MOCK_QUERY_HISTORY: Query[] = [
  {
    id: 'query-1',
    title: '사용자 목록 조회',
    sql: 'SELECT * FROM users WHERE created_at > NOW() - INTERVAL \'7 days\'',
    timestamp: new Date(Date.now() - 2 * 60 * 1000),
    duration: '0.45s',
    rows: 247,
    status: 'success',
    connectionId: 'conn-1'
  },
  {
    id: 'query-2',
    title: '주문 통계',
    sql: 'SELECT COUNT(*) as total, status FROM orders GROUP BY status',
    timestamp: new Date(Date.now() - 15 * 60 * 1000),
    duration: '0.23s',
    rows: 5,
    status: 'success',
    connectionId: 'conn-1'
  },
  {
    id: 'query-3',
    title: '제품 업데이트',
    sql: 'UPDATE products SET price = price * 1.1 WHERE category = \'electronics\'',
    timestamp: new Date(Date.now() - 60 * 60 * 1000),
    duration: '1.2s',
    rows: 145,
    status: 'success',
    connectionId: 'conn-1'
  }
];

export const MOCK_SAVED_QUERIES: Query[] = [
  {
    id: 'saved-1',
    title: '월별 매출 분석',
    sql: 'SELECT DATE_TRUNC(\'month\', created_at) as month, SUM(amount) as revenue FROM orders GROUP BY month ORDER BY month DESC',
    timestamp: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
    status: 'success',
    connectionId: 'conn-1'
  },
  {
    id: 'saved-2',
    title: '활성 사용자 목록',
    sql: 'SELECT * FROM users WHERE last_login > NOW() - INTERVAL \'30 days\' ORDER BY last_login DESC',
    timestamp: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
    status: 'success',
    connectionId: 'conn-1'
  }
];

export const MOCK_NOTIFICATIONS = [
  {
    id: 'notif-1',
    type: 'success' as const,
    title: '쿼리 실행 완료',
    message: '사용자 목록 조회가 성공적으로 완료되었습니다. (247개 행)',
    timestamp: new Date(Date.now() - 5 * 60 * 1000),
    read: false
  },
  {
    id: 'notif-2',
    type: 'warning' as const,
    title: '느린 쿼리 감지',
    message: '최근 실행된 쿼리가 3초 이상 소요되었습니다. 인덱스 최적화를 고려해보세요.',
    timestamp: new Date(Date.now() - 15 * 60 * 1000),
    read: false
  },
  {
    id: 'notif-3',
    type: 'error' as const,
    title: '연결 오류',
    message: 'MongoDB 스테이징 서버에 연결할 수 없습니다. 네트워크 상태를 확인해주세요.',
    timestamp: new Date(Date.now() - 30 * 60 * 1000),
    read: false
  },
  {
    id: 'notif-4',
    type: 'info' as const,
    title: '시스템 업데이트',
    message: '새로운 버전(v2.1.0)이 출시되었습니다. 업데이트하시겠습니까?',
    timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
    read: true,
    actionLabel: '업데이트',
    actionUrl: '#'
  },
  {
    id: 'notif-5',
    type: 'success' as const,
    title: '백업 완료',
    message: 'PostgreSQL 프로덕션 데이터베이스의 자동 백업이 완료되었습니다.',
    timestamp: new Date(Date.now() - 3 * 60 * 60 * 1000),
    read: true
  }
];

export const MOCK_SEARCH_DATA: SearchResult[] = [
  // 데이터베이스
  { type: 'database', title: 'PostgreSQL 프로덕션', subtitle: 'localhost:5432' },
  { type: 'database', title: 'MySQL 개발', subtitle: 'localhost:3306' },
  { type: 'database', title: 'MongoDB 스테이징', subtitle: 'localhost:27017' },
  
  // 스키마
  { type: 'schema', title: 'public', subtitle: 'PostgreSQL 프로덕션', path: 'PostgreSQL 프로덕션 > public' },
  { type: 'schema', title: 'analytics', subtitle: 'PostgreSQL 프로덕션', path: 'PostgreSQL 프로덕션 > analytics' },
  { type: 'schema', title: 'main', subtitle: 'MySQL 개발', path: 'MySQL 개발 > main' },
  { type: 'schema', title: 'app', subtitle: 'MongoDB 스테이징', path: 'MongoDB 스테이징 > app' },
  
  // 테이블
  { type: 'table', title: 'users', subtitle: 'public 스키마', path: 'PostgreSQL 프로덕션 > public > users' },
  { type: 'table', title: 'products', subtitle: 'public 스키마', path: 'PostgreSQL 프로덕션 > public > products' },
  { type: 'table', title: 'orders', subtitle: 'public 스키마', path: 'PostgreSQL 프로덕션 > public > orders' },
  { type: 'table', title: 'categories', subtitle: 'public 스키마', path: 'PostgreSQL 프로덕션 > public > categories' },
  { type: 'table', title: 'payments', subtitle: 'public 스키마', path: 'PostgreSQL 프로덕션 > public > payments' },
  { type: 'table', title: 'events', subtitle: 'analytics 스키마', path: 'PostgreSQL 프로덕션 > analytics > events' },
  { type: 'table', title: 'sessions', subtitle: 'analytics 스키마', path: 'PostgreSQL 프로덕션 > analytics > sessions' },
  { type: 'table', title: 'conversions', subtitle: 'analytics 스키마', path: 'PostgreSQL 프로덕션 > analytics > conversions' },
  { type: 'table', title: 'customers', subtitle: 'main 스키마', path: 'MySQL 개발 > main > customers' },
  { type: 'table', title: 'inventory', subtitle: 'main 스키마', path: 'MySQL 개발 > main > inventory' },
  { type: 'table', title: 'suppliers', subtitle: 'main 스키마', path: 'MySQL 개발 > main > suppliers' },
  { type: 'table', title: 'logs', subtitle: 'app 스키마', path: 'MongoDB 스테이징 > app > logs' },
  { type: 'table', title: 'metrics', subtitle: 'app 스키마', path: 'MongoDB 스테이징 > app > metrics' },
  { type: 'table', title: 'cache', subtitle: 'app 스키마', path: 'MongoDB 스테이징 > app > cache' },
  
  // 저장된 쿼리
  ...MOCK_SAVED_QUERIES.map(q => ({
    type: 'query' as const,
    title: q.title,
    subtitle: q.sql.substring(0, 50) + '...',
    path: '저장된 쿼리'
  }))
];