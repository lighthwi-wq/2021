import React, { createContext, useContext, useState, useCallback, ReactNode, useEffect } from 'react';
import { ViewType } from '../types';

interface AppContextType {
  // View state
  currentView: ViewType;
  setCurrentView: (view: ViewType) => void;
  
  // Table selection
  selectedTable: string | null;
  selectTable: (tableName: string) => void;
  
  // Query operations
  externalQuery: string;
  insertQuery: (query: string) => void;
  
  // Modal states
  isHelpModalOpen: boolean;
  openHelpModal: () => void;
  closeHelpModal: () => void;
  
  isLogoutDialogOpen: boolean;
  openLogoutDialog: () => void;
  closeLogoutDialog: () => void;
  confirmLogout: () => void;
  
  // Sidebar state (for mobile)
  isSidebarOpen: boolean;
  toggleSidebar: () => void;
  closeSidebar: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  // 초기값: 데스크톱(lg 이상)이면 true, 모바일이면 false
  const [isSidebarOpen, setIsSidebarOpen] = useState(() => {
    if (typeof window !== 'undefined') {
      return window.innerWidth >= 1024; // lg breakpoint
    }
    return true; // SSR 대비
  });
  
  const [currentView, setCurrentView] = useState<ViewType>('home');
  const [selectedTable, setSelectedTable] = useState<string | null>(null);
  const [externalQuery, setExternalQuery] = useState<string>('');
  const [isHelpModalOpen, setIsHelpModalOpen] = useState(false);
  const [isLogoutDialogOpen, setIsLogoutDialogOpen] = useState(false);

  // 화면 크기 변경 감지
  useEffect(() => {
    const handleResize = () => {
      const isDesktop = window.innerWidth >= 1024;
      if (isDesktop) {
        setIsSidebarOpen(true);
      } else {
        setIsSidebarOpen(false);
      }
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const selectTable = useCallback((tableName: string) => {
    setSelectedTable(tableName);
  }, []);

  const insertQuery = useCallback((query: string) => {
    setExternalQuery(query);
    setCurrentView('editor');
    setTimeout(() => setExternalQuery(''), 100);
  }, []);

  const openHelpModal = useCallback(() => setIsHelpModalOpen(true), []);
  const closeHelpModal = useCallback(() => setIsHelpModalOpen(false), []);
  
  const openLogoutDialog = useCallback(() => setIsLogoutDialogOpen(true), []);
  const closeLogoutDialog = useCallback(() => setIsLogoutDialogOpen(false), []);
  
  const confirmLogout = useCallback(() => {
    console.log('로그아웃 처리');
    setIsLogoutDialogOpen(false);
    // 여기에 실제 로그아웃 로직 추가
  }, []);

  const toggleSidebar = useCallback(() => setIsSidebarOpen(!isSidebarOpen), [isSidebarOpen]);
  const closeSidebar = useCallback(() => setIsSidebarOpen(false), []);

  const value: AppContextType = {
    currentView,
    setCurrentView,
    selectedTable,
    selectTable,
    externalQuery,
    insertQuery,
    isHelpModalOpen,
    openHelpModal,
    closeHelpModal,
    isLogoutDialogOpen,
    openLogoutDialog,
    closeLogoutDialog,
    confirmLogout,
    isSidebarOpen,
    toggleSidebar,
    closeSidebar,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}