/**
 * Format date to Korean locale string
 */
export function formatDate(date: Date): string {
  const now = new Date();
  const diff = now.getTime() - date.getTime();
  const minutes = Math.floor(diff / 60000);
  const hours = Math.floor(diff / 3600000);
  const days = Math.floor(diff / 86400000);

  if (minutes < 1) return '방금 전';
  if (minutes < 60) return `${minutes}분 전`;
  if (hours < 24) return `${hours}시간 전`;
  if (days < 7) return `${days}일 전`;

  return date.toLocaleDateString('ko-KR', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });
}

/**
 * Format duration in milliseconds to human readable string
 */
export function formatDuration(ms: number): string {
  if (ms < 1000) return `${ms}ms`;
  return `${(ms / 1000).toFixed(2)}s`;
}

/**
 * Format large numbers with commas
 */
export function formatNumber(num: number): string {
  return num.toLocaleString('ko-KR');
}

/**
 * Truncate string to specified length
 */
export function truncate(str: string, length: number): string {
  if (str.length <= length) return str;
  return str.substring(0, length) + '...';
}

/**
 * Generate unique ID
 */
export function generateId(prefix: string = 'id'): string {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}

/**
 * Debounce function
 */
export function debounce<T extends (...args: any[]) => any>(
  func: T,
  wait: number
): (...args: Parameters<T>) => void {
  let timeout: NodeJS.Timeout;
  return (...args: Parameters<T>) => {
    clearTimeout(timeout);
    timeout = setTimeout(() => func(...args), wait);
  };
}

/**
 * Get database icon color
 */
export function getDbIconColor(type: string): string {
  switch (type.toLowerCase()) {
    case 'postgresql':
      return 'text-blue-600 dark:text-blue-500';
    case 'mysql':
      return 'text-orange-600 dark:text-orange-500';
    case 'mongodb':
      return 'text-green-600 dark:text-green-500';
    default:
      return 'text-gray-600 dark:text-gray-400';
  }
}

/**
 * Validate SQL query
 */
export function validateSql(sql: string): { valid: boolean; error?: string } {
  if (!sql.trim()) {
    return { valid: false, error: '쿼리가 비어있습니다' };
  }

  const dangerousKeywords = ['DROP', 'TRUNCATE', 'DELETE FROM'];
  const upperSql = sql.toUpperCase();
  
  for (const keyword of dangerousKeywords) {
    if (upperSql.includes(keyword)) {
      return { valid: true, error: `주의: ${keyword} 명령어가 포함되어 있습니다` };
    }
  }

  return { valid: true };
}
