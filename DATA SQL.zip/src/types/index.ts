// Database Connection Types
export interface Connection {
  id: string;
  name: string;
  type: 'PostgreSQL' | 'MySQL' | 'MongoDB';
  host: string;
  port: number;
  database: string;
  username: string;
  password?: string;
  status: 'connected' | 'disconnected' | 'error';
}

export interface Schema {
  name: string;
  tables: string[];
}

// Query Types
export interface Query {
  id: string;
  title: string;
  sql: string;
  timestamp: Date;
  duration?: string;
  rows?: number;
  status: 'success' | 'error';
  connectionId?: string;
}

export interface QueryTab {
  id: string;
  title: string;
  content: string;
  isActive: boolean;
}

// Search Types
export interface SearchResult {
  type: 'table' | 'database' | 'schema' | 'query';
  title: string;
  subtitle?: string;
  path?: string;
}

// Settings Types
export interface Settings {
  theme: 'light' | 'dark' | 'auto';
  fontSize: number;
  editorTheme: 'vs-dark' | 'vs-light';
  autoComplete: boolean;
  syntaxHighlight: boolean;
  lineNumbers: boolean;
  minimap: boolean;
  wordWrap: boolean;
  tabSize: number;
  queryTimeout: number;
  maxRows: number;
  dateFormat: string;
  language: 'ko' | 'en';
}

// Context Menu Types
export interface ContextMenuItem {
  label: string;
  icon?: React.ReactNode;
  onClick: () => void;
  danger?: boolean;
  separator?: boolean;
}

// Notification Types
export type NotificationType = 'info' | 'success' | 'warning' | 'error';

export interface Notification {
  id: string;
  type: NotificationType;
  title: string;
  message: string;
  timestamp: Date;
  read: boolean;
  actionLabel?: string;
  actionUrl?: string;
}

// View Types
export type ViewType = 'home' | 'editor' | 'history' | 'saved';