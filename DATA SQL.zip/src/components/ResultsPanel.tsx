import React, { useState } from 'react';
import { Download, Filter, RefreshCw, Table2, Grid3x3 } from 'lucide-react';

interface ResultsPanelProps {
  results: any[];
  executedQuery: string;
}

export function ResultsPanel({ results, executedQuery }: ResultsPanelProps) {
  const [viewMode, setViewMode] = useState<'table' | 'grid'>('table');
  const [activeTab, setActiveTab] = useState<'data' | 'messages' | 'history'>('data');

  if (results.length === 0) {
    return (
      <div className="flex-1 bg-white dark:bg-[#1e1e1e] overflow-auto">
        {/* Tabs */}
        <div className="flex items-center gap-4 px-4 py-2 border-b border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#252526]">
          <button
            onClick={() => setActiveTab('data')}
            className={`px-3 py-2 text-sm rounded transition-colors ${
              activeTab === 'data' ? 'bg-white dark:bg-[#1e1e1e] text-blue-600 dark:text-blue-400' : 'text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-300'
            }`}
          >
            데이터
          </button>
          <button
            onClick={() => setActiveTab('messages')}
            className={`px-3 py-2 text-sm rounded transition-colors ${
              activeTab === 'messages' ? 'bg-white dark:bg-[#1e1e1e] text-blue-600 dark:text-blue-400' : 'text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-300'
            }`}
          >
            메시지
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`px-3 py-2 text-sm rounded transition-colors ${
              activeTab === 'history' ? 'bg-white dark:bg-[#1e1e1e] text-blue-600 dark:text-blue-400' : 'text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-300'
            }`}
          >
            실행 기록
          </button>
        </div>

        <div className="flex flex-col items-center justify-center h-full text-gray-400 dark:text-gray-500 p-8">
          <Table2 className="w-16 h-16 mb-4" />
          <p className="text-lg">표시할 결과가 없습니다</p>
          <p className="text-sm mt-2">쿼리를 실행하면 여기에 결과가 표시됩니다</p>
        </div>
      </div>
    );
  }

  const columns = Object.keys(results[0]);

  return (
    <div className="flex-1 flex flex-col bg-white dark:bg-[#1e1e1e] overflow-hidden">
      {/* Tabs */}
      <div className="flex items-center gap-4 px-4 py-2 border-b border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#252526]">
        <button
          onClick={() => setActiveTab('data')}
          className={`px-3 py-2 text-sm rounded transition-colors ${
            activeTab === 'data' ? 'bg-white dark:bg-[#1e1e1e] text-blue-600 dark:text-blue-400 border-b-2 border-blue-600 dark:border-blue-400' : 'text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-300'
          }`}
        >
          데이터
        </button>
        <button
          onClick={() => setActiveTab('messages')}
          className={`px-3 py-2 text-sm rounded transition-colors ${
            activeTab === 'messages' ? 'bg-white dark:bg-[#1e1e1e] text-blue-600 dark:text-blue-400 border-b-2 border-blue-600 dark:border-blue-400' : 'text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-300'
          }`}
        >
          메시지
        </button>
        <button
          onClick={() => setActiveTab('history')}
          className={`px-3 py-2 text-sm rounded transition-colors ${
            activeTab === 'history' ? 'bg-white dark:bg-[#1e1e1e] text-blue-600 dark:text-blue-400 border-b-2 border-blue-600 dark:border-blue-400' : 'text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-300'
          }`}
        >
          실행 기록
        </button>
      </div>

      {activeTab === 'data' && (
        <>
          <div className="flex items-center justify-between px-4 py-3 border-b border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#252526]">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <span className="text-sm text-gray-700 dark:text-gray-300">
                  {results.length}개 행
                </span>
                <span className="text-gray-400 dark:text-gray-600">•</span>
                <span className="text-sm text-gray-500">실행 시간: 0.123초</span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <div className="flex items-center border border-gray-300 dark:border-gray-700 rounded-lg overflow-hidden">
                <button
                  onClick={() => setViewMode('table')}
                  className={`p-2 ${
                    viewMode === 'table' ? 'bg-blue-600 text-white' : 'bg-white dark:bg-[#2d2d30] text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-[#3e3e42]'
                  } transition-colors`}
                >
                  <Table2 className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setViewMode('grid')}
                  className={`p-2 ${
                    viewMode === 'grid' ? 'bg-blue-600 text-white' : 'bg-white dark:bg-[#2d2d30] text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-[#3e3e42]'
                  } transition-colors`}
                >
                  <Grid3x3 className="w-4 h-4" />
                </button>
              </div>

              <button className="flex items-center gap-2 px-3 py-2 bg-white dark:bg-[#2d2d30] border border-gray-300 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-[#3e3e42] transition-colors text-gray-700 dark:text-gray-300">
                <Filter className="w-4 h-4" />
                <span className="text-sm">필터</span>
              </button>
              <button className="flex items-center gap-2 px-3 py-2 bg-white dark:bg-[#2d2d30] border border-gray-300 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-[#3e3e42] transition-colors text-gray-700 dark:text-gray-300">
                <Download className="w-4 h-4" />
                <span className="text-sm">내보내기</span>
              </button>
              <button className="p-2 bg-white dark:bg-[#2d2d30] border border-gray-300 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-[#3e3e42] transition-colors">
                <RefreshCw className="w-4 h-4 text-gray-600 dark:text-gray-400" />
              </button>
            </div>
          </div>

          <div className="flex-1 overflow-auto">
            {viewMode === 'table' ? (
              <table className="w-full">
                <thead className="bg-gray-100 dark:bg-[#252526] sticky top-0">
                  <tr>
                    {columns.map((column) => (
                      <th
                        key={column}
                        className="px-4 py-3 text-left text-xs uppercase tracking-wider text-gray-700 dark:text-gray-400 border-b border-gray-300 dark:border-gray-700"
                      >
                        {column}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {results.map((row, rowIndex) => (
                    <tr
                      key={rowIndex}
                      className="hover:bg-gray-50 dark:hover:bg-[#2d2d30] transition-colors border-b border-gray-200 dark:border-gray-800"
                    >
                      {columns.map((column) => (
                        <td
                          key={column}
                          className="px-4 py-3 text-sm text-gray-900 dark:text-gray-300 whitespace-nowrap"
                        >
                          {formatValue(row[column])}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            ) : (
              <div className="p-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {results.map((row, rowIndex) => (
                  <div
                    key={rowIndex}
                    className="p-4 bg-white dark:bg-[#252526] border border-gray-300 dark:border-gray-700 rounded-lg hover:border-blue-600 dark:hover:border-blue-600 transition-all"
                  >
                    {columns.map((column) => (
                      <div key={column} className="mb-2 last:mb-0">
                        <div className="text-xs text-gray-500 uppercase tracking-wider">
                          {column}
                        </div>
                        <div className="text-sm text-gray-900 dark:text-gray-300 mt-1">
                          {formatValue(row[column])}
                        </div>
                      </div>
                    ))}
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="px-4 py-2 border-t border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#252526]">
            <div className="text-xs text-gray-500 font-mono">
              {executedQuery}
            </div>
          </div>
        </>
      )}

      {activeTab === 'messages' && (
        <div className="flex-1 p-4">
          <div className="text-sm text-green-600 dark:text-green-400">✓ 쿼리가 성공적으로 실행되었습니다.</div>
          <div className="text-sm text-gray-500 mt-2">{results.length}개의 행이 반환되었습니다.</div>
        </div>
      )}

      {activeTab === 'history' && (
        <div className="flex-1 p-4">
          <div className="text-sm text-gray-600 dark:text-gray-400">최근 실행한 쿼리가 여기에 표시됩니다.</div>
        </div>
      )}
    </div>
  );
}

function formatValue(value: any): string {
  if (value === null) return 'NULL';
  if (value === undefined) return '-';
  if (typeof value === 'boolean') return value.toString().toUpperCase();
  if (typeof value === 'object') return JSON.stringify(value);
  return String(value);
}