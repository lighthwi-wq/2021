import React from 'react';
import { motion } from 'motion/react';
import { LucideIcon } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, ResponsiveContainer } from 'recharts';

interface StatCardProps {
  icon: React.ReactNode;
  label: string;
  value: string;
  color: string;
  change: string;
  index: number;
}

const colorVariants = {
  blue: {
    bg: 'bg-blue-50',
    text: 'text-blue-600',
    border: 'border-blue-200',
    gradient: '#3b82f6',
  },
  green: {
    bg: 'bg-green-50',
    text: 'text-green-600',
    border: 'border-green-200',
    gradient: '#10b981',
  },
  yellow: {
    bg: 'bg-yellow-50',
    text: 'text-yellow-600',
    border: 'border-yellow-200',
    gradient: '#f59e0b',
  },
  purple: {
    bg: 'bg-purple-50',
    text: 'text-purple-600',
    border: 'border-purple-200',
    gradient: '#8b5cf6',
  },
  red: {
    bg: 'bg-red-50',
    text: 'text-red-600',
    border: 'border-red-200',
    gradient: '#ef4444',
  },
  indigo: {
    bg: 'bg-indigo-50',
    text: 'text-indigo-600',
    border: 'border-indigo-200',
    gradient: '#6366f1',
  },
};

export const StatCard = React.memo(function StatCard({
  icon,
  label,
  value,
  color,
  change,
  index,
}: StatCardProps) {
  const variant = colorVariants[color as keyof typeof colorVariants] || colorVariants.blue;
  
  const miniChartData = Array.from({ length: 7 }, (_, i) => ({
    value: 100 + Math.sin(i * 1.2) * 60 + Math.random() * 50,
  }));

  const isPositiveChange = change.startsWith('+');
  const isNegativeGood = color === 'yellow' || color === 'red';

  return (
    <motion.div
      initial={{ opacity: 0, y: 20, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{
        duration: 0.4,
        delay: index * 0.05,
        ease: [0.25, 0.46, 0.45, 0.94],
      }}
      whileHover={{
        y: -4,
        boxShadow: '0 12px 24px rgba(0,0,0,0.1)',
        transition: { duration: 0.2 },
      }}
      className={`bg-white rounded-xl p-5 border-2 ${variant.border} cursor-pointer overflow-hidden relative group`}
    >
      {/* Gradient Overlay on Hover */}
      <motion.div
        className={`absolute inset-0 ${variant.bg} opacity-0 group-hover:opacity-10 transition-opacity duration-300`}
      />

      <div className="relative z-10">
        <div className="flex items-center justify-between mb-3">
          <motion.div
            className={`inline-flex p-2.5 rounded-lg ${variant.bg}`}
            whileHover={{ scale: 1.1, rotate: 5 }}
            transition={{ type: 'spring', stiffness: 300 }}
          >
            <div className={variant.text}>{icon}</div>
          </motion.div>

          <motion.span
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: index * 0.05 + 0.2, type: 'spring', stiffness: 200 }}
            className={`text-xs px-2 py-1 rounded-full ${
              (isPositiveChange && !isNegativeGood) || (!isPositiveChange && isNegativeGood)
                ? 'bg-green-100 text-green-700'
                : 'bg-gray-100 text-gray-600'
            }`}
          >
            {change}
          </motion.span>
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: index * 0.05 + 0.1 }}
          className="text-2xl text-gray-900 mb-1 text-[24px] font-bold"
        >
          {value}
        </motion.div>

        <div className="text-sm text-gray-600 mb-3 text-[14px] font-bold">{label}</div>

        {/* Mini Chart */}
        <div className="h-20 flex justify-end -mr-3 -mb-2">
          <div className="w-[50%]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={miniChartData} margin={{ top: 5, right: 5, left: 0, bottom: 5 }}>
                <defs>
                  <linearGradient id={`miniGradient${index}`} x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor={variant.gradient} stopOpacity={0.3} />
                    <stop offset="95%" stopColor={variant.gradient} stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#d1d5db" opacity={0.3} />
                <XAxis
                  stroke="#9ca3af"
                  style={{ fontSize: '7px' }}
                  tickLine={false}
                  axisLine={{ stroke: '#d1d5db', strokeWidth: 1 }}
                  tick={{ fill: '#9ca3af' }}
                />
                <YAxis
                  stroke="#9ca3af"
                  style={{ fontSize: '7px' }}
                  tickLine={false}
                  axisLine={{ stroke: '#d1d5db', strokeWidth: 1 }}
                  width={25}
                  tick={{ fill: '#9ca3af' }}
                />
                <Area
                  type="monotone"
                  dataKey="value"
                  stroke={variant.gradient}
                  fill={`url(#miniGradient${index})`}
                  strokeWidth={2}
                  dot={false}
                  isAnimationActive={true}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </motion.div>
  );
});
