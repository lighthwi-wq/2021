import React, { useMemo } from 'react';
import {
  Database,
  Activity,
  Clock,
  Star,
  TrendingUp,
  AlertTriangle,
  Users,
  Zap,
  BarChart3,
  PieChart,
} from 'lucide-react';
import { motion } from 'motion/react';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart as RePieChart,
  Pie,
  Cell,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import { StatCard } from './features/home/StatCard';
import { ChartCard } from './features/home/ChartCard';
import { staggerContainer, staggerItem } from '../lib/animations/variants';

export function HomeView() {
  // Stats data
  const stats = useMemo(
    () => [
      { icon: <Database className="w-5 h-5" />, label: '연결된 데이터베이스', value: '3', color: 'blue', change: '+1' },
      { icon: <Activity className="w-5 h-5" />, label: '오늘 실행한 쿼리', value: '247', color: 'green', change: '+12%' },
      { icon: <Clock className="w-5 h-5" />, label: '평균 실행 시간', value: '0.8s', color: 'yellow', change: '-15%' },
      { icon: <Star className="w-5 h-5" />, label: '저장된 쿼리', value: '12', color: 'purple', change: '+3' },
      { icon: <AlertTriangle className="w-5 h-5" />, label: '쿼리 에러율', value: '2.3%', color: 'red', change: '-0.5%' },
      { icon: <Users className="w-5 h-5" />, label: '활성 사용자', value: '8', color: 'indigo', change: '+2' },
    ],
    []
  );

  const queryPerformanceData = useMemo(
    () => [
      { time: '00:00', queries: 45, avgTime: 0.65, errors: 1 },
      { time: '04:00', queries: 23, avgTime: 0.52, errors: 0 },
      { time: '08:00', queries: 89, avgTime: 0.78, errors: 3 },
      { time: '12:00', queries: 156, avgTime: 0.92, errors: 5 },
      { time: '16:00', queries: 134, avgTime: 0.85, errors: 2 },
      { time: '20:00', queries: 78, avgTime: 0.71, errors: 1 },
    ],
    []
  );

  const databaseDistribution = useMemo(
    () => [
      { name: 'PostgreSQL', value: 145, color: '#3b82f6' },
      { name: 'MySQL', value: 78, color: '#10b981' },
      { name: 'MongoDB', value: 24, color: '#8b5cf6' },
    ],
    []
  );

  const queryTypeDistribution = useMemo(
    () => [
      { name: 'SELECT', value: 180, color: '#3b82f6' },
      { name: 'INSERT', value: 35, color: '#10b981' },
      { name: 'UPDATE', value: 22, color: '#f59e0b' },
      { name: 'DELETE', value: 10, color: '#ef4444' },
    ],
    []
  );

  const tableAccessFrequency = useMemo(
    () => [
      { table: 'users', reads: 145, writes: 23 },
      { table: 'products', reads: 98, writes: 15 },
      { table: 'orders', reads: 134, writes: 45 },
      { table: 'payments', reads: 67, writes: 28 },
      { table: 'sessions', reads: 201, writes: 89 },
    ],
    []
  );

  const dataQualityMetrics = useMemo(
    () => [
      { metric: '데이터 완정성', score: 98 },
      { metric: '중복 제거율', score: 95 },
      { metric: '스키마 일관성', score: 97 },
      { metric: '참조 무결성', score: 100 },
    ],
    []
  );

  const recentQueries = useMemo(
    () => [
      {
        query: "SELECT * FROM users WHERE created_at > NOW() - INTERVAL '7 days'",
        time: '2분 전',
        duration: '0.45s',
        type: 'success',
      },
      {
        query: 'SELECT COUNT(*) FROM orders GROUP BY status',
        time: '15분 전',
        duration: '0.23s',
        type: 'success',
      },
      {
        query: "UPDATE products SET price = price * 1.1 WHERE category = 'electronics'",
        time: '1시간 전',
        duration: '1.2s',
        type: 'success',
      },
    ],
    []
  );

  const CustomTooltip = React.memo(({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-white p-3 rounded-lg shadow-xl border border-gray-200"
        >
          <p className="text-sm text-gray-900 mb-1">{label}</p>
          {payload.map((entry: any, index: number) => (
            <p key={index} className="text-xs" style={{ color: entry.color }}>
              {entry.name}: {entry.value}
            </p>
          ))}
        </motion.div>
      );
    }
    return null;
  });

  return (
    <div className="flex-1 overflow-y-auto p-8 bg-gradient-to-br from-gray-50 to-gray-100">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        {/* Header */}
        <motion.div
          className="mb-8"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: [0.25, 0.46, 0.45, 0.94] }}
        >
          <h1 className="text-3xl mb-2 text-black font-bold">
            DataEye SQL 대시보드
          </h1>
          <p className="text-gray-600">데이터베이스 성능 모니터링 및 쿼리 인사이트</p>
        </motion.div>

        {/* Stats Cards */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8"
          variants={staggerContainer}
          initial="initial"
          animate="animate"
        >
          {stats.map((stat, index) => (
            <StatCard key={index} {...stat} index={index} />
          ))}
        </motion.div>

        {/* Charts Row 1 */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          {/* Query Performance Trend */}
          <ChartCard
            title="쿼리 실행 추이"
            icon={<TrendingUp className="w-5 h-5 text-blue-600" />}
            subtitle="오늘"
            delay={0.3}
          >
            <ResponsiveContainer width="100%" height={250}>
              <AreaChart data={queryPerformanceData}>
                <defs>
                  <linearGradient id="colorQueries" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#d1d5db" opacity={0.6} />
                <XAxis dataKey="time" stroke="#9ca3af" style={{ fontSize: '12px' }} />
                <YAxis stroke="#9ca3af" style={{ fontSize: '12px' }} />
                <Tooltip content={<CustomTooltip />} cursor={{ fill: '#fafafa', opacity: 0.15 }} />
                <Area type="monotone" dataKey="queries" stroke="#3b82f6" fill="url(#colorQueries)" strokeWidth={3} />
              </AreaChart>
            </ResponsiveContainer>
          </ChartCard>

          {/* Database Distribution */}
          <ChartCard
            title="데이터베이스별 쿼리 분포"
            icon={<PieChart className="w-5 h-5 text-purple-600" />}
            delay={0.35}
          >
            <ResponsiveContainer width="100%" height={250}>
              <RePieChart>
                <Pie
                  data={databaseDistribution}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={90}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {databaseDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
                <Legend verticalAlign="bottom" height={36} iconType="circle" wrapperStyle={{ fontSize: '12px' }} />
              </RePieChart>
            </ResponsiveContainer>
          </ChartCard>
        </div>

        {/* Charts Row 2 */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          {/* Table Access Frequency */}
          <ChartCard
            title="테이블 접근 빈도"
            icon={<BarChart3 className="w-5 h-5 text-green-600" />}
            subtitle="최근 24시간"
            delay={0.4}
          >
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={tableAccessFrequency} barCategoryGap="20%">
                <CartesianGrid strokeDasharray="3 3" stroke="#d1d5db" opacity={0.6} />
                <XAxis dataKey="table" stroke="#9ca3af" style={{ fontSize: '12px' }} />
                <YAxis stroke="#9ca3af" style={{ fontSize: '12px' }} />
                <Tooltip content={<CustomTooltip />} cursor={{ fill: '#fafafa', opacity: 0.15 }} />
                <Legend wrapperStyle={{ fontSize: '12px' }} />
                <Bar
                  dataKey="reads"
                  fill="#3b82f6"
                  radius={[8, 8, 0, 0]}
                  name="읽기"
                  fillOpacity={0.85}
                  activeBar={{ fillOpacity: 0.95 }}
                  maxBarSize={40}
                />
                <Bar
                  dataKey="writes"
                  fill="#10b981"
                  radius={[8, 8, 0, 0]}
                  name="쓰기"
                  fillOpacity={0.85}
                  activeBar={{ fillOpacity: 0.95 }}
                  maxBarSize={40}
                />
              </BarChart>
            </ResponsiveContainer>
          </ChartCard>

          {/* Query Type Distribution */}
          <ChartCard
            title="쿼리 유형 분석"
            icon={<Zap className="w-5 h-5 text-yellow-600" />}
            delay={0.45}
          >
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={queryTypeDistribution} layout="vertical" barCategoryGap="20%">
                <CartesianGrid strokeDasharray="3 3" stroke="#d1d5db" opacity={0.6} />
                <XAxis type="number" stroke="#9ca3af" style={{ fontSize: '12px' }} />
                <YAxis dataKey="name" type="category" stroke="#9ca3af" style={{ fontSize: '12px' }} width={80} />
                <Tooltip content={<CustomTooltip />} cursor={{ fill: '#fafafa', opacity: 0.15 }} />
                <Bar
                  dataKey="value"
                  radius={[0, 8, 8, 0]}
                  name="쿼리 수"
                  fillOpacity={0.85}
                  activeBar={{ fillOpacity: 0.95 }}
                  maxBarSize={28}
                >
                  {queryTypeDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </ChartCard>
        </div>

        {/* Data Quality Metrics */}
        <ChartCard
          title="데이터 품질 지표"
          icon={<Database className="w-5 h-5 text-blue-600" />}
          delay={0.5}
          badge={
            <span className="text-xs px-3 py-1 bg-green-100 text-green-700 rounded-full">우수</span>
          }
        >
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {dataQualityMetrics.map((metric, index) => (
              <div key={index} className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-700">{metric.metric}</span>
                  <span className="text-sm text-gray-900">{metric.score}%</span>
                </div>
                <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${metric.score}%` }}
                    transition={{ duration: 1, delay: 0.5 + index * 0.1, ease: 'easeOut' }}
                    className={`h-full rounded-full ${
                      metric.score >= 95 ? 'bg-green-500' : metric.score >= 85 ? 'bg-yellow-500' : 'bg-red-500'
                    }`}
                  />
                </div>
              </div>
            ))}
          </div>
        </ChartCard>

        {/* Recent Queries */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.55 }}
          className="bg-white rounded-xl border border-gray-200 overflow-hidden shadow-sm hover:shadow-lg transition-shadow duration-300 mt-6"
        >
          <div className="p-6 border-b border-gray-200 bg-gradient-to-r from-gray-50 to-white">
            <h2 className="text-gray-900 flex items-center gap-2 font-bold">
              <Activity className="w-5 h-5 text-green-600" />
              최근 실행한 쿼리
            </h2>
          </div>
          <div className="divide-y divide-gray-200">
            {recentQueries.map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.3, delay: 0.6 + index * 0.05 }}
                whileHover={{
                  backgroundColor: '#f9fafb',
                  x: 4,
                  transition: { duration: 0.2 },
                }}
                className="p-4 cursor-pointer"
              >
                <div className="font-mono text-sm text-gray-900 mb-2">{item.query}</div>
                <div className="flex items-center gap-4 text-xs text-gray-600">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {item.time}
                  </span>
                  <span>실행 시간: {item.duration}</span>
                  <span className="flex items-center gap-1">
                    <motion.div
                      className="w-2 h-2 rounded-full bg-green-500"
                      animate={{
                        scale: [1, 1.2, 1],
                        opacity: [1, 0.7, 1],
                      }}
                      transition={{
                        duration: 2,
                        repeat: Infinity,
                        ease: 'easeInOut',
                      }}
                    />
                    성공
                  </span>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </motion.div>
    </div>
  );
}