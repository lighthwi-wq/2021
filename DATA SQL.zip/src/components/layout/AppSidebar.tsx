import React, { useState, useMemo } from 'react';
import {
  Database,
  ChevronRight,
  Plus,
  Table,
  Home,
  Activity,
  FileText,
  HelpCircle,
  LogOut,
  Search,
  Edit2,
  Trash2,
  Circle,
  X,
  MoreVertical,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Connection, Schema, ViewType } from '../../types';
import { DEFAULT_CONNECTIONS, DEFAULT_SCHEMAS } from '../../constants/database';
import { ConnectionModal } from '../ConnectionModal';
import { ContextMenu } from '../ContextMenu';
import { slideInLeft, staggerContainer, staggerItem } from '../../lib/animations/variants';
import { useApp } from '../../contexts/AppContext';
import { useMediaQuery } from '../../hooks/useMediaQuery';

interface AppSidebarProps {
  onTableSelect: (tableName: string) => void;
  selectedTable: string | null;
  onViewChange: (view: ViewType) => void;
  currentView: string;
  onHelpClick: () => void;
  onLogoutClick: () => void;
}

export const AppSidebar = React.memo(function AppSidebar({
  onTableSelect,
  selectedTable,
  onViewChange,
  currentView,
  onHelpClick,
  onLogoutClick,
}: AppSidebarProps) {
  const { isSidebarOpen, closeSidebar } = useApp();
  const [expandedDatabases, setExpandedDatabases] = useState<string[]>(['conn-1']);
  const [expandedSchemas, setExpandedSchemas] = useState<string[]>(['public']);
  const [searchQuery, setSearchQuery] = useState('');
  const [isConnectionModalOpen, setIsConnectionModalOpen] = useState(false);
  const [editingConnection, setEditingConnection] = useState<Connection | null>(null);
  const [contextMenu, setContextMenu] = useState<{
    isOpen: boolean;
    x: number;
    y: number;
    connection: Connection | null;
  }>({ isOpen: false, x: 0, y: 0, connection: null });
  const [connections, setConnections] = useState<Connection[]>(DEFAULT_CONNECTIONS);

  const schemas: { [key: string]: Schema[] } = DEFAULT_SCHEMAS;

  const menuItems = useMemo(
    () => [
      { id: 'home', label: '홈', icon: Home, view: 'home' as ViewType },
      { id: 'editor', label: 'SQL 편집기', icon: Database, view: 'editor' as ViewType },
      { id: 'history', label: '쿼리 히스토리', icon: Activity, view: 'history' as ViewType },
      { id: 'saved', label: '저장된 쿼리', icon: FileText, view: 'saved' as ViewType },
    ],
    []
  );

  const toggleDatabase = (dbId: string) => {
    setExpandedDatabases((prev) => (prev.includes(dbId) ? prev.filter((id) => id !== dbId) : [...prev, dbId]));
  };

  const toggleSchema = (schemaName: string) => {
    setExpandedSchemas((prev) =>
      prev.includes(schemaName) ? prev.filter((name) => name !== schemaName) : [...prev, schemaName]
    );
  };

  const handleNewConnection = () => {
    setEditingConnection(null);
    setIsConnectionModalOpen(true);
  };

  const handleSaveConnection = (connection: Connection) => {
    setConnections((prev) => {
      const exists = prev.find((c) => c.id === connection.id);
      if (exists) {
        return prev.map((c) => (c.id === connection.id ? connection : c));
      }
      return [...prev, connection];
    });
  };

  const handleEditConnection = (connection: Connection) => {
    setEditingConnection(connection);
    setIsConnectionModalOpen(true);
  };

  const handleDeleteConnection = (connectionId: string) => {
    setConnections((prev) => prev.filter((c) => c.id !== connectionId));
  };

  const handleConnectionContextMenu = (e: React.MouseEvent, connection: Connection) => {
    e.preventDefault();
    e.stopPropagation();
    setContextMenu({
      isOpen: true,
      x: e.clientX,
      y: e.clientY,
      connection,
    });
  };

  const filteredConnections = useMemo(() => {
    if (!searchQuery) return connections;
    return connections.filter((conn) => conn.name.toLowerCase().includes(searchQuery.toLowerCase()));
  }, [connections, searchQuery]);

  const isMobile = useMediaQuery('(max-width: 1024px)');

  return (
    <>
      {/* Mobile Overlay */}
      <AnimatePresence>
        {isSidebarOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={closeSidebar}
            className="lg:hidden fixed inset-0 bg-black/50 z-40 backdrop-blur-sm"
          />
        )}
      </AnimatePresence>

      {/* Sidebar */}
      <aside
        className="w-72 bg-white border-r border-gray-200 flex flex-col h-full fixed lg:static top-0 bottom-0 z-50 transition-transform duration-300 ease-in-out lg:translate-x-0"
        style={{
          left: 0,
          transform: isMobile ? (isSidebarOpen ? 'translateX(0)' : 'translateX(-100%)') : 'translateX(0)',
        }}
      >
        {/* Mobile Close Button */}
        <div className="lg:hidden absolute top-4 right-4 z-10">
          <motion.button
            onClick={closeSidebar}
            whileHover={{ scale: 1.1, rotate: 90 }}
            whileTap={{ scale: 0.9 }}
            className="p-2 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-gray-700" />
          </motion.button>
        </div>

        {/* Header */}
        <motion.div
          className="p-5 border-b border-gray-200 bg-gradient-to-br from-blue-50 to-purple-50"
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.4 }}
        >
          <div className="flex items-center gap-3 mb-4">
            <motion.div
              className="p-2 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg"
              whileHover={{ scale: 1.05, rotate: 5 }}
              whileTap={{ scale: 0.95 }}
            >
              <Database className="w-6 h-6 text-white" />
            </motion.div>
            <div>
              <h1 className="font-bold text-gray-900">DataEye SQL</h1>
              <p className="text-xs text-gray-600">Database Manager</p>
            </div>
          </div>

          {/* Search */}
          <motion.div
            className="relative"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3, duration: 0.3 }}
          >
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              placeholder="연결 검색..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-2 text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
            />
          </motion.div>
        </motion.div>

        {/* Navigation Menu */}
        <motion.div
          className="p-3 border-b border-gray-200"
          variants={staggerContainer}
          initial="initial"
          animate="animate"
        >
          {menuItems.map((item, index) => (
            <motion.button
              key={item.id}
              variants={staggerItem}
              onClick={() => onViewChange(item.view)}
              whileHover={{ x: 4, backgroundColor: '#f3f4f6' }}
              whileTap={{ scale: 0.98 }}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all ${
                currentView === item.view
                  ? 'bg-gradient-to-r from-blue-50 to-purple-50 text-blue-700 font-semibold'
                  : 'text-gray-700 hover:bg-gray-100'
              }`}
            >
              <item.icon className="w-4 h-4" />
              <span>{item.label}</span>
              {currentView === item.view && (
                <motion.div
                  layoutId="activeIndicator"
                  className="ml-auto w-1.5 h-1.5 rounded-full bg-blue-600"
                  initial={false}
                  transition={{ type: 'spring', stiffness: 300, damping: 30 }}
                />
              )}
            </motion.button>
          ))}
        </motion.div>

        {/* Connections */}
        <div className="flex-1 overflow-y-auto p-3">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-gray-500 uppercase tracking-wide">연결</span>
            <motion.button
              onClick={handleNewConnection}
              whileHover={{ scale: 1.1, rotate: 90 }}
              whileTap={{ scale: 0.9 }}
              className="p-1 hover:bg-gray-100 rounded-md transition-colors"
            >
              <Plus className="w-4 h-4 text-gray-600" />
            </motion.button>
          </div>

          <AnimatePresence mode="popLayout">
            {filteredConnections.map((connection, connIndex) => (
              <motion.div
                key={connection.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ delay: connIndex * 0.03 }}
                className="mb-2"
              >
                <motion.div
                  className="flex items-center gap-2 px-2 py-2 hover:bg-gray-50 rounded-lg cursor-pointer group"
                  onClick={(e) => {
                    // 점점점 버튼 클릭이 아닐 때만 토글
                    const target = e.target as HTMLElement;
                    if (!target.closest('.menu-button')) {
                      toggleDatabase(connection.id);
                    }
                  }}
                  onContextMenu={(e) => handleConnectionContextMenu(e, connection)}
                  whileHover={{ backgroundColor: '#f9fafb' }}
                >
                  <motion.div
                    animate={{ rotate: expandedDatabases.includes(connection.id) ? 90 : 0 }}
                    transition={{ duration: 0.2 }}
                  >
                    <ChevronRight className="w-4 h-4 text-gray-500" />
                  </motion.div>
                  <Circle
                    className={`w-2 h-2 ${
                      connection.status === 'connected'
                        ? 'text-green-500 fill-green-500'
                        : connection.status === 'connecting'
                        ? 'text-yellow-500 fill-yellow-500'
                        : 'text-red-500 fill-red-500'
                    }`}
                  />
                  <span className="text-sm flex-1 text-gray-900">{connection.name}</span>
                  {/* 점점점 메뉴 버튼 */}
                  <motion.button
                    className="menu-button opacity-0 group-hover:opacity-100 p-1 hover:bg-gray-200 rounded transition-all"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleConnectionContextMenu(e, connection);
                    }}
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                  >
                    <MoreVertical className="w-4 h-4 text-gray-600" />
                  </motion.button>
                </motion.div>

                <AnimatePresence>
                  {expandedDatabases.includes(connection.id) && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.2 }}
                      className="ml-6 mt-1 overflow-hidden"
                    >
                      {schemas[connection.id]?.map((schema) => (
                        <div key={schema.name} className="mb-1">
                          <motion.div
                            className="flex items-center gap-2 px-2 py-1.5 hover:bg-gray-50 rounded-md cursor-pointer text-sm"
                            onClick={() => toggleSchema(schema.name)}
                            whileHover={{ x: 2 }}
                          >
                            <motion.div
                              animate={{ rotate: expandedSchemas.includes(schema.name) ? 90 : 0 }}
                              transition={{ duration: 0.2 }}
                            >
                              <ChevronRight className="w-3 h-3 text-gray-400" />
                            </motion.div>
                            <span className="text-gray-700">{schema.name}</span>
                          </motion.div>

                          <AnimatePresence>
                            {expandedSchemas.includes(schema.name) && (
                              <motion.div
                                initial={{ height: 0, opacity: 0 }}
                                animate={{ height: 'auto', opacity: 1 }}
                                exit={{ height: 0, opacity: 0 }}
                                transition={{ duration: 0.2 }}
                                className="ml-5 mt-1 overflow-hidden"
                              >
                                {schema.tables.map((table, tableIndex) => (
                                  <motion.div
                                    key={table}
                                    initial={{ opacity: 0, x: -10 }}
                                    animate={{ opacity: 1, x: 0 }}
                                    transition={{ delay: tableIndex * 0.02 }}
                                    className={`flex items-center gap-2 px-2 py-1.5 rounded-md cursor-pointer text-sm group ${
                                      selectedTable === table
                                        ? 'bg-blue-50 text-blue-700'
                                        : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                                    }`}
                                    onClick={() => {
                                      onTableSelect(table);
                                      onViewChange('editor');
                                    }}
                                    whileHover={{ x: 4 }}
                                  >
                                    <Table className="w-3 h-3" />
                                    <span>{table}</span>
                                  </motion.div>
                                ))}
                              </motion.div>
                            )}
                          </AnimatePresence>
                        </div>
                      ))}
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {/* Footer */}
        <motion.div
          className="p-3 border-t border-gray-200 bg-gray-50"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <motion.button
            onClick={onHelpClick}
            whileHover={{ x: 4, backgroundColor: '#ffffff' }}
            whileTap={{ scale: 0.98 }}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-gray-700 hover:bg-white transition-all mb-2"
          >
            <HelpCircle className="w-4 h-4" />
            <span>도움말</span>
          </motion.button>
          <motion.button
            onClick={onLogoutClick}
            whileHover={{ x: 4, backgroundColor: '#fee2e2' }}
            whileTap={{ scale: 0.98 }}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-red-600 hover:bg-red-50 transition-all"
          >
            <LogOut className="w-4 h-4" />
            <span>로그아웃</span>
          </motion.button>
        </motion.div>
      </aside>

      {/* Modals */}
      <ConnectionModal
        isOpen={isConnectionModalOpen}
        onClose={() => {
          setIsConnectionModalOpen(false);
          setEditingConnection(null);
        }}
        onSave={handleSaveConnection}
        editingConnection={editingConnection}
      />

      <ContextMenu
        isOpen={contextMenu.isOpen}
        x={contextMenu.x}
        y={contextMenu.y}
        items={[
          {
            label: '편집',
            icon: <Edit2 className="w-4 h-4" />,
            onClick: () => {
              if (contextMenu.connection) {
                handleEditConnection(contextMenu.connection);
              }
              setContextMenu({ ...contextMenu, isOpen: false });
            },
          },
          {
            label: '삭제',
            icon: <Trash2 className="w-4 h-4" />,
            onClick: () => {
              if (contextMenu.connection) {
                handleDeleteConnection(contextMenu.connection.id);
              }
              setContextMenu({ ...contextMenu, isOpen: false });
            },
            danger: true,
          },
        ]}
        onClose={() => setContextMenu({ ...contextMenu, isOpen: false })}
      />
    </>
  );
});