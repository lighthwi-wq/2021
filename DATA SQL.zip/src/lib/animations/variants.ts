import { Variants } from 'motion/react';

// 페이지 전환 애니메이션
export const pageVariants: Variants = {
  initial: {
    opacity: 0,
    y: 20,
    scale: 0.98,
  },
  animate: {
    opacity: 1,
    y: 0,
    scale: 1,
    transition: {
      duration: 0.4,
      ease: [0.25, 0.46, 0.45, 0.94],
    },
  },
  exit: {
    opacity: 0,
    y: -20,
    scale: 0.98,
    transition: {
      duration: 0.3,
    },
  },
};

// 스태거 컨테이너
export const staggerContainer: Variants = {
  initial: {},
  animate: {
    transition: {
      staggerChildren: 0.05,
      delayChildren: 0.1,
    },
  },
};

// 스태거 아이템 (위에서 아래로)
export const staggerItem: Variants = {
  initial: {
    opacity: 0,
    y: 20,
  },
  animate: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.4,
      ease: [0.25, 0.46, 0.45, 0.94],
    },
  },
};

// 스태거 아이템 (아래에서 위로)
export const staggerItemUp: Variants = {
  initial: {
    opacity: 0,
    y: -20,
  },
  animate: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.4,
      ease: [0.25, 0.46, 0.45, 0.94],
    },
  },
};

// 좌측에서 나타남
export const slideInLeft: Variants = {
  initial: {
    opacity: 0,
    x: -40,
  },
  animate: {
    opacity: 1,
    x: 0,
    transition: {
      duration: 0.5,
      ease: [0.25, 0.46, 0.45, 0.94],
    },
  },
};

// 우측에서 나타남
export const slideInRight: Variants = {
  initial: {
    opacity: 0,
    x: 40,
  },
  animate: {
    opacity: 1,
    x: 0,
    transition: {
      duration: 0.5,
      ease: [0.25, 0.46, 0.45, 0.94],
    },
  },
};

// 페이드 인
export const fadeIn: Variants = {
  initial: {
    opacity: 0,
  },
  animate: {
    opacity: 1,
    transition: {
      duration: 0.3,
    },
  },
  exit: {
    opacity: 0,
    transition: {
      duration: 0.2,
    },
  },
};

// 스케일 팝
export const scalePop: Variants = {
  initial: {
    opacity: 0,
    scale: 0.8,
  },
  animate: {
    opacity: 1,
    scale: 1,
    transition: {
      duration: 0.4,
      ease: [0.34, 1.56, 0.64, 1],
    },
  },
  exit: {
    opacity: 0,
    scale: 0.9,
    transition: {
      duration: 0.2,
    },
  },
};

// 카드 호버
export const cardHover = {
  rest: {
    scale: 1,
    boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
  },
  hover: {
    scale: 1.02,
    boxShadow: '0 10px 30px rgba(0,0,0,0.15)',
    transition: {
      duration: 0.3,
      ease: [0.25, 0.46, 0.45, 0.94],
    },
  },
  tap: {
    scale: 0.98,
  },
};

// 버튼 호버
export const buttonHover = {
  rest: {
    scale: 1,
  },
  hover: {
    scale: 1.05,
    transition: {
      duration: 0.2,
      ease: 'easeInOut',
    },
  },
  tap: {
    scale: 0.95,
  },
};

// 리플 효과
export const ripple = {
  initial: {
    opacity: 0.5,
    scale: 0,
  },
  animate: {
    opacity: 0,
    scale: 2,
    transition: {
      duration: 0.6,
      ease: 'easeOut',
    },
  },
};

// 스프링 바운스
export const springBounce = {
  type: 'spring',
  stiffness: 300,
  damping: 20,
};

// 부드러운 스프링
export const smoothSpring = {
  type: 'spring',
  stiffness: 100,
  damping: 15,
};

// 글라스모피즘 카드
export const glassCard: Variants = {
  initial: {
    opacity: 0,
    y: 20,
    backdropFilter: 'blur(0px)',
  },
  animate: {
    opacity: 1,
    y: 0,
    backdropFilter: 'blur(20px)',
    transition: {
      duration: 0.5,
      ease: [0.25, 0.46, 0.45, 0.94],
    },
  },
};

// 자석 효과용 (마우스 추적)
export const magneticEffect = (mousePosition: { x: number; y: number }, elementPosition: { x: number; y: number }) => {
  const deltaX = mousePosition.x - elementPosition.x;
  const deltaY = mousePosition.y - elementPosition.y;
  const distance = Math.sqrt(deltaX * deltaX + deltaY * deltaY);
  const maxDistance = 100;
  
  if (distance < maxDistance) {
    const strength = 0.3;
    return {
      x: deltaX * strength,
      y: deltaY * strength,
    };
  }
  
  return { x: 0, y: 0 };
};

// 셰이크 애니메이션
export const shake: Variants = {
  shake: {
    x: [0, -10, 10, -10, 10, 0],
    transition: {
      duration: 0.5,
    },
  },
};

// 펄스 애니메이션
export const pulse: Variants = {
  pulse: {
    scale: [1, 1.05, 1],
    transition: {
      duration: 0.6,
      repeat: Infinity,
      ease: 'easeInOut',
    },
  },
};

// 그라데이션 애니메이션
export const gradientShift = {
  animate: {
    backgroundPosition: ['0% 50%', '100% 50%', '0% 50%'],
    transition: {
      duration: 5,
      ease: 'linear',
      repeat: Infinity,
    },
  },
};
