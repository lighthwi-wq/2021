import { Connection, Schema } from '../types';

export const DEFAULT_CONNECTIONS: Connection[] = [
  {
    id: 'conn-1',
    name: 'PostgreSQL 프로덕션',
    type: 'PostgreSQL',
    host: 'localhost',
    port: 5432,
    database: 'production_db',
    username: 'admin',
    status: 'connected'
  },
  {
    id: 'conn-2',
    name: 'MySQL 개발',
    type: 'MySQL',
    host: 'localhost',
    port: 3306,
    database: 'dev_db',
    username: 'developer',
    status: 'connected'
  },
  {
    id: 'conn-3',
    name: 'MongoDB 스테이징',
    type: 'MongoDB',
    host: 'localhost',
    port: 27017,
    database: 'staging_db',
    username: 'staging_user',
    status: 'disconnected'
  }
];

export const DEFAULT_SCHEMAS: Record<string, Schema[]> = {
  'conn-1': [
    { name: 'public', tables: ['users', 'products', 'orders', 'categories', 'payments'] },
    { name: 'analytics', tables: ['events', 'sessions', 'conversions'] }
  ],
  'conn-2': [
    { name: 'main', tables: ['customers', 'inventory', 'suppliers'] }
  ],
  'conn-3': [
    { name: 'app', tables: ['logs', 'metrics', 'cache'] }
  ]
};

export const SQL_KEYWORDS = [
  'SELECT', 'FROM', 'WHERE', 'INSERT', 'UPDATE', 'DELETE',
  'CREATE', 'DROP', 'ALTER', 'TABLE', 'INDEX', 'VIEW',
  'JOIN', 'LEFT', 'RIGHT', 'INNER', 'OUTER', 'ON',
  'GROUP BY', 'ORDER BY', 'HAVING', 'LIMIT', 'OFFSET',
  'UNION', 'INTERSECT', 'EXCEPT', 'AS', 'DISTINCT',
  'AND', 'OR', 'NOT', 'IN', 'EXISTS', 'BETWEEN', 'LIKE',
  'IS', 'NULL', 'TRUE', 'FALSE', 'CASE', 'WHEN', 'THEN', 'ELSE', 'END'
];

export const SQL_FUNCTIONS = [
  'COUNT', 'SUM', 'AVG', 'MIN', 'MAX',
  'UPPER', 'LOWER', 'SUBSTRING', 'CONCAT', 'LENGTH',
  'NOW', 'CURRENT_DATE', 'CURRENT_TIME', 'CURRENT_TIMESTAMP',
  'CAST', 'CONVERT', 'COALESCE', 'NULLIF'
];
