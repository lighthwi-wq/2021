import { AutocompleteItem } from '../types/autocomplete';

// SQL 키워드 (데이터베이스별)
export const SQL_KEYWORDS: AutocompleteItem[] = [
  // 기본 DML
  { text: 'SELECT', type: 'keyword', category: 'DML', description: '데이터 조회', example: 'SELECT * FROM table', database: 'all' },
  { text: 'FROM', type: 'keyword', category: 'DML', description: '테이블 지정', example: 'FROM users', database: 'all' },
  { text: 'WHERE', type: 'keyword', category: 'DML', description: '조건 필터', example: 'WHERE id = 1', database: 'all' },
  { text: 'INSERT INTO', type: 'keyword', category: 'DML', description: '데이터 삽입', example: 'INSERT INTO table VALUES', database: 'all' },
  { text: 'UPDATE', type: 'keyword', category: 'DML', description: '데이터 수정', example: 'UPDATE table SET', database: 'all' },
  { text: 'DELETE FROM', type: 'keyword', category: 'DML', description: '데이터 삭제', example: 'DELETE FROM table WHERE', database: 'all' },
  { text: 'SET', type: 'keyword', category: 'DML', description: '값 설정', example: 'SET column = value', database: 'all' },
  { text: 'VALUES', type: 'keyword', category: 'DML', description: '삽입할 값', example: 'VALUES (1, "text")', database: 'all' },
  
  // JOIN
  { text: 'JOIN', type: 'keyword', category: 'JOIN', description: 'INNER JOIN', example: 'JOIN table ON condition', database: 'all' },
  { text: 'INNER JOIN', type: 'keyword', category: 'JOIN', description: '내부 조인', example: 'INNER JOIN table ON id', database: 'all' },
  { text: 'LEFT JOIN', type: 'keyword', category: 'JOIN', description: '왼쪽 외부 조인', example: 'LEFT JOIN table ON id', database: 'all' },
  { text: 'RIGHT JOIN', type: 'keyword', category: 'JOIN', description: '오른쪽 외부 조인', example: 'RIGHT JOIN table ON id', database: 'all' },
  { text: 'FULL OUTER JOIN', type: 'keyword', category: 'JOIN', description: '완전 외부 조인', example: 'FULL OUTER JOIN table', database: 'all' },
  { text: 'CROSS JOIN', type: 'keyword', category: 'JOIN', description: '교차 조인', example: 'CROSS JOIN table', database: 'all' },
  { text: 'ON', type: 'keyword', category: 'JOIN', description: '조인 조건', example: 'ON a.id = b.id', database: 'all' },
  
  // 집계/정렬
  { text: 'GROUP BY', type: 'keyword', category: '집계', description: '그룹화', example: 'GROUP BY column', database: 'all' },
  { text: 'HAVING', type: 'keyword', category: '집계', description: '그룹 조건', example: 'HAVING COUNT(*) > 10', database: 'all' },
  { text: 'ORDER BY', type: 'keyword', category: '정렬', description: '정렬', example: 'ORDER BY column DESC', database: 'all' },
  { text: 'ASC', type: 'keyword', category: '정렬', description: '오름차순', example: 'ORDER BY id ASC', database: 'all' },
  { text: 'DESC', type: 'keyword', category: '정렬', description: '내림차순', example: 'ORDER BY id DESC', database: 'all' },
  { text: 'LIMIT', type: 'keyword', category: '제한', description: '행 수 제한', example: 'LIMIT 100', database: 'all' },
  { text: 'OFFSET', type: 'keyword', category: '제한', description: '건너뛸 행 수', example: 'OFFSET 10', database: 'all' },
  
  // 논리 연산자
  { text: 'AND', type: 'operator', category: '논리', description: '논리 AND', example: 'WHERE a = 1 AND b = 2', database: 'all' },
  { text: 'OR', type: 'operator', category: '논리', description: '논리 OR', example: 'WHERE a = 1 OR b = 2', database: 'all' },
  { text: 'NOT', type: 'operator', category: '논리', description: '논리 NOT', example: 'WHERE NOT status = "deleted"', database: 'all' },
  { text: 'IN', type: 'operator', category: '비교', description: '값 목록 포함', example: 'WHERE id IN (1,2,3)', database: 'all' },
  { text: 'NOT IN', type: 'operator', category: '비교', description: '값 목록 불포함', example: 'WHERE id NOT IN (1,2,3)', database: 'all' },
  { text: 'BETWEEN', type: 'operator', category: '비교', description: '범위 조건', example: 'WHERE price BETWEEN 100 AND 500', database: 'all' },
  { text: 'LIKE', type: 'operator', category: '비교', description: '패턴 매칭', example: 'WHERE name LIKE "John%"', database: 'all' },
  { text: 'ILIKE', type: 'operator', category: '비교', description: '대소문자 무시 패턴', example: 'WHERE name ILIKE "john%"', database: 'postgresql' },
  { text: 'IS NULL', type: 'operator', category: '비교', description: 'NULL 체크', example: 'WHERE email IS NULL', database: 'all' },
  { text: 'IS NOT NULL', type: 'operator', category: '비교', description: 'NOT NULL 체크', example: 'WHERE email IS NOT NULL', database: 'all' },
  { text: 'EXISTS', type: 'operator', category: '서브쿼리', description: '서브쿼리 존재 확인', example: 'WHERE EXISTS (SELECT 1...)', database: 'all' },
  
  // 기타
  { text: 'DISTINCT', type: 'keyword', category: '수식어', description: '중복 제거', example: 'SELECT DISTINCT column', database: 'all' },
  { text: 'AS', type: 'keyword', category: '별칭', description: '별칭 지정', example: 'SELECT col AS alias', database: 'all' },
  { text: 'CASE', type: 'keyword', category: '조건', description: 'CASE 문', example: 'CASE WHEN ... THEN ... END', database: 'all' },
  { text: 'WHEN', type: 'keyword', category: '조건', description: 'CASE 조건', example: 'WHEN status = 1 THEN "Active"', database: 'all' },
  { text: 'THEN', type: 'keyword', category: '조건', description: 'CASE 결과', example: 'THEN "Active"', database: 'all' },
  { text: 'ELSE', type: 'keyword', category: '조건', description: 'CASE 기본값', example: 'ELSE "Inactive"', database: 'all' },
  { text: 'END', type: 'keyword', category: '조건', description: 'CASE 종료', example: 'END AS status_name', database: 'all' },
  
  // DDL
  { text: 'CREATE TABLE', type: 'keyword', category: 'DDL', description: '테이블 생성', example: 'CREATE TABLE users (...)', database: 'all' },
  { text: 'DROP TABLE', type: 'keyword', category: 'DDL', description: '테이블 삭제', example: 'DROP TABLE users', database: 'all' },
  { text: 'ALTER TABLE', type: 'keyword', category: 'DDL', description: '테이블 수정', example: 'ALTER TABLE users ADD COLUMN', database: 'all' },
  { text: 'TRUNCATE TABLE', type: 'keyword', category: 'DDL', description: '테이블 초기화', example: 'TRUNCATE TABLE users', database: 'all' },
  { text: 'CREATE INDEX', type: 'keyword', category: 'DDL', description: '인덱스 생성', example: 'CREATE INDEX idx ON table(col)', database: 'all' },
  { text: 'DROP INDEX', type: 'keyword', category: 'DDL', description: '인덱스 삭제', example: 'DROP INDEX idx', database: 'all' },
  
  // 트랜잭션
  { text: 'BEGIN', type: 'keyword', category: '트랜잭션', description: '트랜잭션 시작', database: 'all' },
  { text: 'COMMIT', type: 'keyword', category: '트랜잭션', description: '트랜잭션 커밋', database: 'all' },
  { text: 'ROLLBACK', type: 'keyword', category: '트랜잭션', description: '트랜잭션 롤백', database: 'all' },
  
  // PostgreSQL 특화
  { text: 'RETURNING', type: 'keyword', category: 'PostgreSQL', description: '결과 반환', example: 'INSERT ... RETURNING *', database: 'postgresql' },
  { text: 'WITH', type: 'keyword', category: 'CTE', description: 'CTE (Common Table Expression)', example: 'WITH cte AS (SELECT ...)', database: 'all' },
  { text: 'RECURSIVE', type: 'keyword', category: 'CTE', description: '재귀 CTE', example: 'WITH RECURSIVE ...', database: 'postgresql' },
];

// SQL 함수
export const SQL_FUNCTIONS: AutocompleteItem[] = [
  // 집계 함수
  { text: 'COUNT(*)', type: 'function', category: '집계', description: '전체 행 개수', example: 'COUNT(*)', insertText: 'COUNT(*)', database: 'all' },
  { text: 'COUNT()', type: 'function', category: '집계', description: '값 개수', example: 'COUNT(column)', insertText: 'COUNT()', cursorOffset: -1, database: 'all' },
  { text: 'SUM()', type: 'function', category: '집계', description: '합계', example: 'SUM(price)', insertText: 'SUM()', cursorOffset: -1, database: 'all' },
  { text: 'AVG()', type: 'function', category: '집계', description: '평균', example: 'AVG(score)', insertText: 'AVG()', cursorOffset: -1, database: 'all' },
  { text: 'MAX()', type: 'function', category: '집계', description: '최대값', example: 'MAX(price)', insertText: 'MAX()', cursorOffset: -1, database: 'all' },
  { text: 'MIN()', type: 'function', category: '집계', description: '최소값', example: 'MIN(price)', insertText: 'MIN()', cursorOffset: -1, database: 'all' },
  { text: 'GROUP_CONCAT()', type: 'function', category: '집계', description: '문자열 결합', example: 'GROUP_CONCAT(name)', insertText: 'GROUP_CONCAT()', cursorOffset: -1, database: 'mysql' },
  { text: 'STRING_AGG()', type: 'function', category: '집계', description: '문자열 결합', example: 'STRING_AGG(name, ", ")', insertText: 'STRING_AGG(, ", ")', cursorOffset: -7, database: 'postgresql' },
  
  // 문자열 함수
  { text: 'CONCAT()', type: 'function', category: '문자열', description: '문자열 연결', example: 'CONCAT(first, " ", last)', insertText: 'CONCAT()', cursorOffset: -1, database: 'all' },
  { text: 'UPPER()', type: 'function', category: '문자열', description: '대문자 변환', example: 'UPPER(name)', insertText: 'UPPER()', cursorOffset: -1, database: 'all' },
  { text: 'LOWER()', type: 'function', category: '문자열', description: '소문자 변환', example: 'LOWER(name)', insertText: 'LOWER()', cursorOffset: -1, database: 'all' },
  { text: 'LENGTH()', type: 'function', category: '문자열', description: '문자열 길이', example: 'LENGTH(text)', insertText: 'LENGTH()', cursorOffset: -1, database: 'all' },
  { text: 'SUBSTRING()', type: 'function', category: '문자열', description: '부분 문자열', example: 'SUBSTRING(text, 1, 5)', insertText: 'SUBSTRING(, 1, 5)', cursorOffset: -9, database: 'all' },
  { text: 'TRIM()', type: 'function', category: '문자열', description: '공백 제거', example: 'TRIM(text)', insertText: 'TRIM()', cursorOffset: -1, database: 'all' },
  { text: 'REPLACE()', type: 'function', category: '문자열', description: '문자열 치환', example: 'REPLACE(text, "old", "new")', insertText: 'REPLACE(, "", "")', cursorOffset: -9, database: 'all' },
  { text: 'LEFT()', type: 'function', category: '문자열', description: '왼쪽에서 자르기', example: 'LEFT(text, 5)', insertText: 'LEFT(, 5)', cursorOffset: -4, database: 'all' },
  { text: 'RIGHT()', type: 'function', category: '문자열', description: '오른쪽에서 자르기', example: 'RIGHT(text, 5)', insertText: 'RIGHT(, 5)', cursorOffset: -4, database: 'all' },
  
  // 날짜/시간 함수
  { text: 'NOW()', type: 'function', category: '날짜/시간', description: '현재 시간', example: 'NOW()', insertText: 'NOW()', database: 'all' },
  { text: 'CURRENT_DATE', type: 'function', category: '날짜/시간', description: '현재 날짜', example: 'CURRENT_DATE', insertText: 'CURRENT_DATE', database: 'all' },
  { text: 'CURRENT_TIME', type: 'function', category: '날짜/시간', description: '현재 시간', example: 'CURRENT_TIME', insertText: 'CURRENT_TIME', database: 'all' },
  { text: 'CURRENT_TIMESTAMP', type: 'function', category: '날짜/시간', description: '현재 타임스탬프', example: 'CURRENT_TIMESTAMP', insertText: 'CURRENT_TIMESTAMP', database: 'all' },
  { text: 'DATE()', type: 'function', category: '날짜/시간', description: '날짜 추출', example: 'DATE(timestamp)', insertText: 'DATE()', cursorOffset: -1, database: 'all' },
  { text: 'YEAR()', type: 'function', category: '날짜/시간', description: '연도 추출', example: 'YEAR(date)', insertText: 'YEAR()', cursorOffset: -1, database: 'all' },
  { text: 'MONTH()', type: 'function', category: '날짜/시간', description: '월 추출', example: 'MONTH(date)', insertText: 'MONTH()', cursorOffset: -1, database: 'all' },
  { text: 'DAY()', type: 'function', category: '날짜/시간', description: '일 추출', example: 'DAY(date)', insertText: 'DAY()', cursorOffset: -1, database: 'all' },
  { text: 'DATE_ADD()', type: 'function', category: '날짜/시간', description: '날짜 더하기', example: 'DATE_ADD(date, INTERVAL 1 DAY)', insertText: 'DATE_ADD(, INTERVAL 1 DAY)', cursorOffset: -20, database: 'mysql' },
  { text: 'DATE_SUB()', type: 'function', category: '날짜/시간', description: '날짜 빼기', example: 'DATE_SUB(date, INTERVAL 1 DAY)', insertText: 'DATE_SUB(, INTERVAL 1 DAY)', cursorOffset: -20, database: 'mysql' },
  { text: 'DATE_TRUNC()', type: 'function', category: '날짜/시간', description: '날짜 절삭', example: 'DATE_TRUNC("day", timestamp)', insertText: 'DATE_TRUNC("day", )', cursorOffset: -1, database: 'postgresql' },
  { text: 'EXTRACT()', type: 'function', category: '날짜/시간', description: '날짜 부분 추출', example: 'EXTRACT(YEAR FROM date)', insertText: 'EXTRACT(YEAR FROM )', cursorOffset: -1, database: 'postgresql' },
  { text: 'AGE()', type: 'function', category: '날짜/시간', description: '날짜 차이', example: 'AGE(date1, date2)', insertText: 'AGE(, )', cursorOffset: -3, database: 'postgresql' },
  
  // 수학 함수
  { text: 'ABS()', type: 'function', category: '수학', description: '절대값', example: 'ABS(number)', insertText: 'ABS()', cursorOffset: -1, database: 'all' },
  { text: 'ROUND()', type: 'function', category: '수학', description: '반올림', example: 'ROUND(number, 2)', insertText: 'ROUND(, 2)', cursorOffset: -4, database: 'all' },
  { text: 'CEIL()', type: 'function', category: '수학', description: '올림', example: 'CEIL(number)', insertText: 'CEIL()', cursorOffset: -1, database: 'all' },
  { text: 'FLOOR()', type: 'function', category: '수학', description: '내림', example: 'FLOOR(number)', insertText: 'FLOOR()', cursorOffset: -1, database: 'all' },
  { text: 'POWER()', type: 'function', category: '수학', description: '거듭제곱', example: 'POWER(2, 3)', insertText: 'POWER(, )', cursorOffset: -3, database: 'all' },
  { text: 'SQRT()', type: 'function', category: '수학', description: '제곱근', example: 'SQRT(number)', insertText: 'SQRT()', cursorOffset: -1, database: 'all' },
  { text: 'MOD()', type: 'function', category: '수학', description: '나머지', example: 'MOD(10, 3)', insertText: 'MOD(, )', cursorOffset: -3, database: 'all' },
  { text: 'RANDOM()', type: 'function', category: '수학', description: '난수', example: 'RANDOM()', insertText: 'RANDOM()', database: 'postgresql' },
  { text: 'RAND()', type: 'function', category: '수학', description: '난수', example: 'RAND()', insertText: 'RAND()', database: 'mysql' },
  
  // 형변환 함수
  { text: 'CAST()', type: 'function', category: '형변환', description: '타입 변환', example: 'CAST(value AS INTEGER)', insertText: 'CAST( AS INTEGER)', cursorOffset: -13, database: 'all' },
  { text: 'CONVERT()', type: 'function', category: '형변환', description: '타입 변환', example: 'CONVERT(value, INTEGER)', insertText: 'CONVERT(, INTEGER)', cursorOffset: -10, database: 'mysql' },
  
  // NULL 처리
  { text: 'COALESCE()', type: 'function', category: 'NULL 처리', description: '첫 NULL이 아닌 값', example: 'COALESCE(col1, col2, "default")', insertText: 'COALESCE(, "")', cursorOffset: -4, database: 'all' },
  { text: 'NULLIF()', type: 'function', category: 'NULL 처리', description: '같으면 NULL 반환', example: 'NULLIF(col, "")', insertText: 'NULLIF(, "")', cursorOffset: -5, database: 'all' },
  { text: 'IFNULL()', type: 'function', category: 'NULL 처리', description: 'NULL 대체값', example: 'IFNULL(col, "default")', insertText: 'IFNULL(, "")', cursorOffset: -4, database: 'mysql' },
  
  // 조건 함수
  { text: 'IF()', type: 'function', category: '조건', description: '조건부 값', example: 'IF(condition, true_val, false_val)', insertText: 'IF(, , )', cursorOffset: -5, database: 'mysql' },
];

// SQL 스니펫
export const SQL_SNIPPETS: AutocompleteItem[] = [
  {
    text: 'SELECT 기본 템플릿',
    type: 'snippet',
    category: '템플릿',
    description: '기본 SELECT 쿼리',
    insertText: 'SELECT column1, column2\nFROM table_name\nWHERE condition\nORDER BY column1;',
    cursorOffset: -70
  },
  {
    text: 'JOIN 템플릿',
    type: 'snippet',
    category: '템플릿',
    description: '두 테이블 조인',
    insertText: 'SELECT a.*, b.column\nFROM table1 a\nINNER JOIN table2 b ON a.id = b.table1_id\nWHERE condition;',
    cursorOffset: -40
  },
  {
    text: 'GROUP BY 템플릿',
    type: 'snippet',
    category: '템플릿',
    description: '그룹별 집계',
    insertText: 'SELECT column, COUNT(*) as count\nFROM table_name\nGROUP BY column\nORDER BY count DESC;',
    cursorOffset: -60
  },
  {
    text: 'INSERT 템플릿',
    type: 'snippet',
    category: '템플릿',
    description: '데이터 삽입',
    insertText: 'INSERT INTO table_name (column1, column2)\nVALUES (value1, value2);',
    cursorOffset: -30
  },
  {
    text: 'UPDATE 템플릿',
    type: 'snippet',
    category: '템플릿',
    description: '데이터 업데이트',
    insertText: 'UPDATE table_name\nSET column1 = value1,\n    column2 = value2\nWHERE id = 1;',
    cursorOffset: -40
  },
  {
    text: 'CASE WHEN 템플릿',
    type: 'snippet',
    category: '템플릿',
    description: '조건부 값 설정',
    insertText: 'CASE\n  WHEN condition1 THEN result1\n  WHEN condition2 THEN result2\n  ELSE default_result\nEND AS alias',
    cursorOffset: -90
  },
  {
    text: 'CTE (WITH) 템플릿',
    type: 'snippet',
    category: '템플릿',
    description: 'Common Table Expression',
    insertText: 'WITH cte_name AS (\n  SELECT column1, column2\n  FROM table_name\n  WHERE condition\n)\nSELECT * FROM cte_name;',
    cursorOffset: -70
  },
  {
    text: '서브쿼리 템플릿',
    type: 'snippet',
    category: '템플릿',
    description: 'IN 서브쿼리',
    insertText: 'SELECT *\nFROM table_name\nWHERE column IN (\n  SELECT column\n  FROM other_table\n  WHERE condition\n);',
    cursorOffset: -50
  },
  {
    text: '윈도우 함수 템플릿',
    type: 'snippet',
    category: '템플릿',
    description: 'ROW_NUMBER 예제',
    insertText: 'SELECT *,\n  ROW_NUMBER() OVER (PARTITION BY column ORDER BY column2) as row_num\nFROM table_name;',
    cursorOffset: -50
  },
  {
    text: 'UNION 템플릿',
    type: 'snippet',
    category: '템플릿',
    description: '결과 합치기',
    insertText: 'SELECT column1, column2 FROM table1\nUNION ALL\nSELECT column1, column2 FROM table2;',
    cursorOffset: -40
  }
];

// 샘플 테이블 정보
export const SAMPLE_TABLES = [
  { name: 'users', description: '사용자 테이블' },
  { name: 'products', description: '상품 테이블' },
  { name: 'orders', description: '주문 테이블' },
  { name: 'categories', description: '카테고리 테이블' },
  { name: 'payments', description: '결제 테이블' },
  { name: 'customers', description: '고객 테이블' },
  { name: 'inventory', description: '재고 테이블' },
  { name: 'reviews', description: '리뷰 테이블' },
  { name: 'sessions', description: '세션 테이블' }
];

// 테이블별 컬럼
export const TABLE_COLUMNS: Record<string, Array<{ name: string; type: string; description: string }>> = {
  users: [
    { name: 'id', type: 'INTEGER', description: '사용자 ID (PK)' },
    { name: 'username', type: 'VARCHAR', description: '사용자명' },
    { name: 'email', type: 'VARCHAR', description: '이메일' },
    { name: 'password', type: 'VARCHAR', description: '비밀번호' },
    { name: 'created_at', type: 'TIMESTAMP', description: '생성일시' },
    { name: 'updated_at', type: 'TIMESTAMP', description: '수정일시' },
    { name: 'status', type: 'VARCHAR', description: '상태 (active/inactive)' },
    { name: 'last_login', type: 'TIMESTAMP', description: '마지막 로그인' }
  ],
  products: [
    { name: 'id', type: 'INTEGER', description: '상품 ID (PK)' },
    { name: 'name', type: 'VARCHAR', description: '상품명' },
    { name: 'category', type: 'VARCHAR', description: '카테고리' },
    { name: 'price', type: 'DECIMAL', description: '가격' },
    { name: 'stock', type: 'INTEGER', description: '재고 수량' },
    { name: 'description', type: 'TEXT', description: '상품 설명' },
    { name: 'created_at', type: 'TIMESTAMP', description: '등록일시' }
  ],
  orders: [
    { name: 'id', type: 'INTEGER', description: '주문 ID (PK)' },
    { name: 'user_id', type: 'INTEGER', description: '사용자 ID (FK)' },
    { name: 'product_id', type: 'INTEGER', description: '상품 ID (FK)' },
    { name: 'quantity', type: 'INTEGER', description: '수량' },
    { name: 'total', type: 'DECIMAL', description: '총액' },
    { name: 'status', type: 'VARCHAR', description: '주문 상태' },
    { name: 'order_date', type: 'TIMESTAMP', description: '주문일시' }
  ],
  categories: [
    { name: 'id', type: 'INTEGER', description: '카테고리 ID (PK)' },
    { name: 'name', type: 'VARCHAR', description: '카테고리명' },
    { name: 'description', type: 'TEXT', description: '설명' },
    { name: 'item_count', type: 'INTEGER', description: '항목 수' }
  ],
  payments: [
    { name: 'id', type: 'INTEGER', description: '결제 ID (PK)' },
    { name: 'order_id', type: 'INTEGER', description: '주문 ID (FK)' },
    { name: 'method', type: 'VARCHAR', description: '결제 수단' },
    { name: 'amount', type: 'DECIMAL', description: '결제 금액' },
    { name: 'status', type: 'VARCHAR', description: '결제 상태' },
    { name: 'processed_at', type: 'TIMESTAMP', description: '처리일시' }
  ]
};
