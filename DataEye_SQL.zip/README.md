
  # DATA SQL

  This is a code bundle for DATA SQL. The original project is available at https://www.figma.com/design/B5wIPqI8G5jokFDw6n9lt8/DATA-SQL.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  