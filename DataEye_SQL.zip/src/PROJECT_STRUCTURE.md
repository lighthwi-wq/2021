# 프로젝트 구조

## 개요
이 프로젝트는 엔터프라이즈급 데이터베이스 관리 도구의 프론트엔드 애플리케이션입니다.
DBeaver, SQL GATE와 같은 전문적인 데이터베이스 관리 도구를 웹 환경에서 구현했습니다.

## 기술 스택
- **React 18** with TypeScript
- **Tailwind CSS 4.0** for styling
- **Motion (Framer Motion)** for animations
- **Lucide React** for icons
- **Monaco Editor** for SQL editing
- **Recharts** for data visualization

## 폴더 구조

```
src/
├── features/              # 기능별 도메인 모듈
│   ├── auth/             # 인증 관련
│   │   ├── components/   # 인증 UI 컴포넌트
│   │   ├── contexts/     # 인증 컨텍스트
│   │   ├── hooks/        # 인증 커스텀 훅
│   │   └── types/        # 인증 타입 정의
│   ├── dashboard/        # 대시보드
│   │   ├── components/   # 대시보드 컴포넌트
│   │   └── services/     # 대시보드 비즈니스 로직
│   ├── sql-editor/       # SQL 편집기
│   │   ├── components/   # 에디터 컴포넌트
│   │   ├── services/     # SQL 파싱, 검증 등
│   │   └── constants/    # SQL 키워드, 자동완성 데이터
│   ├── query-history/    # 쿼리 히스토리
│   ├── saved-queries/    # 저장된 쿼리
│   └── connections/      # 데이터베이스 연결
│
├── shared/               # 공유 리소스
│   ├── components/       # 재사용 가능한 컴포넌트
│   │   ├── ui/          # UI 프리미티브 (Button, Input 등)
│   │   ├── layout/      # 레이아웃 컴포넌트
│   │   └── common/      # 공통 컴포넌트
│   ├── hooks/           # 공통 커스텀 훅
│   ├── utils/           # 유틸리티 함수
│   ├── types/           # 공통 타입 정의
│   ├── constants/       # 상수
│   └── services/        # 공통 서비스
│
├── core/                 # 핵심 애플리케이션 설정
│   ├── config/          # 설정 파일
│   ├── router/          # 라우팅 설정
│   └── providers/       # 전역 프로바이더
│
├── assets/              # 정적 리소스
│   ├── images/
│   └── fonts/
│
└── styles/              # 전역 스타일
    └── globals.css
```

## 설계 원칙

### 1. Feature-First Architecture
각 기능은 독립적인 모듈로 구성되어 있으며, 필요한 모든 리소스(컴포넌트, 훅, 타입)를 포함합니다.

### 2. Separation of Concerns
- **Components**: UI 렌더링만 담당
- **Services**: 비즈니스 로직 처리
- **Hooks**: 상태 관리 및 사이드 이펙트
- **Types**: 타입 안정성 보장

### 3. DRY (Don't Repeat Yourself)
공통으로 사용되는 로직은 shared 폴더에서 관리하여 중복을 제거합니다.

### 4. Single Responsibility Principle
각 파일과 함수는 하나의 책임만 가지도록 설계되었습니다.

### 5. Type Safety
TypeScript를 활용하여 컴파일 타임에 오류를 방지합니다.

## 주요 기능

### 1. 인증 시스템
- 로그인/로그아웃
- 보호된 라우트
- 세션 관리

### 2. SQL 편집기
- 구문 강조 (Monaco Editor)
- 자동완성
- 실시간 검증
- AI 어시스턴트

### 3. 데이터베이스 연결 관리
- 다중 연결 지원 (PostgreSQL, MySQL, MongoDB)
- 연결 테스트
- 스키마 트리 뷰

### 4. 쿼리 관리
- 쿼리 저장 및 조직화
- 폴더 구조 관리
- 태그 시스템
- 검색 기능

### 5. 결과 시각화
- 테이블/그리드 뷰
- 차트 및 그래프
- 데이터 내보내기

### 6. 대시보드
- 실시간 통계
- 드래그 앤 드롭 카드
- 데이터 시각화

## 성능 최적화

- React.memo를 활용한 불필요한 리렌더링 방지
- 코드 스플리팅 (React.lazy)
- 최적화된 번들 크기
- 효율적인 상태 관리

## 코드 컨벤션

- **파일명**: kebab-case (예: sql-editor.tsx)
- **컴포넌트명**: PascalCase (예: SqlEditor)
- **함수/변수명**: camelCase (예: handleSubmit)
- **타입/인터페이스명**: PascalCase (예: UserType, DatabaseConnection)
- **상수명**: UPPER_SNAKE_CASE (예: MAX_CONNECTIONS)

## 상태 관리

- **전역 상태**: Context API (Auth, App)
- **로컬 상태**: useState, useReducer
- **서버 상태**: 추후 React Query 도입 고려

## 스타일링

- Tailwind CSS 4.0 사용
- 반응형 디자인
- 한글 인터페이스 (Noto Sans KR 12-14px)

## 테스트 전략

- 단위 테스트: Jest + React Testing Library
- E2E 테스트: Playwright (추후 도입)
- 타입 체크: TypeScript strict mode

## 배포

- 정적 사이트 호스팅
- CDN 활용
- 환경 변수 관리
