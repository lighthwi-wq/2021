# DataEye SQL - Professional Database Management Tool

엔터프라이즈급 SQL 데이터베이스 관리 도구. PostgreSQL, MySQL, MongoDB를 지원하며, AI 기반 쿼리 지원 및 고급 데이터 거버넌스 대시보드를 제공합니다.

## ✨ 주요 기능

### 🗄️ 다중 데이터베이스 지원
- PostgreSQL, MySQL, MongoDB 연결 관리
- 실시간 연결 상태 모니터링
- 다중 연결 동시 관리

### 📊 데이터 거버넌스 대시보드
- 실시간 쿼리 실행 통계
- 데이터베이스별 쿼리 분포
- 테이블 접근 빈도 분석
- 데이터 품질 지표 (완정성, 중복 제거율, 스키마 일관성)
- 쿼리 유형 분석 (SELECT, INSERT, UPDATE, DELETE)

### 💻 고급 SQL 에디터
- 실시간 구문 강조
- SQL 자동완성 (키워드, 테이블명, 컬럼명)
- 실시간 문법 검증
- 다중 탭 지원
- 쿼리 기록 자동 저장

### 🤖 AI 쿼리 어시스턴트
- 자연어를 SQL로 변환
- 쿼리 최적화 제안
- 실시간 AI 챗봇 지원
- 부드러운 바운스/흔들기 애니메이션

### 🔍 통합 검색 시스템
- 전역 검색 (데이터베이스, 스키마, 테이블, 쿼리)
- 사이드바 트리 검색
- 실시간 필터링
- 빠른 네비게이션

### 🎨 현대적인 UI/UX
- 라이트/다크 모드 토글
- Motion/React 기반 부드러운 애니메이션
- 반응형 디자인
- 고급스러운 톤 다운 컬러 팔레트
- Noto Sans KR 폰트 (12px-14px)

## 📁 프로젝트 구조

```
/
├── components/
│   ├── modals/              # 모달 컴포넌트
│   │   └── SettingsModal.tsx
│   ├── ConnectionModal.tsx   # 연결 관리 모달
│   ├── ConfirmDialog.tsx     # 확인 다이얼로그
│   ├── ContextMenu.tsx       # 컨텍스트 메뉴
│   ├── FloatingAIChatBot.tsx # AI 챗봇
│   ├── Header.tsx            # 헤더 (검색, 설정)
│   ├── HelpModal.tsx         # 도움말 모달
│   ├── HomeView.tsx          # 홈 대시보드
│   ├── QueryHistoryView.tsx  # 쿼리 기록 뷰
│   ├── ResultsPanel.tsx      # 쿼리 결과 패널
│   ├── SavedQueriesView.tsx  # 저장된 쿼리 뷰
│   ├── Sidebar.tsx           # 사이드바 (트리 뷰)
│   ├── SqlEditor.tsx         # SQL 에디터
│   └── SqlEditorTabs.tsx     # SQL 에디터 탭
│
├── contexts/                 # React Context
│   └── ThemeContext.tsx     # 테마 컨텍스트
│
├── hooks/                    # 커스텀 훅
│   └── useLocalStorage.ts   # 로컬 스토리지 훅
│
├── types/                    # TypeScript 타입
│   └── index.ts             # 모든 타입 정의
│
├── constants/                # 상수
│   ├── database.ts          # 데이터베이스 관련 상수
│   └── mockData.ts          # Mock 데이터
│
├── utils/                    # 유틸리티 함수
│   └── helpers.ts           # 헬퍼 함수들
│
├── styles/
│   └── globals.css          # 글로벌 스타일
│
└── App.tsx                  # 메인 앱 컴포넌트
```

## 🛠️ 기술 스택

### Core
- **React 18** - UI 라이브러리
- **TypeScript** - 타입 안정성
- **Tailwind CSS 4.0** - 스타일링

### Animation
- **Motion/React (Framer Motion)** - 고급 애니메이션
  - Spring physics 기반 자연스러운 움직임
  - Stagger 애니메이션
  - Layout animations
  - Exit animations

### Data Visualization
- **Recharts** - 차트 라이브러리
  - Area Chart (쿼리 실행 추이)
  - Pie Chart (DB별 쿼리 분포)
  - Bar Chart (테이블 접근 빈도, 쿼리 유형)

### Icons
- **Lucide React** - 아이콘 라이브러리

## 🎯 타입 시스템

### 주요 타입

```typescript
// Connection - 데이터베이스 연결
interface Connection {
  id: string;
  name: string;
  type: 'PostgreSQL' | 'MySQL' | 'MongoDB';
  host: string;
  port: number;
  database: string;
  username: string;
  password?: string;
  status: 'connected' | 'disconnected' | 'error';
}

// Query - SQL 쿼리
interface Query {
  id: string;
  title: string;
  sql: string;
  timestamp: Date;
  duration?: string;
  rows?: number;
  status: 'success' | 'error';
  connectionId?: string;
}

// Settings - 애플리케이션 설정
interface Settings {
  theme: 'light' | 'dark' | 'auto';
  fontSize: number;
  editorTheme: 'vs-dark' | 'vs-light';
  autoComplete: boolean;
  syntaxHighlight: boolean;
  lineNumbers: boolean;
  minimap: boolean;
  wordWrap: boolean;
  tabSize: number;
  queryTimeout: number;
  maxRows: number;
  dateFormat: string;
  language: 'ko' | 'en';
}
```

## 🎨 디자인 시스템

### 색상 팔레트

**Primary Colors (톤 다운 버전)**
- Blue: `#1d4ed8` (blue-700), `#1e40af` (blue-800)
- Slate: `#334155` (slate-700), `#475569` (slate-600)
- Amber: `#d97706` (amber-600), `#f59e0b` (amber-500)

**Status Colors**
- Success: `#059669` (emerald-600)
- Error: `#e11d48` (rose-600)
- Warning: `#d97706` (amber-600)

### 애니메이션 원칙

1. **Spring Physics** - 모든 애니메이션은 스프링 물리 엔진 사용
   - `stiffness: 260-500`
   - `damping: 20-30`

2. **Stagger** - 리스트 항목은 순차적으로 등장
   - `delay: index * 0.03-0.05`

3. **Micro-interactions** - 작은 상호작용에 생동감 부여
   - 호버 시 `scale: 1.01-1.15`
   - 탭 시 `scale: 0.98`
   - 아이콘 회전 5-15도

## 🚀 주요 기능 설명

### 1. 홈 대시보드
- 6개 실시간 통계 카드
- 4개 인터랙티브 차트 (Recharts)
- 데이터 품질 지표 (진행률 바 애니메이션)
- 최근 쿼리 목록

### 2. SQL 에디터
- 구문 강조 및 자동완성
- 실시간 문법 검증
- 다중 탭 관리
- 쿼리 결과 그리드 뷰

### 3. AI 챗봇
- 플로팅 버튼 (우측 하단)
- 자연어 → SQL 변환
- 쿼리 최적화 제안
- 부드러운 바운스/흔들기 모션

### 4. 검색 시스템
- **헤더 검색**: 전역 검색 with 드롭다운
- **사이드바 검색**: 트리 자동 확장
- 실시간 필터링 (전체/테이블/DB·스키마/쿼리)

### 5. 설정 모달
- 4개 탭 (외관, 에디터, 쿼리, 고급)
- LocalStorage 자동 저장
- 다크/라이트/자동 테마
- 폰트 크기, 탭 크기 조절
- 쿼리 타임아웃, 최대 행 수 설정

## 📝 코드 컨벤션

### 컴포넌트 구조
```typescript
// 1. Imports
import React, { useState } from 'react';
import { Icon } from 'lucide-react';
import { motion } from 'motion/react';
import { Type } from '../types';
import { CONSTANT } from '../constants';

// 2. Interface
interface ComponentProps {
  prop: Type;
}

// 3. Component
export function Component({ prop }: ComponentProps) {
  // 4. State
  const [state, setState] = useState();

  // 5. Handlers
  const handleAction = () => {};

  // 6. Render
  return <div>...</div>;
}
```

### 네이밍 컨벤션
- **Components**: PascalCase (`ConnectionModal`)
- **Functions**: camelCase (`handleSaveConnection`)
- **Constants**: UPPER_SNAKE_CASE (`DEFAULT_CONNECTIONS`)
- **Types**: PascalCase (`Connection`, `Query`)
- **Files**: PascalCase for components, camelCase for utils

## 🔧 유틸리티 함수

```typescript
// 날짜 포맷 (한국어)
formatDate(date: Date): string

// 숫자 포맷 (쉼표)
formatNumber(num: number): string

// 디바운스
debounce<T>(func: T, wait: number): Function

// SQL 검증
validateSql(sql: string): { valid: boolean; error?: string }
```

## 💾 로컬 스토리지

- `dataeye-settings`: 앱 설정
- `dataeye-connections`: 저장된 연결
- `dataeye-queries`: 저장된 쿼리

## 🎭 테마 시스템

다크/라이트 모드 자동 전환:
```typescript
const { isDark, toggleTheme } = useTheme();
```

Tailwind 다크 모드 클래스:
```tsx
className="bg-white dark:bg-[#252526]"
```

## 📱 반응형 디자인

- **Mobile**: 768px 미만
- **Tablet**: 768px - 1024px
- **Desktop**: 1024px 이상

Grid 시스템:
```tsx
className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4"
```

## 🔐 보안 고려사항

- 비밀번호는 UI에서만 사용, 저장 시 암호화 필요
- SQL Injection 방지를 위한 검증
- 위험한 쿼리 경고 (DROP, TRUNCATE, DELETE)

## 🚧 향후 개선사항

- [ ] 실제 데이터베이스 연결 구현
- [ ] 백엔드 API 통합
- [ ] 사용자 인증/권한 관리
- [ ] 쿼리 실행 이력 영구 저장
- [ ] 엑셀 export 기능
- [ ] 스키마 다이어그램 시각화
- [ ] 쿼리 성능 분석

## 📄 라이선스

MIT License

## 👥 기여자

프로젝트에 기여해주신 모든 분들께 감사드립니다!

---

**Made with ❤️ using React, TypeScript, and Motion**
