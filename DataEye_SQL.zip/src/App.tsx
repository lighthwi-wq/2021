import React from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { AppProvider, useApp } from './contexts/AppContext';
import { LoginPage } from './components/auth/LoginPage';
import { ProtectedRoute } from './components/common/ProtectedRoute';
import { AppSidebar } from './components/layout/AppSidebar';
import { Header } from './components/Header';
import { SqlEditorTabs } from './components/SqlEditorTabs';
import { FloatingAIChatBot } from './components/FloatingAIChatBot';
import { HomeView } from './components/HomeView';
import { QueryHistoryView } from './components/QueryHistoryView';
import { SavedQueriesView } from './components/SavedQueriesView';
import { SearchResultsView } from './components/SearchResultsView';
import { HelpModal } from './components/HelpModal';
import { ConfirmDialog } from './components/ConfirmDialog';
import { PageTransition } from './components/common/PageTransition';
import { motion } from 'motion/react';
import { Toaster } from 'sonner@2.0.3';

export default function App() {
  return (
    <AuthProvider>
      <AppProvider>
        <AppRouter />
        <Toaster position="top-right" richColors />
      </AppProvider>
    </AuthProvider>
  );
}

function AppRouter() {
  const { isAuthenticated } = useAuth();

  if (!isAuthenticated) {
    return <LoginPage />;
  }

  return (
    <ProtectedRoute>
      <AppContent />
    </ProtectedRoute>
  );
}

function AppContent() {
  const {
    currentView,
    setCurrentView,
    selectedTable,
    selectTable,
    externalQuery,
    insertQuery,
    searchResults,
    searchQuery,
    isHelpModalOpen,
    closeHelpModal,
    openHelpModal,
    isLogoutDialogOpen,
    closeLogoutDialog,
    openLogoutDialog,
    confirmLogout,
  } = useApp();

  const { logout } = useAuth();

  const handleLogout = () => {
    logout();
    closeLogoutDialog();
  };

  const handleSearchResultClick = (result: any) => {
    // 검색 결과 클릭 시 처리
    console.log('Search result clicked:', result);
    if (result.type === 'table') {
      selectTable(result.title);
      setCurrentView('editor');
    } else if (result.type === 'query') {
      insertQuery(result.title);
    }
  };

  return (
    <motion.div 
      className="flex h-screen bg-gray-50 overflow-hidden"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      {/* Sidebar */}
      <AppSidebar
        onTableSelect={selectTable}
        selectedTable={selectedTable}
        onViewChange={setCurrentView}
        currentView={currentView}
        onHelpClick={openHelpModal}
        onLogoutClick={openLogoutDialog}
      />

      {/* Main Content Area */}
      <div className="flex flex-col flex-1 overflow-hidden">
        <Header />
        
        {/* View Router with Page Transitions */}
        <PageTransition viewKey={currentView}>
          {currentView === 'home' && <HomeView />}
          {currentView === 'history' && <QueryHistoryView onQuerySelect={insertQuery} />}
          {currentView === 'saved' && <SavedQueriesView onQuerySelect={insertQuery} />}
          {currentView === 'search' && (
            <SearchResultsView 
              results={searchResults} 
              searchQuery={searchQuery}
              onResultClick={handleSearchResultClick}
            />
          )}
          {currentView === 'editor' && (
            <SqlEditorTabs selectedTable={selectedTable} externalQuery={externalQuery} />
          )}
        </PageTransition>
      </div>

      {/* Floating Components */}
      <FloatingAIChatBot onQueryInsert={insertQuery} />

      {/* Modals */}
      <HelpModal isOpen={isHelpModalOpen} onClose={closeHelpModal} />
      
      <ConfirmDialog
        isOpen={isLogoutDialogOpen}
        title="로그아웃"
        message="정말 로그아웃 하시겠습니까?"
        confirmText="로그아웃"
        cancelText="취소"
        onConfirm={handleLogout}
        onCancel={closeLogoutDialog}
        danger
      />
    </motion.div>
  );
}