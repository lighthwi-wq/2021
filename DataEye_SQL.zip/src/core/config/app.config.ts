/**
 * 애플리케이션 전역 설정
 */

export const APP_CONFIG = {
  name: 'DB Manager Pro',
  version: '1.0.0',
  description: '엔터프라이즈급 데이터베이스 관리 도구',
  
  // UI 설정
  ui: {
    defaultFontSize: 14,
    maxSidebarWidth: 280,
    minSidebarWidth: 64,
    editorHeight: 400,
    maxTabsCount: 10,
  },
  
  // 에디터 설정
  editor: {
    theme: 'vs-light',
    fontSize: 14,
    lineNumbers: true,
    minimap: { enabled: true },
    wordWrap: 'on',
    tabSize: 2,
  },
  
  // 쿼리 설정
  query: {
    maxHistoryCount: 100,
    defaultLimit: 1000,
    timeout: 30000, // 30초
  },
  
  // 애니메이션 설정
  animation: {
    duration: 0.3,
    easing: 'easeInOut',
  },
} as const;

export type AppConfig = typeof APP_CONFIG;
