/**
 * 데이터베이스 연결 설정
 */

export const DATABASE_TYPES = {
  POSTGRESQL: 'postgresql',
  MYSQL: 'mysql',
  MONGODB: 'mongodb',
  MARIADB: 'mariadb',
  ORACLE: 'oracle',
  MSSQL: 'mssql',
} as const;

export type DatabaseType = typeof DATABASE_TYPES[keyof typeof DATABASE_TYPES];

export const DATABASE_DEFAULT_PORTS: Record<DatabaseType, number> = {
  [DATABASE_TYPES.POSTGRESQL]: 5432,
  [DATABASE_TYPES.MYSQL]: 3306,
  [DATABASE_TYPES.MONGODB]: 27017,
  [DATABASE_TYPES.MARIADB]: 3306,
  [DATABASE_TYPES.ORACLE]: 1521,
  [DATABASE_TYPES.MSSQL]: 1433,
};

export const DATABASE_ICONS: Record<DatabaseType, string> = {
  [DATABASE_TYPES.POSTGRESQL]: '🐘',
  [DATABASE_TYPES.MYSQL]: '🐬',
  [DATABASE_TYPES.MONGODB]: '🍃',
  [DATABASE_TYPES.MARIADB]: '🦭',
  [DATABASE_TYPES.ORACLE]: '🔶',
  [DATABASE_TYPES.MSSQL]: '📘',
};

export const DATABASE_COLORS: Record<DatabaseType, string> = {
  [DATABASE_TYPES.POSTGRESQL]: '#336791',
  [DATABASE_TYPES.MYSQL]: '#4479A1',
  [DATABASE_TYPES.MONGODB]: '#47A248',
  [DATABASE_TYPES.MARIADB]: '#003545',
  [DATABASE_TYPES.ORACLE]: '#F80000',
  [DATABASE_TYPES.MSSQL]: '#CC2927',
};
