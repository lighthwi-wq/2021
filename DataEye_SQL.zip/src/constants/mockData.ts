import { Query, SearchResult } from '../types';

export const MOCK_QUERY_HISTORY: Query[] = [
  {
    id: 'query-1',
    title: '사용자 목록 조회',
    sql: 'SELECT * FROM users WHERE created_at > NOW() - INTERVAL \'7 days\'',
    timestamp: new Date(Date.now() - 2 * 60 * 1000),
    duration: '0.45s',
    rows: 247,
    status: 'success',
    connectionId: 'conn-1'
  },
  {
    id: 'query-2',
    title: '주문 통계',
    sql: 'SELECT COUNT(*) as total, status FROM orders GROUP BY status',
    timestamp: new Date(Date.now() - 15 * 60 * 1000),
    duration: '0.23s',
    rows: 5,
    status: 'success',
    connectionId: 'conn-1'
  },
  {
    id: 'query-3',
    title: '제품 업데이트',
    sql: 'UPDATE products SET price = price * 1.1 WHERE category = \'electronics\'',
    timestamp: new Date(Date.now() - 60 * 60 * 1000),
    duration: '1.2s',
    rows: 145,
    status: 'success',
    connectionId: 'conn-1'
  }
];

export const MOCK_SAVED_QUERIES: Query[] = [
  {
    id: 'saved-1',
    title: '월별 매출 분석',
    sql: 'SELECT DATE_TRUNC(\'month\', created_at) as month, SUM(amount) as revenue FROM orders GROUP BY month ORDER BY month DESC',
    timestamp: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
    status: 'success',
    connectionId: 'conn-1'
  },
  {
    id: 'saved-2',
    title: '활�� 사용자 목록',
    sql: 'SELECT * FROM users WHERE last_login > NOW() - INTERVAL \'30 days\' ORDER BY last_login DESC',
    timestamp: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
    status: 'success',
    connectionId: 'conn-1'
  }
];

export const MOCK_NOTIFICATIONS = [
  {
    id: 'notif-1',
    type: 'success' as const,
    title: '쿼리 실행 완료',
    message: '사용자 목록 조회가 성공적으로 완료되었습니다. (247개 행)',
    timestamp: new Date(Date.now() - 5 * 60 * 1000),
    read: false
  },
  {
    id: 'notif-2',
    type: 'warning' as const,
    title: '느린 쿼리 감지',
    message: '최근 실행된 쿼리가 3초 이상 소요되었습니다. 인덱스 최적화를 고려해보세요.',
    timestamp: new Date(Date.now() - 15 * 60 * 1000),
    read: false
  },
  {
    id: 'notif-3',
    type: 'error' as const,
    title: '연결 오류',
    message: 'MongoDB 스테이징 서버에 연결할 수 없습니다. 네트워크 상태를 확인해주세요.',
    timestamp: new Date(Date.now() - 30 * 60 * 1000),
    read: false
  },
  {
    id: 'notif-4',
    type: 'info' as const,
    title: '시스템 업데이트',
    message: '새로운 버전(v2.1.0)이 출시되었습니다. 업데이트하시겠습니까?',
    timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
    read: true,
    actionLabel: '업데이트',
    actionUrl: '#'
  },
  {
    id: 'notif-5',
    type: 'success' as const,
    title: '백업 완료',
    message: 'PostgreSQL 프로덕션 데이터베이스의 자동 백업이 완료되었습니다.',
    timestamp: new Date(Date.now() - 3 * 60 * 60 * 1000),
    read: true
  }
];

export const MOCK_SEARCH_DATA: SearchResult[] = [
  // 데이터베이스
  { 
    id: 'db-1',
    type: 'database', 
    title: 'PostgreSQL 프로덕션', 
    description: '프로덕션 환경의 주 데이터베이스 - 사용자, 주문, 제품 데이터 관리',
    subtitle: 'localhost:5432',
    metadata: {
      database: 'PostgreSQL',
      lastModified: '2024-11-20'
    }
  },
  { 
    id: 'db-2',
    type: 'database', 
    title: 'MySQL 개발', 
    description: '개발 환경 데이터베이스 - 테스트 및 개발용',
    subtitle: 'localhost:3306',
    metadata: {
      database: 'MySQL',
      lastModified: '2024-11-22'
    }
  },
  { 
    id: 'db-3',
    type: 'database', 
    title: 'MongoDB 스테이징', 
    description: '스테이징 환경 NoSQL 데이터베이스 - 로그 및 캐시 관리',
    subtitle: 'localhost:27017',
    metadata: {
      database: 'MongoDB',
      lastModified: '2024-11-25'
    }
  },
  
  // 스키마
  { 
    id: 'schema-1',
    type: 'schema', 
    title: 'public', 
    description: 'PostgreSQL 기본 공개 스키마 - 주요 비즈니스 데이터',
    subtitle: 'PostgreSQL 프로덕션', 
    path: 'PostgreSQL 프로덕션 > public',
    metadata: {
      database: 'PostgreSQL 프로덕션',
      lastModified: '2024-11-20'
    }
  },
  { 
    id: 'schema-2',
    type: 'schema', 
    title: 'analytics', 
    description: '분석 데이터 스키마 - 이벤트 추적 및 통계',
    subtitle: 'PostgreSQL 프로덕션', 
    path: 'PostgreSQL 프로덕션 > analytics',
    metadata: {
      database: 'PostgreSQL 프로덕션',
      lastModified: '2024-11-18'
    }
  },
  { 
    id: 'schema-3',
    type: 'schema', 
    title: 'main', 
    description: 'MySQL 주 스키마 - 고객 및 재고 관리',
    subtitle: 'MySQL 개발', 
    path: 'MySQL 개발 > main',
    metadata: {
      database: 'MySQL 개발',
      lastModified: '2024-11-22'
    }
  },
  { 
    id: 'schema-4',
    type: 'schema', 
    title: 'app', 
    description: 'MongoDB 애플리케이션 스키마 - 로그 및 메트릭',
    subtitle: 'MongoDB 스테이징', 
    path: 'MongoDB 스테이징 > app',
    metadata: {
      database: 'MongoDB 스테이징',
      lastModified: '2024-11-25'
    }
  },
  
  // 테이블 - public 스키마
  { 
    id: 'table-1',
    type: 'table', 
    title: 'users', 
    description: '사용자 정보 테이블 - 이메일, 이름, 권한 등',
    subtitle: 'public 스키마', 
    path: 'PostgreSQL 프로덕션 > public > users',
    metadata: {
      database: 'PostgreSQL 프로덕션',
      lastModified: '2024-11-25',
      rows: '15,847',
      columns: '12'
    }
  },
  { 
    id: 'table-2',
    type: 'table', 
    title: 'products', 
    description: '제품 정보 테이블 - 상품명, 가격, 재고 등',
    subtitle: 'public 스키마', 
    path: 'PostgreSQL 프로덕션 > public > products',
    metadata: {
      database: 'PostgreSQL 프로덕션',
      lastModified: '2024-11-24',
      rows: '3,542',
      columns: '18'
    }
  },
  { 
    id: 'table-3',
    type: 'table', 
    title: 'orders', 
    description: '주문 정보 테이블 - 주문 상태, 금액, 배송 정보',
    subtitle: 'public 스키마', 
    path: 'PostgreSQL 프로덕션 > public > orders',
    metadata: {
      database: 'PostgreSQL 프로덕션',
      lastModified: '2024-11-26',
      rows: '45,231',
      columns: '15'
    }
  },
  { 
    id: 'table-4',
    type: 'table', 
    title: 'categories', 
    description: '상품 카테고리 테이블 - 분류 체계 관리',
    subtitle: 'public 스키마', 
    path: 'PostgreSQL 프로덕션 > public > categories',
    metadata: {
      database: 'PostgreSQL 프로덕션',
      lastModified: '2024-11-10',
      rows: '87',
      columns: '8'
    }
  },
  { 
    id: 'table-5',
    type: 'table', 
    title: 'payments', 
    description: '결제 정보 테이블 - 결제 수단, 상태, 거래 내역',
    subtitle: 'public 스키마', 
    path: 'PostgreSQL 프로덕션 > public > payments',
    metadata: {
      database: 'PostgreSQL 프로덕션',
      lastModified: '2024-11-26',
      rows: '38,942',
      columns: '14'
    }
  },
  { 
    id: 'table-6',
    type: 'table', 
    title: 'reviews', 
    description: '상품 리뷰 테이블 - 평점, 코멘트, 작성자',
    subtitle: 'public 스키마', 
    path: 'PostgreSQL 프로덕션 > public > reviews',
    metadata: {
      database: 'PostgreSQL 프로덕션',
      lastModified: '2024-11-25',
      rows: '8,764',
      columns: '10'
    }
  },
  { 
    id: 'table-7',
    type: 'table', 
    title: 'user_sessions', 
    description: '사용자 세션 테이블 - 로그인 기록 및 세션 관리',
    subtitle: 'public 스키마', 
    path: 'PostgreSQL 프로덕션 > public > user_sessions',
    metadata: {
      database: 'PostgreSQL 프로덕션',
      lastModified: '2024-11-26',
      rows: '124,532',
      columns: '9'
    }
  },
  { 
    id: 'table-8',
    type: 'table', 
    title: 'shipping_addresses', 
    description: '배송지 정보 테이블 - 주소, 연락처 관리',
    subtitle: 'public 스키마', 
    path: 'PostgreSQL 프로덕션 > public > shipping_addresses',
    metadata: {
      database: 'PostgreSQL 프로덕션',
      lastModified: '2024-11-23',
      rows: '22,145',
      columns: '11'
    }
  },
  
  // 테이블 - analytics 스키마
  { 
    id: 'table-9',
    type: 'table', 
    title: 'events', 
    description: '이벤트 추적 테이블 - 사용자 행동 분석',
    subtitle: 'analytics 스키마', 
    path: 'PostgreSQL 프로덕션 > analytics > events',
    metadata: {
      database: 'PostgreSQL 프로덕션',
      lastModified: '2024-11-26',
      rows: '1,245,867',
      columns: '16'
    }
  },
  { 
    id: 'table-10',
    type: 'table', 
    title: 'sessions', 
    description: '세션 분석 테이블 - 방문자 추적 및 통계',
    subtitle: 'analytics 스키마', 
    path: 'PostgreSQL 프로덕션 > analytics > sessions',
    metadata: {
      database: 'PostgreSQL 프로덕션',
      lastModified: '2024-11-26',
      rows: '542,321',
      columns: '13'
    }
  },
  { 
    id: 'table-11',
    type: 'table', 
    title: 'conversions', 
    description: '전환율 분석 테이블 - 구매 전환 추적',
    subtitle: 'analytics 스키마', 
    path: 'PostgreSQL 프로덕션 > analytics > conversions',
    metadata: {
      database: 'PostgreSQL 프로덕션',
      lastModified: '2024-11-25',
      rows: '34,781',
      columns: '12'
    }
  },
  { 
    id: 'table-12',
    type: 'table', 
    title: 'page_views', 
    description: '페이지 뷰 테이블 - 페이지별 조회수 통계',
    subtitle: 'analytics 스키마', 
    path: 'PostgreSQL 프로덕션 > analytics > page_views',
    metadata: {
      database: 'PostgreSQL 프로덕션',
      lastModified: '2024-11-26',
      rows: '2,145,632',
      columns: '10'
    }
  },
  
  // 테이블 - MySQL 개발
  { 
    id: 'table-13',
    type: 'table', 
    title: 'customers', 
    description: '고객 정보 테이블 - 개발 환경 테스트 데이터',
    subtitle: 'main 스키마', 
    path: 'MySQL 개발 > main > customers',
    metadata: {
      database: 'MySQL 개발',
      lastModified: '2024-11-22',
      rows: '856',
      columns: '11'
    }
  },
  { 
    id: 'table-14',
    type: 'table', 
    title: 'inventory', 
    description: '재고 관리 테이블 - 입출고 내역 및 재고 현황',
    subtitle: 'main 스키마', 
    path: 'MySQL 개발 > main > inventory',
    metadata: {
      database: 'MySQL 개발',
      lastModified: '2024-11-21',
      rows: '1,245',
      columns: '14'
    }
  },
  { 
    id: 'table-15',
    type: 'table', 
    title: 'suppliers', 
    description: '공급업체 정보 테이블 - 협력사 관리',
    subtitle: 'main 스키마', 
    path: 'MySQL 개발 > main > suppliers',
    metadata: {
      database: 'MySQL 개발',
      lastModified: '2024-11-15',
      rows: '342',
      columns: '9'
    }
  },
  { 
    id: 'table-16',
    type: 'table', 
    title: 'warehouses', 
    description: '창고 정보 테이블 - 물류 센터 관리',
    subtitle: 'main 스키마', 
    path: 'MySQL 개발 > main > warehouses',
    metadata: {
      database: 'MySQL 개발',
      lastModified: '2024-11-18',
      rows: '28',
      columns: '12'
    }
  },
  
  // 테이블 - MongoDB 스테이징
  { 
    id: 'table-17',
    type: 'table', 
    title: 'logs', 
    description: '애플리케이션 로그 컬렉션 - 에러 및 디버그 로그',
    subtitle: 'app 스키마', 
    path: 'MongoDB 스테이징 > app > logs',
    metadata: {
      database: 'MongoDB 스테이징',
      lastModified: '2024-11-26',
      rows: '3,456,789',
      columns: '8'
    }
  },
  { 
    id: 'table-18',
    type: 'table', 
    title: 'metrics', 
    description: '성능 메트릭 컬렉션 - 시스템 모니터링',
    subtitle: 'app 스키마', 
    path: 'MongoDB 스테이징 > app > metrics',
    metadata: {
      database: 'MongoDB 스테이징',
      lastModified: '2024-11-26',
      rows: '876,543',
      columns: '15'
    }
  },
  { 
    id: 'table-19',
    type: 'table', 
    title: 'cache', 
    description: '캐시 데이터 컬렉션 - 임시 데이터 저장소',
    subtitle: 'app 스키마', 
    path: 'MongoDB 스테이징 > app > cache',
    metadata: {
      database: 'MongoDB 스테이징',
      lastModified: '2024-11-26',
      rows: '45,678',
      columns: '6'
    }
  },
  
  // 저장된 쿼리
  ...MOCK_SAVED_QUERIES.map((q, index) => ({
    id: `query-saved-${index + 1}`,
    type: 'query' as const,
    title: q.title,
    description: q.sql,
    subtitle: q.sql.substring(0, 50) + '...',
    path: '저장된 쿼리',
    metadata: {
      database: 'PostgreSQL 프로덕션',
      lastModified: q.timestamp.toISOString().split('T')[0]
    }
  }))
];