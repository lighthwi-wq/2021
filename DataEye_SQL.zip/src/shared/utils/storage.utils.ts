/**
 * 로컬 스토리지 유틸리티 함수
 */

const STORAGE_PREFIX = 'dbmanager_';

/**
 * 로컬 스토리지에 데이터 저장
 */
export function setStorageItem<T>(key: string, value: T): void {
  try {
    const serializedValue = JSON.stringify(value);
    localStorage.setItem(`${STORAGE_PREFIX}${key}`, serializedValue);
  } catch (error) {
    console.error(`Failed to save to localStorage: ${key}`, error);
  }
}

/**
 * 로컬 스토리지에서 데이터 가져오기
 */
export function getStorageItem<T>(key: string, defaultValue?: T): T | null {
  try {
    const item = localStorage.getItem(`${STORAGE_PREFIX}${key}`);
    if (item === null) return defaultValue || null;
    return JSON.parse(item) as T;
  } catch (error) {
    console.error(`Failed to read from localStorage: ${key}`, error);
    return defaultValue || null;
  }
}

/**
 * 로컬 스토리지에서 데이터 제거
 */
export function removeStorageItem(key: string): void {
  try {
    localStorage.removeItem(`${STORAGE_PREFIX}${key}`);
  } catch (error) {
    console.error(`Failed to remove from localStorage: ${key}`, error);
  }
}

/**
 * 로컬 스토리지 전체 초기화
 */
export function clearStorage(): void {
  try {
    const keys = Object.keys(localStorage);
    keys.forEach(key => {
      if (key.startsWith(STORAGE_PREFIX)) {
        localStorage.removeItem(key);
      }
    });
  } catch (error) {
    console.error('Failed to clear localStorage', error);
  }
}

/**
 * 세션 스토리지에 데이터 저장
 */
export function setSessionItem<T>(key: string, value: T): void {
  try {
    const serializedValue = JSON.stringify(value);
    sessionStorage.setItem(`${STORAGE_PREFIX}${key}`, serializedValue);
  } catch (error) {
    console.error(`Failed to save to sessionStorage: ${key}`, error);
  }
}

/**
 * 세션 스토리지에서 데이터 가져오기
 */
export function getSessionItem<T>(key: string, defaultValue?: T): T | null {
  try {
    const item = sessionStorage.getItem(`${STORAGE_PREFIX}${key}`);
    if (item === null) return defaultValue || null;
    return JSON.parse(item) as T;
  } catch (error) {
    console.error(`Failed to read from sessionStorage: ${key}`, error);
    return defaultValue || null;
  }
}
