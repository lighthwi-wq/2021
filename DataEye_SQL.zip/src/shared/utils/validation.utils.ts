/**
 * 유효성 검사 유틸리티 함수
 */

/**
 * 이메일 유효성 검사
 */
export function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

/**
 * 비밀번호 강도 검사 (최소 8자, 대소문자, 숫자 포함)
 */
export function isStrongPassword(password: string): boolean {
  if (password.length < 8) return false;
  
  const hasUpperCase = /[A-Z]/.test(password);
  const hasLowerCase = /[a-z]/.test(password);
  const hasNumber = /\d/.test(password);
  
  return hasUpperCase && hasLowerCase && hasNumber;
}

/**
 * SQL 쿼리 기본 검증
 */
export function isValidSqlQuery(query: string): boolean {
  if (!query || query.trim().length === 0) return false;
  
  const trimmedQuery = query.trim().toUpperCase();
  const validKeywords = ['SELECT', 'INSERT', 'UPDATE', 'DELETE', 'CREATE', 'DROP', 'ALTER', 'WITH'];
  
  return validKeywords.some(keyword => trimmedQuery.startsWith(keyword));
}

/**
 * SQL 인젝션 기본 검사 (간단한 버전)
 */
export function hasSqlInjectionRisk(input: string): boolean {
  const dangerousPatterns = [
    /(\b(UNION|SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|ALTER)\b.*\b(FROM|INTO|TABLE|DATABASE)\b)/i,
    /[';]--/,
    /\/\*.*\*\//,
  ];
  
  return dangerousPatterns.some(pattern => pattern.test(input));
}

/**
 * 포트 번호 유효성 검사
 */
export function isValidPort(port: number): boolean {
  return Number.isInteger(port) && port > 0 && port <= 65535;
}

/**
 * 호스트명 유효성 검사
 */
export function isValidHost(host: string): boolean {
  // localhost, IP 주소, 도메인 허용
  const localhostRegex = /^localhost$/i;
  const ipRegex = /^(\d{1,3}\.){3}\d{1,3}$/;
  const domainRegex = /^[a-zA-Z0-9][a-zA-Z0-9-]{0,61}[a-zA-Z0-9]?(\.[a-zA-Z0-9][a-zA-Z0-9-]{0,61}[a-zA-Z0-9]?)*$/;
  
  return localhostRegex.test(host) || ipRegex.test(host) || domainRegex.test(host);
}

/**
 * 빈 값 체크
 */
export function isEmpty(value: any): boolean {
  if (value === null || value === undefined) return true;
  if (typeof value === 'string') return value.trim().length === 0;
  if (Array.isArray(value)) return value.length === 0;
  if (typeof value === 'object') return Object.keys(value).length === 0;
  return false;
}
