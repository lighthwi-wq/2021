/**
 * SQL 쿼리 관련 비즈니스 로직
 */

import { QueryResult, QueryHistory } from '../types/query.types';
import { formatDuration } from '../utils/format.utils';

export class QueryService {
  /**
   * SQL 쿼리 실행 (모의 구현)
   */
  static async executeQuery(query: string, connectionId: string): Promise<QueryResult> {
    // 실제 구현에서는 백엔드 API를 호출
    const startTime = Date.now();
    
    // 모의 지연
    await new Promise(resolve => setTimeout(resolve, 500 + Math.random() * 1000));
    
    const endTime = Date.now();
    const duration = endTime - startTime;
    
    // 모의 데이터 생성
    const mockData = this.generateMockData(query);
    
    return {
      columns: mockData.columns,
      rows: mockData.rows,
      rowCount: mockData.rows.length,
      duration,
    };
  }
  
  /**
   * 쿼리 문법 검증
   */
  static validateQuery(query: string): { isValid: boolean; errors: string[] } {
    const errors: string[] = [];
    const trimmedQuery = query.trim();
    
    if (!trimmedQuery) {
      errors.push('쿼리가 비어있습니다.');
      return { isValid: false, errors };
    }
    
    // 기본적인 SQL 키워드 체크
    const validKeywords = /^(SELECT|INSERT|UPDATE|DELETE|CREATE|DROP|ALTER|WITH|EXPLAIN)/i;
    if (!validKeywords.test(trimmedQuery)) {
      errors.push('유효한 SQL 키워드로 시작하지 않습니다.');
    }
    
    // 괄호 매칭 체크
    const openParens = (trimmedQuery.match(/\(/g) || []).length;
    const closeParens = (trimmedQuery.match(/\)/g) || []).length;
    if (openParens !== closeParens) {
      errors.push('괄호가 올바르게 닫히지 않았습니다.');
    }
    
    return {
      isValid: errors.length === 0,
      errors,
    };
  }
  
  /**
   * 쿼리 히스토리에 추가
   */
  static addToHistory(
    query: string,
    connectionId: string,
    result: QueryResult | null,
    error?: string
  ): QueryHistory {
    return {
      id: Date.now().toString(),
      query,
      connectionId,
      executedAt: new Date(),
      duration: result?.duration || 0,
      rowCount: result?.rowCount || 0,
      status: error ? 'error' : 'success',
      error,
    };
  }
  
  /**
   * 모의 데이터 생성
   */
  private static generateMockData(query: string): { columns: string[]; rows: Record<string, any>[] } {
    const queryUpper = query.toUpperCase();
    
    // SELECT 쿼리인 경우
    if (queryUpper.includes('SELECT')) {
      return {
        columns: ['id', 'name', 'email', 'created_at'],
        rows: Array.from({ length: 10 }, (_, i) => ({
          id: i + 1,
          name: `사용자 ${i + 1}`,
          email: `user${i + 1}@example.com`,
          created_at: new Date(Date.now() - Math.random() * 10000000000).toISOString(),
        })),
      };
    }
    
    // INSERT/UPDATE/DELETE 쿼리인 경우
    return {
      columns: ['affected_rows'],
      rows: [{ affected_rows: Math.floor(Math.random() * 10) + 1 }],
    };
  }
  
  /**
   * 쿼리 포맷팅
   */
  static formatQuery(query: string): string {
    const keywords = [
      'SELECT', 'FROM', 'WHERE', 'JOIN', 'LEFT JOIN', 'RIGHT JOIN', 'INNER JOIN',
      'GROUP BY', 'ORDER BY', 'HAVING', 'LIMIT', 'OFFSET',
      'INSERT INTO', 'VALUES', 'UPDATE', 'SET', 'DELETE FROM',
    ];
    
    let formatted = query;
    keywords.forEach(keyword => {
      const regex = new RegExp(`\\b${keyword}\\b`, 'gi');
      formatted = formatted.replace(regex, `\n${keyword}`);
    });
    
    return formatted.trim();
  }
  
  /**
   * 쿼리에서 테이블명 추출
   */
  static extractTableNames(query: string): string[] {
    const tableNames: string[] = [];
    const fromMatch = query.match(/FROM\s+([a-zA-Z0-9_]+)/gi);
    const joinMatch = query.match(/JOIN\s+([a-zA-Z0-9_]+)/gi);
    
    if (fromMatch) {
      fromMatch.forEach(match => {
        const table = match.replace(/FROM\s+/i, '').trim();
        tableNames.push(table);
      });
    }
    
    if (joinMatch) {
      joinMatch.forEach(match => {
        const table = match.replace(/JOIN\s+/i, '').trim();
        tableNames.push(table);
      });
    }
    
    return [...new Set(tableNames)];
  }
}
