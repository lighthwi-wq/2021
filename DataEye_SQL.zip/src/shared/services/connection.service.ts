/**
 * 데이터베이스 연결 관련 비즈니스 로직
 */

import { DatabaseConnection, SchemaNode } from '../types/database.types';
import { DATABASE_DEFAULT_PORTS } from '../../core/config/database.config';

export class ConnectionService {
  /**
   * 데이터베이스 연결 테스트
   */
  static async testConnection(connection: Omit<DatabaseConnection, 'id' | 'isConnected' | 'createdAt' | 'updatedAt'>): Promise<{
    success: boolean;
    message: string;
    duration: number;
  }> {
    const startTime = Date.now();
    
    // 유효성 검사
    const validation = this.validateConnection(connection);
    if (!validation.isValid) {
      return {
        success: false,
        message: validation.errors.join(', '),
        duration: Date.now() - startTime,
      };
    }
    
    // 모의 연결 테스트 (실제로는 백엔드 API 호출)
    await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 500));
    
    const duration = Date.now() - startTime;
    const success = Math.random() > 0.1; // 90% 성공률
    
    return {
      success,
      message: success ? '연결 성공' : '연결 실패: 호스트에 연결할 수 없습니다.',
      duration,
    };
  }
  
  /**
   * 연결 정보 유효성 검사
   */
  static validateConnection(connection: Partial<DatabaseConnection>): {
    isValid: boolean;
    errors: string[];
  } {
    const errors: string[] = [];
    
    if (!connection.name?.trim()) {
      errors.push('연결 이름을 입력해주세요.');
    }
    
    if (!connection.type) {
      errors.push('데이터베이스 타입을 선택해주세요.');
    }
    
    if (!connection.host?.trim()) {
      errors.push('호스트를 입력해주세요.');
    }
    
    if (!connection.port || connection.port < 1 || connection.port > 65535) {
      errors.push('유효한 포트 번호를 입력해주세요. (1-65535)');
    }
    
    if (!connection.database?.trim()) {
      errors.push('데이터베이스 이름을 입력해주세요.');
    }
    
    if (!connection.username?.trim()) {
      errors.push('사용자명을 입력해주세요.');
    }
    
    return {
      isValid: errors.length === 0,
      errors,
    };
  }
  
  /**
   * 스키마 트리 로드 (모의 구현)
   */
  static async loadSchemaTree(connectionId: string): Promise<SchemaNode[]> {
    // 모의 지연
    await new Promise(resolve => setTimeout(resolve, 500));
    
    // 모의 스키마 데이터
    return [
      {
        id: '1',
        name: 'public',
        type: 'schema',
        children: [
          {
            id: '1-1',
            name: 'users',
            type: 'table',
            children: [
              {
                id: '1-1-1',
                name: 'id',
                type: 'column',
                metadata: {
                  dataType: 'INTEGER',
                  nullable: false,
                  primaryKey: true,
                },
              },
              {
                id: '1-1-2',
                name: 'name',
                type: 'column',
                metadata: {
                  dataType: 'VARCHAR(100)',
                  nullable: false,
                },
              },
              {
                id: '1-1-3',
                name: 'email',
                type: 'column',
                metadata: {
                  dataType: 'VARCHAR(255)',
                  nullable: false,
                },
              },
              {
                id: '1-1-4',
                name: 'created_at',
                type: 'column',
                metadata: {
                  dataType: 'TIMESTAMP',
                  nullable: false,
                  defaultValue: 'CURRENT_TIMESTAMP',
                },
              },
            ],
          },
          {
            id: '1-2',
            name: 'orders',
            type: 'table',
            children: [
              {
                id: '1-2-1',
                name: 'id',
                type: 'column',
                metadata: {
                  dataType: 'INTEGER',
                  nullable: false,
                  primaryKey: true,
                },
              },
              {
                id: '1-2-2',
                name: 'user_id',
                type: 'column',
                metadata: {
                  dataType: 'INTEGER',
                  nullable: false,
                  foreignKey: true,
                },
              },
              {
                id: '1-2-3',
                name: 'total',
                type: 'column',
                metadata: {
                  dataType: 'DECIMAL(10,2)',
                  nullable: false,
                },
              },
            ],
          },
          {
            id: '1-3',
            name: 'products',
            type: 'table',
          },
        ],
      },
    ];
  }
  
  /**
   * 연결 문자열 생성
   */
  static buildConnectionString(connection: DatabaseConnection): string {
    switch (connection.type) {
      case 'postgresql':
        return `postgresql://${connection.username}:****@${connection.host}:${connection.port}/${connection.database}`;
      case 'mysql':
        return `mysql://${connection.username}:****@${connection.host}:${connection.port}/${connection.database}`;
      case 'mongodb':
        return `mongodb://${connection.username}:****@${connection.host}:${connection.port}/${connection.database}`;
      default:
        return '';
    }
  }
  
  /**
   * 기본 포트 가져오기
   */
  static getDefaultPort(type: string): number {
    return DATABASE_DEFAULT_PORTS[type as keyof typeof DATABASE_DEFAULT_PORTS] || 5432;
  }
}
