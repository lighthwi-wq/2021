/**
 * 데이터베이스 관련 타입 정의
 */

import { DatabaseType } from '../../core/config/database.config';

export interface DatabaseConnection {
  id: string;
  name: string;
  type: DatabaseType;
  host: string;
  port: number;
  database: string;
  username: string;
  password: string;
  isConnected: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface SchemaNode {
  id: string;
  name: string;
  type: 'database' | 'schema' | 'table' | 'view' | 'column' | 'function' | 'procedure';
  children?: SchemaNode[];
  metadata?: {
    dataType?: string;
    nullable?: boolean;
    primaryKey?: boolean;
    foreignKey?: boolean;
    defaultValue?: string;
  };
}

export interface TableInfo {
  name: string;
  schema: string;
  rowCount: number;
  size: string;
  createdAt: Date;
}

export interface ColumnInfo {
  name: string;
  dataType: string;
  nullable: boolean;
  primaryKey: boolean;
  foreignKey: boolean;
  defaultValue?: string;
}
