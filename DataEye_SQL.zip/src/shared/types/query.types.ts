/**
 * SQL 쿼리 관련 타입 정의
 */

export interface SavedQuery {
  id: string;
  name: string;
  query: string;
  description?: string;
  folder?: string;
  tags: string[];
  createdAt: Date;
  updatedAt: Date;
}

export interface QueryHistory {
  id: string;
  query: string;
  connectionId: string;
  executedAt: Date;
  duration: number;
  rowCount: number;
  status: 'success' | 'error';
  error?: string;
}

export interface QueryResult {
  columns: string[];
  rows: Record<string, any>[];
  rowCount: number;
  duration: number;
  affectedRows?: number;
}

export interface QueryTab {
  id: string;
  title: string;
  content: string;
  connectionId?: string;
  isActive: boolean;
  isDirty: boolean;
}

export type QueryExecutionStatus = 'idle' | 'running' | 'success' | 'error';

export interface QueryExecution {
  id: string;
  query: string;
  status: QueryExecutionStatus;
  result?: QueryResult;
  error?: string;
  startTime: Date;
  endTime?: Date;
}
