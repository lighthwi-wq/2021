# DataEye SQL - 아키텍처 문서

## 🏗️ 프로젝트 구조

```
/
├── components/
│   ├── common/                 # 공통 컴포넌트
│   │   ├── AnimatedCard.tsx    # 애니메이션 카드 래퍼
│   │   ├── PageTransition.tsx  # 페이지 전환 애니메이션
│   │   └── LoadingSkeleton.tsx # 로딩 스켈레톤
│   │
│   ├── features/               # 기능별 컴포넌트
│   │   └── home/
│   │       ├── StatCard.tsx    # 통계 카드
│   │       └── ChartCard.tsx   # 차트 카드
│   │
│   ├── layout/                 # 레이아웃 컴포넌트
│   │   └── AppSidebar.tsx      # 메인 사이드바
│   │
│   ├── modals/                 # 모달 컴포넌트
│   │   └── SettingsModal.tsx
│   │
│   ├── ui/                     # UI 라이브러리
│   │   └── ...                 # shadcn/ui 컴포넌트들
│   │
│   └── ...                     # 기타 컴포넌트들
│
├── contexts/                   # React Context
│   └── AppContext.tsx          # 앱 전역 상태 관리
│
├── hooks/                      # 커스텀 훅
│   ├── useLocalStorage.ts
│   ├── useDisclosure.ts        # 모달/드로어 상태 관리
│   ├── useScrollAnimation.ts   # 스크롤 애니메이션
│   └── useMagneticEffect.ts    # 자석 효과
│
├── lib/                        # 유틸리티 & 헬퍼
│   ├── animations/
│   │   └── variants.ts         # Motion 애니메이션 variants
│   └── ...
│
├── constants/                  # 상수 정의
│   ├── database.ts
│   ├── mockData.ts
│   └── sqlAutocomplete.ts
│
├── types/                      # TypeScript 타입
│   ├── index.ts
│   └── autocomplete.ts
│
├── utils/                      # 유틸리티 함수
│   ├── helpers.ts
│   └── sqlContext.ts
│
└── styles/
    └── globals.css             # 전역 스타일
```

## 🎨 디자인 패턴

### 1. **Context API 패턴**
전역 상태 관리를 위해 React Context API 사용:
```tsx
// AppContext 사용 예시
const { currentView, setCurrentView, insertQuery } = useApp();
```

### 2. **Compound Components 패턴**
재사용 가능한 컴포넌트 구조:
```tsx
<ChartCard title="..." icon={<Icon />}>
  <ResponsiveContainer>...</ResponsiveContainer>
</ChartCard>
```

### 3. **Custom Hooks 패턴**
로직 재사용:
```tsx
const { isOpen, open, close } = useDisclosure();
const { ref, isVisible } = useScrollAnimation();
const [ref, position] = useMagneticEffect(0.3);
```

### 4. **Memoization 최적화**
```tsx
const stats = useMemo(() => [...], []);
export const StatCard = React.memo(function StatCard({ ... }) { ... });
```

## 🎭 애니메이션 시스템

### Motion Variants
`/lib/animations/variants.ts`에 모든 애니메이션 정의:

- **pageVariants**: 페이지 전환
- **staggerContainer**: 스태거 컨테이너
- **staggerItem**: 스태거 아이템
- **slideInLeft/Right**: 슬라이드 인
- **fadeIn**: 페이드 인
- **scalePop**: 스케일 팝
- **cardHover**: 카드 호버
- **buttonHover**: 버튼 호버

### 사용 예시
```tsx
<motion.div
  variants={pageVariants}
  initial="initial"
  animate="animate"
  exit="exit"
>
  {children}
</motion.div>
```

## 🔧 성능 최적화

### 1. React.memo
불필요한 리렌더링 방지:
```tsx
export const StatCard = React.memo(function StatCard({ ... }) { ... });
```

### 2. useMemo
값 메모이제이션:
```tsx
const filteredData = useMemo(() => {
  return data.filter(...)
}, [data, filter]);
```

### 3. useCallback
함수 메모이제이션:
```tsx
const handleClick = useCallback(() => {
  // ...
}, [dependencies]);
```

### 4. Code Splitting
필요시 동적 import 사용 가능:
```tsx
const HeavyComponent = React.lazy(() => import('./HeavyComponent'));
```

## 🎯 컴포넌트 가이드라인

### 1. 컴포넌트 작성 원칙
- **단일 책임 원칙**: 하나의 컴포넌트는 하나의 역할만
- **재사용성**: 가능한 한 재사용 가능하게 설계
- **타입 안정성**: 모든 props에 TypeScript 타입 정의
- **접근성**: ARIA 속성 추가

### 2. 파일 구조
```tsx
// 1. Imports
import React from 'react';
import { motion } from 'motion/react';

// 2. Types/Interfaces
interface ComponentProps {
  // ...
}

// 3. Component
export const Component = React.memo(function Component({ ... }) {
  // 4. Hooks
  const [state, setState] = useState();
  
  // 5. Handlers
  const handleClick = useCallback(() => { ... }, []);
  
  // 6. Render
  return (
    <motion.div>
      {/* ... */}
    </motion.div>
  );
});
```

### 3. 네이밍 컨벤션
- **컴포넌트**: PascalCase (e.g., `StatCard`)
- **함수/변수**: camelCase (e.g., `handleClick`)
- **상수**: UPPER_SNAKE_CASE (e.g., `DEFAULT_CONNECTIONS`)
- **타입/인터페이스**: PascalCase (e.g., `StatCardProps`)

## 🚀 주요 기능

### 1. Context 기반 상태 관리
- Prop drilling 없이 깔끔한 상태 관리
- 전역 상태와 로컬 상태 분리

### 2. 고급 애니메이션
- Page transitions
- Stagger animations
- Micro-interactions
- Hover effects
- Magnetic effects

### 3. 반응형 디자인
- Mobile-first approach
- Breakpoints: sm, md, lg, xl
- Flexible grid system

### 4. 성능 최적화
- React.memo로 불필요한 리렌더링 방지
- useMemo/useCallback로 값/함수 메모이제이션
- Lazy loading 지원

## 📚 기술 스택

- **React 18**: UI 라이브러리
- **TypeScript**: 타입 안정성
- **Tailwind CSS**: 스타일링
- **Motion (Framer Motion)**: 애니메이션
- **Recharts**: 차트 라이브러리
- **Lucide React**: 아이콘

## 🎨 디자인 시스템

### Colors
- **Primary**: Blue (#3b82f6)
- **Success**: Green (#10b981)
- **Warning**: Yellow (#f59e0b)
- **Danger**: Red (#ef4444)
- **Info**: Purple (#8b5cf6)

### Typography
- **Font**: Noto Sans KR
- **Sizes**: 12px ~ 14px (본문)

### Spacing
- **Base unit**: 4px (Tailwind default)
- **Container padding**: 2rem (8 units)

### Shadows
- **sm**: `0 1px 2px rgba(0,0,0,0.05)`
- **md**: `0 4px 6px rgba(0,0,0,0.1)`
- **lg**: `0 10px 15px rgba(0,0,0,0.1)`
- **xl**: `0 20px 25px rgba(0,0,0,0.1)`

## 🔮 향후 개선 사항

1. **더 많은 커스텀 훅**
   - useDebounce
   - useThrottle
   - useMediaQuery

2. **고급 애니메이션**
   - Gesture animations
   - Scroll-triggered animations
   - 3D transforms

3. **성능 모니터링**
   - React DevTools Profiler
   - Performance metrics

4. **테스트**
   - Unit tests
   - Integration tests
   - E2E tests

## 📖 참고 문서

- [React 공식 문서](https://react.dev/)
- [TypeScript 핸드북](https://www.typescriptlang.org/docs/)
- [Tailwind CSS 문서](https://tailwindcss.com/docs)
- [Motion 문서](https://motion.dev/)
- [Recharts 문서](https://recharts.org/)
