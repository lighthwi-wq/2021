export interface AutocompleteItem {
  text: string;
  type: 'keyword' | 'table' | 'column' | 'function' | 'snippet' | 'operator';
  category?: string;
  description?: string;
  example?: string;
  database?: 'postgresql' | 'mysql' | 'mongodb' | 'all';
  insertText?: string;
  cursorOffset?: number; // 삽입 후 커서 위치 오프셋
  score?: number; // 정렬을 위한 점수
}

export interface SQLContext {
  keywords: string[];
  tables: string[];
  currentTable?: string;
  currentClause?: 'SELECT' | 'FROM' | 'WHERE' | 'JOIN' | 'GROUP BY' | 'ORDER BY' | 'INSERT' | 'UPDATE' | 'DELETE' | 'HAVING' | 'SET';
  lastWord: string;
  fullQuery: string;
}
