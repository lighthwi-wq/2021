import React, { createContext, useContext, useState, useCallback, useEffect, ReactNode } from 'react';
import { useLocalStorage } from '../hooks/useLocalStorage';

interface User {
  id: string;
  email: string;
  name: string;
  avatar?: string;
  role: 'admin' | 'developer' | 'viewer';
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  updateProfile: (data: Partial<User>) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Mock users database
const MOCK_USERS = [
  {
    id: '1',
    email: 'admin@dataeye.com',
    password: 'admin123',
    name: '관리자',
    avatar: '',
    role: 'admin' as const,
  },
  {
    id: '2',
    email: 'dev@dataeye.com',
    password: 'dev123',
    name: '개발자',
    avatar: '',
    role: 'developer' as const,
  },
  {
    id: '3',
    email: 'viewer@dataeye.com',
    password: 'viewer123',
    name: '뷰어',
    avatar: '',
    role: 'viewer' as const,
  },
];

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useLocalStorage<User | null>('dataeye_user', null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // 앱 시작 시 저장된 사용자 정보 확인
    const checkAuth = async () => {
      setIsLoading(true);
      // 실제 앱에서는 토큰 검증 API 호출
      await new Promise((resolve) => setTimeout(resolve, 500));
      setIsLoading(false);
    };
    checkAuth();
  }, []);

  const login = useCallback(
    async (email: string, password: string): Promise<{ success: boolean; error?: string }> => {
      setIsLoading(true);

      // 로그인 시뮬레이션
      await new Promise((resolve) => setTimeout(resolve, 1000));

      const foundUser = MOCK_USERS.find((u) => u.email === email && u.password === password);

      if (foundUser) {
        const { password: _, ...userWithoutPassword } = foundUser;
        setUser(userWithoutPassword);
        setIsLoading(false);
        return { success: true };
      }

      setIsLoading(false);
      return { success: false, error: '이메일 또는 비밀번호가 올바르지 않습니다.' };
    },
    [setUser]
  );

  const logout = useCallback(() => {
    setUser(null);
    // 실제 앱에서는 토큰 삭제 및 서버 로그아웃 API 호출
  }, [setUser]);

  const updateProfile = useCallback(
    (data: Partial<User>) => {
      if (user) {
        setUser({ ...user, ...data });
      }
    },
    [user, setUser]
  );

  const value: AuthContextType = {
    user,
    isAuthenticated: !!user,
    isLoading,
    login,
    logout,
    updateProfile,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
