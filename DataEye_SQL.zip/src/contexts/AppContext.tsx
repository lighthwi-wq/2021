import React, { createContext, useContext, useState, useCallback, ReactNode, useEffect } from 'react';
import { ViewType, SearchResult } from '../types';

export interface QueryHistoryItem {
  id: string;
  query: string;
  timestamp: Date;
  duration: string;
  status: 'success' | 'error';
  rowsAffected?: number;
}

export interface SavedQuery {
  id: string;
  name: string;
  query: string;
  description?: string;
  folder?: string;
  createdAt: Date;
  tags: string[];
}

interface AppContextType {
  // View state
  currentView: ViewType;
  setCurrentView: (view: ViewType) => void;
  
  // Table selection
  selectedTable: string | null;
  selectTable: (tableName: string) => void;
  
  // Query operations
  externalQuery: string;
  insertQuery: (query: string) => void;
  
  // Query history
  queryHistory: QueryHistoryItem[];
  addToHistory: (query: string, duration: string, status: 'success' | 'error', rowsAffected?: number) => void;
  deleteFromHistory: (id: string) => void;
  clearHistory: () => void;
  
  // Saved queries
  savedQueries: SavedQuery[];
  saveQuery: (name: string, query: string, description?: string, folder?: string, tags?: string[]) => void;
  updateSavedQuery: (id: string, updates: Partial<SavedQuery>) => void;
  deleteSavedQuery: (id: string) => void;
  
  // Search
  searchResults: SearchResult[];
  searchQuery: string;
  setSearchResults: (results: SearchResult[]) => void;
  setSearchQuery: (query: string) => void;
  
  // Modal states
  isHelpModalOpen: boolean;
  openHelpModal: () => void;
  closeHelpModal: () => void;
  
  isLogoutDialogOpen: boolean;
  openLogoutDialog: () => void;
  closeLogoutDialog: () => void;
  confirmLogout: () => void;
  
  // Sidebar state (for mobile)
  isSidebarOpen: boolean;
  toggleSidebar: () => void;
  closeSidebar: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  // 초기값: 데스크톱(lg 이상)이면 true, 모바일이면 false
  const [isSidebarOpen, setIsSidebarOpen] = useState(() => {
    if (typeof window !== 'undefined') {
      return window.innerWidth >= 1024; // lg breakpoint
    }
    return true; // SSR 대비
  });
  
  const [currentView, setCurrentView] = useState<ViewType>('home');
  const [selectedTable, setSelectedTable] = useState<string | null>(null);
  const [externalQuery, setExternalQuery] = useState<string>('');
  const [isHelpModalOpen, setIsHelpModalOpen] = useState(false);
  const [isLogoutDialogOpen, setIsLogoutDialogOpen] = useState(false);
  
  // Search state
  const [searchResults, setSearchResults] = useState<SearchResult[]>([]);
  const [searchQuery, setSearchQuery] = useState<string>('');
  
  // Query history state
  const [queryHistory, setQueryHistory] = useState<QueryHistoryItem[]>([
    {
      id: '1',
      query: 'SELECT * FROM users WHERE created_at > NOW() - INTERVAL \'7 days\' ORDER BY created_at DESC',
      timestamp: new Date(Date.now() - 2 * 60 * 1000),
      duration: '0.45s',
      status: 'success',
      rowsAffected: 156
    },
    {
      id: '2',
      query: 'SELECT COUNT(*) as total, status FROM orders GROUP BY status',
      timestamp: new Date(Date.now() - 15 * 60 * 1000),
      duration: '0.23s',
      status: 'success',
      rowsAffected: 4
    }
  ]);
  
  // Saved queries state
  const [savedQueries, setSavedQueries] = useState<SavedQuery[]>([
    {
      id: '1',
      name: '일별 신규 사용자',
      query: 'SELECT DATE(created_at) as date, COUNT(*) as new_users FROM users GROUP BY DATE(created_at) ORDER BY date DESC LIMIT 30',
      description: '최근 30일간 일별 신규 사용자 수',
      folder: '리포트',
      createdAt: new Date(2025, 10, 1),
      tags: ['사용자', '리포트', '일별']
    },
    {
      id: '2',
      name: '상위 판매 제품',
      query: 'SELECT p.name, SUM(oi.quantity) as total_sold, SUM(oi.quantity * oi.price) as revenue FROM products p JOIN order_items oi ON p.id = oi.product_id GROUP BY p.id, p.name ORDER BY revenue DESC LIMIT 10',
      description: '매출 기준 상위 10개 제품',
      folder: '리포트',
      createdAt: new Date(2025, 10, 5),
      tags: ['제품', '매출', '리포트']
    }
  ]);

  // 화면 크기 변경 감지
  useEffect(() => {
    const handleResize = () => {
      const isDesktop = window.innerWidth >= 1024;
      if (isDesktop) {
        setIsSidebarOpen(true);
      } else {
        setIsSidebarOpen(false);
      }
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const selectTable = useCallback((tableName: string) => {
    setSelectedTable(tableName);
  }, []);

  const insertQuery = useCallback((query: string) => {
    setExternalQuery(query);
    setCurrentView('editor');
    setTimeout(() => setExternalQuery(''), 100);
  }, []);
  
  // Query history functions
  const addToHistory = useCallback((query: string, duration: string, status: 'success' | 'error', rowsAffected?: number) => {
    const newHistoryItem: QueryHistoryItem = {
      id: Date.now().toString(),
      query,
      timestamp: new Date(),
      duration,
      status,
      rowsAffected
    };
    setQueryHistory(prev => [newHistoryItem, ...prev]);
  }, []);
  
  const deleteFromHistory = useCallback((id: string) => {
    setQueryHistory(prev => prev.filter(item => item.id !== id));
  }, []);
  
  const clearHistory = useCallback(() => {
    setQueryHistory([]);
  }, []);
  
  // Saved queries functions
  const saveQuery = useCallback((name: string, query: string, description?: string, folder?: string, tags: string[] = []) => {
    const newQuery: SavedQuery = {
      id: Date.now().toString(),
      name,
      query,
      description,
      folder,
      createdAt: new Date(),
      tags
    };
    setSavedQueries(prev => [newQuery, ...prev]);
  }, []);
  
  const updateSavedQuery = useCallback((id: string, updates: Partial<SavedQuery>) => {
    setSavedQueries(prev => prev.map(q => q.id === id ? { ...q, ...updates } : q));
  }, []);
  
  const deleteSavedQuery = useCallback((id: string) => {
    setSavedQueries(prev => prev.filter(q => q.id !== id));
  }, []);

  const openHelpModal = useCallback(() => setIsHelpModalOpen(true), []);
  const closeHelpModal = useCallback(() => setIsHelpModalOpen(false), []);
  
  const openLogoutDialog = useCallback(() => setIsLogoutDialogOpen(true), []);
  const closeLogoutDialog = useCallback(() => setIsLogoutDialogOpen(false), []);
  
  const confirmLogout = useCallback(() => {
    console.log('로그아웃 처리');
    setIsLogoutDialogOpen(false);
    // 여기에 실제 로그아웃 로직 추가
  }, []);

  const toggleSidebar = useCallback(() => setIsSidebarOpen(!isSidebarOpen), [isSidebarOpen]);
  const closeSidebar = useCallback(() => setIsSidebarOpen(false), []);

  const value: AppContextType = {
    currentView,
    setCurrentView,
    selectedTable,
    selectTable,
    externalQuery,
    insertQuery,
    queryHistory,
    addToHistory,
    deleteFromHistory,
    clearHistory,
    savedQueries,
    saveQuery,
    updateSavedQuery,
    deleteSavedQuery,
    searchResults,
    searchQuery,
    setSearchResults,
    setSearchQuery,
    isHelpModalOpen,
    openHelpModal,
    closeHelpModal,
    isLogoutDialogOpen,
    openLogoutDialog,
    closeLogoutDialog,
    confirmLogout,
    isSidebarOpen,
    toggleSidebar,
    closeSidebar,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}