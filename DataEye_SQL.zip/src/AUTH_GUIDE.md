# 🔐 DataEye SQL - 인증 시스템 가이드

## 개요

DataEye SQL에 완전한 로그인/로그아웃 기능이 구현되었습니다!

## 📋 주요 기능

### 1. **로그인 페이지**
- ✨ **트렌디한 UI**: Glassmorphism & 그라데이션 디자인
- 🎭 **애니메이션**: 배경 애니메이션, 입력 필드 포커스 효과
- 🚀 **빠른 로그인**: 데모 계정 원클릭 로그인
- 🔒 **비밀번호 표시/숨김**: Eye 아이콘으로 토글
- ⚡ **로딩 상태**: 로그인 중 스피너 표시
- ❌ **에러 처리**: 실패 시 에러 메시지 표시

### 2. **인증 시스템**
- 🏗️ **AuthContext**: React Context API 기반 전역 상태 관리
- 💾 **LocalStorage**: 로그인 정보 영구 저장
- 🔄 **자동 로그인**: 페이지 새로고침 시에도 로그인 유지
- 🛡️ **Protected Routes**: 인증되지 않은 사용자 자동 리다이렉트

### 3. **사용자 프로필**
- 👤 **Header 사용자 메뉴**: 프로필 정보 표시
- 🎨 **아바타**: 이름 첫 글자로 생성된 그라데이션 아바타
- 🏷️ **역할 배지**: 관리자/개발자/뷰어 표시
- 🚪 **로그아웃**: 원클릭 로그아웃

## 🎯 데모 계정

### 관리자 계정
```
이메일: admin@dataeye.com
비밀번호: admin123
권한: 전체 관리자 권한
```

### 개발자 계정
```
이메일: dev@dataeye.com
비밀번호: dev123
권한: 개발 권한
```

### 뷰어 계정
```
이메일: viewer@dataeye.com
비밀번호: viewer123
권한: 읽기 전용
```

## 🏗️ 아키텍처

### Context 구조
```tsx
AuthProvider
  ├─ user: User | null
  ├─ isAuthenticated: boolean
  ├─ isLoading: boolean
  ├─ login(email, password)
  ├─ logout()
  └─ updateProfile(data)
```

### 파일 구조
```
/contexts/
  └─ AuthContext.tsx          # 인증 Context & Hooks

/components/
  ├─ auth/
  │   └─ LoginPage.tsx        # 로그인 페이지
  └─ common/
      └─ ProtectedRoute.tsx   # 보호된 라우트 컴포넌트
```

## 💻 사용법

### 1. useAuth Hook 사용
```tsx
import { useAuth } from './contexts/AuthContext';

function MyComponent() {
  const { user, isAuthenticated, login, logout } = useAuth();

  return (
    <div>
      {isAuthenticated ? (
        <div>
          <p>환영합니다, {user?.name}님!</p>
          <button onClick={logout}>로그아웃</button>
        </div>
      ) : (
        <p>로그인이 필요합니다.</p>
      )}
    </div>
  );
}
```

### 2. 로그인 처리
```tsx
const handleLogin = async () => {
  const result = await login(email, password);
  
  if (result.success) {
    console.log('로그인 성공!');
  } else {
    console.error('로그인 실패:', result.error);
  }
};
```

### 3. 사용자 정보 업데이트
```tsx
const { updateProfile } = useAuth();

updateProfile({
  name: '새로운 이름',
  avatar: 'https://example.com/avatar.jpg'
});
```

## 🎨 UI/UX 특징

### 로그인 페이지
- **배경 애니메이션**: 3개의 블러 원이 부드럽게 움직임
- **로고 애니메이션**: 호버 시 회전 & 스케일 효과
- **Glassmorphism**: 반투명 배경 & backdrop blur
- **입력 필드 포커스**: 테두리 색상 애니메이션
- **Shine 효과**: 로그인 버튼에 빛나는 효과

### 사용자 메뉴
- **그라데이션 아바타**: from-blue-600 to-purple-600
- **호버 애니메이션**: x축 이동 효과
- **Backdrop**: 클릭 시 메뉴 닫힘
- **스무스 전환**: scale & opacity 애니메이션

## 🔒 보안

### 현재 구현
- ✅ LocalStorage에 사용자 정보 저장
- ✅ 비밀번호는 저장하지 않음
- ✅ 로그아웃 시 완전 삭제

### 프로덕션 환경 개선 사항
- [ ] JWT 토큰 기반 인증
- [ ] HttpOnly Cookie 사용
- [ ] Refresh Token 구현
- [ ] CSRF 보호
- [ ] Rate Limiting
- [ ] 2FA (Two-Factor Authentication)

## 🚀 확장 가능성

### Phase 1 (완료 ✅)
- [x] 로그인 페이지
- [x] AuthContext
- [x] LocalStorage 저장
- [x] 사용자 메뉴
- [x] 로그아웃

### Phase 2 (계획)
- [ ] 회원가입 페이지
- [ ] 비밀번호 재설정
- [ ] 이메일 인증
- [ ] 프로필 수정 페이지

### Phase 3 (계획)
- [ ] 소셜 로그인 (Google, GitHub)
- [ ] 2FA 인증
- [ ] 세션 관리
- [ ] 로그인 히스토리

## 📝 주요 파일

### AuthContext.tsx
```tsx
// 전역 인증 상태 관리
- User 타입 정의
- MOCK_USERS 데이터베이스
- login/logout 로직
- LocalStorage 통합
```

### LoginPage.tsx
```tsx
// 트렌디한 로그인 UI
- 배경 애니메이션
- 폼 유효성 검사
- 에러 처리
- 데모 계정 버튼
```

### App.tsx
```tsx
// 인증 라우팅
- AuthProvider 래핑
- AppRouter (인증 체크)
- ProtectedRoute
```

### Header.tsx
```tsx
// 사용자 메뉴
- useAuth 훅 사용
- 프로필 표시
- 로그아웃 버튼
```

## 🎯 사용 시나리오

### 1. 첫 방문
1. 로그인 페이지 표시
2. 데모 계정 클릭으로 빠른 로그인
3. 자동으로 홈 화면 이동
4. LocalStorage에 정보 저장

### 2. 재방문
1. 저장된 정보 자동 로드
2. 로그인 페이지 스킵
3. 바로 홈 화면 표시

### 3. 로그아웃
1. Header의 User 아이콘 클릭
2. 로그아웃 버튼 클릭
3. LocalStorage 클리어
4. 로그인 페이지로 이동

## 🎨 디자인 토큰

### Colors
```css
Primary Gradient: from-blue-600 to-purple-600
Background: from-blue-50 via-purple-50 to-pink-50
Avatar: from-blue-600 to-purple-600
Badge: blue-100 / blue-700
Error: red-50 / red-700
```

### Animations
```tsx
// 배경 원 애니메이션
duration: 8-15s
repeat: Infinity
ease: easeInOut

// 로그인 버튼
whileHover: scale(1.02)
whileTap: scale(0.98)

// 사용자 메뉴
whileHover: x(4px)
```

## 📚 참고 자료

### React Context API
- [React Context 공식 문서](https://react.dev/reference/react/useContext)
- [Context Best Practices](https://react.dev/learn/passing-data-deeply-with-context)

### LocalStorage
- [Web Storage API](https://developer.mozilla.org/en-US/docs/Web/API/Web_Storage_API)

### Motion 애니메이션
- [Motion 공식 문서](https://motion.dev/)
- [Animation Variants](https://motion.dev/docs/react-animation)

## ✅ 체크리스트

### 인증 시스템 ✅
- [x] AuthContext 구현
- [x] useAuth 훅
- [x] LocalStorage 통합
- [x] 로그인 로직
- [x] 로그아웃 로직

### UI 컴포넌트 ✅
- [x] LoginPage
- [x] ProtectedRoute
- [x] User Menu (Header)
- [x] Avatar Component
- [x] Role Badge

### 애니메이션 ✅
- [x] 배경 애니메이션
- [x] 폼 포커스 효과
- [x] 버튼 호버 효과
- [x] 페이지 전환
- [x] 사용자 메뉴 전환

### 보안 ✅
- [x] 비밀번호 숨김
- [x] 로그아웃 시 데이터 삭제
- [x] Protected Routes

## 🎉 결론

완전한 로그인/로그아웃 시스템이 구현되었습니다!

**주요 특징:**
- 🎨 트렌디한 디자인
- ⚡ 빠른 성능
- 🔒 안전한 인증
- 📱 반응형 UI
- 🎭 부드러운 애니메이션

이제 DataEye SQL은 완전한 인증 시스템을 갖춘 엔터프라이즈급 애플리케이션입니다! 🚀
