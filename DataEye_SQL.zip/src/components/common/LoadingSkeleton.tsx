import React from 'react';
import { motion } from 'motion/react';

interface LoadingSkeletonProps {
  className?: string;
  count?: number;
  height?: string;
}

export const LoadingSkeleton = React.memo(function LoadingSkeleton({
  className = '',
  count = 1,
  height = 'h-4',
}: LoadingSkeletonProps) {
  return (
    <>
      {Array.from({ length: count }).map((_, index) => (
        <motion.div
          key={index}
          className={`bg-gray-200 rounded ${height} ${className}`}
          animate={{
            opacity: [0.5, 1, 0.5],
          }}
          transition={{
            duration: 1.5,
            repeat: Infinity,
            ease: 'easeInOut',
            delay: index * 0.1,
          }}
        />
      ))}
    </>
  );
});

export const CardSkeleton = React.memo(function CardSkeleton() {
  return (
    <div className="bg-white rounded-lg border border-gray-200 p-6 space-y-4">
      <div className="flex items-center justify-between">
        <LoadingSkeleton className="w-32" />
        <LoadingSkeleton className="w-16" />
      </div>
      <LoadingSkeleton height="h-8" className="w-24" />
      <LoadingSkeleton height="h-32" />
    </div>
  );
});
