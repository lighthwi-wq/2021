import React, { ReactNode } from 'react';
import { motion } from 'motion/react';
import { cardHover } from '../../lib/animations/variants';

interface AnimatedCardProps {
  children: ReactNode;
  className?: string;
  delay?: number;
  onClick?: () => void;
  whileHover?: boolean;
}

export const AnimatedCard = React.memo(function AnimatedCard({
  children,
  className = '',
  delay = 0,
  onClick,
  whileHover = true,
}: AnimatedCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{
        duration: 0.4,
        delay,
        ease: [0.25, 0.46, 0.45, 0.94],
      }}
      variants={whileHover ? cardHover : undefined}
      whileHover={whileHover ? 'hover' : undefined}
      whileTap={whileHover ? 'tap' : undefined}
      className={className}
      onClick={onClick}
    >
      {children}
    </motion.div>
  );
});
