import React, { useState } from 'react';
import { Download, Filter, RefreshCw, Table2, Grid3x3, Clock, CheckCircle, AlertCircle, Info } from 'lucide-react';
import { useApp, QueryHistoryItem } from '../contexts/AppContext';
import { motion } from 'motion/react';

interface ResultsPanelProps {
  results: any[];
  executedQuery: string;
}

export function ResultsPanel({ results, executedQuery }: ResultsPanelProps) {
  const { queryHistory } = useApp();
  const [viewMode, setViewMode] = useState<'table' | 'grid'>('table');
  const [activeTab, setActiveTab] = useState<'data' | 'messages' | 'history'>('data');
  const [executionTime, setExecutionTime] = useState('0.123');
  const [executionMessages, setExecutionMessages] = useState<Array<{
    type: 'success' | 'error' | 'warning' | 'info';
    message: string;
    timestamp: Date;
  }>>([
    {
      type: 'success',
      message: '쿼리가 성공적으로 실행되었습니다.',
      timestamp: new Date()
    }
  ]);

  if (results.length === 0) {
    return (
      <div className="flex-1 bg-white dark:bg-[#1e1e1e] overflow-auto">
        {/* Tabs */}
        <div className="flex items-center gap-4 px-4 py-2 border-b border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#252526]">
          <button
            onClick={() => setActiveTab('data')}
            className={`px-3 py-2 text-sm rounded transition-colors ${
              activeTab === 'data' ? 'bg-white dark:bg-[#1e1e1e] text-blue-600 dark:text-blue-400' : 'text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-300'
            }`}
          >
            데이터
          </button>
          <button
            onClick={() => setActiveTab('messages')}
            className={`px-3 py-2 text-sm rounded transition-colors ${
              activeTab === 'messages' ? 'bg-white dark:bg-[#1e1e1e] text-blue-600 dark:text-blue-400' : 'text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-300'
            }`}
          >
            메시지
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`px-3 py-2 text-sm rounded transition-colors ${
              activeTab === 'history' ? 'bg-white dark:bg-[#1e1e1e] text-blue-600 dark:text-blue-400' : 'text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-300'
            }`}
          >
            실행 기록
          </button>
        </div>

        <div className="flex flex-col items-center justify-center h-full text-gray-400 dark:text-gray-500 p-8">
          <Table2 className="w-16 h-16 mb-4" />
          <p className="text-lg">표시할 결과가 없습니다</p>
          <p className="text-sm mt-2">쿼리를 실행하면 여기에 결과가 표시됩니다</p>
        </div>
      </div>
    );
  }

  const columns = Object.keys(results[0]);

  return (
    <div className="flex-1 flex flex-col bg-white dark:bg-[#1e1e1e] overflow-hidden">
      {/* Tabs */}
      <div className="flex items-center gap-4 px-4 py-2 border-b border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#252526]">
        <button
          onClick={() => setActiveTab('data')}
          className={`px-3 py-2 text-sm rounded transition-colors ${
            activeTab === 'data' ? 'bg-white dark:bg-[#1e1e1e] text-blue-600 dark:text-blue-400 border-b-2 border-blue-600 dark:border-blue-400' : 'text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-300'
          }`}
        >
          데이터
        </button>
        <button
          onClick={() => setActiveTab('messages')}
          className={`px-3 py-2 text-sm rounded transition-colors ${
            activeTab === 'messages' ? 'bg-white dark:bg-[#1e1e1e] text-blue-600 dark:text-blue-400 border-b-2 border-blue-600 dark:border-blue-400' : 'text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-300'
          }`}
        >
          메시지
        </button>
        <button
          onClick={() => setActiveTab('history')}
          className={`px-3 py-2 text-sm rounded transition-colors ${
            activeTab === 'history' ? 'bg-white dark:bg-[#1e1e1e] text-blue-600 dark:text-blue-400 border-b-2 border-blue-600 dark:border-blue-400' : 'text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-300'
          }`}
        >
          실행 기록
        </button>
      </div>

      {activeTab === 'data' && (
        <>
          <div className="flex items-center justify-between px-4 py-3 border-b border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#252526]">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <span className="text-sm text-gray-700 dark:text-gray-300">
                  {results.length}개 행
                </span>
                <span className="text-gray-400 dark:text-gray-600">•</span>
                <span className="text-sm text-gray-500">실행 시간: 0.123초</span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <div className="flex items-center border border-gray-300 dark:border-gray-700 rounded-lg overflow-hidden">
                <button
                  onClick={() => setViewMode('table')}
                  className={`p-2 ${
                    viewMode === 'table' ? 'bg-blue-600 text-white' : 'bg-white dark:bg-[#2d2d30] text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-[#3e3e42]'
                  } transition-colors`}
                >
                  <Table2 className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setViewMode('grid')}
                  className={`p-2 ${
                    viewMode === 'grid' ? 'bg-blue-600 text-white' : 'bg-white dark:bg-[#2d2d30] text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-[#3e3e42]'
                  } transition-colors`}
                >
                  <Grid3x3 className="w-4 h-4" />
                </button>
              </div>

              <button className="flex items-center gap-2 px-3 py-2 bg-white dark:bg-[#2d2d30] border border-gray-300 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-[#3e3e42] transition-colors text-gray-700 dark:text-gray-300">
                <Filter className="w-4 h-4" />
                <span className="text-sm">필터</span>
              </button>
              <button className="flex items-center gap-2 px-3 py-2 bg-white dark:bg-[#2d2d30] border border-gray-300 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-[#3e3e42] transition-colors text-gray-700 dark:text-gray-300">
                <Download className="w-4 h-4" />
                <span className="text-sm">내보내기</span>
              </button>
              <button className="p-2 bg-white dark:bg-[#2d2d30] border border-gray-300 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-[#3e3e42] transition-colors">
                <RefreshCw className="w-4 h-4 text-gray-600 dark:text-gray-400" />
              </button>
            </div>
          </div>

          <div className="flex-1 overflow-auto">
            {viewMode === 'table' ? (
              <table className="w-full">
                <thead className="bg-gray-100 dark:bg-[#252526] sticky top-0">
                  <tr>
                    {columns.map((column) => (
                      <th
                        key={column}
                        className="px-4 py-3 text-left text-xs uppercase tracking-wider text-gray-700 dark:text-gray-400 border-b border-gray-300 dark:border-gray-700"
                      >
                        {column}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {results.map((row, rowIndex) => (
                    <tr
                      key={rowIndex}
                      className="hover:bg-gray-50 dark:hover:bg-[#2d2d30] transition-colors border-b border-gray-200 dark:border-gray-800"
                    >
                      {columns.map((column) => (
                        <td
                          key={column}
                          className="px-4 py-3 text-sm text-gray-900 dark:text-gray-300 whitespace-nowrap"
                        >
                          {formatValue(row[column])}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            ) : (
              <div className="p-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {results.map((row, rowIndex) => (
                  <div
                    key={rowIndex}
                    className="p-4 bg-white dark:bg-[#252526] border border-gray-300 dark:border-gray-700 rounded-lg hover:border-blue-600 dark:hover:border-blue-600 transition-all"
                  >
                    {columns.map((column) => (
                      <div key={column} className="mb-2 last:mb-0">
                        <div className="text-xs text-gray-500 uppercase tracking-wider">
                          {column}
                        </div>
                        <div className="text-sm text-gray-900 dark:text-gray-300 mt-1">
                          {formatValue(row[column])}
                        </div>
                      </div>
                    ))}
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="px-4 py-2 border-t border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-[#252526]">
            <div className="text-xs text-gray-500 font-mono">
              {executedQuery}
            </div>
          </div>
        </>
      )}

      {activeTab === 'messages' && (
        <div className="flex-1 p-6 overflow-auto">
          <div className="space-y-3">
            {results.length > 0 && (
              <>
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex items-start gap-3 p-4 bg-green-50 border border-green-200 rounded-lg"
                >
                  <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                  <div className="flex-1">
                    <div className="text-sm text-green-900 mb-1">
                      ✓ 쿼리가 성공적으로 실행되었습니다.
                    </div>
                    <div className="text-xs text-green-700">
                      {results.length}개의 행이 반환되었습니다 • 실행 시간: {executionTime}초
                    </div>
                    <div className="text-xs text-green-600 mt-2">
                      {new Date().toLocaleString('ko-KR')}
                    </div>
                  </div>
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 }}
                  className="flex items-start gap-3 p-4 bg-blue-50 border border-blue-200 rounded-lg"
                >
                  <Info className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                  <div className="flex-1">
                    <div className="text-sm text-blue-900 mb-1">
                      실행 정보
                    </div>
                    <div className="text-xs text-blue-700 space-y-1">
                      <div>• 데이터베이스: PostgreSQL</div>
                      <div>• 실행 시간: {executionTime}초</div>
                      <div>• 반환된 행: {results.length}개</div>
                      <div>• 컬럼 수: {Object.keys(results[0] || {}).length}개</div>
                    </div>
                  </div>
                </motion.div>
              </>
            )}

            {executionMessages.map((message, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className={`flex items-start gap-3 p-4 rounded-lg border ${
                  message.type === 'success'
                    ? 'bg-green-50 border-green-200'
                    : message.type === 'error'
                    ? 'bg-red-50 border-red-200'
                    : message.type === 'warning'
                    ? 'bg-yellow-50 border-yellow-200'
                    : 'bg-blue-50 border-blue-200'
                }`}
              >
                <div
                  className={`w-5 h-5 flex-shrink-0 mt-0.5 ${
                    message.type === 'success'
                      ? 'text-green-600'
                      : message.type === 'error'
                      ? 'text-red-600'
                      : message.type === 'warning'
                      ? 'text-yellow-600'
                      : 'text-blue-600'
                  }`}
                >
                  {message.type === 'success' ? (
                    <CheckCircle className="w-5 h-5" />
                  ) : message.type === 'error' ? (
                    <AlertCircle className="w-5 h-5" />
                  ) : message.type === 'warning' ? (
                    <AlertCircle className="w-5 h-5" />
                  ) : (
                    <Info className="w-5 h-5" />
                  )}
                </div>
                <div className="flex-1">
                  <div
                    className={`text-sm mb-1 ${
                      message.type === 'success'
                        ? 'text-green-900'
                        : message.type === 'error'
                        ? 'text-red-900'
                        : message.type === 'warning'
                        ? 'text-yellow-900'
                        : 'text-blue-900'
                    }`}
                  >
                    {message.message}
                  </div>
                  <div
                    className={`text-xs ${
                      message.type === 'success'
                        ? 'text-green-700'
                        : message.type === 'error'
                        ? 'text-red-700'
                        : message.type === 'warning'
                        ? 'text-yellow-700'
                        : 'text-blue-700'
                    }`}
                  >
                    {message.timestamp.toLocaleString('ko-KR')}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'history' && (
        <div className="flex-1 p-6 overflow-auto">
          {queryHistory.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-gray-400">
              <Clock className="w-16 h-16 mb-4" />
              <p className="text-lg">실행 기록이 없습니다</p>
              <p className="text-sm mt-2">쿼리를 실행하면 여기에 기록이 표시됩니다</p>
            </div>
          ) : (
            <div className="space-y-3">
              {queryHistory.slice(0, 10).map((item, index) => (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className={`p-4 rounded-lg border transition-all hover:shadow-md ${
                    item.status === 'success'
                      ? 'bg-white border-gray-200 hover:border-blue-300'
                      : 'bg-red-50 border-red-200'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                        item.status === 'success' ? 'bg-green-100' : 'bg-red-100'
                      }`}
                    >
                      {item.status === 'success' ? (
                        <CheckCircle className="w-4 h-4 text-green-600" />
                      ) : (
                        <AlertCircle className="w-4 h-4 text-red-600" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-mono text-sm text-gray-900 mb-2 break-all">
                        {item.query}
                      </div>
                      <div className="flex flex-wrap items-center gap-3 text-xs text-gray-600">
                        <div className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          <span>{formatTimestamp(item.timestamp)}</span>
                        </div>
                        <div>실행 시간: {item.duration}</div>
                        {item.rowsAffected !== undefined && (
                          <div>{item.rowsAffected}개 행</div>
                        )}
                        <div
                          className={`px-2 py-0.5 rounded ${
                            item.status === 'success'
                              ? 'bg-green-100 text-green-700'
                              : 'bg-red-100 text-red-700'
                          }`}
                        >
                          {item.status === 'success' ? '성공' : '실패'}
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
              {queryHistory.length > 10 && (
                <div className="text-center text-sm text-gray-500 pt-4">
                  최근 10개의 기록만 표시됩니다
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function formatValue(value: any): string {
  if (value === null) return 'NULL';
  if (value === undefined) return '-';
  if (typeof value === 'boolean') return value.toString().toUpperCase();
  if (typeof value === 'object') return JSON.stringify(value);
  return String(value);
}

function formatTimestamp(timestamp: Date): string {
  const now = new Date();
  const diff = now.getTime() - timestamp.getTime();
  const seconds = Math.floor(diff / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);

  if (days > 0) {
    return `${days}일 전`;
  } else if (hours > 0) {
    return `${hours}시간 전`;
  } else if (minutes > 0) {
    return `${minutes}분 전`;
  } else {
    return `${seconds}초 전`;
  }
}