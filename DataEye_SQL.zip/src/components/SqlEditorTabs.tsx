import React, { useState, useEffect } from 'react';
import { Plus, X, Edit2 } from 'lucide-react';
import { SqlEditor } from './SqlEditor';
import { ResultsPanel } from './ResultsPanel';

interface Tab {
  id: string;
  name: string;
  query: string;
  results: any[];
  executedQuery: string;
}

interface SqlEditorTabsProps {
  selectedTable: string | null;
  externalQuery?: string;
}

export function SqlEditorTabs({ selectedTable, externalQuery }: SqlEditorTabsProps) {
  const [tabs, setTabs] = useState<Tab[]>([
    {
      id: '1',
      name: '쿼리 1',
      query: '',
      results: [],
      executedQuery: ''
    }
  ]);
  const [activeTabId, setActiveTabId] = useState('1');
  const [editingTabId, setEditingTabId] = useState<string | null>(null);
  const [editingName, setEditingName] = useState('');

  const activeTab = tabs.find(tab => tab.id === activeTabId);

  useEffect(() => {
    if (externalQuery && activeTab) {
      handleQueryChange(externalQuery);
    }
  }, [externalQuery]);

  const addNewTab = () => {
    const newTab: Tab = {
      id: Date.now().toString(),
      name: `쿼리 ${tabs.length + 1}`,
      query: '',
      results: [],
      executedQuery: ''
    };
    setTabs([...tabs, newTab]);
    setActiveTabId(newTab.id);
  };

  const closeTab = (tabId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (tabs.length === 1) return; // Don't close last tab

    const newTabs = tabs.filter(tab => tab.id !== tabId);
    setTabs(newTabs);

    if (activeTabId === tabId) {
      setActiveTabId(newTabs[0].id);
    }
  };

  const startEditing = (tabId: string, currentName: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingTabId(tabId);
    setEditingName(currentName);
  };

  const finishEditing = () => {
    if (editingTabId && editingName.trim()) {
      setTabs(tabs.map(tab =>
        tab.id === editingTabId ? { ...tab, name: editingName.trim() } : tab
      ));
    }
    setEditingTabId(null);
    setEditingName('');
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      finishEditing();
    } else if (e.key === 'Escape') {
      setEditingTabId(null);
      setEditingName('');
    }
  };

  const handleQueryChange = (query: string) => {
    setTabs(tabs.map(tab =>
      tab.id === activeTabId ? { ...tab, query } : tab
    ));
  };

  const handleQueryExecute = (query: string, results: any[]) => {
    setTabs(tabs.map(tab =>
      tab.id === activeTabId ? { ...tab, executedQuery: query, results } : tab
    ));
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      {/* Tab Bar */}
      <div className="flex items-center gap-1 px-2 py-1 bg-white dark:bg-[#252526] border-b border-gray-200 dark:border-gray-700 overflow-x-auto">
        {tabs.map(tab => (
          <div
            key={tab.id}
            onClick={() => setActiveTabId(tab.id)}
            className={`group flex items-center gap-2 px-3 py-2 rounded-t-lg cursor-pointer transition-colors min-w-[120px] ${
              activeTabId === tab.id
                ? 'bg-gray-50 dark:bg-[#1e1e1e] text-gray-900 dark:text-gray-100 border-t-2 border-blue-500'
                : 'bg-white dark:bg-[#2d2d30] text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-[#3e3e42]'
            }`}
          >
            {editingTabId === tab.id ? (
              <input
                type="text"
                value={editingName}
                onChange={(e) => setEditingName(e.target.value)}
                onBlur={finishEditing}
                onKeyDown={handleKeyDown}
                className="flex-1 px-1 py-0 text-sm bg-white dark:bg-[#1e1e1e] border border-blue-500 rounded outline-none"
                autoFocus
                onClick={(e) => e.stopPropagation()}
              />
            ) : (
              <>
                <span 
                  className="flex-1 text-sm truncate"
                  onDoubleClick={(e) => startEditing(tab.id, tab.name, e)}
                >
                  {tab.name}
                </span>
                <button
                  onClick={(e) => startEditing(tab.id, tab.name, e)}
                  className="opacity-0 group-hover:opacity-100 p-1 hover:bg-gray-200 dark:hover:bg-[#4e4e52] rounded transition-opacity"
                  title="이름 변경"
                >
                  <Edit2 className="w-3 h-3" />
                </button>
              </>
            )}
            {tabs.length > 1 && (
              <button
                onClick={(e) => closeTab(tab.id, e)}
                className="p-1 hover:bg-gray-200 dark:hover:bg-[#4e4e52] rounded transition-colors"
                title="닫기"
              >
                <X className="w-3 h-3" />
              </button>
            )}
          </div>
        ))}
        
        <button
          onClick={addNewTab}
          className="flex items-center gap-1 px-3 py-2 text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-[#2d2d30] rounded-lg transition-colors"
          title="새 쿼리 탭"
        >
          <Plus className="w-4 h-4" />
          <span className="text-sm">새 탭</span>
        </button>
      </div>

      {/* Active Tab Content */}
      {activeTab && (
        <div className="flex-1 flex flex-col overflow-hidden">
          <SqlEditor
            selectedTable={selectedTable}
            onQueryExecute={handleQueryExecute}
            externalQuery={activeTab.query}
            onQueryChange={handleQueryChange}
          />
          <ResultsPanel
            results={activeTab.results}
            executedQuery={activeTab.executedQuery}
          />
        </div>
      )}
    </div>
  );
}
