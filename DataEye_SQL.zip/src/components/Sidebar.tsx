import React, { useState, useEffect } from 'react';
import { Database, ChevronRight, Plus, Folder, Table, Home, Activity, FileText, HelpCircle, LogOut, MoreVertical, Circle, Search, Edit2, Trash2 } from 'lucide-react';
import { ConnectionModal } from './ConnectionModal';
import { ContextMenu } from './ContextMenu';
import { motion, AnimatePresence } from 'motion/react';
import { Connection, Schema, ViewType, ContextMenuItem } from '../types';
import { DEFAULT_CONNECTIONS, DEFAULT_SCHEMAS } from '../constants/database';

interface SidebarProps {
  onTableSelect: (tableName: string) => void;
  selectedTable: string | null;
  onViewChange: (view: ViewType) => void;
  currentView: string;
  onHelpClick: () => void;
  onLogoutClick: () => void;
}

export function Sidebar({ 
  onTableSelect, 
  selectedTable, 
  onViewChange, 
  currentView,
  onHelpClick,
  onLogoutClick
}: SidebarProps) {
  const [expandedDatabases, setExpandedDatabases] = useState<string[]>(['conn-1']);
  const [expandedSchemas, setExpandedSchemas] = useState<string[]>(['public']);
  const [searchQuery, setSearchQuery] = useState('');
  const [isConnectionModalOpen, setIsConnectionModalOpen] = useState(false);
  const [editingConnection, setEditingConnection] = useState<Connection | null>(null);
  const [contextMenu, setContextMenu] = useState<{
    isOpen: boolean;
    x: number;
    y: number;
    connection: Connection | null;
  }>({ isOpen: false, x: 0, y: 0, connection: null });

  const [connections, setConnections] = useState<Connection[]>(DEFAULT_CONNECTIONS);

  const schemas: { [key: string]: Schema[] } = DEFAULT_SCHEMAS;

  const toggleDatabase = (dbId: string) => {
    setExpandedDatabases(prev =>
      prev.includes(dbId) ? prev.filter(id => id !== dbId) : [...prev, dbId]
    );
  };

  const toggleSchema = (schemaName: string) => {
    setExpandedSchemas(prev =>
      prev.includes(schemaName) ? prev.filter(name => name !== schemaName) : [...prev, schemaName]
    );
  };

  const handleNewConnection = () => {
    setEditingConnection(null);
    setIsConnectionModalOpen(true);
  };

  const handleSaveConnection = (connection: Connection) => {
    setConnections(prev => {
      const exists = prev.find(c => c.id === connection.id);
      if (exists) {
        return prev.map(c => c.id === connection.id ? connection : c);
      }
      return [...prev, connection];
    });
  };

  const handleEditConnection = (connection: Connection) => {
    setEditingConnection(connection);
    setIsConnectionModalOpen(true);
  };

  const handleDeleteConnection = (connectionId: string) => {
    setConnections(prev => prev.filter(c => c.id !== connectionId));
  };

  const handleConnectionContextMenu = (e: React.MouseEvent, connection: Connection) => {
    e.preventDefault();
    e.stopPropagation();
    setContextMenu({
      isOpen: true,
      x: e.clientX,
      y: e.clientY,
      connection
    });
  };

  const contextMenuItems: ContextMenuItem[] = contextMenu.connection ? [
    {
      label: '편집',
      icon: <Edit2 className="w-4 h-4" />,
      onClick: () => {
        if (contextMenu.connection) {
          handleEditConnection(contextMenu.connection);
        }
      }
    },
    { separator: true, label: '', onClick: () => {} },
    {
      label: '삭제',
      icon: <Trash2 className="w-4 h-4" />,
      onClick: () => {
        if (contextMenu.connection) {
          handleDeleteConnection(contextMenu.connection.id);
        }
      },
      danger: true
    }
  ] : [];

  const filteredConnections = connections.filter(conn =>
    conn.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    conn.type.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getStatusColor = (status: Connection['status']) => {
    switch (status) {
      case 'connected':
        return 'text-emerald-600';
      case 'disconnected':
        return 'text-gray-400';
      case 'error':
        return 'text-rose-600';
    }
  };

  // 검색어에 따라 연결, 스키마, 테이블을 필터링하고 자동으로 확장
  const getFilteredTree = () => {
    if (!searchQuery.trim()) {
      return { connections: filteredConnections, shouldExpand: false };
    }

    const query = searchQuery.toLowerCase();
    const filtered: typeof connections = [];
    const expandDbs: string[] = [];
    const expandSchemas: string[] = [];

    connections.forEach(conn => {
      const connMatch = conn.name.toLowerCase().includes(query) || 
                        conn.type.toLowerCase().includes(query);
      
      const connSchemas = schemas[conn.id] || [];
      const matchingSchemas: Schema[] = [];

      connSchemas.forEach(schema => {
        const schemaMatch = schema.name.toLowerCase().includes(query);
        const matchingTables = schema.tables.filter(table => 
          table.toLowerCase().includes(query)
        );

        if (schemaMatch || matchingTables.length > 0) {
          matchingSchemas.push({
            name: schema.name,
            tables: matchingTables.length > 0 ? matchingTables : schema.tables
          });
          expandDbs.push(conn.id);
          expandSchemas.push(schema.name);
        }
      });

      if (connMatch || matchingSchemas.length > 0) {
        filtered.push(conn);
        if (matchingSchemas.length > 0) {
          schemas[conn.id] = matchingSchemas;
        }
      }
    });

    return { connections: filtered, expandDbs, expandSchemas, shouldExpand: true };
  };

  const { connections: displayConnections, expandDbs, expandSchemas: expandSchemasSearch, shouldExpand } = getFilteredTree();

  // 검색 시 자동으로 트리 확장
  useEffect(() => {
    if (shouldExpand && expandDbs && expandSchemasSearch) {
      setExpandedDatabases(expandDbs);
      setExpandedSchemas(expandSchemasSearch);
    } else if (!searchQuery.trim()) {
      // 검색어가 없으면 기본 상태로
      setExpandedDatabases(['conn-1']);
      setExpandedSchemas(['public']);
    }
  }, [searchQuery, shouldExpand]);

  return (
    <>
      <motion.aside 
        initial={{ x: -288, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        transition={{ 
          type: "spring", 
          stiffness: 260, 
          damping: 20,
          duration: 0.6 
        }}
        className="w-72 bg-white border-r border-gray-200 flex flex-col"
      >
        <div className="p-4 border-b border-gray-200">
          <motion.div 
            className="flex items-center gap-2 mb-4"
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ 
              type: "spring",
              stiffness: 300,
              damping: 25,
              delay: 0.1 
            }}
          >
            <motion.div
              animate={{ 
                rotate: [0, 5, -5, 0],
                scale: [1, 1.05, 1]
              }}
              transition={{
                duration: 3,
                repeat: Infinity,
                ease: "easeInOut"
              }}
            >
              <Database className="w-6 h-6 text-slate-700" />
            </motion.div>
            <span className="text-gray-900 font-bold">DataEye SQL</span>
          </motion.div>
          
          <motion.button
            onClick={handleNewConnection}
            className="w-full flex items-center gap-2 px-3 py-2 bg-blue-700 text-white rounded-lg transition-colors relative overflow-hidden"
            whileHover={{ 
              scale: 1.02,
              boxShadow: "0 4px 12px rgba(29, 78, 216, 0.25)"
            }}
            whileTap={{ scale: 0.98 }}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ 
              type: "spring",
              stiffness: 300,
              damping: 25,
              delay: 0.15 
            }}
          >
            <motion.div
              className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent"
              initial={{ x: '-100%' }}
              animate={{ x: '200%' }}
              transition={{
                duration: 2,
                repeat: Infinity,
                repeatDelay: 1,
                ease: "easeInOut"
              }}
            />
            <Plus className="w-4 h-4 relative z-10" />
            <span className="text-sm relative z-10">새 연결</span>
          </motion.button>
        </div>

        <nav className="flex-1 overflow-y-auto p-2">
          <motion.div 
            className="mb-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
          >
            <div className="px-3 py-2 text-xs text-gray-500 uppercase tracking-wider">탐색</div>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ staggerChildren: 0.05, delayChildren: 0.25 }}
            >
              <NavItem 
                icon={<Home className="w-4 h-4" />} 
                label="홈"
                isActive={currentView === 'home'}
                onClick={() => onViewChange('home')}
                delay={0}
              />
              <NavItem 
                icon={<Activity className="w-4 h-4" />} 
                label="쿼리 기록"
                isActive={currentView === 'history'}
                onClick={() => onViewChange('history')}
                delay={0.05}
              />
              <NavItem 
                icon={<FileText className="w-4 h-4" />} 
                label="저장된 쿼리"
                isActive={currentView === 'saved'}
                onClick={() => onViewChange('saved')}
                delay={0.1}
              />
            </motion.div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.35 }}
          >
            <div className="px-3 py-2 text-xs text-gray-500 uppercase tracking-wider flex items-center justify-between">
              <span>연결</span>
              <motion.span 
                className="text-gray-400"
                key={connections.length}
                initial={{ scale: 1.5, color: '#3b82f6' }}
                animate={{ scale: 1, color: '#9ca3af' }}
                transition={{ type: "spring", stiffness: 500, damping: 25 }}
              >
                {connections.length}
              </motion.span>
            </div>
            
            <motion.div 
              className="px-2 mb-2"
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
            >
              <div className="relative">
                <Search className="absolute left-2 top-1/2 -translate-y-1/2 w-3 h-3 text-gray-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="검색..."
                  className="w-full pl-7 pr-2 py-1.5 text-xs bg-gray-50 border border-gray-300 rounded focus:outline-none focus:ring-1 focus:ring-blue-500 text-gray-900 transition-all"
                />
              </div>
            </motion.div>

            <AnimatePresence mode="popLayout">
              {displayConnections.map((conn, index) => (
                <motion.div 
                  key={conn.id} 
                  className="mb-1"
                  initial={{ opacity: 0, x: -20, height: 0 }}
                  animate={{ 
                    opacity: 1, 
                    x: 0,
                    height: 'auto'
                  }}
                  exit={{ 
                    opacity: 0, 
                    x: -20,
                    height: 0
                  }}
                  transition={{ 
                    type: "spring",
                    stiffness: 500,
                    damping: 30,
                    delay: 0.45 + index * 0.05
                  }}
                  layout
                >
                  <div className="group relative">
                    <motion.button
                      onClick={() => toggleDatabase(conn.id)}
                      onContextMenu={(e) => handleConnectionContextMenu(e, conn)}
                      className="w-full flex items-center gap-2 px-3 py-2 hover:bg-gray-100 rounded-lg transition-colors text-left"
                      whileHover={{ x: 4 }}
                      transition={{ type: "spring", stiffness: 400, damping: 25 }}
                    >
                      <motion.div
                        animate={{ rotate: expandedDatabases.includes(conn.id) ? 90 : 0 }}
                        transition={{ type: "spring", stiffness: 300, damping: 25 }}
                      >
                        <ChevronRight className="w-4 h-4 text-gray-600" />
                      </motion.div>
                      <motion.div
                        whileHover={{ scale: 1.1, rotate: 5 }}
                        transition={{ type: "spring", stiffness: 400 }}
                      >
                        <Database className="w-4 h-4 text-slate-600" />
                      </motion.div>
                      <div className="flex-1 min-w-0">
                        <div className="text-sm text-gray-900 truncate flex items-center gap-2">
                          {conn.name}
                          <motion.div
                            animate={{ 
                              scale: [1, 1.2, 1],
                              opacity: conn.status === 'connected' ? [1, 0.7, 1] : 1
                            }}
                            transition={{ 
                              duration: 2,
                              repeat: conn.status === 'connected' ? Infinity : 0,
                              ease: "easeInOut"
                            }}
                          >
                            <Circle className={`w-2 h-2 fill-current ${getStatusColor(conn.status)}`} />
                          </motion.div>
                        </div>
                        <div className="text-xs text-gray-500">{conn.type}</div>
                      </div>
                      <motion.div
                        onClick={(e) => {
                          e.stopPropagation();
                          handleConnectionContextMenu(e, conn);
                        }}
                        className="opacity-0 group-hover:opacity-100 transition-opacity p-1 hover:bg-gray-200 rounded cursor-pointer"
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.9 }}
                      >
                        <MoreVertical className="w-3 h-3 text-gray-600" />
                      </motion.div>
                    </motion.button>

                    <AnimatePresence>
                      {expandedDatabases.includes(conn.id) && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: 'auto', opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ 
                            type: "spring",
                            stiffness: 300,
                            damping: 30
                          }}
                          className="ml-6 overflow-hidden"
                        >
                          {schemas[conn.id]?.map((schema, schemaIndex) => (
                            <motion.div 
                              key={schema.name} 
                              className="mb-1"
                              initial={{ opacity: 0, x: -10 }}
                              animate={{ opacity: 1, x: 0 }}
                              exit={{ opacity: 0, x: -10 }}
                              transition={{ 
                                type: "spring",
                                stiffness: 400,
                                damping: 25,
                                delay: schemaIndex * 0.05
                              }}
                            >
                              <motion.button
                                onClick={() => toggleSchema(schema.name)}
                                className="w-full flex items-center gap-2 px-3 py-1.5 hover:bg-gray-100 rounded-lg transition-colors text-left"
                                whileHover={{ x: 4 }}
                                transition={{ type: "spring", stiffness: 400, damping: 25 }}
                              >
                                <motion.div
                                  animate={{ rotate: expandedSchemas.includes(schema.name) ? 90 : 0 }}
                                  transition={{ type: "spring", stiffness: 300, damping: 25 }}
                                >
                                  <ChevronRight className="w-3 h-3 text-gray-600" />
                                </motion.div>
                                <motion.div
                                  whileHover={{ scale: 1.15, rotate: -5 }}
                                  transition={{ type: "spring", stiffness: 400 }}
                                >
                                  <Folder className="w-3 h-3 text-amber-600" />
                                </motion.div>
                                <span className="text-sm text-gray-700">{schema.name}</span>
                              </motion.button>

                              <AnimatePresence>
                                {expandedSchemas.includes(schema.name) && (
                                  <motion.div
                                    initial={{ height: 0, opacity: 0 }}
                                    animate={{ height: 'auto', opacity: 1 }}
                                    exit={{ height: 0, opacity: 0 }}
                                    transition={{ 
                                      type: "spring",
                                      stiffness: 300,
                                      damping: 30
                                    }}
                                    className="ml-8 overflow-hidden"
                                  >
                                    {schema.tables.map((table, tableIndex) => (
                                      <motion.button
                                        key={table}
                                        onClick={() => {
                                          onTableSelect(table);
                                          onViewChange('editor');
                                        }}
                                        className={`w-full flex items-center gap-2 px-3 py-1.5 hover:bg-gray-100 rounded-lg transition-colors text-left ${
                                          selectedTable === table ? 'bg-blue-100 text-blue-700' : 'text-gray-700'
                                        }`}
                                        initial={{ opacity: 0, x: -10 }}
                                        animate={{ opacity: 1, x: 0 }}
                                        exit={{ opacity: 0, x: -10 }}
                                        whileHover={{ 
                                          x: 4,
                                          backgroundColor: selectedTable === table 
                                            ? 'rgba(59, 130, 246, 0.15)' 
                                            : undefined
                                        }}
                                        whileTap={{ scale: 0.98 }}
                                        transition={{ 
                                          type: "spring", 
                                          stiffness: 400, 
                                          damping: 25,
                                          delay: tableIndex * 0.03
                                        }}
                                      >
                                        <motion.div
                                          whileHover={{ scale: 1.2, rotate: 10 }}
                                          transition={{ type: "spring", stiffness: 400 }}
                                        >
                                          <Table className="w-3 h-3" />
                                        </motion.div>
                                        <span className="text-sm">{table}</span>
                                      </motion.button>
                                    ))}
                                  </motion.div>
                                )}
                              </AnimatePresence>
                            </motion.div>
                          ))}
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </motion.div>
        </nav>

        <motion.div 
          className="p-2 border-t border-gray-200"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          <NavItem 
            icon={<HelpCircle className="w-4 h-4" />} 
            label="도움말"
            onClick={onHelpClick}
            delay={0}
          />
          <NavItem 
            icon={<LogOut className="w-4 h-4" />} 
            label="로그아웃"
            onClick={onLogoutClick}
            delay={0.05}
          />
        </motion.div>
      </motion.aside>

      <ConnectionModal
        isOpen={isConnectionModalOpen}
        onClose={() => {
          setIsConnectionModalOpen(false);
          setEditingConnection(null);
        }}
        onSave={handleSaveConnection}
        editConnection={editingConnection}
      />

      <ContextMenu
        isOpen={contextMenu.isOpen}
        x={contextMenu.x}
        y={contextMenu.y}
        items={contextMenuItems}
        onClose={() => setContextMenu({ isOpen: false, x: 0, y: 0, connection: null })}
      />
    </>
  );
}

interface NavItemProps {
  icon: React.ReactNode;
  label: string;
  isActive?: boolean;
  onClick?: () => void;
  delay?: number;
}

function NavItem({ icon, label, isActive, onClick, delay = 0 }: NavItemProps) {
  return (
    <motion.button 
      onClick={onClick}
      className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg transition-colors text-left ${
        isActive 
          ? 'bg-blue-100 text-blue-700'
          : 'hover:bg-gray-100 text-gray-700'
      }`}
      initial={{ opacity: 0, x: -10 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -10 }}
      whileHover={{ x: 4, scale: 1.01 }}
      whileTap={{ scale: 0.98 }}
      transition={{ 
        type: "spring", 
        stiffness: 400, 
        damping: 25,
        delay: delay
      }}
    >
      <motion.span 
        className={isActive ? 'text-blue-600' : 'text-gray-600'}
        whileHover={{ scale: 1.1, rotate: isActive ? 0 : 5 }}
        transition={{ type: "spring", stiffness: 400 }}
      >
        {icon}
      </motion.span>
      <span className="text-sm">{label}</span>
    </motion.button>
  );
}
