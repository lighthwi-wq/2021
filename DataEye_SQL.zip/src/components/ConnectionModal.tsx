import React, { useState, useEffect } from 'react';
import { X, Database, CheckCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface ConnectionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (connection: Connection) => void;
  editConnection?: Connection | null;
}

export interface Connection {
  id: string;
  name: string;
  type: 'PostgreSQL' | 'MySQL' | 'MongoDB';
  host: string;
  port: string;
  database: string;
  username: string;
  password: string;
  status: 'connected' | 'disconnected' | 'error';
}

export function ConnectionModal({ isOpen, onClose, onSave, editConnection }: ConnectionModalProps) {
  const [formData, setFormData] = useState<Omit<Connection, 'id' | 'status'>>({
    name: '',
    type: 'PostgreSQL',
    host: 'localhost',
    port: '5432',
    database: '',
    username: '',
    password: ''
  });

  const [testStatus, setTestStatus] = useState<'idle' | 'testing' | 'success' | 'error'>('idle');

  useEffect(() => {
    if (editConnection) {
      setFormData({
        name: editConnection.name || '',
        type: editConnection.type || 'PostgreSQL',
        host: editConnection.host || 'localhost',
        port: editConnection.port || '5432',
        database: editConnection.database || '',
        username: editConnection.username || '',
        password: editConnection.password || ''
      });
    } else {
      setFormData({
        name: '',
        type: 'PostgreSQL',
        host: 'localhost',
        port: '5432',
        database: '',
        username: '',
        password: ''
      });
    }
    setTestStatus('idle');
  }, [editConnection, isOpen]);

  useEffect(() => {
    if (formData.type === 'PostgreSQL') {
      setFormData(prev => ({ ...prev, port: '5432' }));
    } else if (formData.type === 'MySQL') {
      setFormData(prev => ({ ...prev, port: '3306' }));
    } else if (formData.type === 'MongoDB') {
      setFormData(prev => ({ ...prev, port: '27017' }));
    }
  }, [formData.type]);

  const handleTestConnection = async () => {
    setTestStatus('testing');
    // 실제 연결 테스트 시뮬레이션
    await new Promise(resolve => setTimeout(resolve, 1500));
    const success = Math.random() > 0.3; // 70% 성공률
    setTestStatus(success ? 'success' : 'error');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const connection: Connection = {
      id: editConnection?.id || `conn-${Date.now()}`,
      ...formData,
      status: testStatus === 'success' ? 'connected' : 'disconnected'
    };
    onSave(connection);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          transition={{ duration: 0.2 }}
          className="bg-white rounded-lg shadow-xl w-full max-w-md max-h-[90vh] overflow-y-auto"
        >
          <div className="sticky top-0 bg-white border-b border-gray-200 p-4 flex items-center justify-between">
            <h2 className="text-gray-900">
              {editConnection ? '연결 편집' : '새 데이터베이스 연결'}
            </h2>
            <button
              onClick={onClose}
              className="text-gray-500 hover:text-gray-700 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="p-6 space-y-4">
            <div>
              <label className="block text-sm text-gray-700 mb-2">
                연결 이름
              </label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full px-3 py-2 bg-white border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900"
                placeholder="예: 프로덕션 DB"
                required
              />
            </div>

            <div>
              <label className="block text-sm text-gray-700 mb-2">
                데이터베이스 유형
              </label>
              <div className="grid grid-cols-3 gap-2">
                {(['PostgreSQL', 'MySQL', 'MongoDB'] as const).map(type => (
                  <button
                    key={type}
                    type="button"
                    onClick={() => setFormData({ ...formData, type })}
                    className={`px-4 py-2 rounded-lg border transition-all ${
                      formData.type === type
                        ? 'bg-blue-600 text-white border-blue-600'
                        : 'bg-white text-gray-700 border-gray-300 hover:border-blue-500'
                    }`}
                  >
                    <Database className="w-4 h-4 mx-auto mb-1" />
                    <div className="text-xs">{type}</div>
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm text-gray-700 mb-2">
                  호스트
                </label>
                <input
                  type="text"
                  value={formData.host}
                  onChange={(e) => setFormData({ ...formData, host: e.target.value })}
                  className="w-full px-3 py-2 bg-white border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900"
                  required
                />
              </div>
              <div>
                <label className="block text-sm text-gray-700 mb-2">
                  포트
                </label>
                <input
                  type="text"
                  value={formData.port}
                  onChange={(e) => setFormData({ ...formData, port: e.target.value })}
                  className="w-full px-3 py-2 bg-white border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm text-gray-700 mb-2">
                데이터베이스
              </label>
              <input
                type="text"
                value={formData.database}
                onChange={(e) => setFormData({ ...formData, database: e.target.value })}
                className="w-full px-3 py-2 bg-white border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900"
                placeholder="데이터베이스 이름"
                required
              />
            </div>

            <div>
              <label className="block text-sm text-gray-700 mb-2">
                사용자명
              </label>
              <input
                type="text"
                value={formData.username}
                onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                className="w-full px-3 py-2 bg-white border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900"
                required
              />
            </div>

            <div>
              <label className="block text-sm text-gray-700 mb-2">
                비밀번호
              </label>
              <input
                type="password"
                value={formData.password}
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                className="w-full px-3 py-2 bg-white border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900"
                required
              />
            </div>

            <button
              type="button"
              onClick={handleTestConnection}
              disabled={testStatus === 'testing'}
              className={`w-full px-4 py-2 rounded-lg border transition-all ${
                testStatus === 'success'
                  ? 'bg-green-50 border-green-500 text-green-700'
                  : testStatus === 'error'
                  ? 'bg-red-50 border-red-500 text-red-700'
                  : 'bg-white border-gray-300 text-gray-700 hover:border-blue-500'
              }`}
            >
              {testStatus === 'testing' && '연결 테스트 중...'}
              {testStatus === 'success' && (
                <span className="flex items-center justify-center gap-2">
                  <CheckCircle className="w-4 h-4" />
                  연결 성공
                </span>
              )}
              {testStatus === 'error' && '연결 실패 - 다시 시도'}
              {testStatus === 'idle' && '연결 테스트'}
            </button>

            <div className="flex gap-3 pt-4">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
              >
                취소
              </button>
              <button
                type="submit"
                className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                {editConnection ? '저장' : '연결 추가'}
              </button>
            </div>
          </form>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}