import React, { useState } from 'react';
import { Star, Search, Trash2, Play, Edit2, Folder, Plus, X, Save } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useApp } from '../contexts/AppContext';

interface SavedQuery {
  id: string;
  name: string;
  query: string;
  description?: string;
  folder?: string;
  createdAt: Date;
  tags: string[];
}

interface SavedQueriesViewProps {
  onQuerySelect?: (query: string) => void;
}

export function SavedQueriesView({ onQuerySelect }: SavedQueriesViewProps) {
  const { savedQueries, saveQuery, updateSavedQuery, deleteSavedQuery, insertQuery } = useApp();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFolder, setSelectedFolder] = useState<string | null>(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editingQuery, setEditingQuery] = useState<SavedQuery | null>(null);
  const [editingFolderName, setEditingFolderName] = useState<string | null>(null);
  const [editingFolderValue, setEditingFolderValue] = useState('');

  // 편집 폼 상태
  const [formData, setFormData] = useState({
    name: '',
    query: '',
    description: '',
    folder: '',
    tags: [] as string[],
  });
  const [tagInput, setTagInput] = useState('');

  const folders = Array.from(new Set(savedQueries.map(q => q.folder).filter(Boolean))) as string[];

  const filteredQueries = savedQueries.filter(query => {
    const matchesSearch = String(query.name || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
                         String(query.query || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
                         (Array.isArray(query.tags) ? query.tags : []).some(tag => String(tag || '').toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesFolder = !selectedFolder || query.folder === selectedFolder;
    return matchesSearch && matchesFolder;
  });

  const handleEditQuery = (query: SavedQuery) => {
    setEditingQuery(query);
    setFormData({
      name: query.name,
      query: query.query,
      description: query.description || '',
      folder: query.folder || '',
      tags: query.tags,
    });
    setIsEditModalOpen(true);
  };

  const handleSaveEdit = () => {
    if (editingQuery) {
      updateSavedQuery(editingQuery.id, {
        name: formData.name,
        query: formData.query,
        description: formData.description,
        folder: formData.folder,
        tags: formData.tags,
      });
    }
    setIsEditModalOpen(false);
  };

  const handleAddTag = () => {
    if (tagInput.trim() && !formData.tags.includes(tagInput.trim())) {
      setFormData({
        ...formData,
        tags: [...formData.tags, tagInput.trim()],
      });
      setTagInput('');
    }
  };

  const handleRemoveTag = (tag: string) => {
    setFormData({
      ...formData,
      tags: formData.tags.filter(t => t !== tag),
    });
  };

  const handleNewFolder = () => {
    const newFolderName = `새 폴더 ${folders.length + 1}`;
    const newQuery: SavedQuery = {
      id: Date.now().toString(),
      name: '새 쿼리',
      query: 'SELECT * FROM table;',
      description: '',
      folder: newFolderName,
      createdAt: new Date(),
      tags: [],
    };
    saveQuery(newQuery);
    setEditingFolderName(newFolderName);
    setEditingFolderValue(newFolderName);
  };

  const handleStartEditFolder = (folderName: string) => {
    setEditingFolderName(folderName);
    setEditingFolderValue(folderName);
  };

  const handleSaveFolderName = () => {
    if (editingFolderName && editingFolderValue.trim() && editingFolderValue !== editingFolderName) {
      // 해당 폴더의 모든 쿼리 업데이트
      savedQueries
        .filter(q => q.folder === editingFolderName)
        .forEach(query => {
          updateSavedQuery(query.id, {
            ...query,
            folder: editingFolderValue.trim(),
          });
        });
      
      // 선택된 폴더도 업데이트
      if (selectedFolder === editingFolderName) {
        setSelectedFolder(editingFolderValue.trim());
      }
    }
    setEditingFolderName(null);
    setEditingFolderValue('');
  };

  const handleCancelEditFolder = () => {
    setEditingFolderName(null);
    setEditingFolderValue('');
  };

  const handleDeleteFolder = (folderName: string) => {
    if (confirm(`"${folderName}" 폴더를 삭제하시겠습니까? (폴더 내 쿼리는 폴더 없음으로 변경됩니다)`)) {
      savedQueries
        .filter(q => q.folder === folderName)
        .forEach(query => {
          updateSavedQuery(query.id, {
            ...query,
            folder: '',
          });
        });
      
      if (selectedFolder === folderName) {
        setSelectedFolder(null);
      }
    }
  };

  return (
    <div className="flex-1 flex overflow-hidden bg-white dark:bg-[#252526] relative">
      {/* 폴더 사이드바 */}
      <motion.div 
        className="w-56 bg-white dark:bg-[#252526] border-r border-gray-200 dark:border-gray-700 flex-shrink-0"
        animate={{ x: 0 }}
        transition={{ type: "spring", stiffness: 300, damping: 30 }}
      >
        <div className="p-4 border-b border-gray-200 dark:border-gray-700">
          <button 
            onClick={handleNewFolder}
            className="w-full flex items-center gap-2 px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span className="text-sm">새 폴더</span>
          </button>
        </div>
        <div className="p-2">
          <button
            onClick={() => setSelectedFolder(null)}
            className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg transition-colors text-left ${
              selectedFolder === null
                ? 'bg-blue-50 dark:bg-blue-600/20 text-blue-700 dark:text-blue-400'
                : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-[#2d2d30]'
            }`}
          >
            <Star className="w-4 h-4" />
            <span className="text-sm">모든 쿼리</span>
            <span className="ml-auto text-xs text-gray-500">{savedQueries.length}</span>
          </button>
          {folders.map(folder => (
            <div
              key={folder}
              className={`group w-full flex items-center gap-2 px-3 py-2 rounded-lg transition-colors ${
                selectedFolder === folder
                  ? 'bg-blue-50 dark:bg-blue-600/20'
                  : 'hover:bg-gray-100 dark:hover:bg-[#2d2d30]'
              }`}
            >
              {editingFolderName === folder ? (
                <>
                  <Folder className="w-4 h-4 text-gray-400 flex-shrink-0" />
                  <input
                    type="text"
                    value={editingFolderValue}
                    onChange={(e) => setEditingFolderValue(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') handleSaveFolderName();
                      if (e.key === 'Escape') handleCancelEditFolder();
                    }}
                    onBlur={handleSaveFolderName}
                    autoFocus
                    className="flex-1 px-2 py-0.5 text-sm bg-white dark:bg-[#3c3c3c] border border-blue-500 rounded focus:outline-none text-gray-900 dark:text-gray-100"
                  />
                </>
              ) : (
                <>
                  <button
                    onClick={() => setSelectedFolder(folder)}
                    className={`flex-1 flex items-center gap-2 text-left ${
                      selectedFolder === folder
                        ? 'text-blue-700 dark:text-blue-400'
                        : 'text-gray-700 dark:text-gray-300'
                    }`}
                  >
                    <Folder className="w-4 h-4" />
                    <span className="text-sm">{folder}</span>
                    <span className="ml-auto text-xs text-gray-500">
                      {savedQueries.filter(q => q.folder === folder).length}
                    </span>
                  </button>
                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleStartEditFolder(folder);
                      }}
                      className="p-1 hover:bg-gray-200 dark:hover:bg-[#4d4d4d] rounded transition-colors"
                      title="폴더 이름 변경"
                    >
                      <Edit2 className="w-3 h-3 text-gray-500 dark:text-gray-400" />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDeleteFolder(folder);
                      }}
                      className="p-1 hover:bg-red-100 dark:hover:bg-red-900/30 rounded transition-colors"
                      title="폴더 삭제"
                    >
                      <Trash2 className="w-3 h-3 text-red-500 dark:text-red-400" />
                    </button>
                  </div>
                </>
              )}
            </div>
          ))}
        </div>
      </motion.div>

      {/* 쿼리 목록 - 메인 컨테이너 */}
      <motion.div 
        className="flex-1 overflow-y-auto bg-white dark:bg-[#252526]"
        animate={{ 
          marginRight: isEditModalOpen ? '480px' : '0px'
        }}
        transition={{ type: "spring", stiffness: 300, damping: 30 }}
      >
        <div className="min-h-full">
          <div className="sticky top-0 bg-white dark:bg-[#252526] border-b border-gray-200 dark:border-gray-700 p-6 z-10">
            <h1 className="text-xl text-gray-900 dark:text-gray-100 mb-4 flex items-center gap-2">
              <Star className="w-5 h-5" />
              저장된 쿼리
            </h1>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="쿼리, 태그로 검색..."
                className="w-full pl-10 pr-4 py-2 bg-gray-50 dark:bg-[#3c3c3c] border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900 dark:text-gray-100"
              />
            </div>
          </div>

          <div className="p-6 space-y-3">
            {filteredQueries.map((item, index) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.05 }}
                className="bg-white dark:bg-[#252526] rounded-lg border border-gray-200 dark:border-gray-700 p-4 hover:shadow-md transition-shadow"
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="text-gray-900 dark:text-gray-100">{String(item.name || '제목 없음')}</h3>
                      {item.folder && (
                        <span className="px-2 py-0.5 bg-blue-100 dark:bg-blue-600/20 text-blue-700 dark:text-blue-400 text-xs rounded">
                          {String(item.folder)}
                        </span>
                      )}
                    </div>
                    {item.description && (
                      <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                        {String(item.description)}
                      </p>
                    )}
                    <div className="font-mono text-xs text-gray-700 dark:text-gray-300 bg-gray-50 dark:bg-[#1e1e1e] p-3 rounded mb-2 overflow-x-auto">
                      {String(item.query || '')}
                    </div>
                    <div className="flex items-center gap-2 flex-wrap">
                      {Array.isArray(item.tags) && item.tags.map(tag => (
                        <span
                          key={tag}
                          className="px-2 py-0.5 bg-gray-100 dark:bg-[#3c3c3c] text-gray-700 dark:text-gray-300 text-xs rounded"
                        >
                          #{String(tag)}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2 pt-3 border-t border-gray-200 dark:border-gray-700">
                  <button 
                    onClick={() => insertQuery(item.query)}
                    className="flex items-center gap-1 px-3 py-1.5 text-xs bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors"
                  >
                    <Play className="w-3 h-3" />
                    실행
                  </button>
                  <button 
                    onClick={() => handleEditQuery(item)}
                    className="flex items-center gap-1 px-3 py-1.5 text-xs bg-gray-100 dark:bg-[#3c3c3c] text-gray-700 dark:text-gray-300 rounded hover:bg-gray-200 dark:hover:bg-[#4d4d4d] transition-colors"
                  >
                    <Edit2 className="w-3 h-3" />
                    편집
                  </button>
                  <button 
                    onClick={() => deleteSavedQuery(item.id)}
                    className="flex items-center gap-1 px-3 py-1.5 text-xs bg-red-100 dark:bg-red-900/20 text-red-600 dark:text-red-400 rounded hover:bg-red-200 dark:hover:bg-red-900/30 transition-colors ml-auto"
                  >
                    <Trash2 className="w-3 h-3" />
                    삭제
                  </button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </motion.div>

      {/* 편집 모달 */}
      <AnimatePresence>
        {isEditModalOpen && (
          <motion.div
            className="fixed top-0 right-0 h-full w-[480px] bg-white dark:bg-[#252526] shadow-2xl z-50 overflow-y-auto border-l border-gray-200 dark:border-gray-700"
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
          >
            {/* 헤더 */}
            <div className="sticky top-0 bg-white dark:bg-[#252526] border-b border-gray-200 dark:border-gray-700 p-6 z-10">
              <div className="flex items-center justify-between">
                <h2 className="text-xl text-gray-900 dark:text-gray-100">쿼리 편집</h2>
                <button
                  className="text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 transition-colors"
                  onClick={() => setIsEditModalOpen(false)}
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* 폼 내용 */}
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm text-gray-700 dark:text-gray-300 mb-2">이름</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-3 py-2 bg-gray-50 dark:bg-[#3c3c3c] border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900 dark:text-gray-100"
                />
              </div>
              <div>
                <label className="block text-sm text-gray-700 dark:text-gray-300 mb-2">쿼리</label>
                <textarea
                  value={formData.query}
                  onChange={(e) => setFormData({ ...formData, query: e.target.value })}
                  className="w-full px-3 py-2 bg-gray-50 dark:bg-[#3c3c3c] border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900 dark:text-gray-100 font-mono text-sm"
                  rows={8}
                />
              </div>
              <div>
                <label className="block text-sm text-gray-700 dark:text-gray-300 mb-2">설명</label>
                <input
                  type="text"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="w-full px-3 py-2 bg-gray-50 dark:bg-[#3c3c3c] border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900 dark:text-gray-100"
                />
              </div>
              <div>
                <label className="block text-sm text-gray-700 dark:text-gray-300 mb-2">폴더</label>
                <input
                  type="text"
                  value={formData.folder}
                  onChange={(e) => setFormData({ ...formData, folder: e.target.value })}
                  className="w-full px-3 py-2 bg-gray-50 dark:bg-[#3c3c3c] border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900 dark:text-gray-100"
                  list="folder-suggestions"
                />
                <datalist id="folder-suggestions">
                  {folders.map(folder => (
                    <option key={folder} value={folder} />
                  ))}
                </datalist>
              </div>
              <div>
                <label className="block text-sm text-gray-700 dark:text-gray-300 mb-2">태그</label>
                <div className="flex items-center gap-2 mb-2">
                  <input
                    type="text"
                    value={tagInput}
                    onChange={(e) => setTagInput(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddTag())}
                    placeholder="태그 입력 후 Enter"
                    className="flex-1 px-3 py-2 bg-gray-50 dark:bg-[#3c3c3c] border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900 dark:text-gray-100"
                  />
                  <button
                    className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                    onClick={handleAddTag}
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
                <div className="flex items-center gap-2 flex-wrap">
                  {formData.tags.map(tag => (
                    <motion.span
                      key={tag}
                      initial={{ scale: 0.8, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      exit={{ scale: 0.8, opacity: 0 }}
                      className="inline-flex items-center gap-1 px-2 py-1 bg-blue-100 dark:bg-blue-600/20 text-blue-700 dark:text-blue-400 text-sm rounded-lg"
                    >
                      #{tag}
                      <button
                        className="ml-1 text-blue-500 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300"
                        onClick={() => handleRemoveTag(tag)}
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </motion.span>
                  ))}
                </div>
              </div>
            </div>

            {/* 푸터 버튼 */}
            <div className="sticky bottom-0 bg-white dark:bg-[#252526] border-t border-gray-200 dark:border-gray-700 p-6 flex items-center justify-end gap-3">
              <button
                className="px-4 py-2 bg-gray-100 dark:bg-[#3c3c3c] text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-200 dark:hover:bg-[#4d4d4d] transition-colors"
                onClick={() => setIsEditModalOpen(false)}
              >
                취소
              </button>
              <button
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2"
                onClick={handleSaveEdit}
              >
                <Save className="w-4 h-4" />
                저장
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}