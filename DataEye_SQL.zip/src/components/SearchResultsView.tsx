import React, { useState, useMemo } from 'react';
import { Search, Database, FileText, Table2, ChevronRight, Clock, Filter } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { SearchResult } from '../types';

interface SearchResultsViewProps {
  results: SearchResult[];
  searchQuery: string;
  onResultClick: (result: SearchResult) => void;
}

type FilterType = 'all' | 'table' | 'database' | 'schema' | 'query';

export function SearchResultsView({ results, searchQuery, onResultClick }: SearchResultsViewProps) {
  const [selectedFilter, setSelectedFilter] = useState<FilterType>('all');

  const filters = useMemo(() => {
    const counts = {
      all: results.length,
      table: results.filter(r => r.type === 'table').length,
      database: results.filter(r => r.type === 'database').length,
      schema: results.filter(r => r.type === 'schema').length,
      query: results.filter(r => r.type === 'query').length,
    };
    return [
      { id: 'all' as const, label: '전체', count: counts.all },
      { id: 'table' as const, label: '테이블', count: counts.table },
      { id: 'database' as const, label: '데이터베이스', count: counts.database },
      { id: 'schema' as const, label: '스키마', count: counts.schema },
      { id: 'query' as const, label: '쿼리', count: counts.query },
    ].filter(f => f.count > 0);
  }, [results]);

  const filteredResults = useMemo(() => {
    if (selectedFilter === 'all') return results;
    return results.filter(r => r.type === selectedFilter);
  }, [results, selectedFilter]);

  const getIcon = (type: string) => {
    switch (type) {
      case 'table':
        return <Table2 className="w-5 h-5" />;
      case 'query':
        return <FileText className="w-5 h-5" />;
      case 'database':
        return <Database className="w-5 h-5" />;
      default:
        return <Search className="w-5 h-5" />;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'table':
        return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'query':
        return 'bg-green-100 text-green-700 border-green-200';
      case 'database':
        return 'bg-purple-100 text-purple-700 border-purple-200';
      default:
        return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  if (!searchQuery) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center bg-gray-50 p-8">
        <Search className="w-24 h-24 text-gray-300 mb-6" />
        <h2 className="text-2xl text-gray-700 mb-2">검색하려는 항목을 입력하세요</h2>
        <p className="text-gray-500">테이블, 쿼리, 데이터베이스 등을 검색할 수 있습니다</p>
      </div>
    );
  }

  if (results.length === 0) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center bg-gray-50 p-8">
        <Search className="w-24 h-24 text-gray-300 mb-6" />
        <h2 className="text-2xl text-gray-700 mb-2">'{searchQuery}'에 대한 결과가 없습니다</h2>
        <p className="text-gray-500">다른 검색어로 시도해보세요</p>
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-y-auto bg-gray-50">
      {/* Header */}
      <div className="sticky top-0 bg-white border-b border-gray-200 p-6 z-10">
        <div className="flex items-center gap-3 mb-2">
          <Search className="w-6 h-6 text-gray-600" />
          <h1 className="text-2xl text-gray-900">검색 결과</h1>
        </div>
        <p className="text-gray-600">
          '{searchQuery}'에 대한 <strong>{results.length}개</strong>의 결과를 찾았습니다
        </p>
      </div>

      {/* Filters */}
      <div className="sticky top-[72px] bg-white border-b border-gray-200 px-6 py-4 z-10">
        <div className="flex items-center gap-2 flex-wrap">
          {filters.map(filter => (
            <motion.button
              key={filter.id}
              onClick={() => setSelectedFilter(filter.id)}
              className={`px-4 py-2 text-[13px] rounded-lg transition-all ${
                selectedFilter === filter.id 
                  ? 'bg-blue-500 text-white shadow-md' 
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              {filter.label} <span className="ml-1 opacity-75">({filter.count})</span>
            </motion.button>
          ))}
        </div>
      </div>

      {/* Results */}
      <div className="p-6 space-y-3">
        <AnimatePresence mode="popLayout">
          {filteredResults.map((result, index) => (
            <motion.div
              key={result.id}
              layout
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.3, delay: Math.min(index * 0.03, 0.3) }}
              onClick={() => onResultClick(result)}
              className="bg-white rounded-lg border border-gray-200 p-5 hover:shadow-lg hover:border-blue-300 transition-all cursor-pointer group"
            >
              <div className="flex items-start gap-4">
                {/* Icon */}
                <div className={`w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0 border ${getTypeColor(result.type)}`}>
                  {getIcon(result.type)}
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-2">
                    <h3 className="text-lg text-gray-900 group-hover:text-blue-600 transition-colors">
                      {result.title}
                    </h3>
                    <span className={`px-2 py-0.5 text-xs rounded border ${getTypeColor(result.type)}`}>
                      {result.type}
                    </span>
                  </div>
                  <p className="text-gray-600 text-sm mb-3">{result.description}</p>
                  
                  {/* Metadata */}
                  <div className="flex items-center gap-4 text-xs text-gray-500">
                    {result.metadata?.database && (
                      <div className="flex items-center gap-1">
                        <Database className="w-3 h-3" />
                        <span>{result.metadata.database}</span>
                      </div>
                    )}
                    {result.metadata?.lastModified && (
                      <div className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        <span>{new Date(result.metadata.lastModified).toLocaleDateString('ko-KR')}</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Arrow */}
                <div className="flex-shrink-0 text-gray-400 group-hover:text-blue-600 transition-colors">
                  <ChevronRight className="w-5 h-5" />
                </div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}