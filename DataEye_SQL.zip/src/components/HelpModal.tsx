import React from 'react';
import { X, Keyboard, Database, Zap, BookOpen } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface HelpModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function HelpModal({ isOpen, onClose }: HelpModalProps) {
  if (!isOpen) return null;

  const shortcuts = [
    { key: 'Ctrl + Enter', description: '쿼리 실행' },
    { key: 'Ctrl + S', description: '쿼리 저장' },
    { key: 'Ctrl + N', description: '새 쿼리 탭' },
    { key: 'Ctrl + W', description: '탭 닫기' },
    { key: 'Ctrl + /', description: 'AI 챗봇 토글' },
    { key: 'Ctrl + Space', description: '자동완성' },
    { key: 'Ctrl + F', description: '검색' },
    { key: 'F5', description: '새로고침' }
  ];

  const features = [
    {
      icon: <Database className="w-5 h-5" />,
      title: '다중 데이터베이스 지원',
      description: 'PostgreSQL, MySQL, MongoDB 연결 관리'
    },
    {
      icon: <Zap className="w-5 h-5" />,
      title: 'AI 기반 쿼리 작성',
      description: '자연어를 SQL로 자동 변환'
    },
    {
      icon: <Keyboard className="w-5 h-5" />,
      title: '강력한 편집기',
      description: '문법 검증, 자동완성, 코드 하이라이팅'
    },
    {
      icon: <BookOpen className="w-5 h-5" />,
      title: '쿼리 히스토리',
      description: '실행한 모든 쿼리 자동 저장'
    }
  ];

  return (
    <AnimatePresence>
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          transition={{ duration: 0.2 }}
          className="bg-white dark:bg-[#2d2d30] rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto"
        >
          <div className="sticky top-0 bg-white dark:bg-[#2d2d30] border-b border-gray-200 dark:border-gray-700 p-4 flex items-center justify-between">
            <h2 className="text-gray-900 dark:text-gray-100">도움말</h2>
            <button
              onClick={onClose}
              className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="p-6 space-y-6">
            <div>
              <h3 className="text-gray-900 dark:text-gray-100 mb-4 flex items-center gap-2">
                <Keyboard className="w-5 h-5" />
                키보드 단축키
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {shortcuts.map((shortcut, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-3 bg-gray-50 dark:bg-[#3c3c3c] rounded-lg"
                  >
                    <span className="text-sm text-gray-600 dark:text-gray-400">
                      {shortcut.description}
                    </span>
                    <kbd className="px-2 py-1 bg-white dark:bg-[#252526] border border-gray-300 dark:border-gray-600 rounded text-xs text-gray-700 dark:text-gray-300">
                      {shortcut.key}
                    </kbd>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <h3 className="text-gray-900 dark:text-gray-100 mb-4">주요 기능</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {features.map((feature, index) => (
                  <div
                    key={index}
                    className="p-4 bg-gray-50 dark:bg-[#3c3c3c] rounded-lg"
                  >
                    <div className="flex items-center gap-3 mb-2">
                      <div className="text-blue-600 dark:text-blue-500">{feature.icon}</div>
                      <h4 className="text-gray-900 dark:text-gray-100">{feature.title}</h4>
                    </div>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      {feature.description}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-4 border-t border-gray-200 dark:border-gray-700">
              <p className="text-sm text-gray-600 dark:text-gray-400 text-center">
                DataEye SQL v1.0.0 | © 2025
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
