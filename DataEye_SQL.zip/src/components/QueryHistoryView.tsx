import React, { useState } from 'react';
import { Clock, Search, Trash2, Play, Copy, CheckCircle } from 'lucide-react';
import { motion } from 'motion/react';

interface QueryHistoryItem {
  id: string;
  query: string;
  timestamp: Date;
  duration: string;
  status: 'success' | 'error';
  rowsAffected?: number;
}

export function QueryHistoryView() {
  const [searchQuery, setSearchQuery] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const history: QueryHistoryItem[] = [
    {
      id: '1',
      query: 'SELECT * FROM users WHERE created_at > NOW() - INTERVAL \'7 days\' ORDER BY created_at DESC',
      timestamp: new Date(Date.now() - 2 * 60 * 1000),
      duration: '0.45s',
      status: 'success',
      rowsAffected: 156
    },
    {
      id: '2',
      query: 'SELECT COUNT(*) as total, status FROM orders GROUP BY status',
      timestamp: new Date(Date.now() - 15 * 60 * 1000),
      duration: '0.23s',
      status: 'success',
      rowsAffected: 4
    },
    {
      id: '3',
      query: 'UPDATE products SET price = price * 1.1 WHERE category = \'electronics\'',
      timestamp: new Date(Date.now() - 60 * 60 * 1000),
      duration: '1.2s',
      status: 'success',
      rowsAffected: 234
    },
    {
      id: '4',
      query: 'DELETE FROM temp_cache WHERE created_at < NOW() - INTERVAL \'1 day\'',
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
      duration: '0.67s',
      status: 'success',
      rowsAffected: 1542
    },
    {
      id: '5',
      query: 'SELECT u.name, COUNT(o.id) as order_count FROM users u LEFT JOIN orders o ON u.id = o.user_id GROUP BY u.id, u.name HAVING COUNT(o.id) > 5',
      timestamp: new Date(Date.now() - 3 * 60 * 60 * 1000),
      duration: '2.1s',
      status: 'success',
      rowsAffected: 89
    },
    {
      id: '6',
      query: 'SELECT * FROM non_existent_table',
      timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000),
      duration: '0.02s',
      status: 'error'
    }
  ];

  const filteredHistory = history.filter(item =>
    item.query.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const formatTime = (date: Date) => {
    const now = Date.now();
    const diff = now - date.getTime();
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (minutes < 1) return '방금 전';
    if (minutes < 60) return `${minutes}분 전`;
    if (hours < 24) return `${hours}시간 전`;
    return `${days}일 전`;
  };

  const handleCopy = (query: string, id: string) => {
    navigator.clipboard.writeText(query);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="flex-1 overflow-y-auto bg-gray-50 dark:bg-[#1e1e1e]">
      <div className="sticky top-0 bg-white dark:bg-[#252526] border-b border-gray-200 dark:border-gray-700 p-6 z-10">
        <h1 className="text-xl text-gray-900 dark:text-gray-100 mb-4 flex items-center gap-2">
          <Clock className="w-5 h-5" />
          쿼리 히스토리
        </h1>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="쿼리 검색..."
            className="w-full pl-10 pr-4 py-2 bg-gray-50 dark:bg-[#3c3c3c] border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900 dark:text-gray-100"
          />
        </div>
      </div>

      <div className="p-6 space-y-3">
        {filteredHistory.map((item, index) => (
          <motion.div
            key={item.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: index * 0.05 }}
            className={`bg-white dark:bg-[#252526] rounded-lg border ${
              item.status === 'error'
                ? 'border-red-300 dark:border-red-700'
                : 'border-gray-200 dark:border-gray-700'
            } p-4 hover:shadow-md transition-shadow`}
          >
            <div className="flex items-start justify-between mb-3">
              <div className="flex-1">
                <div className="font-mono text-sm text-gray-900 dark:text-gray-100 mb-2 break-all">
                  {item.query}
                </div>
                <div className="flex items-center gap-4 text-xs text-gray-600 dark:text-gray-400">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {formatTime(item.timestamp)}
                  </span>
                  <span>실행 시간: {item.duration}</span>
                  {item.status === 'success' && item.rowsAffected !== undefined && (
                    <span>{item.rowsAffected}개 행 영향받음</span>
                  )}
                  {item.status === 'error' && (
                    <span className="text-red-600 dark:text-red-400">실행 실패</span>
                  )}
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => handleCopy(item.query, item.id)}
                className="flex items-center gap-1 px-3 py-1.5 text-xs bg-gray-100 dark:bg-[#3c3c3c] text-gray-700 dark:text-gray-300 rounded hover:bg-gray-200 dark:hover:bg-[#4d4d4d] transition-colors"
              >
                {copiedId === item.id ? (
                  <>
                    <CheckCircle className="w-3 h-3" />
                    복사됨
                  </>
                ) : (
                  <>
                    <Copy className="w-3 h-3" />
                    복사
                  </>
                )}
              </button>
              <button className="flex items-center gap-1 px-3 py-1.5 text-xs bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors">
                <Play className="w-3 h-3" />
                다시 실행
              </button>
              <button className="flex items-center gap-1 px-3 py-1.5 text-xs bg-red-100 dark:bg-red-900/20 text-red-600 dark:text-red-400 rounded hover:bg-red-200 dark:hover:bg-red-900/30 transition-colors">
                <Trash2 className="w-3 h-3" />
                삭제
              </button>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
