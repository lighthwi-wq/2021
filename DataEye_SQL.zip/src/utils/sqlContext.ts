import { SQLContext, AutocompleteItem } from '../types/autocomplete';
import { SQL_KEYWORDS, SQL_FUNCTIONS, SQL_SNIPPETS, SAMPLE_TABLES, TABLE_COLUMNS } from '../constants/sqlAutocomplete';

/**
 * SQL 컨텍스트 분석
 */
export function analyzeSQLContext(query: string, cursorPosition: number): SQLContext {
  const textBeforeCursor = query.substring(0, cursorPosition);
  const words = textBeforeCursor.trim().split(/\s+/);
  const lastWord = words[words.length - 1] || '';
  
  // 쿼리에서 현재 절 파악
  const queryUpper = textBeforeCursor.toUpperCase();
  let currentClause: SQLContext['currentClause'] = undefined;
  
  if (queryUpper.includes('SELECT') && !queryUpper.includes('FROM')) {
    currentClause = 'SELECT';
  } else if (queryUpper.lastIndexOf('FROM') > queryUpper.lastIndexOf('WHERE')) {
    currentClause = 'FROM';
  } else if (queryUpper.lastIndexOf('WHERE') > queryUpper.lastIndexOf('GROUP BY')) {
    currentClause = 'WHERE';
  } else if (queryUpper.lastIndexOf('JOIN') > queryUpper.lastIndexOf('WHERE')) {
    currentClause = 'JOIN';
  } else if (queryUpper.includes('GROUP BY') && !queryUpper.includes('HAVING')) {
    currentClause = 'GROUP BY';
  } else if (queryUpper.includes('ORDER BY')) {
    currentClause = 'ORDER BY';
  } else if (queryUpper.includes('HAVING')) {
    currentClause = 'HAVING';
  } else if (queryUpper.includes('INSERT INTO')) {
    currentClause = 'INSERT';
  } else if (queryUpper.includes('UPDATE')) {
    currentClause = 'UPDATE';
  } else if (queryUpper.includes('DELETE FROM')) {
    currentClause = 'DELETE';
  } else if (queryUpper.includes('SET')) {
    currentClause = 'SET';
  }
  
  // 쿼리에서 테이블명 추출
  const tables = extractTables(query);
  const currentTable = tables.length > 0 ? tables[tables.length - 1] : undefined;
  
  return {
    keywords: words.filter(w => w.length > 0),
    tables,
    currentTable,
    currentClause,
    lastWord,
    fullQuery: query
  };
}

/**
 * 쿼리에서 테이블명 추출
 */
function extractTables(query: string): string[] {
  const tables: string[] = [];
  const queryUpper = query.toUpperCase();
  
  // FROM 절에서 테이블 찾기
  const fromMatch = query.match(/FROM\s+(\w+)/gi);
  if (fromMatch) {
    fromMatch.forEach(match => {
      const table = match.replace(/FROM\s+/i, '').trim();
      if (SAMPLE_TABLES.some(t => t.name === table.toLowerCase())) {
        tables.push(table.toLowerCase());
      }
    });
  }
  
  // JOIN 절에서 테이블 찾기
  const joinMatch = query.match(/JOIN\s+(\w+)/gi);
  if (joinMatch) {
    joinMatch.forEach(match => {
      const table = match.replace(/JOIN\s+/i, '').trim();
      if (SAMPLE_TABLES.some(t => t.name === table.toLowerCase())) {
        tables.push(table.toLowerCase());
      }
    });
  }
  
  // INSERT INTO, UPDATE, DELETE FROM에서 테이블 찾기
  const dmlMatch = query.match(/(?:INSERT INTO|UPDATE|DELETE FROM)\s+(\w+)/gi);
  if (dmlMatch) {
    dmlMatch.forEach(match => {
      const table = match.replace(/(?:INSERT INTO|UPDATE|DELETE FROM)\s+/i, '').trim();
      if (SAMPLE_TABLES.some(t => t.name === table.toLowerCase())) {
        tables.push(table.toLowerCase());
      }
    });
  }
  
  return [...new Set(tables)]; // 중복 제거
}

/**
 * 컨텍스트 기반 자동완성 제안
 */
export function getContextualSuggestions(context: SQLContext, currentDatabase: string = 'all'): AutocompleteItem[] {
  const { currentClause, lastWord, tables } = context;
  const wordLower = lastWord.toLowerCase();
  const suggestions: AutocompleteItem[] = [];
  
  // 빈 쿼리이거나 새 줄 시작: 스니펫 우선 제안
  if (!context.fullQuery.trim() || lastWord === '') {
    SQL_SNIPPETS.forEach(snippet => {
      suggestions.push({ ...snippet, score: 100 });
    });
    
    // 기본 키워드도 추가
    ['SELECT', 'INSERT INTO', 'UPDATE', 'DELETE FROM', 'CREATE TABLE', 'WITH'].forEach(keyword => {
      const item = SQL_KEYWORDS.find(k => k.text === keyword);
      if (item) {
        suggestions.push({ ...item, score: 90 });
      }
    });
    
    return suggestions.sort((a, b) => (b.score || 0) - (a.score || 0)).slice(0, 15);
  }
  
  // 컨텍스트별 제안
  switch (currentClause) {
    case 'SELECT':
      // SELECT 절: 컬럼, 함수, DISTINCT, CASE 등
      addColumnSuggestions(suggestions, tables, wordLower);
      addMatchingItems(suggestions, SQL_FUNCTIONS.filter(f => f.category === '집계' || f.category === '문자열' || f.category === '날짜/시간'), wordLower, 80);
      addMatchingItems(suggestions, SQL_KEYWORDS.filter(k => ['DISTINCT', 'CASE', 'CAST'].includes(k.text)), wordLower, 70);
      break;
      
    case 'FROM':
      // FROM 절: 테이블명만
      addTableSuggestions(suggestions, wordLower, 100);
      break;
      
    case 'WHERE':
    case 'HAVING':
      // WHERE/HAVING 절: 컬럼, 연산자, 함수
      addColumnSuggestions(suggestions, tables, wordLower);
      addMatchingItems(suggestions, SQL_KEYWORDS.filter(k => k.category === '논리' || k.type === 'operator'), wordLower, 85);
      addMatchingItems(suggestions, SQL_FUNCTIONS, wordLower, 75);
      break;
      
    case 'JOIN':
      // JOIN 절: 테이블명, JOIN 타입
      addTableSuggestions(suggestions, wordLower, 100);
      addMatchingItems(suggestions, SQL_KEYWORDS.filter(k => k.category === 'JOIN'), wordLower, 90);
      break;
      
    case 'GROUP BY':
    case 'ORDER BY':
      // GROUP BY/ORDER BY 절: 컬럼명
      addColumnSuggestions(suggestions, tables, wordLower);
      if (currentClause === 'ORDER BY') {
        addMatchingItems(suggestions, SQL_KEYWORDS.filter(k => k.category === '정렬'), wordLower, 90);
      }
      break;
      
    case 'SET':
      // SET 절: 컬럼명
      addColumnSuggestions(suggestions, tables, wordLower);
      break;
      
    default:
      // 기본: 모든 항목 검색
      addMatchingItems(suggestions, SQL_KEYWORDS, wordLower, 70);
      addTableSuggestions(suggestions, wordLower, 80);
      addColumnSuggestions(suggestions, tables, wordLower);
      addMatchingItems(suggestions, SQL_FUNCTIONS, wordLower, 75);
      
      // 입력이 없으면 스니펫도 제안
      if (wordLower.length < 2) {
        SQL_SNIPPETS.forEach(snippet => {
          suggestions.push({ ...snippet, score: 60 });
        });
      }
  }
  
  // 데이터베이스별 필터링
  const filtered = suggestions.filter(s => 
    !s.database || s.database === 'all' || s.database === currentDatabase
  );
  
  // 점수순 정렬 및 상위 20개만 반환
  return filtered
    .sort((a, b) => (b.score || 0) - (a.score || 0))
    .slice(0, 20);
}

/**
 * 매칭되는 항목 추가
 */
function addMatchingItems(
  suggestions: AutocompleteItem[],
  items: AutocompleteItem[],
  searchWord: string,
  baseScore: number
) {
  items.forEach(item => {
    const itemLower = item.text.toLowerCase();
    const insertTextLower = (item.insertText || item.text).toLowerCase();
    
    if (itemLower.startsWith(searchWord) || insertTextLower.startsWith(searchWord)) {
      // 정확히 시작하면 높은 점수
      suggestions.push({ ...item, score: baseScore + 20 });
    } else if (itemLower.includes(searchWord) || insertTextLower.includes(searchWord)) {
      // 포함되면 기본 점수
      suggestions.push({ ...item, score: baseScore });
    }
  });
}

/**
 * 테이블 제안 추가
 */
function addTableSuggestions(suggestions: AutocompleteItem[], searchWord: string, baseScore: number) {
  SAMPLE_TABLES.forEach(table => {
    if (table.name.toLowerCase().startsWith(searchWord) || searchWord === '') {
      suggestions.push({
        text: table.name,
        type: 'table',
        description: table.description,
        score: table.name.toLowerCase().startsWith(searchWord) ? baseScore + 20 : baseScore
      });
    }
  });
}

/**
 * 컬럼 제안 추가
 */
function addColumnSuggestions(suggestions: AutocompleteItem[], tables: string[], searchWord: string) {
  tables.forEach(tableName => {
    const columns = TABLE_COLUMNS[tableName];
    if (columns) {
      columns.forEach(col => {
        if (col.name.toLowerCase().startsWith(searchWord) || searchWord === '') {
          suggestions.push({
            text: col.name,
            type: 'column',
            category: col.type,
            description: `${tableName}.${col.name} (${col.type})`,
            example: col.description,
            score: col.name.toLowerCase().startsWith(searchWord) ? 85 : 70
          });
        }
      });
    }
  });
  
  // 테이블이 없으면 모든 테이블의 컬럼 제안
  if (tables.length === 0 && searchWord.length >= 2) {
    Object.keys(TABLE_COLUMNS).forEach(tableName => {
      const columns = TABLE_COLUMNS[tableName];
      columns.forEach(col => {
        if (col.name.toLowerCase().includes(searchWord)) {
          suggestions.push({
            text: col.name,
            type: 'column',
            category: col.type,
            description: `${tableName}.${col.name} (${col.type})`,
            example: col.description,
            score: 60
          });
        }
      });
    });
  }
}

/**
 * 자동완성 항목 필터링 및 정렬
 */
export function filterAndSortSuggestions(
  items: AutocompleteItem[],
  searchWord: string
): AutocompleteItem[] {
  // 중복 제거 (text 기준)
  const uniqueMap = new Map<string, AutocompleteItem>();
  items.forEach(item => {
    const existing = uniqueMap.get(item.text);
    if (!existing || (item.score || 0) > (existing.score || 0)) {
      uniqueMap.set(item.text, item);
    }
  });
  
  // 배열로 변환 및 정렬
  return Array.from(uniqueMap.values())
    .sort((a, b) => {
      // 1. 점수순
      const scoreDiff = (b.score || 0) - (a.score || 0);
      if (scoreDiff !== 0) return scoreDiff;
      
      // 2. 타입별 우선순위 (keyword > function > table > column > snippet)
      const typePriority: Record<string, number> = {
        keyword: 5,
        function: 4,
        operator: 4,
        table: 3,
        column: 2,
        snippet: 1
      };
      const typeDiff = (typePriority[b.type] || 0) - (typePriority[a.type] || 0);
      if (typeDiff !== 0) return typeDiff;
      
      // 3. 알파벳순
      return a.text.localeCompare(b.text);
    });
}
