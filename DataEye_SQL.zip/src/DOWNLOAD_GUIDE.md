# 프로젝트 다운로드 및 실행 가이드

## 📥 다운로드 방법

### Figma Make에서 다운로드
1. Figma Make 우측 상단의 **"Download"** 버튼 클릭
2. ZIP 파일로 다운로드됩니다
3. ZIP 파일 압축 해제

### 또는 Git으로 클론 (GitHub 업로드 후)
```bash
git clone https://github.com/your-repo/db-manager-pro.git
cd db-manager-pro
```

## 🚀 프로젝트 실행

### 1. 필수 요구사항
- **Node.js**: v18.0.0 이상
- **npm**: v9.0.0 이상 (또는 yarn, pnpm)

### 2. 의존성 설치
```bash
npm install
# 또는
yarn install
# 또는
pnpm install
```

### 3. 개발 서버 실행
```bash
npm run dev
# 또는
yarn dev
# 또는
pnpm dev
```

브라우저에서 `http://localhost:5173` 접속

### 4. 프로덕션 빌드
```bash
npm run build
# 또는
yarn build
# 또는
pnpm build
```

빌드된 파일은 `dist` 폴더에 생성됩니다.

### 5. 프로덕션 미리보기
```bash
npm run preview
# 또는
yarn preview
# 또는
pnpm preview
```

## 📁 프로젝트 구조

```
db-manager-pro/
├── public/                    # 정적 파일
├── src/
│   ├── core/                 # 핵심 설정
│   │   ├── config/          # 앱 설정 파일
│   │   ├── router/          # 라우팅
│   │   └── providers/       # 전역 프로바이더
│   │
│   ├── features/            # 기능별 모듈
│   │   ├── auth/           # 인증
│   │   ├── dashboard/      # 대시보드
│   │   ├── sql-editor/     # SQL 편집기
│   │   ├── saved-queries/  # 저장된 쿼리
│   │   └── connections/    # DB 연결
│   │
│   ├── shared/             # 공유 리소스
│   │   ├── components/    # 재사용 컴포넌트
│   │   │   ├── ui/       # UI 프리미티브
│   │   │   ├── layout/   # 레이아웃
│   │   │   └── common/   # 공통 컴포넌트
│   │   ├── hooks/        # 커스텀 훅
│   │   ├── utils/        # 유틸리티 함수
│   │   ├── types/        # 타입 정의
│   │   ├── services/     # 비즈니스 로직
│   │   └── constants/    # 상수
│   │
│   ├── styles/            # 전역 스타일
│   │   └── globals.css   # 글로벌 CSS
│   │
│   ├── App.tsx           # 루트 컴포넌트
│   └── main.tsx          # 진입점
│
├── .env.example          # 환경변수 예제
├── package.json          # 의존성 목록
├── tsconfig.json         # TypeScript 설정
├── vite.config.ts        # Vite 설정
├── tailwind.config.js    # Tailwind 설정
├── PROJECT_STRUCTURE.md  # 프로젝트 구조 문서
└── README.md            # 프로젝트 소개
```

## ⚙️ 환경 설정

### 환경 변수 (.env)
```bash
# .env.local 파일 생성
cp .env.example .env.local
```

```env
# API 설정
VITE_API_URL=http://localhost:3000/api
VITE_API_TIMEOUT=30000

# 앱 설정
VITE_APP_NAME="DB Manager Pro"
VITE_APP_VERSION="1.0.0"

# 기타 설정
VITE_MAX_QUERY_HISTORY=100
VITE_DEFAULT_QUERY_LIMIT=1000
```

## 🔑 주요 기능

### 1. 인증 시스템
- 로그인/로그아웃
- 세션 관리
- 보호된 라우트

**기본 로그인 정보** (개발 모드):
- 이메일: `admin@example.com`
- 비밀번호: `password123`

### 2. 데이터베이스 연결
지원 데이터베이스:
- PostgreSQL
- MySQL
- MongoDB
- MariaDB
- Oracle
- MS SQL Server

### 3. SQL 편집기
- 구문 강조 (Monaco Editor)
- 자동완성
- 실시간 검증
- 쿼리 실행
- 결과 시각화

### 4. 저장된 쿼리
- 쿼리 저장 및 관리
- 폴더 구조화
- 태그 시스템
- 검색 기능

### 5. 대시보드
- 실시간 통계
- 차트 시각화
- 드래그 앤 드롭 카드

## 📦 주요 의존성

### Core
- `react` ^18.3.0
- `react-dom` ^18.3.0
- `typescript` ^5.0.0

### UI & Styling
- `tailwindcss` ^4.0.0
- `motion` (Framer Motion)
- `lucide-react` (아이콘)

### Data Visualization
- `recharts`
- `react-dnd`

### Code Editor
- `@monaco-editor/react`

### Utilities
- `date-fns` (날짜 처리)
- `clsx` (클래스 조합)

## 🛠️ 개발 도구

### VSCode 추천 익스텐션
- ESLint
- Prettier
- Tailwind CSS IntelliSense
- TypeScript Vue Plugin
- Error Lens

### VSCode 설정 (.vscode/settings.json)
```json
{
  "editor.formatOnSave": true,
  "editor.defaultFormatter": "esbenp.prettier-vscode",
  "editor.codeActionsOnSave": {
    "source.fixAll.eslint": true
  },
  "typescript.tsdk": "node_modules/typescript/lib",
  "typescript.enablePromptUseWorkspaceTsdk": true
}
```

## 🧪 테스트

### 단위 테스트 실행
```bash
npm test
# 또는
yarn test
```

### 커버리지 확인
```bash
npm run test:coverage
# 또는
yarn test:coverage
```

## 📝 스크립트

```json
{
  "dev": "vite",                    // 개발 서버 시작
  "build": "vite build",            // 프로덕션 빌드
  "preview": "vite preview",        // 빌드 미리보기
  "lint": "eslint src --ext ts,tsx", // Lint 검사
  "format": "prettier --write src",  // 코드 포맷팅
  "type-check": "tsc --noEmit"      // 타입 체크
}
```

## 🌐 배포

### Vercel
```bash
npm install -g vercel
vercel
```

### Netlify
```bash
npm install -g netlify-cli
netlify deploy
```

### GitHub Pages
```bash
npm run build
# dist 폴더를 gh-pages 브랜치에 푸시
```

### Docker
```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build
EXPOSE 5173
CMD ["npm", "run", "preview"]
```

```bash
docker build -t db-manager-pro .
docker run -p 5173:5173 db-manager-pro
```

## 🐛 트러블슈팅

### 포트가 이미 사용 중인 경우
```bash
# 다른 포트로 실행
vite --port 3000
```

### 의존성 설치 오류
```bash
# node_modules 삭제 후 재설치
rm -rf node_modules package-lock.json
npm install
```

### 타입 오류
```bash
# TypeScript 캐시 삭제
rm -rf node_modules/.cache
npm run type-check
```

### 빌드 오류
```bash
# 캐시 클리어 후 재빌드
rm -rf dist .vite
npm run build
```

## 📚 추가 리소스

### 문서
- [PROJECT_STRUCTURE.md](./PROJECT_STRUCTURE.md) - 프로젝트 구조
- [REFACTORING_SUMMARY.md](./REFACTORING_SUMMARY.md) - 리팩토링 내역
- [ARCHITECTURE.md](./ARCHITECTURE.md) - 아키텍처 설계

### 외부 링크
- [React 문서](https://react.dev)
- [TypeScript 문서](https://www.typescriptlang.org/docs)
- [Tailwind CSS 문서](https://tailwindcss.com/docs)
- [Vite 문서](https://vitejs.dev)

## 💬 지원

### 이슈 리포트
GitHub Issues에 문제를 보고해주세요:
```
제목: [버그] 간단한 설명
내용:
- 발생한 문제
- 재현 방법
- 예상 동작
- 실제 동작
- 스크린샷 (선택)
```

### 기능 요청
```
제목: [기능] 기능 이름
내용:
- 필요한 이유
- 사용 시나리오
- 예상 구현 방법
```

## 📄 라이센스

MIT License - 자유롭게 사용 및 수정 가능

---

**개발 시작 전 체크리스트:**
- [ ] Node.js v18+ 설치 확인
- [ ] 의존성 설치 완료
- [ ] 환경 변수 설정 완료
- [ ] 개발 서버 정상 실행 확인
- [ ] PROJECT_STRUCTURE.md 읽기
- [ ] REFACTORING_SUMMARY.md 읽기

**Happy Coding! 🚀**
