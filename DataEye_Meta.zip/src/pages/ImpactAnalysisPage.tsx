import { useState } from 'react';
import { Card } from '../components/common/Card';
import { Button } from '../components/common/Button';
import { Badge } from '../components/common/Badge';
import { Search, AlertTriangle, Database, Table, Activity } from 'lucide-react';
import { colors } from '../constants/designSystem';

export function ImpactAnalysisPage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedColumn, setSelectedColumn] = useState('');
  const [showResults, setShowResults] = useState(false);

  const impactResults = [
    { type: 'Table', name: 'TB_ORDER', impact: 'Direct', severity: 'High', affected: '직접 참조' },
    { type: 'View', name: 'VW_CUSTOMER_SUMMARY', impact: 'Indirect', severity: 'Medium', affected: '계산에 사용' },
    { type: 'Report', name: 'RPT_SALES_MONTHLY', impact: 'Indirect', severity: 'Low', affected: '표시 항목' },
  ];

  const handleAnalyze = () => {
    if (searchTerm) {
      setShowResults(true);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in-up">
      {/* Search Section */}
      <Card>
        <div className="space-y-4">
          <div>
            <h3 className="font-semibold mb-2" style={{ color: colors.textPrimary }}>
              영향도 분석할 컬럼 선택
            </h3>
            <p className="text-sm mb-4" style={{ color: colors.textSecondary }}>
              변경하고자 하는 테이블.컬럼을 입력하세요
            </p>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block mb-2 font-medium" style={{ color: colors.textPrimary }}>
                테이블명
              </label>
              <select 
                className="w-full px-4 py-2 rounded-lg border"
                style={{ borderColor: colors.border }}
              >
                <option value="">선택하세요</option>
                <option value="TB_CUSTOMER">TB_CUSTOMER</option>
                <option value="TB_ORDER">TB_ORDER</option>
                <option value="TB_PRODUCT">TB_PRODUCT</option>
              </select>
            </div>
            <div>
              <label className="block mb-2 font-medium" style={{ color: colors.textPrimary }}>
                컬럼명
              </label>
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full px-4 py-2 rounded-lg border"
                style={{ borderColor: colors.border }}
                placeholder="예: CUST_ID"
              />
            </div>
          </div>

          <div className="flex justify-end">
            <Button 
              variant="primary" 
              icon={<Activity className="w-4 h-4" />}
              onClick={handleAnalyze}
            >
              영향도 분석 시작
            </Button>
          </div>
        </div>
      </Card>

      {/* Results */}
      {showResults && (
        <Card>
          <div className="mb-4">
            <div className="flex items-center gap-3 mb-2">
              <AlertTriangle className="w-5 h-5" style={{ color: colors.warning }} />
              <h3 className="font-semibold" style={{ color: colors.textPrimary }}>
                영향도 분석 결과
              </h3>
            </div>
            <p className="text-sm" style={{ color: colors.textSecondary }}>
              총 {impactResults.length}개의 객체가 영향을 받습니다
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b" style={{ borderColor: colors.divider }}>
                  <th className="text-left py-3 px-4" style={{ color: colors.textSecondary }}>유형</th>
                  <th className="text-left py-3 px-4" style={{ color: colors.textSecondary }}>객체명</th>
                  <th className="text-left py-3 px-4" style={{ color: colors.textSecondary }}>영향도</th>
                  <th className="text-left py-3 px-4" style={{ color: colors.textSecondary }}>심각도</th>
                  <th className="text-left py-3 px-4" style={{ color: colors.textSecondary }}>영향 내용</th>
                </tr>
              </thead>
              <tbody>
                {impactResults.map((result, index) => (
                  <tr 
                    key={index}
                    className="border-b hover:bg-black/[0.02] transition-colors"
                    style={{ borderColor: colors.divider }}
                  >
                    <td className="py-3 px-4">
                      <Badge variant="info">{result.type}</Badge>
                    </td>
                    <td className="py-3 px-4">
                      <span className="font-mono font-medium" style={{ color: colors.textPrimary }}>
                        {result.name}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <Badge variant={result.impact === 'Direct' ? 'error' : 'warning'}>
                        {result.impact}
                      </Badge>
                    </td>
                    <td className="py-3 px-4">
                      <Badge 
                        variant={
                          result.severity === 'High' ? 'error' : 
                          result.severity === 'Medium' ? 'warning' : 
                          'info'
                        }
                      >
                        {result.severity}
                      </Badge>
                    </td>
                    <td className="py-3 px-4" style={{ color: colors.textSecondary }}>
                      {result.affected}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="mt-6 p-4 rounded-lg" style={{ backgroundColor: colors.warningLight }}>
            <div className="flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 flex-shrink-0 mt-0.5" style={{ color: colors.warning }} />
              <div>
                <p className="font-medium mb-1" style={{ color: colors.textPrimary }}>
                  변경 전 주의사항
                </p>
                <p className="text-sm" style={{ color: colors.textSecondary }}>
                  해당 컬럼을 변경하면 위 목록의 객체들에 영향을 미칩니다. 변경 전 관련 담당자와 협의하세요.
                </p>
              </div>
            </div>
          </div>
        </Card>
      )}
    </div>
  );
}
