import { useState } from 'react';
import { 
  Layers, 
  Database, 
  TrendingUp, 
  Search, 
  Filter, 
  Plus, 
  Eye, 
  Edit, 
  Trash2, 
  Download,
  Upload,
  RefreshCw,
  FileText,
  Calendar,
  User,
  Tag,
  GitBranch,
  ArrowUpDown,
  ChevronUp,
  ChevronDown
} from 'lucide-react';
import { Card } from '../components/common/Card';
import { IconBox } from '../components/common/IconBox';
import { Badge } from '../components/common/Badge';
import { Modal } from '../components/common/Modal';

export function MetadataPage() {
  const [selectedItem, setSelectedItem] = useState<any>(null);
  const [showModal, setShowModal] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all');
  const [sortField, setSortField] = useState<string>('');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');

  const stats = [
    { 
      label: '총 테이블', 
      value: '247', 
      icon: Database, 
      color: '#3B82F6',
      bgColor: 'bg-gradient-to-br from-blue-50 to-blue-100/50',
      change: '+3',
      changePercent: '+1.2%',
      isPositive: true 
    },
    { 
      label: '총 컬럼', 
      value: '2,458', 
      icon: Layers, 
      color: '#14B8A6',
      bgColor: 'bg-gradient-to-br from-teal-50 to-teal-100/50',
      change: '+124',
      changePercent: '+5.3%',
      isPositive: true 
    },
    { 
      label: '문서화율', 
      value: '87%', 
      icon: FileText, 
      color: '#2B8DFF',
      bgColor: 'bg-gradient-to-br from-blue-50 to-blue-100/50',
      change: '+7',
      changePercent: '+8.7%',
      isPositive: true 
    },
  ];

  const metadataList = [
    {
      id: 1,
      schema: 'PUBLIC',
      table: 'CUSTOMER',
      description: '고객 기본 정보',
      fields: 24,
      type: 'TABLE',
      owner: '홍길동',
      created: '2024-01-15',
      updated: '2024-11-20',
      status: 'active',
      tags: ['고객', '마스터'],
      relationships: 5
    },
    {
      id: 2,
      schema: 'PUBLIC',
      table: 'ORDER',
      description: '주문 정보',
      fields: 18,
      type: 'TABLE',
      owner: '김철수',
      created: '2024-02-01',
      updated: '2024-11-19',
      status: 'active',
      tags: ['주문', '거래'],
      relationships: 8
    },
    {
      id: 3,
      schema: 'PUBLIC',
      table: 'PRODUCT',
      description: '상품 정보',
      fields: 32,
      type: 'TABLE',
      owner: '이영희',
      created: '2024-01-20',
      updated: '2024-11-18',
      status: 'active',
      tags: ['상품', '마스터'],
      relationships: 6
    },
    {
      id: 4,
      schema: 'ANALYTICS',
      table: 'SALES_SUMMARY',
      description: '매출 요약 뷰',
      fields: 12,
      type: 'VIEW',
      owner: '박민수',
      created: '2024-03-10',
      updated: '2024-11-17',
      status: 'active',
      tags: ['분석', '매출'],
      relationships: 3
    },
    {
      id: 5,
      schema: 'PUBLIC',
      table: 'TRANSACTION',
      description: '거래 이력',
      fields: 28,
      type: 'TABLE',
      owner: '홍길동',
      created: '2024-01-25',
      updated: '2024-11-16',
      status: 'archived',
      tags: ['거래', '이력'],
      relationships: 4
    }
  ];

  const handleViewDetail = (item: any) => {
    setSelectedItem(item);
    setShowModal(true);
  };

  const handleSort = (field: string) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const SortIcon = ({ field }: { field: string }) => {
    if (sortField !== field) {
      return <ArrowUpDown className="w-3.5 h-3.5 text-gray-400 ml-1" />;
    }
    return sortDirection === 'asc' ? (
      <ChevronUp className="w-3.5 h-3.5 ml-1" style={{ color: '#2B8DFF' }} />
    ) : (
      <ChevronDown className="w-3.5 h-3.5 ml-1" style={{ color: '#2B8DFF' }} />
    );
  };

  const filteredMetadata = metadataList.filter(item => {
    const matchesSearch = 
      item.table.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.schema.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesFilter = 
      filterType === 'all' || 
      item.type.toLowerCase() === filterType.toLowerCase() ||
      (filterType === 'active' && item.status === 'active') ||
      (filterType === 'archived' && item.status === 'archived');
    
    return matchesSearch && matchesFilter;
  });

  const sortedMetadata = filteredMetadata.sort((a, b) => {
    if (!sortField) return 0;
    const aValue = a[sortField];
    const bValue = b[sortField];
    if (typeof aValue === 'string' && typeof bValue === 'string') {
      return sortDirection === 'asc' ? aValue.localeCompare(bValue) : bValue.localeCompare(aValue);
    }
    return sortDirection === 'asc' ? (aValue as number) - (bValue as number) : (bValue as number) - (aValue as number);
  });

  return (
    <div className="space-y-6">
      {/* 헤더 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-bold mb-2" style={{ fontSize: '24px', color: '#202124' }}>
            메타데이터 관리
          </h1>
          <p style={{ color: '#5F6368' }}>
            데이터 정의를 체계적으로 관리합니다
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button className="flex items-center gap-2 px-4 py-2 rounded-lg transition-colors" style={{ backgroundColor: '#F1F3F4', color: '#5F6368' }} onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#E8EAED'} onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#F1F3F4'}>
            <Download className="w-4 h-4" />
            내보내기
          </button>
          <button className="flex items-center gap-2 px-4 py-2 rounded-lg transition-colors" style={{ backgroundColor: '#F1F3F4', color: '#5F6368' }} onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#E8EAED'} onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#F1F3F4'}>
            <Upload className="w-4 h-4" />
            가져오기
          </button>
          <button className="flex items-center gap-2 px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition-colors">
            <Plus className="w-4 h-4" />
            새 메타데이터
          </button>
        </div>
      </div>

      {/* 통계 카드 */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {stats.map((stat, idx) => (
          <Card 
            key={idx} 
            padding="lg" 
            className="hover:shadow-lg transition-shadow duration-300"
          >
            <div className="flex items-center justify-between mb-4">
              <div className={`${stat.bgColor} p-3 rounded-xl`}>
                <stat.icon className="w-6 h-6" style={{ color: stat.color }} />
              </div>
              <div className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-teal-500" />
                <span className="text-teal-500 font-bold text-sm">{stat.change}</span>
              </div>
            </div>
            <h3 className="font-bold mb-1" style={{ fontSize: '28px', color: '#202124' }}>
              {stat.value}
            </h3>
            <p className="text-sm" style={{ color: '#5F6368' }}>{stat.label}</p>
          </Card>
        ))}
      </div>

      {/* 검색 및 필터 */}
      <Card padding="lg">
        <div className="flex items-center gap-4 mb-6">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="테이블명, 스키마, 설명으로 검색..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 rounded-lg border bg-white focus:ring-2 focus:ring-blue-500 outline-none transition-all"
              style={{ borderColor: '#DADCE0', color: '#202124' }}
            />
          </div>
          <div className="flex items-center gap-2">
            <Filter className="w-5 h-5 text-gray-400" />
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value)}
              className="px-4 py-2 rounded-lg border bg-white focus:ring-2 focus:ring-blue-500 outline-none transition-all"
              style={{ borderColor: '#DADCE0', color: '#202124' }}
            >
              <option value="all">전체</option>
              <option value="table">테이블</option>
              <option value="view">뷰</option>
              <option value="active">활성</option>
              <option value="archived">보관</option>
            </select>
          </div>
          <button className="flex items-center gap-2 px-4 py-2 rounded-lg transition-colors" style={{ backgroundColor: '#F1F3F4', color: '#5F6368' }} onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#E8EAED'} onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#F1F3F4'}>
            <RefreshCw className="w-4 h-4" />
            새로고침
          </button>
        </div>

        {/* 메타데이터 테이블 */}
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead style={{ backgroundColor: '#F7F8FA' }}>
              <tr style={{ borderBottom: '1px solid #DADCE0' }}>
                <th 
                  className="px-4 py-3 text-left text-sm cursor-pointer hover:bg-gray-100 transition-colors"
                  style={{ color: '#5F6368' }}
                  onClick={() => handleSort('schema')}
                >
                  <div className="flex items-center">
                    스키마
                    <SortIcon field="schema" />
                  </div>
                </th>
                <th 
                  className="px-4 py-3 text-left text-sm cursor-pointer hover:bg-gray-100 transition-colors"
                  style={{ color: '#5F6368' }}
                  onClick={() => handleSort('table')}
                >
                  <div className="flex items-center">
                    테이블명
                    <SortIcon field="table" />
                  </div>
                </th>
                <th 
                  className="px-4 py-3 text-left text-sm"
                  style={{ color: '#5F6368' }}
                >
                  설명
                </th>
                <th 
                  className="px-4 py-3 text-left text-sm cursor-pointer hover:bg-gray-100 transition-colors"
                  style={{ color: '#5F6368' }}
                  onClick={() => handleSort('fields')}
                >
                  <div className="flex items-center">
                    필드
                    <SortIcon field="fields" />
                  </div>
                </th>
                <th 
                  className="px-4 py-3 text-left text-sm cursor-pointer hover:bg-gray-100 transition-colors"
                  style={{ color: '#5F6368' }}
                  onClick={() => handleSort('type')}
                >
                  <div className="flex items-center">
                    타입
                    <SortIcon field="type" />
                  </div>
                </th>
                <th 
                  className="px-4 py-3 text-left text-sm cursor-pointer hover:bg-gray-100 transition-colors"
                  style={{ color: '#5F6368' }}
                  onClick={() => handleSort('owner')}
                >
                  <div className="flex items-center">
                    소유자
                    <SortIcon field="owner" />
                  </div>
                </th>
                <th 
                  className="px-4 py-3 text-left text-sm cursor-pointer hover:bg-gray-100 transition-colors"
                  style={{ color: '#5F6368' }}
                  onClick={() => handleSort('status')}
                >
                  <div className="flex items-center">
                    상태
                    <SortIcon field="status" />
                  </div>
                </th>
                <th 
                  className="px-4 py-3 text-left text-sm"
                  style={{ color: '#5F6368' }}
                >
                  태그
                </th>
                <th 
                  className="px-4 py-3 text-left text-sm"
                  style={{ color: '#5F6368' }}
                >
                  액션
                </th>
              </tr>
            </thead>
            <tbody>
              {sortedMetadata.map((item) => (
                <tr
                  key={item.id}
                  className="border-b transition-colors cursor-pointer"
                  style={{ borderColor: '#DADCE0', backgroundColor: 'transparent' }}
                  onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#F9F9F9'}
                  onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
                  onClick={() => handleViewDetail(item)}
                >
                  <td className="px-4 py-4">
                    <span className="font-mono text-sm" style={{ color: '#202124' }}>
                      {item.schema}
                    </span>
                  </td>
                  <td className="px-4 py-4">
                    <div className="flex items-center gap-2">
                      <Database className="w-4 h-4 text-blue-500" />
                      <span className="font-bold" style={{ color: '#202124' }}>
                        {item.table}
                      </span>
                    </div>
                  </td>
                  <td className="px-4 py-4">
                    <span className="text-sm" style={{ color: '#5F6368' }}>
                      {item.description}
                    </span>
                  </td>
                  <td className="px-4 py-4">
                    <span className="font-bold" style={{ color: '#202124' }}>
                      {item.fields}
                    </span>
                  </td>
                  <td className="px-4 py-4">
                    <Badge variant={item.type === 'TABLE' ? 'default' : 'warning'}>
                      {item.type}
                    </Badge>
                  </td>
                  <td className="px-4 py-4">
                    <div className="flex items-center gap-2">
                      <User className="w-4 h-4 text-gray-400" />
                      <span className="text-sm" style={{ color: '#202124' }}>
                        {item.owner}
                      </span>
                    </div>
                  </td>
                  <td className="px-4 py-4">
                    <Badge variant={item.status === 'active' ? 'success' : 'default'}>
                      {item.status === 'active' ? '활성' : '보관'}
                    </Badge>
                  </td>
                  <td className="px-4 py-4">
                    <div className="flex items-center gap-1">
                      {item.tags.slice(0, 2).map((tag, idx) => (
                        <span
                          key={idx}
                          className="px-2 py-1 rounded text-xs"
                          style={{ backgroundColor: '#F1F3F4', color: '#5F6368' }}
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  </td>
                  <td className="px-4 py-4">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleViewDetail(item);
                        }}
                        className="p-1.5 rounded transition-colors"
                        style={{ color: '#5F6368' }}
                        onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#F1F3F4'}
                        onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                      <button
                        onClick={(e) => e.stopPropagation()}
                        className="p-1.5 rounded transition-colors"
                        style={{ color: '#5F6368' }}
                        onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#F1F3F4'}
                        onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                      <button
                        onClick={(e) => e.stopPropagation()}
                        className="p-1.5 rounded transition-colors"
                        onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#FEE2E2'}
                        onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
                      >
                        <Trash2 className="w-4 h-4 text-red-600" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {filteredMetadata.length === 0 && (
          <div className="py-12 text-center">
            <Database className="w-12 h-12 mx-auto mb-4" style={{ color: '#DADCE0' }} />
            <p style={{ color: '#5F6368' }}>검색 결과가 없습니다</p>
          </div>
        )}
      </Card>

      {/* 상세 모달 */}
      <Modal
        isOpen={showModal}
        onClose={() => setShowModal(false)}
        title={`${selectedItem?.schema}.${selectedItem?.table}`}
        size="xl"
        footer={
          <div className="flex items-center justify-end gap-3">
            <button
              onClick={() => setShowModal(false)}
              className="px-4 py-2 rounded-lg transition-colors"
              style={{ backgroundColor: '#F1F3F4', color: '#5F6368' }}
              onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#E8EAED'}
              onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#F1F3F4'}
            >
              닫기
            </button>
            <button className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors">
              수정
            </button>
          </div>
        }
      >
        {selectedItem && (
          <div className="space-y-6">
            {/* 기본 정보 */}
            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 rounded-lg" style={{ backgroundColor: '#F9F9F9' }}>
                <div className="flex items-center gap-2 mb-2">
                  <FileText className="w-4 h-4 text-gray-500" />
                  <p className="text-sm" style={{ color: '#5F6368' }}>설명</p>
                </div>
                <p className="font-bold" style={{ color: '#202124' }}>
                  {selectedItem.description}
                </p>
              </div>
              <div className="p-4 rounded-lg" style={{ backgroundColor: '#F9F9F9' }}>
                <div className="flex items-center gap-2 mb-2">
                  <Layers className="w-4 h-4 text-gray-500" />
                  <p className="text-sm" style={{ color: '#5F6368' }}>필드 수</p>
                </div>
                <p className="font-bold" style={{ color: '#202124' }}>
                  {selectedItem.fields}개
                </p>
              </div>
              <div className="p-4 rounded-lg" style={{ backgroundColor: '#F9F9F9' }}>
                <div className="flex items-center gap-2 mb-2">
                  <User className="w-4 h-4 text-gray-500" />
                  <p className="text-sm" style={{ color: '#5F6368' }}>소유자</p>
                </div>
                <p className="font-bold" style={{ color: '#202124' }}>
                  {selectedItem.owner}
                </p>
              </div>
              <div className="p-4 rounded-lg" style={{ backgroundColor: '#F9F9F9' }}>
                <div className="flex items-center gap-2 mb-2">
                  <GitBranch className="w-4 h-4 text-gray-500" />
                  <p className="text-sm" style={{ color: '#5F6368' }}>관계</p>
                </div>
                <p className="font-bold" style={{ color: '#202124' }}>
                  {selectedItem.relationships}개
                </p>
              </div>
            </div>

            {/* 태그 */}
            <div>
              <div className="flex items-center gap-2 mb-3">
                <Tag className="w-4 h-4 text-gray-500" />
                <h4 className="font-bold" style={{ color: '#202124' }}>태그</h4>
              </div>
              <div className="flex items-center gap-2">
                {selectedItem.tags.map((tag: string, idx: number) => (
                  <span
                    key={idx}
                    className="px-3 py-1.5 rounded-lg text-sm font-bold"
                    style={{ backgroundColor: '#E8F0FE', color: '#1967D2' }}
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>

            {/* 생성/수정 정보 */}
            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 border rounded-lg" style={{ borderColor: '#DADCE0' }}>
                <div className="flex items-center gap-2 mb-2">
                  <Calendar className="w-4 h-4 text-gray-500" />
                  <p className="text-sm" style={{ color: '#5F6368' }}>생성일</p>
                </div>
                <p className="font-bold" style={{ color: '#202124' }}>
                  {selectedItem.created}
                </p>
              </div>
              <div className="p-4 border rounded-lg" style={{ borderColor: '#DADCE0' }}>
                <div className="flex items-center gap-2 mb-2">
                  <Calendar className="w-4 h-4 text-gray-500" />
                  <p className="text-sm" style={{ color: '#5F6368' }}>수정일</p>
                </div>
                <p className="font-bold" style={{ color: '#202124' }}>
                  {selectedItem.updated}
                </p>
              </div>
            </div>

            {/* 필드 목록 예시 */}
            <div>
              <h4 className="font-bold mb-4" style={{ color: '#202124' }}>필드 목록</h4>
              <div className="border rounded-lg overflow-hidden" style={{ borderColor: '#DADCE0' }}>
                <table className="w-full">
                  <thead style={{ backgroundColor: '#F7F8FA' }}>
                    <tr>
                      <th className="px-4 py-3 text-left text-sm" style={{ color: '#5F6368' }}>필드명</th>
                      <th className="px-4 py-3 text-left text-sm" style={{ color: '#5F6368' }}>타입</th>
                      <th className="px-4 py-3 text-left text-sm" style={{ color: '#5F6368' }}>Null 허용</th>
                      <th className="px-4 py-3 text-left text-sm" style={{ color: '#5F6368' }}>설명</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      { name: 'ID', type: 'NUMBER', nullable: 'NO', description: '고유 식별자' },
                      { name: 'NAME', type: 'VARCHAR(100)', nullable: 'NO', description: '이름' },
                      { name: 'EMAIL', type: 'VARCHAR(255)', nullable: 'YES', description: '이메일' },
                      { name: 'PHONE', type: 'VARCHAR(20)', nullable: 'YES', description: '전화번호' },
                    ].map((field, idx) => (
                      <tr key={idx} className="border-t" style={{ borderColor: '#DADCE0' }}>
                        <td className="px-4 py-3 font-mono text-sm" style={{ color: '#202124' }}>
                          {field.name}
                        </td>
                        <td className="px-4 py-3 text-sm" style={{ color: '#202124' }}>
                          {field.type}
                        </td>
                        <td className="px-4 py-3">
                          <Badge variant={field.nullable === 'NO' ? 'error' : 'default'}>
                            {field.nullable}
                          </Badge>
                        </td>
                        <td className="px-4 py-3 text-sm" style={{ color: '#5F6368' }}>
                          {field.description}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}