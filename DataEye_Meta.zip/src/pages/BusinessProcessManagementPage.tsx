import { useState, useMemo } from 'react';
import { Workflow, Plus, Search, Filter, Download, Upload, GitBranch, Users, Clock, CheckCircle, ArrowUpDown, ChevronUp, ChevronDown, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { colors } from '../constants/designSystem';
import { useTheme } from '../contexts/ThemeContext';
import { Pagination } from '../components/common/Pagination';

interface BusinessProcess {
  id: string;
  processName: string;
  processCode: string;
  businessArea: string;
  owner: string;
  status: 'active' | 'inactive' | 'draft';
  steps: number;
  createdDate: string;
  updatedDate: string;
  description: string;
}

export function BusinessProcessManagementPage() {
  const { isDarkMode } = useTheme();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedProcess, setSelectedProcess] = useState<BusinessProcess | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [sortField, setSortField] = useState<string>('');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);

  const [processes, setProcesses] = useState<BusinessProcess[]>([
    {
      id: '1',
      processName: '고객 주문 처리',
      processCode: 'PROC-001',
      businessArea: '영업',
      owner: '김영업',
      status: 'active',
      steps: 8,
      createdDate: '2024-01-15',
      updatedDate: '2024-11-18',
      description: '고객 주문 수부터 배송 완료까지의 전체 프로세스'
    },
    {
      id: '2',
      processName: '재고 관리',
      processCode: 'PROC-002',
      businessArea: '물류',
      owner: '이물류',
      status: 'active',
      steps: 6,
      createdDate: '2024-02-01',
      updatedDate: '2024-11-19',
      description: '입고, 출고, 재고 조정 등 재고 관리 전반'
    },
    {
      id: '3',
      processName: '매출 정산',
      processCode: 'PROC-003',
      businessArea: '회계',
      owner: '박회계',
      status: 'active',
      steps: 10,
      createdDate: '2024-01-20',
      updatedDate: '2024-11-20',
      description: '일일 매출 집계 및 정산 프로세스'
    },
    {
      id: '4',
      processName: '고객 불만 처리',
      processCode: 'PROC-004',
      businessArea: '고객서비스',
      owner: '최서비스',
      status: 'active',
      steps: 5,
      createdDate: '2024-03-10',
      updatedDate: '2024-11-17',
      description: '고객 불만 접수부터 해결까지의 처리 절차'
    },
    {
      id: '5',
      processName: '신규 입점 승인',
      processCode: 'PROC-005',
      businessArea: '파트너십',
      owner: '정파트너',
      status: 'draft',
      steps: 7,
      createdDate: '2024-04-01',
      updatedDate: '2024-11-15',
      description: '신규 파트너사 입점 심사 및 승인 프로세스'
    },
  ]);

  const filteredProcesses = processes.filter(process =>
    process.processName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    process.processCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
    process.businessArea.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSort = (field: string) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const SortIcon = ({ field }: { field: string }) => {
    if (sortField !== field) {
      return <ArrowUpDown className="w-3.5 h-3.5 text-gray-400 ml-1" />;
    }
    return sortDirection === 'asc' ? (
      <ChevronUp className="w-3.5 h-3.5 ml-1" style={{ color: '#2B8DFF' }} />
    ) : (
      <ChevronDown className="w-3.5 h-3.5 ml-1" style={{ color: '#2B8DFF' }} />
    );
  };

  const sortedProcesses = [...filteredProcesses].sort((a, b) => {
    if (!sortField) return 0;
    
    let aVal = a[sortField as keyof typeof a];
    let bVal = b[sortField as keyof typeof b];
    
    if (typeof aVal === 'number' && typeof bVal === 'number') {
      return sortDirection === 'asc' ? aVal - bVal : bVal - aVal;
    }
    
    const aStr = String(aVal).toLowerCase();
    const bStr = String(bVal).toLowerCase();
    
    if (sortDirection === 'asc') {
      return aStr < bStr ? -1 : aStr > bStr ? 1 : 0;
    } else {
      return aStr > bStr ? -1 : aStr < bStr ? 1 : 0;
    }
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return '#F59E0B';
      case 'inactive': return '#6B7280';
      case 'draft': return '#F59E0B';
      default: return '#6B7280';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'active': return '활성';
      case 'inactive': return '비활성';
      case 'draft': return '작성중';
      default: return status;
    }
  };

  const handleAddProcess = () => {
    setSelectedProcess(null);
    setIsModalOpen(true);
  };

  const handleEditProcess = (process: BusinessProcess) => {
    setSelectedProcess(process);
    setIsModalOpen(true);
  };

  const handleViewDetail = (process: BusinessProcess) => {
    setSelectedProcess(process);
    setIsDetailModalOpen(true);
  };

  const handleSaveProcess = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    const newProcess: BusinessProcess = {
      id: selectedProcess?.id || Date.now().toString(),
      processName: formData.get('processName') as string,
      processCode: formData.get('processCode') as string,
      businessArea: formData.get('businessArea') as string,
      owner: formData.get('owner') as string,
      status: formData.get('status') as 'active' | 'inactive' | 'draft',
      steps: parseInt(formData.get('steps') as string),
      description: formData.get('description') as string,
      createdDate: selectedProcess?.createdDate || new Date().toISOString().split('T')[0],
      updatedDate: new Date().toISOString().split('T')[0],
    };

    if (selectedProcess) {
      setProcesses(processes.map(p => p.id === selectedProcess.id ? newProcess : p));
    } else {
      setProcesses([...processes, newProcess]);
    }
    
    setIsModalOpen(false);
  };

  const handleDeleteProcess = (id: string) => {
    if (confirm('정말 삭제하시겠습니까?')) {
      setProcesses(processes.filter(p => p.id !== id));
    }
  };

  const paginatedProcesses = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage;
    const end = start + itemsPerPage;
    return sortedProcesses.slice(start, end);
  }, [currentPage, itemsPerPage, sortedProcesses]);

  return (
    <div className="flex gap-0 h-full relative">
      {/* 메인 콘텐츠 영역 */}
      <motion.div
        className="flex-1 overflow-auto"
        animate={{
          marginRight: isModalOpen || isDetailModalOpen ? '600px' : '0px'
        }}
        transition={{
          type: 'spring',
          damping: 30,
          stiffness: 300
        }}
      >
        <div className="space-y-6">
          {/* 상단 통계 카드 */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {[
              { label: '전체 프로세스', value: processes.length, max: 100, icon: Workflow, color: '#0066FF' },
              { label: '활성 프로세스', value: processes.filter(p => p.status === 'active').length, max: processes.length, icon: CheckCircle, color: '#F59E0B' },
              { label: '평균 단계', value: Math.round(processes.reduce((acc, p) => acc + p.steps, 0) / processes.length), max: 15, icon: GitBranch, color: '#2B8DFF' },
              { label: '작성중', value: processes.filter(p => p.status === 'draft').length, max: processes.length, icon: Clock, color: '#F59E0B' },
            ].map((stat, idx) => (
              <div
                key={idx}
                className="rounded-2xl p-6 border transition-all duration-200 hover:shadow-lg"
                style={{
                  backgroundColor: isDarkMode ? '#252525' : '#FFFFFF',
                  borderColor: isDarkMode ? '#373737' : '#E9EAEC',
                }}
              >
                <div className="flex items-center justify-between mb-3">
                  <div
                    className="p-3 rounded-xl"
                    style={{
                      backgroundColor: isDarkMode ? `${stat.color}20` : `${stat.color}15`,
                    }}
                  >
                    <stat.icon className="w-5 h-5" style={{ color: stat.color }} />
                  </div>
                  <span className="text-2xl font-bold" style={{ color: isDarkMode ? '#EBEBEB' : '#37352F' }}>
                    {stat.value}
                  </span>
                </div>
                <p className="text-sm mb-3" style={{ color: isDarkMode ? '#B4B4B4' : '#787774' }}>
                  {stat.label}
                </p>
                {/* Progress Bar */}
                <div className="w-1/2 h-1 rounded-full overflow-hidden" style={{ backgroundColor: isDarkMode ? '#191919' : '#F7F8FA' }}>
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{
                      width: `${Math.min((stat.value / stat.max) * 100, 100)}%`,
                      backgroundColor: stat.color,
                    }}
                  />
                </div>
              </div>
            ))}
          </div>

          {/* 검색 및 액션 바 */}
          <div
            className="rounded-2xl p-6 border"
            style={{
              backgroundColor: isDarkMode ? '#252525' : '#FFFFFF',
              borderColor: isDarkMode ? '#373737' : '#E9EAEC',
            }}
          >
            <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between">
              <div className="flex-1 max-w-md relative">
                <Search
                  className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4"
                  style={{ color: isDarkMode ? '#6B7280' : '#9CA3AF' }}
                />
                <input
                  type="text"
                  placeholder="프로세스명, 코드, 업무영역으로 검색..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 rounded-lg border transition-colors duration-200"
                  style={{
                    backgroundColor: isDarkMode ? '#191919' : '#F7F8FA',
                    borderColor: isDarkMode ? '#373737' : '#E9EAEC',
                    color: isDarkMode ? '#EBEBEB' : '#37352F',
                  }}
                />
              </div>
              <div className="flex gap-2">
                <button
                  onClick={handleAddProcess}
                  className="px-4 py-2 rounded-full flex items-center gap-2 transition-all duration-200 hover:shadow-md"
                  style={{
                    backgroundColor: '#000000',
                    color: '#FFFFFF',
                  }}
                >
                  <Plus className="w-4 h-4" style={{ color: '#FFFFFF' }} />
                  <span className="text-sm font-medium" style={{ color: '#FFFFFF' }}>프로세스 등록</span>
                </button>
                <button
                  className="px-4 py-2 rounded-lg flex items-center gap-2 border transition-all duration-200 hover:shadow-md"
                  style={{
                    backgroundColor: isDarkMode ? '#252525' : '#FFFFFF',
                    borderColor: isDarkMode ? '#373737' : '#E9EAEC',
                    color: isDarkMode ? '#EBEBEB' : '#37352F',
                  }}
                >
                  <Filter className="w-4 h-4" />
                  <span className="text-sm">필터</span>
                </button>
                <button
                  className="px-4 py-2 rounded-lg flex items-center gap-2 border transition-all duration-200 hover:shadow-md"
                  style={{
                    backgroundColor: isDarkMode ? '#252525' : '#FFFFFF',
                    borderColor: isDarkMode ? '#373737' : '#E9EAEC',
                    color: isDarkMode ? '#EBEBEB' : '#37352F',
                  }}
                >
                  <Download className="w-4 h-4" />
                </button>
                <button
                  className="px-4 py-2 rounded-lg flex items-center gap-2 border transition-all duration-200 hover:shadow-md"
                  style={{
                    backgroundColor: isDarkMode ? '#252525' : '#FFFFFF',
                    borderColor: isDarkMode ? '#373737' : '#E9EAEC',
                    color: isDarkMode ? '#EBEBEB' : '#37352F',
                  }}
                >
                  <Upload className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>

          {/* 프로세스 테이블 */}
          <div
            className="rounded-2xl border overflow-hidden"
            style={{
              backgroundColor: isDarkMode ? '#252525' : '#FFFFFF',
              borderColor: isDarkMode ? '#373737' : '#E9EAEC',
            }}
          >
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead style={{ backgroundColor: '#F7F8FA' }}>
                  <tr style={{ borderBottom: '1px solid #DADCE0' }}>
                    <th 
                      className="px-4 py-3 text-left text-sm cursor-pointer hover:bg-gray-100 transition-colors"
                      style={{ color: sortField === 'processName' ? '#2B8DFF' : '#5F6368' }}
                      onClick={() => handleSort('processName')}
                    >
                      <div className="flex items-center">
                        프로세스명
                        <SortIcon field="processName" />
                      </div>
                    </th>
                    <th 
                      className="px-4 py-3 text-left text-sm cursor-pointer hover:bg-gray-100 transition-colors"
                      style={{ color: sortField === 'businessArea' ? '#2B8DFF' : '#5F6368' }}
                      onClick={() => handleSort('businessArea')}
                    >
                      <div className="flex items-center">
                        업무 영역
                        <SortIcon field="businessArea" />
                      </div>
                    </th>
                    <th 
                      className="px-4 py-3 text-left text-sm cursor-pointer hover:bg-gray-100 transition-colors"
                      style={{ color: sortField === 'steps' ? '#2B8DFF' : '#5F6368' }}
                      onClick={() => handleSort('steps')}
                    >
                      <div className="flex items-center">
                        단계
                        <SortIcon field="steps" />
                      </div>
                    </th>
                    <th 
                      className="px-4 py-3 text-left text-sm cursor-pointer hover:bg-gray-100 transition-colors"
                      style={{ color: sortField === 'owner' ? '#2B8DFF' : '#5F6368' }}
                      onClick={() => handleSort('owner')}
                    >
                      <div className="flex items-center">
                        담당자
                        <SortIcon field="owner" />
                      </div>
                    </th>
                    <th 
                      className="px-4 py-3 text-left text-sm cursor-pointer hover:bg-gray-100 transition-colors"
                      style={{ color: sortField === 'status' ? '#2B8DFF' : '#5F6368' }}
                      onClick={() => handleSort('status')}
                    >
                      <div className="flex items-center">
                        상태
                        <SortIcon field="status" />
                      </div>
                    </th>
                    <th 
                      className="px-4 py-3 text-left text-sm cursor-pointer hover:bg-gray-100 transition-colors"
                      style={{ color: sortField === 'updatedDate' ? '#2B8DFF' : '#5F6368' }}
                      onClick={() => handleSort('updatedDate')}
                    >
                      <div className="flex items-center">
                        수정일
                        <SortIcon field="updatedDate" />
                      </div>
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {paginatedProcesses.map((process, idx) => (
                    <tr
                      key={process.id}
                      className="cursor-pointer transition-colors duration-150"
                      style={{
                        borderBottom: idx < paginatedProcesses.length - 1 ? `1px solid ${isDarkMode ? '#373737' : '#E9EAEC'}` : 'none',
                      }}
                      onMouseEnter={(e) => {
                        e.currentTarget.style.backgroundColor = isDarkMode ? '#1F1F1F' : '#F7F8FA';
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.backgroundColor = 'transparent';
                      }}
                      onClick={() => handleViewDetail(process)}
                    >
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <div
                            className="p-2 rounded-lg"
                            style={{
                              backgroundColor: isDarkMode ? '#0066FF20' : '#0066FF15',
                            }}
                          >
                            <Workflow className="w-4 h-4" style={{ color: '#0066FF' }} />
                          </div>
                          <span className="text-sm font-medium" style={{ color: isDarkMode ? '#EBEBEB' : '#37352F' }}>
                            {process.processName}
                          </span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span className="text-sm" style={{ color: isDarkMode ? '#B4B4B4' : '#787774' }}>
                          {process.businessArea}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <span className="text-sm" style={{ color: isDarkMode ? '#B4B4B4' : '#787774' }}>
                          {process.steps}단계
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <Users className="w-4 h-4" style={{ color: isDarkMode ? '#6B7280' : '#9CA3AF' }} />
                          <span className="text-sm" style={{ color: isDarkMode ? '#B4B4B4' : '#787774' }}>
                            {process.owner}
                          </span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span
                          className="px-3 py-1 rounded-full text-xs font-medium"
                          style={{
                            backgroundColor: `${getStatusColor(process.status)}20`,
                            color: getStatusColor(process.status),
                          }}
                        >
                          {getStatusText(process.status)}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <span className="text-sm" style={{ color: isDarkMode ? '#B4B4B4' : '#787774' }}>
                          {process.updatedDate}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <Pagination
              totalItems={sortedProcesses.length}
              itemsPerPage={itemsPerPage}
              currentPage={currentPage}
              totalPages={Math.ceil(sortedProcesses.length / itemsPerPage)}
              onPageChange={setCurrentPage}
              onItemsPerPageChange={setItemsPerPage}
            />
          </div>
        </div>
      </motion.div>

      {/* 등록/수정 모달 */}
      <AnimatePresence>
        {isModalOpen && (
          <motion.div
            className="fixed right-0 top-0 h-screen w-[600px] z-50 shadow-2xl overflow-hidden flex flex-col border-l"
            style={{
              backgroundColor: colors.bgPrimary,
              borderColor: colors.border,
            }}
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ 
              type: 'spring',
              damping: 30,
              stiffness: 300
            }}
          >
            {/* Header */}
            <div
              className="px-8 py-6 border-b flex items-center justify-between flex-shrink-0"
              style={{
                backgroundColor: colors.bgPrimary,
                borderColor: colors.border,
              }}
            >
              <div>
                <h3 className="text-xl font-bold" style={{ color: colors.textPrimary }}>
                  {selectedProcess ? '프로세스 수정' : '프로세스 등록'}
                </h3>
                <p className="text-sm mt-1" style={{ color: colors.textSecondary }}>
                  {selectedProcess ? '기존 프로세스 정보를 수정합니다' : '새로운 업무 프로세스를 등록합니다'}
                </p>
              </div>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
                style={{ color: colors.textSecondary }}
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto px-8 py-6">
              <form onSubmit={handleSaveProcess} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: colors.textPrimary }}>
                    프로세스명 *
                  </label>
                  <input
                    type="text"
                    name="processName"
                    defaultValue={selectedProcess?.processName}
                    required
                    className="w-full px-4 py-2 rounded-lg border"
                    style={{
                      backgroundColor: colors.surface,
                      borderColor: colors.border,
                      color: colors.textPrimary,
                    }}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: colors.textPrimary }}>
                    프로세스 코드 *
                  </label>
                  <input
                    type="text"
                    name="processCode"
                    defaultValue={selectedProcess?.processCode}
                    required
                    className="w-full px-4 py-2 rounded-lg border"
                    style={{
                      backgroundColor: colors.surface,
                      borderColor: colors.border,
                      color: colors.textPrimary,
                    }}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: colors.textPrimary }}>
                    업무영역 *
                  </label>
                  <input
                    type="text"
                    name="businessArea"
                    defaultValue={selectedProcess?.businessArea}
                    required
                    className="w-full px-4 py-2 rounded-lg border"
                    style={{
                      backgroundColor: colors.surface,
                      borderColor: colors.border,
                      color: colors.textPrimary,
                    }}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: colors.textPrimary }}>
                    담당자 *
                  </label>
                  <input
                    type="text"
                    name="owner"
                    defaultValue={selectedProcess?.owner}
                    required
                    className="w-full px-4 py-2 rounded-lg border"
                    style={{
                      backgroundColor: colors.surface,
                      borderColor: colors.border,
                      color: colors.textPrimary,
                    }}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: colors.textPrimary }}>
                    단계 수 *
                  </label>
                  <input
                    type="number"
                    name="steps"
                    defaultValue={selectedProcess?.steps}
                    required
                    min="1"
                    className="w-full px-4 py-2 rounded-lg border"
                    style={{
                      backgroundColor: colors.surface,
                      borderColor: colors.border,
                      color: colors.textPrimary,
                    }}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: colors.textPrimary }}>
                    상태 *
                  </label>
                  <select
                    name="status"
                    defaultValue={selectedProcess?.status || 'draft'}
                    required
                    className="w-full px-4 py-2 rounded-lg border"
                    style={{
                      backgroundColor: colors.surface,
                      borderColor: colors.border,
                      color: colors.textPrimary,
                    }}
                  >
                    <option value="active">활성</option>
                    <option value="inactive">비활성</option>
                    <option value="draft">작성중</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: colors.textPrimary }}>
                    설명
                  </label>
                  <textarea
                    name="description"
                    defaultValue={selectedProcess?.description}
                    rows={4}
                    className="w-full px-4 py-2 rounded-lg border resize-none"
                    style={{
                      backgroundColor: colors.surface,
                      borderColor: colors.border,
                      color: colors.textPrimary,
                    }}
                  />
                </div>
              </form>
            </div>

            {/* Footer */}
            <div
              className="px-8 py-4 border-t flex items-center justify-end gap-3 flex-shrink-0"
              style={{
                backgroundColor: colors.bgPrimary,
                borderColor: colors.border,
              }}
            >
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="px-4 py-2 rounded-lg font-medium border transition-all duration-200"
                style={{
                  backgroundColor: colors.bgPrimary,
                  borderColor: colors.border,
                  color: colors.textPrimary,
                }}
              >
                취소
              </button>
              <button
                type="submit"
                onClick={(e) => {
                  e.preventDefault();
                  const form = e.currentTarget.closest('div')?.parentElement?.querySelector('form');
                  if (form) {
                    const formEvent = new Event('submit', { bubbles: true, cancelable: true }) as any;
                    Object.defineProperty(formEvent, 'currentTarget', { value: form, writable: false });
                    handleSaveProcess(formEvent);
                  }
                }}
                className="px-4 py-2 rounded-lg font-medium transition-all duration-200"
                style={{
                  backgroundColor: '#2B8DFF',
                  color: '#FFFFFF',
                }}
              >
                {selectedProcess ? '수정' : '등록'}
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 상세 모달 */}
      <AnimatePresence>
        {isDetailModalOpen && selectedProcess && (
          <motion.div
            className="fixed right-0 top-0 h-screen w-[600px] z-50 shadow-2xl overflow-hidden flex flex-col border-l"
            style={{
              backgroundColor: colors.bgPrimary,
              borderColor: colors.border,
            }}
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ 
              type: 'spring',
              damping: 30,
              stiffness: 300
            }}
          >
            {/* Header */}
            <div
              className="px-8 py-6 border-b flex items-center justify-between flex-shrink-0"
              style={{
                backgroundColor: colors.bgPrimary,
                borderColor: colors.border,
              }}
            >
              <div className="flex items-center gap-4">
                <div
                  className="p-3 rounded-xl"
                  style={{
                    backgroundColor: 'rgba(0, 102, 255, 0.15)',
                  }}
                >
                  <Workflow className="w-6 h-6" style={{ color: '#0066FF' }} />
                </div>
                <div>
                  <h3 className="text-xl font-bold" style={{ color: colors.textPrimary }}>
                    {selectedProcess.processName}
                  </h3>
                  <p className="text-sm mt-1" style={{ color: colors.textSecondary }}>
                    {selectedProcess.processCode}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsDetailModalOpen(false)}
                className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
                style={{ color: colors.textSecondary }}
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto px-8 py-6">
              <div className="space-y-6">
                {/* 상태 배지 */}
                <div className="flex justify-end">
                  <span
                    className="px-3 py-1 rounded-full text-xs font-medium"
                    style={{
                      backgroundColor: `${getStatusColor(selectedProcess.status)}20`,
                      color: getStatusColor(selectedProcess.status),
                    }}
                  >
                    {getStatusText(selectedProcess.status)}
                  </span>
                </div>

                <div>
                  <h4 className="text-sm font-medium mb-3" style={{ color: colors.textSecondary }}>
                    기본 정보
                  </h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-4 rounded-lg" style={{ backgroundColor: colors.surface }}>
                      <p className="text-xs mb-1" style={{ color: colors.textSecondary }}>
                        업무영역
                      </p>
                      <p className="text-sm font-medium" style={{ color: colors.textPrimary }}>
                        {selectedProcess.businessArea}
                      </p>
                    </div>
                    <div className="p-4 rounded-lg" style={{ backgroundColor: colors.surface }}>
                      <p className="text-xs mb-1" style={{ color: colors.textSecondary }}>
                        담당자
                      </p>
                      <p className="text-sm font-medium" style={{ color: colors.textPrimary }}>
                        {selectedProcess.owner}
                      </p>
                    </div>
                    <div className="p-4 rounded-lg" style={{ backgroundColor: colors.surface }}>
                      <p className="text-xs mb-1" style={{ color: colors.textSecondary }}>
                        단계 수
                      </p>
                      <p className="text-sm font-medium" style={{ color: colors.textPrimary }}>
                        {selectedProcess.steps}단계
                      </p>
                    </div>
                    <div className="p-4 rounded-lg" style={{ backgroundColor: colors.surface }}>
                      <p className="text-xs mb-1" style={{ color: colors.textSecondary }}>
                        등록일
                      </p>
                      <p className="text-sm font-medium" style={{ color: colors.textPrimary }}>
                        {selectedProcess.createdDate}
                      </p>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="text-sm font-medium mb-3" style={{ color: colors.textSecondary }}>
                    프로세스 설명
                  </h4>
                  <div className="p-4 rounded-lg" style={{ backgroundColor: colors.surface }}>
                    <p className="text-sm" style={{ color: colors.textPrimary }}>
                      {selectedProcess.description}
                    </p>
                  </div>
                </div>

                <div>
                  <h4 className="text-sm font-medium mb-3" style={{ color: colors.textSecondary }}>
                    최근 수정 이력
                  </h4>
                  <div className="p-4 rounded-lg" style={{ backgroundColor: colors.surface }}>
                    <p className="text-sm" style={{ color: colors.textPrimary }}>
                      {selectedProcess.updatedDate}에 마지막으로 수정됨
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Footer */}
            <div
              className="px-8 py-4 border-t flex items-center justify-end gap-3 flex-shrink-0"
              style={{
                backgroundColor: colors.bgPrimary,
                borderColor: colors.border,
              }}
            >
              <button
                onClick={() => setIsDetailModalOpen(false)}
                className="px-4 py-2 rounded-lg font-medium border transition-all duration-200"
                style={{
                  backgroundColor: colors.bgPrimary,
                  borderColor: colors.border,
                  color: colors.textPrimary,
                }}
              >
                닫기
              </button>
              <button
                onClick={() => {
                  setIsDetailModalOpen(false);
                  handleEditProcess(selectedProcess);
                }}
                className="px-4 py-2 rounded-lg font-medium transition-all duration-200"
                style={{
                  backgroundColor: '#2B8DFF',
                  color: '#FFFFFF',
                }}
              >
                수정
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}