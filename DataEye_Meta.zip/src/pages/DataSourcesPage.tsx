import { Database, Plus, RefreshCw } from 'lucide-react';
import { Card } from '../components/common/Card';
import { Button } from '../components/common/Button';
import { DataSourceTable } from '../components/dashboard/DataSourceTable';
import { DataSourceFormModal } from '../components/modals/DataSourceFormModal';
import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { useModal } from '../contexts/ModalContext';

export function DataSourcesPage() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState<'create' | 'edit'>('create');
  const [isSyncing, setIsSyncing] = useState(false);

  const handleAddClick = () => {
    setModalMode('create');
    setIsModalOpen(true);
  };

  const handleSyncAll = () => {
    setIsSyncing(true);
    // 동기화 시뮬레이션
    setTimeout(() => {
      setIsSyncing(false);
      alert('전체 데이터 소스 동기화가 완료되었습니다.');
    }, 2000);
  };

  return (
    <div className="space-y-4 p-0">
      <div className="flex-1 overflow-auto">
        <div className="space-y-4">
          <div className="flex gap-3 mb-6">
            <Button variant="primary" icon={<Database className="w-4 h-4" />} onClick={handleAddClick}>
              새 소스 추가
            </Button>
            <Button 
              variant="secondary" 
              icon={
                isSyncing ? (
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                  >
                    <RefreshCw className="w-4 h-4" />
                  </motion.div>
                ) : (
                  <RefreshCw className="w-4 h-4" />
                )
              }
              onClick={handleSyncAll}
              disabled={isSyncing}
            >
              {isSyncing ? '동기화 중...' : '전체 동기화'}
            </Button>
          </div>
          <DataSourceTable />
        </div>
      </div>

      <DataSourceFormModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        mode={modalMode}
      />
    </div>
  );
}