import { BookOpen, Plus, Search, Filter, Download, X, Save, ChevronRight, History, FileText, Tag } from 'lucide-react';
import { Card } from '../components/common/Card';
import { Button } from '../components/common/Button';
import { Badge } from '../components/common/Badge';
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { colors } from '../constants/designSystem';
import { useModal } from '../contexts/ModalContext';

interface Word {
  id: string;
  word: string;
  englishName: string;
  description: string;
  type: string;
  status: string;
  createdDate: string;
  updatedBy: string;
}

const mockWords: Word[] = [
  { id: '1', word: '고객', englishName: 'CUSTOMER', description: '상품이나 서비스를 구매하는 개인 또는 조직', type: '업무용어', status: '승인', createdDate: '2024-01-15', updatedBy: '김표준' },
  { id: '2', word: '번호', englishName: 'NUMBER', description: '고유하게 식별하기 위한 숫자 또는 문자', type: '속성용어', status: '승인', createdDate: '2024-01-16', updatedBy: '이표준' },
  { id: '3', word: '일자', englishName: 'DATE', description: '특정 시점을 나타내는 연월일', type: '속성용어', status: '승인', createdDate: '2024-01-17', updatedBy: '박표준' },
  { id: '4', word: '금액', englishName: 'AMOUNT', description: '화폐로 표현되는 가치', type: '���어', status: '승인', createdDate: '2024-01-18', updatedBy: '최표준' },
  { id: '5', word: '주문', englishName: 'ORDER', description: '상품 또는 서비스의 구매 요청', type: '업무용어', status: '검토중', createdDate: '2024-01-19', updatedBy: '정표준' },
  { id: '6', word: '상품', englishName: 'PRODUCT', description: '판매를 목적으로 제공되는 재화', type: '업무용어', status: '승인', createdDate: '2024-01-20', updatedBy: '김표준' },
  { id: '7', word: '코드', englishName: 'CODE', description: '분류나 식별을 위한 기호', type: '속성용어', status: '승인', createdDate: '2024-01-21', updatedBy: '이표준' },
];

const historyData = [
  { date: '2024-01-26 14:30', user: '김표준', action: '수정', description: '설명 수정' },
  { date: '2024-01-20 10:15', user: '이표준', action: '승인', description: '표준 단어로 승인됨' },
  { date: '2024-01-15 09:00', user: '김표준', action: '등록', description: '신규 단어 등록' },
];

export function StandardWordPage() {
  const { setIsModalOpen } = useModal();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedWord, setSelectedWord] = useState<Word | null>(null);
  const [activeTab, setActiveTab] = useState<'basic' | 'usage' | 'history'>('basic');
  const [showCreateModal, setShowCreateModal] = useState(false);

  useEffect(() => {
    setIsModalOpen(!!selectedWord || showCreateModal);
  }, [selectedWord, showCreateModal, setIsModalOpen]);

  const handleRowClick = (word: Word) => {
    setSelectedWord(word);
    setActiveTab('basic');
  };

  const handleClose = () => {
    setSelectedWord(null);
  };

  const filteredWords = mockWords.filter(word =>
    word.word.toLowerCase().includes(searchTerm.toLowerCase()) ||
    word.englishName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="h-full flex gap-0 overflow-hidden">
      {/* Main Data Grid - Dynamic Width */}
      <motion.div
        className="flex flex-col"
        initial={{ width: '100%' }}
        animate={{ width: selectedWord ? '60%' : '100%' }}
        transition={{ duration: 0.4, ease: [0.4, 0, 0.2, 1] }}
      >
        <div className="space-y-6 p-6 overflow-auto h-full">
          {/* Stats Cards */}
          <div className="grid grid-cols-4 gap-4">
            <Card>
              <div className="flex items-center gap-3">
                <div className="p-3 rounded-xl" style={{ backgroundColor: colors.primaryLight }}>
                  <BookOpen className="w-6 h-6" style={{ color: colors.primary }} />
                </div>
                <div>
                  <p className="text-sm" style={{ color: colors.textSecondary }}>전체 표준 단어</p>
                  <p className="text-2xl font-bold" style={{ color: colors.textPrimary }}>247</p>
                </div>
              </div>
            </Card>
            <Card>
              <div className="flex items-center gap-3">
                <div className="p-3 rounded-xl" style={{ backgroundColor: colors.successLight }}>
                  <BookOpen className="w-6 h-6" style={{ color: colors.success }} />
                </div>
                <div>
                  <p className="text-sm" style={{ color: colors.textSecondary }}>승인된 단어</p>
                  <p className="text-2xl font-bold" style={{ color: colors.textPrimary }}>198</p>
                </div>
              </div>
            </Card>
            <Card>
              <div className="flex items-center gap-3">
                <div className="p-3 rounded-xl" style={{ backgroundColor: colors.warningLight }}>
                  <BookOpen className="w-6 h-6" style={{ color: colors.warning }} />
                </div>
                <div>
                  <p className="text-sm" style={{ color: colors.textSecondary }}>검토중</p>
                  <p className="text-2xl font-bold" style={{ color: colors.textPrimary }}>32</p>
                </div>
              </div>
            </Card>
            <Card>
              <div className="flex items-center gap-3">
                <div className="p-3 rounded-xl" style={{ backgroundColor: colors.errorLight }}>
                  <BookOpen className="w-6 h-6" style={{ color: colors.error }} />
                </div>
                <div>
                  <p className="text-sm" style={{ color: colors.textSecondary }}>반려</p>
                  <p className="text-2xl font-bold" style={{ color: colors.textPrimary }}>17</p>
                </div>
              </div>
            </Card>
          </div>

          {/* Actions Bar */}
          <Card>
            <div className="flex items-center justify-between">
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: colors.textTertiary }} />
                <input
                  type="text"
                  placeholder="단어 검색..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 rounded-lg border"
                  style={{
                    borderColor: colors.border,
                    backgroundColor: colors.background,
                  }}
                />
              </div>
              <div className="flex gap-2">
                <Button variant="ghost" icon={<Filter className="w-4 h-4" />}>
                  필터
                </Button>
                <Button variant="secondary" icon={<Download className="w-4 h-4" />}>
                  내보내기
                </Button>
                <Button variant="primary" icon={<Plus className="w-4 h-4" />} onClick={() => setShowCreateModal(true)}>
                  단어 추가
                </Button>
              </div>
            </div>
          </Card>

          {/* Words Table */}
          <Card>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b" style={{ borderColor: colors.divider }}>
                    <th className="text-left py-3 px-4" style={{ color: colors.textSecondary }}>한글명</th>
                    <th className="text-left py-3 px-4" style={{ color: colors.textSecondary }}>영문명</th>
                    <th className="text-left py-3 px-4" style={{ color: colors.textSecondary }}>설명</th>
                    <th className="text-left py-3 px-4" style={{ color: colors.textSecondary }}>유형</th>
                    <th className="text-center py-3 px-4" style={{ color: colors.textSecondary }}>상태</th>
                    <th className="text-left py-3 px-4" style={{ color: colors.textSecondary }}>수정자</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredWords.map((word) => (
                    <motion.tr
                      key={word.id}
                      onClick={() => handleRowClick(word)}
                      className="border-b cursor-pointer transition-colors"
                      style={{ 
                        borderColor: colors.divider,
                        backgroundColor: selectedWord?.id === word.id ? colors.primaryLight : 'transparent'
                      }}
                      whileHover={{ 
                        backgroundColor: colors.primaryLight,
                        transition: { duration: 0.2 }
                      }}
                    >
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2">
                          <span className="font-medium" style={{ color: colors.textPrimary }}>
                            {word.word}
                          </span>
                          {selectedWord?.id === word.id && (
                            <ChevronRight className="w-4 h-4" style={{ color: colors.primary }} />
                          )}
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        <span className="font-mono text-sm" style={{ color: colors.textSecondary }}>
                          {word.englishName}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <span className="text-sm" style={{ color: colors.textSecondary }}>
                          {word.description}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <Badge variant="info">{word.type}</Badge>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <Badge variant={word.status === '승인' ? 'success' : 'warning'}>
                          {word.status}
                        </Badge>
                      </td>
                      <td className="py-3 px-4" style={{ color: colors.textSecondary }}>
                        {word.updatedBy}
                      </td>
                    </motion.tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </div>
      </motion.div>

      {/* Glass Separator */}
      <AnimatePresence>
        {selectedWord && (
          <motion.div
            initial={{ opacity: 0, scaleX: 0 }}
            animate={{ opacity: 1, scaleX: 1 }}
            exit={{ opacity: 0, scaleX: 0 }}
            transition={{ duration: 0.3 }}
            className="w-px"
            style={{
              background: `linear-gradient(180deg, transparent, ${colors.border}, transparent)`,
              transformOrigin: 'left'
            }}
          />
        )}
      </AnimatePresence>

      {/* Right Detail Panel - 40% Width */}
      <AnimatePresence>
        {selectedWord && (
          <motion.div
            initial={{ x: '100%', opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: '100%', opacity: 0 }}
            transition={{ duration: 0.4, ease: [0.4, 0, 0.2, 1] }}
            className="flex flex-col overflow-hidden"
            style={{
              width: '40%',
              backgroundColor: colors.background,
              backdropFilter: 'blur(20px)',
              boxShadow: '-4px 0 24px rgba(0, 0, 0, 0.08)'
            }}
          >
            {/* Sticky Header */}
            <div 
              className="sticky top-0 z-10 px-6 py-4 border-b"
              style={{ 
                backgroundColor: colors.background,
                borderColor: colors.divider,
                backdropFilter: 'blur(20px)'
              }}
            >
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold" style={{ color: colors.textPrimary }}>
                  Edit Word Details
                </h2>
                <div className="flex items-center gap-2">
                  <Button 
                    variant="primary" 
                    icon={<Save className="w-4 h-4" />}
                    glow
                  >
                    Save Changes
                  </Button>
                  <button
                    onClick={handleClose}
                    className="p-2 rounded-lg hover:bg-black/5 transition-colors"
                  >
                    <X className="w-5 h-5" style={{ color: colors.textSecondary }} />
                  </button>
                </div>
              </div>

              {/* Tabs */}
              <div className="flex gap-1">
                {[
                  { id: 'basic' as const, label: 'Basic Info', icon: FileText },
                  { id: 'usage' as const, label: 'Usage', icon: Tag },
                  { id: 'history' as const, label: 'History', icon: History },
                ].map((tab) => {
                  const Icon = tab.icon;
                  const isActive = activeTab === tab.id;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      className="flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all duration-200 relative"
                      style={{
                        color: isActive ? colors.primary : colors.textSecondary,
                        backgroundColor: isActive ? colors.primaryLight : 'transparent'
                      }}
                    >
                      <Icon className="w-4 h-4" />
                      <span className="text-sm">{tab.label}</span>
                      {isActive && (
                        <motion.div
                          layoutId="activeTabWord"
                          className="absolute bottom-0 left-0 right-0 h-0.5"
                          style={{ backgroundColor: colors.primary }}
                        />
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Panel Body */}
            <div className="flex-1 overflow-auto p-6">
              <AnimatePresence mode="wait">
                {activeTab === 'basic' && (
                  <motion.div
                    key="basic"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    transition={{ duration: 0.3 }}
                    className="space-y-6"
                  >
                    {/* Floating Label Inputs */}
                    <div className="space-y-4">
                      <div className="relative">
                        <input
                          type="text"
                          defaultValue={selectedWord.word}
                          className="peer w-full px-4 pt-6 pb-2 rounded-xl border-2 transition-all duration-200 focus:outline-none"
                          style={{
                            borderColor: colors.border,
                            backgroundColor: colors.background
                          }}
                          onFocus={(e) => {
                            e.currentTarget.style.borderColor = colors.primary;
                            e.currentTarget.style.boxShadow = `0 0 0 4px ${colors.primaryLight}`;
                          }}
                          onBlur={(e) => {
                            e.currentTarget.style.borderColor = colors.border;
                            e.currentTarget.style.boxShadow = 'none';
                          }}
                        />
                        <label
                          className="absolute left-4 top-2 text-xs font-medium transition-all"
                          style={{ color: colors.textSecondary }}
                        >
                          한글 단어명
                        </label>
                      </div>

                      <div className="relative">
                        <input
                          type="text"
                          defaultValue={selectedWord.englishName}
                          className="peer w-full px-4 pt-6 pb-2 rounded-xl border-2 font-mono transition-all duration-200 focus:outline-none"
                          style={{
                            borderColor: colors.border,
                            backgroundColor: colors.background
                          }}
                          onFocus={(e) => {
                            e.currentTarget.style.borderColor = colors.primary;
                            e.currentTarget.style.boxShadow = `0 0 0 4px ${colors.primaryLight}`;
                          }}
                          onBlur={(e) => {
                            e.currentTarget.style.borderColor = colors.border;
                            e.currentTarget.style.boxShadow = 'none';
                          }}
                        />
                        <label
                          className="absolute left-4 top-2 text-xs font-medium transition-all"
                          style={{ color: colors.textSecondary }}
                        >
                          영문 단어명
                        </label>
                      </div>

                      <div className="relative">
                        <textarea
                          defaultValue={selectedWord.description}
                          rows={4}
                          className="peer w-full px-4 pt-6 pb-2 rounded-xl border-2 transition-all duration-200 focus:outline-none resize-none"
                          style={{
                            borderColor: colors.border,
                            backgroundColor: colors.background
                          }}
                          onFocus={(e) => {
                            e.currentTarget.style.borderColor = colors.primary;
                            e.currentTarget.style.boxShadow = `0 0 0 4px ${colors.primaryLight}`;
                          }}
                          onBlur={(e) => {
                            e.currentTarget.style.borderColor = colors.border;
                            e.currentTarget.style.boxShadow = 'none';
                          }}
                        />
                        <label
                          className="absolute left-4 top-2 text-xs font-medium transition-all"
                          style={{ color: colors.textSecondary }}
                        >
                          단어 설명
                        </label>
                      </div>

                      <div className="relative">
                        <select
                          defaultValue={selectedWord.type}
                          className="peer w-full px-4 pt-6 pb-2 rounded-xl border-2 transition-all duration-200 focus:outline-none"
                          style={{
                            borderColor: colors.border,
                            backgroundColor: colors.background
                          }}
                          onFocus={(e) => {
                            e.currentTarget.style.borderColor = colors.primary;
                            e.currentTarget.style.boxShadow = `0 0 0 4px ${colors.primaryLight}`;
                          }}
                          onBlur={(e) => {
                            e.currentTarget.style.borderColor = colors.border;
                            e.currentTarget.style.boxShadow = 'none';
                          }}
                        >
                          <option value="업무용어">업무용어</option>
                          <option value="속성용어">속성용어</option>
                          <option value="한정어">한정어</option>
                        </select>
                        <label
                          className="absolute left-4 top-2 text-xs font-medium transition-all"
                          style={{ color: colors.textSecondary }}
                        >
                          단어 유형
                        </label>
                      </div>
                    </div>

                    {/* Status Reference */}
                    <div 
                      className="p-4 rounded-xl border"
                      style={{ 
                        backgroundColor: colors.backgroundSecondary,
                        borderColor: colors.divider
                      }}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium" style={{ color: colors.textSecondary }}>
                          현재 상태
                        </span>
                        <Badge variant={selectedWord.status === '승인' ? 'success' : 'warning'}>
                          {selectedWord.status}
                        </Badge>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span style={{ color: colors.textSecondary }}>등록일</span>
                        <span style={{ color: colors.textPrimary }}>{selectedWord.createdDate}</span>
                      </div>
                    </div>
                  </motion.div>
                )}

                {activeTab === 'usage' && (
                  <motion.div
                    key="usage"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    className="space-y-4"
                  >
                    <p className="font-medium" style={{ color: colors.textPrimary }}>
                      이 단어를 사용하는 표준 용어
                    </p>
                    <div className="space-y-2">
                      {['고객번호', '고객명', '고객코드'].map((term, idx) => (
                        <div
                          key={idx}
                          className="p-3 rounded-lg border"
                          style={{ borderColor: colors.divider }}
                        >
                          <span style={{ color: colors.textPrimary }}>{term}</span>
                        </div>
                      ))}
                    </div>
                  </motion.div>
                )}

                {activeTab === 'history' && (
                  <motion.div
                    key="history"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    className="space-y-3"
                  >
                    {historyData.map((item, idx) => (
                      <div
                        key={idx}
                        className="p-4 rounded-lg border"
                        style={{ borderColor: colors.divider }}
                      >
                        <div className="flex items-center gap-2 mb-2">
                          <Badge variant="primary">{item.action}</Badge>
                          <span className="text-sm" style={{ color: colors.textSecondary }}>
                            by {item.user}
                          </span>
                        </div>
                        <p className="text-sm mb-1" style={{ color: colors.textPrimary }}>
                          {item.description}
                        </p>
                        <p className="text-xs" style={{ color: colors.textTertiary }}>
                          {item.date}
                        </p>
                      </div>
                    ))}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Create Modal */}
      <AnimatePresence>
        {showCreateModal && (
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 30, stiffness: 300 }}
            className="fixed top-0 right-0 bottom-0 z-50 shadow-2xl border-l overflow-hidden flex flex-col"
            style={{
              width: '400px',
              backgroundColor: colors.background,
              borderColor: colors.divider
            }}
          >
            {/* Header */}
            <div className="px-6 py-4 border-b flex items-center justify-between" style={{ borderColor: colors.divider }}>
              <div>
                <h3 className="text-xl font-bold" style={{ color: colors.textPrimary }}>신규 표준 단어 등록</h3>
                <p className="text-sm mt-1" style={{ color: colors.textSecondary }}>새로운 표준 단어를 등록합니다</p>
              </div>
              <button
                onClick={() => setShowCreateModal(false)}
                className="p-2 rounded-lg hover:bg-black/5 transition-colors"
              >
                <X className="w-5 h-5" style={{ color: colors.textSecondary }} />
              </button>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto p-6 space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium" style={{ color: colors.textSecondary }}>
                  한글 단어명 <span style={{ color: colors.error }}>*</span>
                </label>
                <input
                  type="text"
                  placeholder="예: 고객"
                  className="w-full px-4 py-2 rounded-lg border focus:outline-none focus:ring-2"
                  style={{
                    borderColor: colors.border,
                    backgroundColor: colors.background
                  }}
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium" style={{ color: colors.textSecondary }}>
                  영문 단어명 <span style={{ color: colors.error }}>*</span>
                </label>
                <input
                  type="text"
                  placeholder="예: CUSTOMER"
                  className="w-full px-4 py-2 rounded-lg border font-mono focus:outline-none focus:ring-2"
                  style={{
                    borderColor: colors.border,
                    backgroundColor: colors.background
                  }}
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium" style={{ color: colors.textSecondary }}>
                  단어 설명 <span style={{ color: colors.error }}>*</span>
                </label>
                <textarea
                  rows={4}
                  placeholder="단어에 대한 설명을 입력하세요"
                  className="w-full px-4 py-2 rounded-lg border focus:outline-none focus:ring-2 resize-none"
                  style={{
                    borderColor: colors.border,
                    backgroundColor: colors.background
                  }}
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium" style={{ color: colors.textSecondary }}>
                  단어 유형 <span style={{ color: colors.error }}>*</span>
                </label>
                <select
                  className="w-full px-4 py-2 rounded-lg border focus:outline-none focus:ring-2"
                  style={{
                    borderColor: colors.border,
                    backgroundColor: colors.background
                  }}
                >
                  <option value="">선택하세요</option>
                  <option value="업무용어">업무용어</option>
                  <option value="속성용어">속성용어</option>
                  <option value="한정어">한정어</option>
                </select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium" style={{ color: colors.textSecondary }}>
                  약어
                </label>
                <input
                  type="text"
                  placeholder="예: CUST"
                  className="w-full px-4 py-2 rounded-lg border font-mono focus:outline-none focus:ring-2"
                  style={{
                    borderColor: colors.border,
                    backgroundColor: colors.background
                  }}
                />
              </div>
            </div>

            {/* Footer */}
            <div className="px-6 py-4 border-t flex items-center justify-end gap-3" style={{ borderColor: colors.divider }}>
              <Button variant="ghost" onClick={() => setShowCreateModal(false)}>
                취소
              </Button>
              <Button variant="primary" glow>
                등록
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}