import { useState, useMemo, useEffect } from 'react';
import { GitBranch, Plus, Search, Filter, Download, Upload, Link2, Database, Table2, CheckCircle2, AlertCircle, X, ArrowUpDown, ChevronUp, ChevronDown } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { colors } from '../constants/designSystem';
import { useTheme } from '../contexts/ThemeContext';
import { Pagination } from '../components/common/Pagination';
import { useModal } from '../contexts/ModalContext';

interface DataLinkage {
  id: string;
  sourceName: string;
  sourceType: 'system' | 'table' | 'column';
  targetName: string;
  targetType: 'system' | 'table' | 'column';
  linkageType: 'direct' | 'transform' | 'aggregate';
  status: 'active' | 'inactive' | 'pending';
  lastSync: string;
  createdDate: string;
  description: string;
  owner: string;
}

export function DataLinkageManagementPage() {
  const { isDarkMode } = useTheme();
  const { setIsModalOpen: setGlobalModalOpen } = useModal();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedLinkage, setSelectedLinkage] = useState<DataLinkage | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);

  const [linkages, setLinkages] = useState<DataLinkage[]>([
    {
      id: '1',
      sourceName: 'ERP 주문 시스템',
      sourceType: 'system',
      targetName: 'DW 주문 테이블',
      targetType: 'table',
      linkageType: 'direct',
      status: 'active',
      lastSync: '2024-11-20 09:30',
      createdDate: '2024-01-15',
      description: 'ERP 주문 데이터를 데이터 웨어하우스로 실시간 연계',
      owner: '김데이터'
    },
    {
      id: '2',
      sourceName: 'CRM 고객 정보',
      sourceType: 'table',
      targetName: 'DW 고객 마스터',
      targetType: 'table',
      linkageType: 'transform',
      status: 'active',
      lastSync: '2024-11-20 08:00',
      createdDate: '2024-02-01',
      description: 'CRM 고객 정보를 변환하여 DW로 통합',
      owner: '이연계'
    },
    {
      id: '3',
      sourceName: '매출 집계 테이블',
      sourceType: 'table',
      targetName: '월별 매출 리포트',
      targetType: 'table',
      linkageType: 'aggregate',
      status: 'active',
      lastSync: '2024-11-20 06:00',
      createdDate: '2024-03-10',
      description: '일별 매출 데이터를 월별로 집계하여 리포트 생성',
      owner: '박집계'
    },
    {
      id: '4',
      sourceName: '재고 관리 시스템',
      sourceType: 'system',
      targetName: 'BI 재고 분석',
      targetType: 'system',
      linkageType: 'direct',
      status: 'active',
      lastSync: '2024-11-20 10:00',
      createdDate: '2024-04-05',
      description: '재고 데이터를 BI 시스템으로 실시간 연계',
      owner: '최재고'
    },
    {
      id: '5',
      sourceName: '상품 카테고리 컬럼',
      sourceType: 'column',
      targetName: '통합 상품 분류',
      targetType: 'column',
      linkageType: 'transform',
      status: 'pending',
      lastSync: '2024-11-19 15:00',
      createdDate: '2024-05-20',
      description: '상품 카테고리 표준화 작업 진행중',
      owner: '정상품'
    },
    {
      id: '6',
      sourceName: '물류 배송 정보',
      sourceType: 'table',
      targetName: 'DW 배송 이력',
      targetType: 'table',
      linkageType: 'direct',
      status: 'inactive',
      lastSync: '2024-11-15 14:30',
      createdDate: '2024-06-01',
      description: '배송 정보 연계 (현재 일시 중단)',
      owner: '한물류'
    },
  ]);

  const filteredLinkages = linkages.filter(linkage =>
    linkage.sourceName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    linkage.targetName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    linkage.owner.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return '#10B981';
      case 'inactive': return '#6B7280';
      case 'pending': return '#F59E0B';
      default: return '#6B7280';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'active': return '활성';
      case 'inactive': return '비활성';
      case 'pending': return '대기중';
      default: return status;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'system': return '#2B8DFF';
      case 'table': return '#0066FF';
      case 'column': return '#10B981';
      default: return '#6B7280';
    }
  };

  const getTypeText = (type: string) => {
    switch (type) {
      case 'system': return '시스템';
      case 'table': return '테이블';
      case 'column': return '컬럼';
      default: return type;
    }
  };

  const getLinkageTypeText = (type: string) => {
    switch (type) {
      case 'direct': return '직접 연계';
      case 'transform': return '변환 연계';
      case 'aggregate': return '집계 연계';
      default: return type;
    }
  };

  useEffect(() => {
    setGlobalModalOpen(isModalOpen || isDetailModalOpen);
  }, [isModalOpen, isDetailModalOpen, setGlobalModalOpen]);

  const handleAddLinkage = () => {
    setSelectedLinkage(null);
    setIsModalOpen(true);
  };

  const handleEditLinkage = (linkage: DataLinkage) => {
    setSelectedLinkage(linkage);
    setIsModalOpen(true);
  };

  const handleViewDetail = (linkage: DataLinkage) => {
    setSelectedLinkage(linkage);
    setIsDetailModalOpen(true);
  };

  const handleSaveLinkage = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    const newLinkage: DataLinkage = {
      id: selectedLinkage?.id || Date.now().toString(),
      sourceName: formData.get('sourceName') as string,
      sourceType: formData.get('sourceType') as 'system' | 'table' | 'column',
      targetName: formData.get('targetName') as string,
      targetType: formData.get('targetType') as 'system' | 'table' | 'column',
      linkageType: formData.get('linkageType') as 'direct' | 'transform' | 'aggregate',
      status: formData.get('status') as 'active' | 'inactive' | 'pending',
      owner: formData.get('owner') as string,
      description: formData.get('description') as string,
      lastSync: new Date().toISOString().slice(0, 16).replace('T', ' '),
      createdDate: selectedLinkage?.createdDate || new Date().toISOString().split('T')[0],
    };

    if (selectedLinkage) {
      setLinkages(linkages.map(l => l.id === selectedLinkage.id ? newLinkage : l));
    } else {
      setLinkages([...linkages, newLinkage]);
    }
    
    setIsModalOpen(false);
  };

  const handleDeleteLinkage = (id: string) => {
    if (confirm('정말 삭제하시겠습니까?')) {
      setLinkages(linkages.filter(l => l.id !== id));
    }
  };

  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);

  const paginatedLinkages = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage;
    const end = start + itemsPerPage;
    return filteredLinkages.slice(start, end);
  }, [currentPage, itemsPerPage, filteredLinkages]);

  return (
    <div className="space-y-4 p-0">
      <div className="flex-1 overflow-auto">
        <div className="space-y-6 p-0">
          {/* 상단 통계 카드 */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {[
              { label: '전체 연계', value: linkages.length, icon: GitBranch, color: '#0066FF' },
              { label: '활성 연계', value: linkages.filter(l => l.status === 'active').length, icon: CheckCircle2, color: '#10B981' },
              { label: '대기중', value: linkages.filter(l => l.status === 'pending').length, icon: AlertCircle, color: '#F59E0B' },
              { label: '비활성', value: linkages.filter(l => l.status === 'inactive').length, icon: Database, color: '#6B7280' },
            ].map((stat, idx) => (
              <div
                key={idx}
                className="rounded-2xl p-6 border transition-all duration-200 hover:shadow-lg"
                style={{
                  backgroundColor: isDarkMode ? '#252525' : '#FFFFFF',
                  borderColor: isDarkMode ? '#373737' : '#E9EAEC',
                }}
              >
                <div className="flex items-center justify-between mb-3">
                  <div
                    className="p-3 rounded-xl"
                    style={{
                      backgroundColor: isDarkMode ? `${stat.color}20` : `${stat.color}15`,
                    }}
                  >
                    <stat.icon className="w-5 h-5" style={{ color: stat.color }} />
                  </div>
                  <span className="text-2xl font-bold" style={{ color: isDarkMode ? '#EBEBEB' : '#37352F' }}>
                    {stat.value}
                  </span>
                </div>
                <p className="text-sm" style={{ color: isDarkMode ? '#B4B4B4' : '#787774' }}>
                  {stat.label}
                </p>
              </div>
            ))}
          </div>

          {/* 검색 및 액션 바 */}
          <div
            className="rounded-2xl p-6 border"
            style={{
              backgroundColor: isDarkMode ? '#252525' : '#FFFFFF',
              borderColor: isDarkMode ? '#373737' : '#E9EAEC',
            }}
          >
            <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between">
              <div className="flex-1 max-w-md relative">
                <Search
                  className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4"
                  style={{ color: isDarkMode ? '#6B7280' : '#9CA3AF' }}
                />
                <input
                  type="text"
                  placeholder="소스, 타겟, 담당자로 검색..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 rounded-lg border transition-colors duration-200"
                  style={{
                    backgroundColor: isDarkMode ? '#191919' : '#F7F8FA',
                    borderColor: isDarkMode ? '#373737' : '#E9EAEC',
                    color: isDarkMode ? '#EBEBEB' : '#37352F',
                  }}
                />
              </div>
              <div className="flex gap-2">
                <button
                  onClick={handleAddLinkage}
                  className="px-4 py-2 rounded-full flex items-center gap-2 transition-all duration-200 hover:shadow-md"
                  style={{
                    backgroundColor: '#000000',
                    color: '#FFFFFF',
                  }}
                >
                  <Plus className="w-4 h-4" />
                  <span className="text-sm font-medium text-[rgb(255,255,255)]">연계 등록</span>
                </button>
                <button
                  className="px-4 py-2 rounded-lg flex items-center gap-2 border transition-all duration-200 hover:shadow-md"
                  style={{
                    backgroundColor: isDarkMode ? '#252525' : '#FFFFFF',
                    borderColor: isDarkMode ? '#373737' : '#E9EAEC',
                    color: isDarkMode ? '#EBEBEB' : '#37352F',
                  }}
                >
                  <Filter className="w-4 h-4" />
                  <span className="text-sm">필터</span>
                </button>
                <button
                  className="px-4 py-2 rounded-lg flex items-center gap-2 border transition-all duration-200 hover:shadow-md"
                  style={{
                    backgroundColor: isDarkMode ? '#252525' : '#FFFFFF',
                    borderColor: isDarkMode ? '#373737' : '#E9EAEC',
                    color: isDarkMode ? '#EBEBEB' : '#37352F',
                  }}
                >
                  <Download className="w-4 h-4" />
                </button>
                <button
                  className="px-4 py-2 rounded-lg flex items-center gap-2 border transition-all duration-200 hover:shadow-md"
                  style={{
                    backgroundColor: isDarkMode ? '#252525' : '#FFFFFF',
                    borderColor: isDarkMode ? '#373737' : '#E9EAEC',
                    color: isDarkMode ? '#EBEBEB' : '#37352F',
                  }}
                >
                  <Upload className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>

          {/* 연계 테이블 */}
          <div
            className="rounded-2xl border overflow-hidden"
            style={{
              backgroundColor: isDarkMode ? '#252525' : '#FFFFFF',
              borderColor: isDarkMode ? '#373737' : '#E9EAEC',
            }}
          >
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead style={{ backgroundColor: '#F7F8FA' }}>
                  <tr style={{ borderBottom: '1px solid #DADCE0' }}>
                    <th className="px-6 py-4 text-left text-sm" style={{ color: '#5F6368' }}>소스</th>
                    <th className="px-6 py-4 text-center text-sm" style={{ color: '#5F6368' }}>→</th>
                    <th className="px-6 py-4 text-left text-sm" style={{ color: '#5F6368' }}>타겟</th>
                    <th className="px-6 py-4 text-left text-sm" style={{ color: '#5F6368' }}>연계유형</th>
                    <th className="px-6 py-4 text-left text-sm" style={{ color: '#5F6368' }}>상태</th>
                    <th className="px-6 py-4 text-left text-sm" style={{ color: '#5F6368' }}>마지막 동기화</th>
                    <th className="px-6 py-4 text-left text-sm" style={{ color: '#5F6368' }}>관리</th>
                  </tr>
                </thead>
                <tbody>
                  {paginatedLinkages.map((linkage, idx) => (
                    <tr
                      key={linkage.id}
                      className="cursor-pointer transition-colors duration-150"
                      style={{
                        borderBottom: idx < paginatedLinkages.length - 1 ? `1px solid ${isDarkMode ? '#373737' : '#E9EAEC'}` : 'none',
                      }}
                      onMouseEnter={(e) => {
                        e.currentTarget.style.backgroundColor = isDarkMode ? '#1F1F1F' : '#F7F8FA';
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.backgroundColor = 'transparent';
                      }}
                      onClick={() => handleViewDetail(linkage)}
                    >
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <div
                            className="p-2 rounded-lg"
                            style={{
                              backgroundColor: isDarkMode ? `${getTypeColor(linkage.sourceType)}20` : `${getTypeColor(linkage.sourceType)}15`,
                            }}
                          >
                            <Database className="w-4 h-4" style={{ color: getTypeColor(linkage.sourceType) }} />
                          </div>
                          <div>
                            <p className="text-sm font-medium" style={{ color: isDarkMode ? '#EBEBEB' : '#37352F' }}>
                              {linkage.sourceName}
                            </p>
                            <p className="text-xs" style={{ color: isDarkMode ? '#6B7280' : '#9CA3AF' }}>
                              {getTypeText(linkage.sourceType)}
                            </p>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-center">
                        <div className="flex justify-center">
                          <Link2 className="w-4 h-4" style={{ color: isDarkMode ? '#6B7280' : '#9CA3AF' }} />
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <div
                            className="p-2 rounded-lg"
                            style={{
                              backgroundColor: isDarkMode ? `${getTypeColor(linkage.targetType)}20` : `${getTypeColor(linkage.targetType)}15`,
                            }}
                          >
                            <Table2 className="w-4 h-4" style={{ color: getTypeColor(linkage.targetType) }} />
                          </div>
                          <div>
                            <p className="text-sm font-medium" style={{ color: isDarkMode ? '#EBEBEB' : '#37352F' }}>
                              {linkage.targetName}
                            </p>
                            <p className="text-xs" style={{ color: isDarkMode ? '#6B7280' : '#9CA3AF' }}>
                              {getTypeText(linkage.targetType)}
                            </p>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span className="text-sm" style={{ color: isDarkMode ? '#B4B4B4' : '#787774' }}>
                          {getLinkageTypeText(linkage.linkageType)}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <span
                          className="px-3 py-1 rounded-full text-xs font-medium"
                          style={{
                            backgroundColor: `${getStatusColor(linkage.status)}20`,
                            color: getStatusColor(linkage.status),
                          }}
                        >
                          {getStatusText(linkage.status)}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <span className="text-sm" style={{ color: isDarkMode ? '#B4B4B4' : '#787774' }}>
                          {linkage.lastSync}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex gap-2" onClick={(e) => e.stopPropagation()}>
                          <button
                            onClick={() => handleEditLinkage(linkage)}
                            className="px-3 py-1 rounded-lg text-xs transition-all duration-200"
                            style={{
                              backgroundColor: isDarkMode ? '#0066FF20' : '#0066FF15',
                              color: '#0066FF',
                            }}
                          >
                            수정
                          </button>
                          <button
                            onClick={() => handleDeleteLinkage(linkage.id)}
                            className="px-3 py-1 rounded-lg text-xs transition-all duration-200"
                            style={{
                              backgroundColor: isDarkMode ? '#EF444420' : '#EF444415',
                              color: '#EF4444',
                            }}
                          >
                            삭제
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <Pagination
              totalItems={filteredLinkages.length}
              itemsPerPage={itemsPerPage}
              currentPage={currentPage}
              totalPages={Math.ceil(filteredLinkages.length / itemsPerPage)}
              onPageChange={setCurrentPage}
              onItemsPerPageChange={setItemsPerPage}
            />
          </div>
        </div>
      </div>

      {/* 등록/수정 모달 */}
      <AnimatePresence>
        {isModalOpen && (
          <motion.div
            className="fixed right-0 top-[72px] h-[calc(100vh-72px)] w-[400px] z-50 shadow-2xl overflow-hidden flex flex-col border-l"
            style={{
              backgroundColor: colors.bgPrimary,
              borderColor: colors.border,
            }}
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ 
              type: 'spring',
              damping: 30,
              stiffness: 300
            }}
          >
            {/* Header */}
            <div
              className="px-8 py-6 border-b flex items-center justify-between flex-shrink-0"
              style={{
                backgroundColor: colors.bgPrimary,
                borderColor: colors.border,
              }}
            >
              <div>
                <h3 className="text-xl font-bold" style={{ color: colors.textPrimary }}>
                  {selectedLinkage ? '연계 수정' : '연계 등록'}
                </h3>
                <p className="text-sm mt-1" style={{ color: colors.textSecondary }}>
                  {selectedLinkage ? '기존 연계 정보를 수정합니다' : '새로운 데이터 연계를 등록합니다'}
                </p>
              </div>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
                style={{ color: colors.textSecondary }}
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto px-8 py-6">
              <form onSubmit={handleSaveLinkage} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2" style={{ color: colors.textPrimary }}>
                      소스명 *
                    </label>
                    <input
                      type="text"
                      name="sourceName"
                      defaultValue={selectedLinkage?.sourceName}
                      required
                      className="w-full px-4 py-2 rounded-lg border"
                      style={{
                        backgroundColor: colors.surface,
                        borderColor: colors.border,
                        color: colors.textPrimary,
                      }}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2" style={{ color: colors.textPrimary }}>
                      소스 유형 *
                    </label>
                    <select
                      name="sourceType"
                      defaultValue={selectedLinkage?.sourceType || 'table'}
                      required
                      className="w-full px-4 py-2 rounded-lg border"
                      style={{
                        backgroundColor: colors.surface,
                        borderColor: colors.border,
                        color: colors.textPrimary,
                      }}
                    >
                      <option value="system">시스템</option>
                      <option value="table">테이블</option>
                      <option value="column">컬럼</option>
                    </select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2" style={{ color: colors.textPrimary }}>
                      타겟명 *
                    </label>
                    <input
                      type="text"
                      name="targetName"
                      defaultValue={selectedLinkage?.targetName}
                      required
                      className="w-full px-4 py-2 rounded-lg border"
                      style={{
                        backgroundColor: colors.surface,
                        borderColor: colors.border,
                        color: colors.textPrimary,
                      }}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2" style={{ color: colors.textPrimary }}>
                      타겟 유형 *
                    </label>
                    <select
                      name="targetType"
                      defaultValue={selectedLinkage?.targetType || 'table'}
                      required
                      className="w-full px-4 py-2 rounded-lg border"
                      style={{
                        backgroundColor: colors.surface,
                        borderColor: colors.border,
                        color: colors.textPrimary,
                      }}
                    >
                      <option value="system">시스템</option>
                      <option value="table">테이블</option>
                      <option value="column">컬럼</option>
                    </select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2" style={{ color: colors.textPrimary }}>
                      연계 유형 *
                    </label>
                    <select
                      name="linkageType"
                      defaultValue={selectedLinkage?.linkageType || 'direct'}
                      required
                      className="w-full px-4 py-2 rounded-lg border"
                      style={{
                        backgroundColor: colors.surface,
                        borderColor: colors.border,
                        color: colors.textPrimary,
                      }}
                    >
                      <option value="direct">직접 연계</option>
                      <option value="transform">변환 연계</option>
                      <option value="aggregate">집계 연계</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2" style={{ color: colors.textPrimary }}>
                      상태 *
                    </label>
                    <select
                      name="status"
                      defaultValue={selectedLinkage?.status || 'pending'}
                      required
                      className="w-full px-4 py-2 rounded-lg border"
                      style={{
                        backgroundColor: colors.surface,
                        borderColor: colors.border,
                        color: colors.textPrimary,
                      }}
                    >
                      <option value="active">활성</option>
                      <option value="inactive">비활성</option>
                      <option value="pending">대기중</option>
                    </select>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: colors.textPrimary }}>
                    담당자 *
                  </label>
                  <input
                    type="text"
                    name="owner"
                    defaultValue={selectedLinkage?.owner}
                    required
                    className="w-full px-4 py-2 rounded-lg border"
                    style={{
                      backgroundColor: colors.surface,
                      borderColor: colors.border,
                      color: colors.textPrimary,
                    }}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: colors.textPrimary }}>
                    설명
                  </label>
                  <textarea
                    name="description"
                    defaultValue={selectedLinkage?.description}
                    rows={4}
                    className="w-full px-4 py-2 rounded-lg border resize-none"
                    style={{
                      backgroundColor: colors.surface,
                      borderColor: colors.border,
                      color: colors.textPrimary,
                    }}
                  />
                </div>
              </form>
            </div>

            {/* Footer */}
            <div
              className="px-8 py-4 border-t flex items-center justify-end gap-3 flex-shrink-0"
              style={{
                backgroundColor: colors.bgPrimary,
                borderColor: colors.border,
              }}
            >
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="px-4 py-2 rounded-lg font-medium border transition-all duration-200"
                style={{
                  backgroundColor: colors.bgPrimary,
                  borderColor: colors.border,
                  color: colors.textPrimary,
                }}
              >
                취소
              </button>
              <button
                type="submit"
                onClick={(e) => {
                  e.preventDefault();
                  const form = e.currentTarget.closest('div')?.parentElement?.querySelector('form');
                  if (form) {
                    const formEvent = new Event('submit', { bubbles: true, cancelable: true }) as any;
                    Object.defineProperty(formEvent, 'currentTarget', { value: form, writable: false });
                    handleSaveLinkage(formEvent);
                  }
                }}
                className="px-4 py-2 rounded-lg font-medium transition-all duration-200"
                style={{
                  backgroundColor: '#2B8DFF',
                  color: '#FFFFFF',
                }}
              >
                {selectedLinkage ? '수정' : '등록'}
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 상세 모달 */}
      <AnimatePresence>
        {isDetailModalOpen && selectedLinkage && (
          <motion.div
            className="fixed right-0 top-[72px] h-[calc(100vh-72px)] w-[400px] z-50 shadow-2xl overflow-hidden flex flex-col border-l"
            style={{
              backgroundColor: colors.bgPrimary,
              borderColor: colors.border,
            }}
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ 
              type: 'spring',
              damping: 30,
              stiffness: 300
            }}
          >
            {/* Header */}
            <div
              className="px-8 py-6 border-b flex items-center justify-between flex-shrink-0"
              style={{
                backgroundColor: colors.bgPrimary,
                borderColor: colors.border,
              }}
            >
              <div className="flex items-center gap-4">
                <div
                  className="p-3 rounded-xl"
                  style={{
                    backgroundColor: 'rgba(0, 102, 255, 0.15)',
                  }}
                >
                  <GitBranch className="w-6 h-6" style={{ color: '#0066FF' }} />
                </div>
                <div>
                  <h3 className="text-xl font-bold" style={{ color: colors.textPrimary }}>
                    데이터 연계 상세
                  </h3>
                  <p className="text-sm mt-1" style={{ color: colors.textSecondary }}>
                    {getLinkageTypeText(selectedLinkage.linkageType)}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsDetailModalOpen(false)}
                className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
                style={{ color: colors.textSecondary }}
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto px-8 py-6">
              <div className="space-y-6">
                {/* 상태 배지 */}
                <div className="flex justify-end">
                  <span
                    className="px-3 py-1 rounded-full text-xs font-medium"
                    style={{
                      backgroundColor: `${getStatusColor(selectedLinkage.status)}20`,
                      color: getStatusColor(selectedLinkage.status),
                    }}
                  >
                    {getStatusText(selectedLinkage.status)}
                  </span>
                </div>

                <div>
                  <h4 className="text-sm font-medium mb-3" style={{ color: colors.textSecondary }}>
                    연계 정보
                  </h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-4 rounded-lg" style={{ backgroundColor: colors.surface }}>
                      <p className="text-xs mb-2" style={{ color: colors.textSecondary }}>
                        소스
                      </p>
                      <p className="text-sm font-medium mb-1" style={{ color: colors.textPrimary }}>
                        {selectedLinkage.sourceName}
                      </p>
                      <span
                        className="px-2 py-1 rounded text-xs"
                        style={{
                          backgroundColor: `${getTypeColor(selectedLinkage.sourceType)}20`,
                          color: getTypeColor(selectedLinkage.sourceType),
                        }}
                      >
                        {getTypeText(selectedLinkage.sourceType)}
                      </span>
                    </div>
                    <div className="p-4 rounded-lg" style={{ backgroundColor: colors.surface }}>
                      <p className="text-xs mb-2" style={{ color: colors.textSecondary }}>
                        타겟
                      </p>
                      <p className="text-sm font-medium mb-1" style={{ color: colors.textPrimary }}>
                        {selectedLinkage.targetName}
                      </p>
                      <span
                        className="px-2 py-1 rounded text-xs"
                        style={{
                          backgroundColor: `${getTypeColor(selectedLinkage.targetType)}20`,
                          color: getTypeColor(selectedLinkage.targetType),
                        }}
                      >
                        {getTypeText(selectedLinkage.targetType)}
                      </span>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="text-sm font-medium mb-3" style={{ color: colors.textSecondary }}>
                    관리 정보
                  </h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-4 rounded-lg" style={{ backgroundColor: colors.surface }}>
                      <p className="text-xs mb-1" style={{ color: colors.textSecondary }}>
                        담당자
                      </p>
                      <p className="text-sm font-medium" style={{ color: colors.textPrimary }}>
                        {selectedLinkage.owner}
                      </p>
                    </div>
                    <div className="p-4 rounded-lg" style={{ backgroundColor: colors.surface }}>
                      <p className="text-xs mb-1" style={{ color: colors.textSecondary }}>
                        마지막 동기화
                      </p>
                      <p className="text-sm font-medium" style={{ color: colors.textPrimary }}>
                        {selectedLinkage.lastSync}
                      </p>
                    </div>
                    <div className="p-4 rounded-lg" style={{ backgroundColor: colors.surface }}>
                      <p className="text-xs mb-1" style={{ color: colors.textSecondary }}>
                        등록일
                      </p>
                      <p className="text-sm font-medium" style={{ color: colors.textPrimary }}>
                        {selectedLinkage.createdDate}
                      </p>
                    </div>
                    <div className="p-4 rounded-lg" style={{ backgroundColor: colors.surface }}>
                      <p className="text-xs mb-1" style={{ color: colors.textSecondary }}>
                        연계 유형
                      </p>
                      <p className="text-sm font-medium" style={{ color: colors.textPrimary }}>
                        {getLinkageTypeText(selectedLinkage.linkageType)}
                      </p>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="text-sm font-medium mb-3" style={{ color: colors.textSecondary }}>
                    설명
                  </h4>
                  <div className="p-4 rounded-lg" style={{ backgroundColor: colors.surface }}>
                    <p className="text-sm" style={{ color: colors.textPrimary }}>
                      {selectedLinkage.description}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Footer */}
            <div
              className="px-8 py-4 border-t flex items-center justify-end gap-3 flex-shrink-0"
              style={{
                backgroundColor: colors.bgPrimary,
                borderColor: colors.border,
              }}
            >
              <button
                onClick={() => setIsDetailModalOpen(false)}
                className="px-4 py-2 rounded-lg font-medium border transition-all duration-200"
                style={{
                  backgroundColor: colors.bgPrimary,
                  borderColor: colors.border,
                  color: colors.textPrimary,
                }}
              >
                닫기
              </button>
              <button
                onClick={() => {
                  setIsDetailModalOpen(false);
                  handleEditLinkage(selectedLinkage);
                }}
                className="px-4 py-2 rounded-lg font-medium transition-all duration-200"
                style={{
                  backgroundColor: '#2B8DFF',
                  color: '#FFFFFF',
                }}
              >
                수정
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}