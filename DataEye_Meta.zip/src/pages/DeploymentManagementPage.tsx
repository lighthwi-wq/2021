import { Send, Calendar, CheckCircle, Clock, XCircle, Play } from 'lucide-react';
import { Card } from '../components/common/Card';
import { IconBox } from '../components/common/IconBox';
import { Button } from '../components/common/Button';
import { Badge } from '../components/common/Badge';

export function DeploymentManagementPage() {
  const deployments = [
    { 
      id: 'DEP-2024-015', 
      name: '11월 표준용어 배포', 
      type: '표준용어', 
      target: '운영 DB', 
      status: '완료', 
      items: 45, 
      scheduledDate: '2024-11-18 14:00',
      completedDate: '2024-11-18 14:23',
      executor: '김민지'
    },
    { 
      id: 'DEP-2024-016', 
      name: '품질규칙 업데이트', 
      type: '품질규칙', 
      target: '운영 DB', 
      status: '진행중', 
      items: 12, 
      scheduledDate: '2024-11-20 15:00',
      completedDate: '-',
      executor: '이지훈'
    },
    { 
      id: 'DEP-2024-017', 
      name: '업무용어 동기화', 
      type: '업무용어', 
      target: '개발 DB', 
      status: '대기', 
      items: 78, 
      scheduledDate: '2024-11-21 10:00',
      completedDate: '-',
      executor: '박서윤'
    },
    { 
      id: 'DEP-2024-014', 
      name: '메타데이터 배포', 
      type: '메타데이터', 
      target: '운영 DB', 
      status: '실패', 
      items: 23, 
      scheduledDate: '2024-11-17 16:00',
      completedDate: '2024-11-17 16:15',
      executor: '최동현'
    },
  ];

  const deploymentStats = [
    { label: '전체 배포', value: '156', icon: Send, color: 'blue' as const },
    { label: '성공', value: '142', icon: CheckCircle, color: 'green' as const },
    { label: '진행중', value: '3', icon: Clock, color: 'orange' as const },
    { label: '실패', value: '11', icon: XCircle, color: 'red' as const },
  ];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case '완료': return CheckCircle;
      case '진행중': return Clock;
      case '대기': return Calendar;
      case '실패': return XCircle;
      default: return Clock;
    }
  };

  const getStatusVariant = (status: string) => {
    switch (status) {
      case '완료': return 'success';
      case '진행중': return 'info';
      case '대기': return 'warning';
      case '실패': return 'error';
      default: return 'default';
    }
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 mb-6">
        {deploymentStats.map((stat, idx) => (
          <Card key={idx} padding="lg">
            <div className="flex items-center justify-between">
              <div>
                <p className="mb-1" style={{ color: '#5F6368' }}>{stat.label}</p>
                <h3 className="font-bold" style={{ color: '#202124' }}>{stat.value}</h3>
              </div>
              <IconBox icon={stat.icon} color={stat.color} size="md" />
            </div>
          </Card>
        ))}
      </div>

      <Card padding="lg">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <IconBox icon={Send} color="blue" size="md" />
            <h3 className="font-bold" style={{ color: '#202124' }}>배포 관리</h3>
          </div>
          <Button variant="primary" icon={<Play className="w-4 h-4" />} size="sm">새 배포 시작</Button>
        </div>

        <div className="space-y-3">
          {deployments.map((deployment, idx) => (
            <div key={idx} className="p-4 rounded-xl border transition-all" style={{ backgroundColor: '#F9F9F9', borderColor: '#DADCE0' }} onMouseEnter={(e) => e.currentTarget.style.borderColor = '#2B8DFF'} onMouseLeave={(e) => e.currentTarget.style.borderColor = '#DADCE0'}>
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-start gap-3 flex-1">
                  <IconBox icon={getStatusIcon(deployment.status)} color={
                    deployment.status === '완료' ? 'green' :
                    deployment.status === '진행중' ? 'blue' :
                    deployment.status === '대기' ? 'orange' : 'red'
                  } size="sm" />
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h4 className="font-bold" style={{ color: '#202124' }}>{deployment.name}</h4>
                      <Badge variant={getStatusVariant(deployment.status) as any}>
                        {deployment.status}
                      </Badge>
                      <span className="text-sm" style={{ color: '#5F6368' }}>#{deployment.id}</span>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                      <div>
                        <span style={{ color: '#5F6368' }}>유형:</span>
                        <span className="ml-2 font-bold" style={{ color: '#202124' }}>{deployment.type}</span>
                      </div>
                      <div>
                        <span style={{ color: '#5F6368' }}>대상:</span>
                        <span className="ml-2 font-bold" style={{ color: '#202124' }}>{deployment.target}</span>
                      </div>
                      <div>
                        <span style={{ color: '#5F6368' }}>항목:</span>
                        <span className="ml-2 font-bold" style={{ color: '#202124' }}>{deployment.items}개</span>
                      </div>
                      <div>
                        <span style={{ color: '#5F6368' }}>담당자:</span>
                        <span className="ml-2 font-bold" style={{ color: '#202124' }}>{deployment.executor}</span>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4 mt-2 text-sm">
                      <div>
                        <span style={{ color: '#5F6368' }}>예정시각:</span>
                        <span className="ml-2" style={{ color: '#202124' }}>{deployment.scheduledDate}</span>
                      </div>
                      <div>
                        <span style={{ color: '#5F6368' }}>완료시각:</span>
                        <span className="ml-2" style={{ color: '#202124' }}>{deployment.completedDate}</span>
                      </div>
                    </div>
                  </div>
                </div>
                {deployment.status === '대기' && (
                  <Button variant="secondary" size="sm">실행</Button>
                )}
                {deployment.status === '실패' && (
                  <Button variant="secondary" size="sm">재시도</Button>
                )}
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}