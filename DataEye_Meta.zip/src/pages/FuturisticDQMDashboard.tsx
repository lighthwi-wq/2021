import { useState, useEffect } from 'react';
import { Activity, AlertTriangle, CheckCircle2, TrendingUp, TrendingDown, Zap, Database, Shield, Target } from 'lucide-react';
import { Card } from '../components/common/Card';
import { Badge } from '../components/common/Badge';
import { Button } from '../components/common/Button';
import { colors, glows } from '../constants/designSystem';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Area, AreaChart } from 'recharts';

const dailyTrend = [
  { date: '01/20', score: 88, issues: 45 },
  { date: '01/21', score: 90, issues: 38 },
  { date: '01/22', score: 89, issues: 42 },
  { date: '01/23', score: 91, issues: 35 },
  { date: '01/24', score: 92, issues: 28 },
  { date: '01/25', score: 91, issues: 31 },
  { date: '01/26', score: 92, issues: 28 },
];

const errorsByType = [
  { type: 'Null', count: 12, color: colors.error },
  { type: 'Format', count: 8, color: colors.warning },
  { type: 'Range', count: 5, color: colors.info },
  { type: 'Duplicate', count: 3, color: colors.accent },
];

const domainQuality = [
  { domain: 'Customer', score: 95, status: 'excellent' },
  { domain: 'Product', score: 89, status: 'good' },
  { domain: 'Transaction', score: 92, status: 'excellent' },
  { domain: 'Finance', score: 78, status: 'warning' },
  { domain: 'Inventory', score: 85, status: 'good' },
];

export function FuturisticDQMDashboard() {
  const [gaugeProgress, setGaugeProgress] = useState(0);
  const targetScore = 92;
  const [activeTab, setActiveTab] = useState<'overview' | 'domains' | 'rules'>('overview');

  useEffect(() => {
    const timer = setTimeout(() => {
      setGaugeProgress(targetScore);
    }, 300);
    return () => clearTimeout(timer);
  }, []);

  // Gauge calculations
  const circumference = 2 * Math.PI * 90;
  const offset = circumference - (gaugeProgress / 100) * (circumference * 0.75); // 270 degree arc

  const criticalErrors = [
    { 
      id: 1, 
      table: 'TB_CUSTOMER', 
      issue: 'Null values detected in primary key column', 
      count: 45,
      severity: 'critical',
    },
    { 
      id: 2, 
      table: 'TB_ORDER', 
      issue: 'Invalid date format in transaction timestamp', 
      count: 23,
      severity: 'high',
    },
    { 
      id: 3, 
      table: 'TB_PRODUCT', 
      issue: 'Price values exceed defined range limits', 
      count: 12,
      severity: 'medium',
    },
  ];

  return (
    <div className="space-y-6 animate-fade-in-up">
      {/* Hero Header */}
      <div className="relative">
        <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/10 via-purple-500/10 to-pink-500/10 blur-3xl" />
        <Card className="relative" glow>
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <div 
                  className="p-3 rounded-xl"
                  style={{ 
                    background: colors.primaryLight,
                    boxShadow: glows.primary,
                  }}
                >
                  <Shield className="w-8 h-8" style={{ color: colors.primary }} />
                </div>
                <div>
                  <h1 className="text-3xl font-bold mb-1 text-glow-primary" style={{ color: colors.textPrimary }}>
                    Data Quality Management
                  </h1>
                  <p style={{ color: colors.textSecondary }}>
                    데이터 품질 관리 · Real-time monitoring & analytics
                  </p>
                </div>
              </div>
            </div>
            <div className="flex gap-3">
              <Button variant="ghost" icon={<Activity className="w-4 h-4" />}>
                Live Monitor
              </Button>
              <Button variant="primary" glow icon={<Zap className="w-4 h-4" />}>
                Run Quality Check
              </Button>
            </div>
          </div>
        </Card>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-12 gap-6">
        {/* Central Health Score Gauge - Engine Core Style */}
        <div className="col-span-5">
          <Card className="h-full" glow>
            <div className="text-center">
              <div className="mb-4">
                <h3 className="text-lg font-semibold mb-1" style={{ color: colors.textPrimary }}>
                  Overall Health Score
                </h3>
                <p className="text-sm" style={{ color: colors.textSecondary }}>
                  전체 데이터 품질 점수
                </p>
              </div>

              {/* Futuristic Gauge */}
              <div className="relative flex items-center justify-center py-8">
                {/* Outer glow ring */}
                <div 
                  className="absolute inset-0 flex items-center justify-center animate-spin-slow"
                  style={{ opacity: 0.3 }}
                >
                  <div 
                    className="w-64 h-64 rounded-full"
                    style={{
                      border: `2px dashed ${colors.primary}`,
                    }}
                  />
                </div>

                {/* Main gauge */}
                <svg width="280" height="280" className="relative">
                  {/* Background arc */}
                  <path
                    d="M 140 230 A 90 90 0 1 1 140 50"
                    fill="none"
                    stroke="rgba(0, 0, 0, 0.05)"
                    strokeWidth="20"
                    strokeLinecap="round"
                  />
                  {/* Progress arc with gradient */}
                  <defs>
                    <linearGradient id="gaugeGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                      <stop offset="0%" stopColor={colors.success} />
                      <stop offset="50%" stopColor={colors.primary} />
                      <stop offset="100%" stopColor={colors.accent} />
                    </linearGradient>
                  </defs>
                  <path
                    d="M 140 230 A 90 90 0 1 1 140 50"
                    fill="none"
                    stroke="url(#gaugeGradient)"
                    strokeWidth="20"
                    strokeLinecap="round"
                    strokeDasharray={circumference * 0.75}
                    strokeDashoffset={offset}
                    style={{
                      transition: 'stroke-dashoffset 2s cubic-bezier(0.4, 0, 0.2, 1)',
                      filter: `drop-shadow(0 0 10px ${colors.primary})`,
                    }}
                  />
                  
                  {/* Center content */}
                  <text
                    x="140"
                    y="130"
                    textAnchor="middle"
                    className="text-6xl font-bold"
                    style={{ 
                      fill: colors.primary,
                      filter: `drop-shadow(0 2px 8px ${colors.primaryGlow})`,
                    }}
                  >
                    {gaugeProgress}
                  </text>
                  <text
                    x="140"
                    y="155"
                    textAnchor="middle"
                    className="text-2xl font-bold"
                    style={{ fill: colors.textPrimary }}
                  >
                    %
                  </text>
                  <text
                    x="140"
                    y="180"
                    textAnchor="middle"
                    className="text-sm"
                    style={{ fill: colors.textSecondary }}
                  >
                    Quality Score
                  </text>
                </svg>
              </div>

              {/* Metrics below gauge */}
              <div className="grid grid-cols-3 gap-4 pt-6 border-t" style={{ borderColor: colors.divider }}>
                <div>
                  <div className="text-2xl font-bold mb-1" style={{ color: colors.success }}>
                    95%
                  </div>
                  <div className="text-xs" style={{ color: colors.textSecondary }}>
                    Completeness
                  </div>
                </div>
                <div>
                  <div className="text-2xl font-bold mb-1" style={{ color: colors.primary }}>
                    93%
                  </div>
                  <div className="text-xs" style={{ color: colors.textSecondary }}>
                    Accuracy
                  </div>
                </div>
                <div>
                  <div className="text-2xl font-bold mb-1" style={{ color: colors.warning }}>
                    88%
                  </div>
                  <div className="text-xs" style={{ color: colors.textSecondary }}>
                    Consistency
                  </div>
                </div>
              </div>
            </div>
          </Card>
        </div>

        {/* Right side stats */}
        <div className="col-span-7 space-y-4">
          {/* Quick Stats Row */}
          <div className="grid grid-cols-3 gap-4">
            <Card hover className="relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-green-500/20 to-transparent rounded-full blur-2xl" />
              <div className="relative">
                <div className="flex items-center gap-2 mb-3">
                  <CheckCircle2 className="w-5 h-5" style={{ color: colors.success }} />
                  <span className="text-xs font-medium" style={{ color: colors.textSecondary }}>
                    PASSED RULES
                  </span>
                </div>
                <div className="text-3xl font-bold mb-1" style={{ color: colors.textPrimary }}>
                  1,247
                </div>
                <div className="flex items-center gap-1 text-xs" style={{ color: colors.success }}>
                  <TrendingUp className="w-3 h-3" />
                  <span>+12 today</span>
                </div>
              </div>
            </Card>

            <Card hover className="relative overflow-hidden animate-pulse-glow-error">
              <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-red-500/20 to-transparent rounded-full blur-2xl" />
              <div className="relative">
                <div className="flex items-center gap-2 mb-3">
                  <AlertTriangle className="w-5 h-5" style={{ color: colors.error }} />
                  <span className="text-xs font-medium" style={{ color: colors.textSecondary }}>
                    CRITICAL ISSUES
                  </span>
                </div>
                <div className="text-3xl font-bold mb-1" style={{ color: colors.error }}>
                  28
                </div>
                <div className="flex items-center gap-1 text-xs" style={{ color: colors.error }}>
                  <AlertTriangle className="w-3 h-3" />
                  <span>Needs attention</span>
                </div>
              </div>
            </Card>

            <Card hover className="relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-cyan-500/20 to-transparent rounded-full blur-2xl" />
              <div className="relative">
                <div className="flex items-center gap-2 mb-3">
                  <Activity className="w-5 h-5" style={{ color: colors.primary }} />
                  <span className="text-xs font-medium" style={{ color: colors.textSecondary }}>
                    ACTIVE MONITORS
                  </span>
                </div>
                <div className="text-3xl font-bold mb-1" style={{ color: colors.textPrimary }}>
                  156
                </div>
                <div className="flex items-center gap-1 text-xs" style={{ color: colors.primary }}>
                  <Activity className="w-3 h-3" />
                  <span>Running now</span>
                </div>
              </div>
            </Card>
          </div>

          {/* Trend Chart */}
          <Card>
            <div className="mb-4">
              <h3 className="font-semibold mb-1" style={{ color: colors.textPrimary }}>
                Quality Trend (7 Days)
              </h3>
              <p className="text-xs" style={{ color: colors.textSecondary }}>
                품질 점수 추세
              </p>
            </div>
            <ResponsiveContainer width="100%" height={180}>
              <AreaChart data={dailyTrend}>
                <defs>
                  <linearGradient id="colorScore" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor={colors.primary} stopOpacity={0.3}/>
                    <stop offset="95%" stopColor={colors.primary} stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke={colors.divider} />
                <XAxis 
                  dataKey="date" 
                  stroke={colors.textTertiary} 
                  style={{ fontSize: '11px' }} 
                />
                <YAxis 
                  stroke={colors.textTertiary} 
                  style={{ fontSize: '11px' }} 
                  domain={[85, 95]} 
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'rgba(255, 255, 255, 0.98)',
                    border: `1px solid ${colors.border}`,
                    borderRadius: '8px',
                    backdropFilter: 'blur(20px)',
                    color: colors.textPrimary,
                  }}
                />
                <Area 
                  type="monotone" 
                  dataKey="score" 
                  stroke={colors.primary} 
                  strokeWidth={3}
                  fill="url(#colorScore)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </Card>
        </div>
      </div>

      {/* Domain Quality Heatmap */}
      <Card>
        <div className="mb-5">
          <h3 className="text-lg font-semibold mb-1" style={{ color: colors.textPrimary }}>
            Domain Quality Heatmap
          </h3>
          <p className="text-sm" style={{ color: colors.textSecondary }}>
            도메인별 품질 점수 히트맵
          </p>
        </div>
        <div className="grid grid-cols-5 gap-4">
          {domainQuality.map((domain, index) => (
            <div
              key={index}
              className="p-5 rounded-xl border-2 transition-all duration-300 hover:scale-105 cursor-pointer"
              style={{
                background: `linear-gradient(135deg, ${
                  domain.score >= 90 ? colors.successLight : 
                  domain.score >= 80 ? colors.primaryLight : 
                  colors.warningLight
                } 0%, rgba(255, 255, 255, 0.5) 100%)`,
                borderColor: domain.score >= 90 ? colors.success : 
                             domain.score >= 80 ? colors.primary : 
                             colors.warning,
                boxShadow: domain.score >= 90 ? glows.success : 
                           domain.score >= 80 ? glows.primary : 
                           'none',
              }}
            >
              <div className="text-center">
                <Database className="w-8 h-8 mx-auto mb-3" style={{ 
                  color: domain.score >= 90 ? colors.success : 
                         domain.score >= 80 ? colors.primary : 
                         colors.warning 
                }} />
                <div className="text-3xl font-bold mb-2" style={{ 
                  color: domain.score >= 90 ? colors.success : 
                         domain.score >= 80 ? colors.primary : 
                         colors.warning 
                }}>
                  {domain.score}%
                </div>
                <div className="font-medium mb-2" style={{ color: colors.textPrimary }}>
                  {domain.domain}
                </div>
                <Badge 
                  variant={
                    domain.score >= 90 ? 'success' : 
                    domain.score >= 80 ? 'primary' : 
                    'warning'
                  }
                  showDot
                >
                  {domain.score >= 90 ? 'Excellent' : 
                   domain.score >= 80 ? 'Good' : 
                   'Warning'}
                </Badge>
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* Critical Errors - Traffic Light Style */}
      <Card>
        <div className="flex items-center justify-between mb-5">
          <div>
            <h3 className="text-lg font-semibold mb-1" style={{ color: colors.textPrimary }}>
              Critical Errors - Immediate Action Required
            </h3>
            <p className="text-sm" style={{ color: colors.textSecondary }}>
              즉시 조치가 필요한 오류
            </p>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
            <span className="text-xs" style={{ color: colors.textSecondary }}>Live monitoring</span>
          </div>
        </div>
        <div className="space-y-3">
          {criticalErrors.map((error, index) => (
            <div
              key={error.id}
              className="p-5 rounded-xl border-2 transition-all duration-300 hover:scale-[1.02] cursor-pointer animate-pulse-glow-error"
              style={{
                background: `linear-gradient(90deg, ${colors.errorLight} 0%, rgba(255, 255, 255, 0.5) 100%)`,
                borderColor: colors.error,
                animationDelay: `${index * 0.2}s`,
              }}
            >
              <div className="flex items-center gap-4">
                <div 
                  className="p-4 rounded-xl flex-shrink-0"
                  style={{ 
                    backgroundColor: colors.error,
                    boxShadow: glows.error,
                  }}
                >
                  <Database className="w-6 h-6" style={{ color: '#FFFFFF' }} />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <span className="font-semibold text-lg" style={{ color: colors.textPrimary }}>
                      {error.table}
                    </span>
                    <Badge variant="error" glow>
                      {error.count} records affected
                    </Badge>
                    <Badge variant="error">
                      {error.severity.toUpperCase()}
                    </Badge>
                  </div>
                  <p style={{ color: colors.textSecondary }}>
                    {error.issue}
                  </p>
                </div>
                <Button variant="error" glow>
                  Fix Now
                </Button>
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* Error Distribution */}
      <div className="grid grid-cols-2 gap-6">
        <Card>
          <h3 className="font-semibold mb-4" style={{ color: colors.textPrimary }}>
            Error Distribution by Type
          </h3>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={errorsByType}>
              <CartesianGrid strokeDasharray="3 3" stroke={colors.divider} />
              <XAxis dataKey="type" stroke={colors.textTertiary} style={{ fontSize: '12px' }} />
              <YAxis stroke={colors.textTertiary} style={{ fontSize: '12px' }} />
              <Tooltip
                contentStyle={{
                  backgroundColor: 'rgba(255, 255, 255, 0.98)',
                  border: `1px solid ${colors.border}`,
                  borderRadius: '8px',
                  backdropFilter: 'blur(20px)',
                  color: colors.textPrimary,
                }}
              />
              <Bar 
                dataKey="count" 
                radius={[8, 8, 0, 0]}
              >
                {errorsByType.map((entry, index) => (
                  <rect key={index} fill={entry.color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </Card>

        <Card>
          <h3 className="font-semibold mb-4" style={{ color: colors.textPrimary }}>
            Recent Quality Activities
          </h3>
          <div className="space-y-3">
            {[
              { action: 'Quality check completed', table: 'TB_CUSTOMER', time: '2 min ago', status: 'success' },
              { action: 'Critical error detected', table: 'TB_ORDER', time: '5 min ago', status: 'error' },
              { action: 'Rule updated', table: 'TB_PRODUCT', time: '12 min ago', status: 'info' },
              { action: 'Monitor activated', table: 'TB_ACCOUNT', time: '18 min ago', status: 'success' },
            ].map((activity, index) => (
              <div
                key={index}
                className="flex items-center gap-3 p-3 rounded-lg hover:bg-white/5 transition-colors"
              >
                <div 
                  className="w-2 h-2 rounded-full flex-shrink-0"
                  style={{ 
                    backgroundColor: activity.status === 'success' ? colors.success : 
                                   activity.status === 'error' ? colors.error : 
                                   colors.primary 
                  }}
                />
                <div className="flex-1">
                  <div className="font-medium text-sm" style={{ color: colors.textPrimary }}>
                    {activity.action}
                  </div>
                  <div className="text-xs" style={{ color: colors.textSecondary }}>
                    {activity.table} · {activity.time}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}