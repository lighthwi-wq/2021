import { Card } from '../components/common/Card';
import { Button } from '../components/common/Button';
import { Badge } from '../components/common/Badge';
import { CheckCircle, Clock, Users } from 'lucide-react';
import { colors } from '../constants/designSystem';

const improvements = [
  { id: 1, title: 'EMAIL 형식 오류 수정', table: 'TB_CUSTOMER', assignee: '김철수', status: 'completed', dueDate: '2024-01-25', completedDate: '2024-01-24' },
  { id: 2, title: 'NULL 값 처리', table: 'TB_PRODUCT', assignee: '이영희', status: 'in-progress', dueDate: '2024-01-30', completedDate: null },
  { id: 3, title: '금액 범위 검증', table: 'TB_ORDER', assignee: '박지훈', status: 'pending', dueDate: '2024-02-05', completedDate: null },
  { id: 4, title: '전화번호 표준화', table: 'TB_CUSTOMER', assignee: '최민수', status: 'in-progress', dueDate: '2024-01-28', completedDate: null },
];

export function ImprovementPage() {
  return (
    <div className="space-y-6 animate-fade-in-up">
      {/* Stats */}
      <div className="grid grid-cols-4 gap-4">
        <Card>
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-xl" style={{ backgroundColor: colors.primaryLight }}>
              <Users className="w-6 h-6" style={{ color: colors.primary }} />
            </div>
            <div>
              <p className="text-sm" style={{ color: colors.textSecondary }}>전체 개선 활동</p>
              <p className="text-2xl font-bold" style={{ color: colors.textPrimary }}>45</p>
            </div>
          </div>
        </Card>
        <Card>
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-xl" style={{ backgroundColor: colors.successLight }}>
              <CheckCircle className="w-6 h-6" style={{ color: colors.success }} />
            </div>
            <div>
              <p className="text-sm" style={{ color: colors.textSecondary }}>완료</p>
              <p className="text-2xl font-bold" style={{ color: colors.textPrimary }}>28</p>
            </div>
          </div>
        </Card>
        <Card>
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-xl" style={{ backgroundColor: colors.warningLight }}>
              <Clock className="w-6 h-6" style={{ color: colors.warning }} />
            </div>
            <div>
              <p className="text-sm" style={{ color: colors.textSecondary }}>진행중</p>
              <p className="text-2xl font-bold" style={{ color: colors.textPrimary }}>12</p>
            </div>
          </div>
        </Card>
        <Card>
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-xl" style={{ backgroundColor: colors.infoLight }}>
              <Clock className="w-6 h-6" style={{ color: colors.info }} />
            </div>
            <div>
              <p className="text-sm" style={{ color: colors.textSecondary }}>대기중</p>
              <p className="text-2xl font-bold" style={{ color: colors.textPrimary }}>5</p>
            </div>
          </div>
        </Card>
      </div>

      {/* Actions */}
      <Card>
        <div className="flex items-center justify-between">
          <h3 className="font-semibold" style={{ color: colors.textPrimary }}>
            개선 활동 목록
          </h3>
        </div>
      </Card>

      {/* Improvement List */}
      <Card>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b" style={{ borderColor: colors.divider }}>
                <th className="text-left py-3 px-4" style={{ color: colors.textSecondary }}>개선 활동</th>
                <th className="text-left py-3 px-4" style={{ color: colors.textSecondary }}>대상 테이블</th>
                <th className="text-left py-3 px-4" style={{ color: colors.textSecondary }}>담당자</th>
                <th className="text-center py-3 px-4" style={{ color: colors.textSecondary }}>상태</th>
                <th className="text-left py-3 px-4" style={{ color: colors.textSecondary }}>마감일</th>
                <th className="text-left py-3 px-4" style={{ color: colors.textSecondary }}>완료일</th>
                <th className="text-center py-3 px-4" style={{ color: colors.textSecondary }}>액션</th>
              </tr>
            </thead>
            <tbody>
              {improvements.map((item) => (
                <tr 
                  key={item.id} 
                  className="border-b hover:bg-black/[0.02] transition-colors"
                  style={{ borderColor: colors.divider }}
                >
                  <td className="py-3 px-4 font-medium" style={{ color: colors.textPrimary }}>
                    {item.title}
                  </td>
                  <td className="py-3 px-4 font-mono" style={{ color: colors.textSecondary }}>
                    {item.table}
                  </td>
                  <td className="py-3 px-4" style={{ color: colors.textPrimary }}>
                    {item.assignee}
                  </td>
                  <td className="py-3 px-4 text-center">
                    <Badge 
                      variant={
                        item.status === 'completed' ? 'success' : 
                        item.status === 'in-progress' ? 'warning' : 
                        'info'
                      }
                    >
                      {item.status === 'completed' ? '완료' : item.status === 'in-progress' ? '진행중' : '대기'}
                    </Badge>
                  </td>
                  <td className="py-3 px-4" style={{ color: colors.textSecondary }}>
                    {item.dueDate}
                  </td>
                  <td className="py-3 px-4" style={{ color: colors.textSecondary }}>
                    {item.completedDate || '-'}
                  </td>
                  <td className="py-3 px-4 text-center">
                    <Button variant="ghost" size="sm">
                      상세 보기
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
