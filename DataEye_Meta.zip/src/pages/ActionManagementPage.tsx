import { useState, useEffect } from 'react';
import { ClipboardCheck, Plus, MessageSquare, CheckCircle, Clock, User, X, Filter } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Card } from '../components/common/Card';
import { IconBox } from '../components/common/IconBox';
import { Button } from '../components/common/Button';
import { Badge } from '../components/common/Badge';
import { Pagination } from '../components/common/Pagination';
import { colors } from '../constants/designSystem';
import { useModal } from '../contexts/ModalContext';

interface Action {
  id: string;
  violationId: string;
  title: string;
  violation: string;
  table: string;
  priority: 'high' | 'medium' | 'low';
  status: string;
  assignee: string;
  dueDate: string;
  createdDate: string;
  progress: number;
  description: string;
  comments: number;
}

export function ActionManagementPage() {
  const { setIsModalOpen: setGlobalModalOpen } = useModal();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedAction, setSelectedAction] = useState<Action | null>(null);
  const [sortField, setSortField] = useState<string>('');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [filters, setFilters] = useState<Record<string, string>>({});
  const [activeFilterColumn, setActiveFilterColumn] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);

  const handleAddClick = () => {
    setSelectedAction(null);
    setIsModalOpen(true);
  };

  const handleActionClick = (action: Action) => {
    setSelectedAction(action);
    setIsModalOpen(true);
  };

  const [actions, setActions] = useState<Action[]>([
    {
      id: 'A-2024-0089',
      violationId: 'V-2024-0156',
      title: '고객명 필수값 누락 데이터 정리',
      violation: '필수값 검증 위반',
      table: 'CUSTOMER',
      priority: 'high',
      status: '진행중',
      assignee: '김민지',
      dueDate: '2024-11-22',
      createdDate: '2024-11-20',
      progress: 60,
      description: '빈값이 있는 3건의 고객 데이터에 대해 원본 데이터 확인 후 보정 작업 진행',
      comments: 5
    },
    {
      id: 'A-2024-0090',
      violationId: 'V-2024-0157',
      title: '이메일 형식 오류 데이터 수정',
      violation: '이메일 형식 검증 위반',
      table: 'CUSTOMER',
      priority: 'medium',
      status: '진행중',
      assignee: '이지훈',
      dueDate: '2024-11-23',
      createdDate: '2024-11-20',
      progress: 40,
      description: '잘못된 이메일 형식 12건에 대한 고객 확인 및 수정 작업',
      comments: 3
    },
    {
      id: 'A-2024-0091',
      violationId: 'V-2024-0158',
      title: '고객번호 중복 데이터 병합',
      violation: '중복 데이터 검사 위반',
      table: 'CUSTOMER',
      priority: 'high',
      status: '대기',
      assignee: '박서윤',
      dueDate: '2024-11-21',
      createdDate: '2024-11-20',
      progress: 0,
      description: '중복된 고객번호 5건에 대한 데이터 병합 및 이력 관리',
      comments: 2
    },
    {
      id: 'A-2024-0092',
      violationId: 'V-2024-0159',
      title: '음수 거래금액 데이터 검증',
      violation: '금액 범위 검증 위반',
      table: 'TRANSACTION',
      priority: 'medium',
      status: '완료',
      assignee: '최동현',
      dueDate: '2024-11-20',
      createdDate: '2024-11-19',
      progress: 100,
      description: '음수 금액 8건에 대한 거래 취소 처리 완료',
      comments: 7
    },
    {
      id: 'A-2024-0093',
      violationId: 'V-2024-0160',
      title: '미래 날짜 주문 데이터 수정',
      violation: '날짜 범위 검증 위반',
      table: 'ORDER',
      priority: 'high',
      status: '검토중',
      assignee: '김민지',
      dueDate: '2024-11-21',
      createdDate: '2024-11-20',
      progress: 80,
      description: '미래 날짜로 입력된 주문 2건 수정 후 검토 대기',
      comments: 4
    },
  ]);

  const actionStats = [
    { label: '전체 조치', value: '234', icon: ClipboardCheck, color: 'blue' as const },
    { label: '완료', value: '156', icon: CheckCircle, color: 'green' as const },
    { label: '진행중', value: '54', icon: Clock, color: 'orange' as const },
    { label: '대기', value: '24', icon: Clock, color: 'red' as const },
  ];

  const assigneeStats = [
    { name: '김민지', total: 45, completed: 32, inProgress: 10, pending: 3 },
    { name: '이지훈', total: 38, completed: 28, inProgress: 8, pending: 2 },
    { name: '박서윤', total: 42, completed: 35, inProgress: 5, pending: 2 },
    { name: '최동현', total: 36, completed: 30, inProgress: 4, pending: 2 },
  ];

  const getPriorityVariant = (priority: string) => {
    switch (priority) {
      case 'high': return 'error';
      case 'medium': return 'warning';
      case 'low': return 'default';
      default: return 'default';
    }
  };

  const getPriorityLabel = (priority: string) => {
    switch (priority) {
      case 'high': return '높음';
      case 'medium': return '중간';
      case 'low': return '낮음';
      default: return priority;
    }
  };

  const getStatusVariant = (status: string) => {
    switch (status) {
      case '완료': return 'success';
      case '진행중': return 'info';
      case '검토중': return 'warning';
      case '대기': return 'default';
      default: return 'default';
    }
  };

  useEffect(() => {
    setGlobalModalOpen(isModalOpen);
  }, [isModalOpen, setGlobalModalOpen]);

  const handleAddAction = () => {
    setSelectedAction(null);
    setIsModalOpen(true);
  };

  const handleSaveAction = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    const newAction: Action = {
      id: selectedAction?.id || `A-2024-${String(Math.floor(Math.random() * 10000)).padStart(4, '0')}`,
      violationId: formData.get('violationId') as string,
      title: formData.get('title') as string,
      violation: formData.get('violation') as string,
      table: formData.get('table') as string,
      priority: formData.get('priority') as 'high' | 'medium' | 'low',
      status: formData.get('status') as string,
      assignee: formData.get('assignee') as string,
      dueDate: formData.get('dueDate') as string,
      description: formData.get('description') as string,
      progress: parseInt(formData.get('progress') as string) || 0,
      createdDate: selectedAction?.createdDate || new Date().toISOString().split('T')[0],
      comments: selectedAction?.comments || 0,
    };

    if (selectedAction) {
      setActions(actions.map(a => a.id === selectedAction.id ? newAction : a));
    } else {
      setActions([...actions, newAction]);
    }
    
    setIsModalOpen(false);
  };

  const handleSort = (field: string) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const handleFilter = (column: string, value: string) => {
    setFilters(prevFilters => ({
      ...prevFilters,
      [column]: value
    }));
    setActiveFilterColumn(column);
  };

  const filteredActions = actions.filter(action => {
    return Object.entries(filters).every(([column, value]) => {
      return action[column as keyof Action]?.toString().includes(value);
    });
  });

  const sortedActions = filteredActions.sort((a, b) => {
    if (!sortField) return 0;
    const aValue = a[sortField as keyof Action];
    const bValue = b[sortField as keyof Action];
    if (typeof aValue === 'string' && typeof bValue === 'string') {
      return sortDirection === 'asc' ? aValue.localeCompare(bValue) : bValue.localeCompare(aValue);
    }
    if (typeof aValue === 'number' && typeof bValue === 'number') {
      return sortDirection === 'asc' ? aValue - bValue : bValue - aValue;
    }
    return 0;
  });

  const totalPages = Math.ceil(sortedActions.length / itemsPerPage);
  const currentActions = sortedActions.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  return (
    <div className="space-y-4 p-0">
      <div className="flex-1 overflow-auto">
        <div className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 mb-6">
            {actionStats.map((stat, idx) => (
              <Card key={idx} padding="lg">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="mb-1" style={{ color: '#5F6368' }}>{stat.label}</p>
                    <h3 className="font-bold" style={{ color: '#202124' }}>{stat.value}</h3>
                  </div>
                  <IconBox icon={stat.icon} color={stat.color} size="md" />
                </div>
              </Card>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <div className="lg:col-span-2 space-y-4">
              <Card padding="lg">
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-3">
                    <IconBox icon={ClipboardCheck} color="blue" size="md" />
                    <h3 className="font-bold" style={{ color: '#202124' }}>조치 작업 목록</h3>
                  </div>
                  <Button 
                    variant="primary" 
                    icon={<Plus className="w-4 h-4" />} 
                    size="sm"
                    onClick={handleAddAction}
                  >
                    조치 등록
                  </Button>
                </div>

                <div className="space-y-3">
                  {currentActions.map((action, idx) => (
                    <div 
                      key={idx} 
                      className="p-4 rounded-xl border transition-all cursor-pointer"
                      style={{ backgroundColor: '#F9F9F9', borderColor: '#DADCE0' }}
                      onClick={() => setSelectedAction(action)}
                      onMouseEnter={(e) => e.currentTarget.style.borderColor = '#2B8DFF'}
                      onMouseLeave={(e) => e.currentTarget.style.borderColor = '#DADCE0'}
                    >
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <h4 className="font-bold" style={{ color: '#202124' }}>{action.title}</h4>
                            <Badge variant={getPriorityVariant(action.priority) as any}>
                              {getPriorityLabel(action.priority)}
                            </Badge>
                            <Badge variant={getStatusVariant(action.status) as any}>
                              {action.status}
                            </Badge>
                            <span className="text-sm" style={{ color: '#5F6368' }}>#{action.id}</span>
                          </div>

                          <p className="mb-3" style={{ color: '#5F6368' }}>{action.description}</p>

                          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm mb-3">
                            <div>
                              <span style={{ color: '#5F6368' }}>위반:</span>
                              <span className="ml-2" style={{ color: '#202124' }}>{action.violationId}</span>
                            </div>
                            <div>
                              <span style={{ color: '#5F6368' }}>테이블:</span>
                              <span className="ml-2 font-bold font-mono" style={{ color: '#202124' }}>{action.table}</span>
                            </div>
                            <div>
                              <span style={{ color: '#5F6368' }}>담당자:</span>
                              <span className="ml-2 font-bold" style={{ color: '#202124' }}>{action.assignee}</span>
                            </div>
                            <div>
                              <span style={{ color: '#5F6368' }}>기한:</span>
                              <span className="ml-2" style={{ color: '#202124' }}>{action.dueDate}</span>
                            </div>
                          </div>

                          <div className="space-y-2">
                            <div className="flex items-center justify-between text-sm">
                              <span style={{ color: '#5F6368' }}>진행률</span>
                              <span className="font-bold" style={{ color: '#202124' }}>{action.progress}%</span>
                            </div>
                            <div className="w-full h-2 rounded-full overflow-hidden" style={{ backgroundColor: '#E8EAED' }}>
                              <div 
                                className={`h-full transition-all ${
                                  action.progress === 100 ? 'bg-green-500' :
                                  action.progress >= 50 ? 'bg-blue-500' : 'bg-orange-500'
                                }`}
                                style={{ width: `${action.progress}%` }}
                              ></div>
                            </div>
                          </div>

                          <div className="flex items-center gap-4 mt-3 text-sm">
                            <div className="flex items-center gap-2" style={{ color: '#5F6368' }}>
                              <MessageSquare className="w-4 h-4" />
                              <span>{action.comments}개의 댓글</span>
                            </div>
                            <span style={{ color: '#5F6368' }}>등록: {action.createdDate}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                <Pagination
                  currentPage={currentPage}
                  totalPages={totalPages}
                  onPageChange={setCurrentPage}
                />
              </Card>
            </div>

            <div className="space-y-4">
              <Card padding="lg">
                <div className="flex items-center gap-3 mb-6">
                  <IconBox icon={User} color="indigo" size="md" />
                  <h3 className="font-bold" style={{ color: '#202124' }}>담당자별 현황</h3>
                </div>
                <div className="space-y-4">
                  {assigneeStats.map((assignee, idx) => (
                    <div key={idx} className="p-3 rounded-xl border" style={{ backgroundColor: '#F9F9F9', borderColor: '#DADCE0' }}>
                      <div className="flex items-center justify-between mb-3">
                        <h4 className="font-bold" style={{ color: '#202124' }}>{assignee.name}</h4>
                        <span className="font-bold" style={{ color: '#202124' }}>{assignee.total}건</span>
                      </div>
                      <div className="grid grid-cols-3 gap-2 text-sm">
                        <div className="text-center p-2 rounded-lg" style={{ backgroundColor: '#F0FDF4' }}>
                          <p className="mb-1" style={{ color: '#16A34A' }}>완료</p>
                          <p className="font-bold" style={{ color: '#15803D' }}>{assignee.completed}</p>
                        </div>
                        <div className="text-center p-2 rounded-lg" style={{ backgroundColor: '#EFF6FF' }}>
                          <p className="mb-1" style={{ color: '#2563EB' }}>진행중</p>
                          <p className="font-bold" style={{ color: '#1E40AF' }}>{assignee.inProgress}</p>
                        </div>
                        <div className="text-center p-2 rounded-lg" style={{ backgroundColor: '#F9F9F9' }}>
                          <p className="mb-1" style={{ color: '#5F6368' }}>대기</p>
                          <p className="font-bold" style={{ color: '#202124' }}>{assignee.pending}</p>
                        </div>
                      </div>
                      <div className="mt-3">
                        <div className="w-full h-2 rounded-full overflow-hidden" style={{ backgroundColor: '#E8EAED' }}>
                          <div 
                            className="h-full bg-green-500"
                            style={{ width: `${(assignee.completed / assignee.total) * 100}%` }}
                          ></div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>

              <Card padding="lg">
                <div className="flex items-center gap-3 mb-6">
                  <IconBox icon={Clock} color="orange" size="md" />
                  <h3 className="font-bold" style={{ color: '#202124' }}>기한 임박</h3>
                </div>
                <div className="space-y-3">
                  {actions.filter(a => a.status !== '완료').slice(0, 3).map((action, idx) => (
                    <div key={idx} className="p-3 rounded-xl border" style={{ backgroundColor: '#FFFBEB', borderColor: '#FED7AA' }}>
                      <h4 className="font-bold mb-1" style={{ color: '#202124' }}>{action.title}</h4>
                      <div className="flex items-center justify-between text-sm">
                        <span style={{ color: '#5F6368' }}>{action.assignee}</span>
                        <span className="font-bold" style={{ color: '#D97706' }}>D-{Math.ceil((new Date(action.dueDate).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>
            </div>
          </div>
        </div>
      </div>

      {/* 조치 등록 모달 */}
      <AnimatePresence>
        {isModalOpen && (
          <motion.div
            className="fixed right-0 top-[72px] h-[calc(100vh-72px)] w-[400px] z-50 shadow-2xl overflow-hidden flex flex-col border-l"
            style={{
              backgroundColor: colors.bgPrimary,
              borderColor: colors.border,
            }}
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ 
              type: 'spring',
              damping: 30,
              stiffness: 300
            }}
          >
            {/* Header */}
            <div
              className="px-8 py-6 border-b flex items-center justify-between flex-shrink-0"
              style={{
                backgroundColor: colors.bgPrimary,
                borderColor: colors.border,
              }}
            >
              <div>
                <h3 className="text-xl font-bold" style={{ color: colors.textPrimary }}>
                  {selectedAction ? '조치 수정' : '조치 등록'}
                </h3>
                <p className="text-sm mt-1" style={{ color: colors.textSecondary }}>
                  {selectedAction ? '기존 조치 정보를 수정합니다' : '새로운 품질 조치를 등록합니다'}
                </p>
              </div>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
                style={{ color: colors.textSecondary }}
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto px-8 py-6">
              <form onSubmit={handleSaveAction} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: colors.textPrimary }}>
                    조치 제목 *
                  </label>
                  <input
                    type="text"
                    name="title"
                    defaultValue={selectedAction?.title}
                    required
                    placeholder="예: 고객명 필수값 누락 데이터 정리"
                    className="w-full px-4 py-2 rounded-lg border"
                    style={{
                      backgroundColor: colors.surface,
                      borderColor: colors.border,
                      color: colors.textPrimary,
                    }}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2" style={{ color: colors.textPrimary }}>
                      위반 ID *
                    </label>
                    <input
                      type="text"
                      name="violationId"
                      defaultValue={selectedAction?.violationId}
                      required
                      placeholder="예: V-2024-0156"
                      className="w-full px-4 py-2 rounded-lg border font-mono"
                      style={{
                        backgroundColor: colors.surface,
                        borderColor: colors.border,
                        color: colors.textPrimary,
                      }}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2" style={{ color: colors.textPrimary }}>
                      테이블명 *
                    </label>
                    <input
                      type="text"
                      name="table"
                      defaultValue={selectedAction?.table}
                      required
                      placeholder="예: CUSTOMER"
                      className="w-full px-4 py-2 rounded-lg border font-mono"
                      style={{
                        backgroundColor: colors.surface,
                        borderColor: colors.border,
                        color: colors.textPrimary,
                      }}
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: colors.textPrimary }}>
                    위반 유형 *
                  </label>
                  <input
                    type="text"
                    name="violation"
                    defaultValue={selectedAction?.violation}
                    required
                    placeholder="예: 필수값 검증 위반"
                    className="w-full px-4 py-2 rounded-lg border"
                    style={{
                      backgroundColor: colors.surface,
                      borderColor: colors.border,
                      color: colors.textPrimary,
                    }}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2" style={{ color: colors.textPrimary }}>
                      우선순위 *
                    </label>
                    <select
                      name="priority"
                      defaultValue={selectedAction?.priority || 'medium'}
                      required
                      className="w-full px-4 py-2 rounded-lg border"
                      style={{
                        backgroundColor: colors.surface,
                        borderColor: colors.border,
                        color: colors.textPrimary,
                      }}
                    >
                      <option value="high">높음</option>
                      <option value="medium">중간</option>
                      <option value="low">낮음</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2" style={{ color: colors.textPrimary }}>
                      상태 *
                    </label>
                    <select
                      name="status"
                      defaultValue={selectedAction?.status || '대기'}
                      required
                      className="w-full px-4 py-2 rounded-lg border"
                      style={{
                        backgroundColor: colors.surface,
                        borderColor: colors.border,
                        color: colors.textPrimary,
                      }}
                    >
                      <option value="대기">대기</option>
                      <option value="진행중">진행중</option>
                      <option value="검토중">검토중</option>
                      <option value="완료">완료</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2" style={{ color: colors.textPrimary }}>
                      담당자 *
                    </label>
                    <input
                      type="text"
                      name="assignee"
                      defaultValue={selectedAction?.assignee}
                      required
                      placeholder="담당자 이름"
                      className="w-full px-4 py-2 rounded-lg border"
                      style={{
                        backgroundColor: colors.surface,
                        borderColor: colors.border,
                        color: colors.textPrimary,
                      }}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2" style={{ color: colors.textPrimary }}>
                      마감일 *
                    </label>
                    <input
                      type="date"
                      name="dueDate"
                      defaultValue={selectedAction?.dueDate}
                      required
                      className="w-full px-4 py-2 rounded-lg border"
                      style={{
                        backgroundColor: colors.surface,
                        borderColor: colors.border,
                        color: colors.textPrimary,
                      }}
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: colors.textPrimary }}>
                    진행률 (%)
                  </label>
                  <input
                    type="number"
                    name="progress"
                    defaultValue={selectedAction?.progress || 0}
                    min="0"
                    max="100"
                    className="w-full px-4 py-2 rounded-lg border"
                    style={{
                      backgroundColor: colors.surface,
                      borderColor: colors.border,
                      color: colors.textPrimary,
                    }}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: colors.textPrimary }}>
                    조치 설명 *
                  </label>
                  <textarea
                    name="description"
                    defaultValue={selectedAction?.description}
                    required
                    rows={5}
                    placeholder="조치 내용에 대한 상세 설명을 입력하세요"
                    className="w-full px-4 py-2 rounded-lg border resize-none"
                    style={{
                      backgroundColor: colors.surface,
                      borderColor: colors.border,
                      color: colors.textPrimary,
                    }}
                  />
                </div>
              </form>
            </div>

            {/* Footer */}
            <div
              className="px-8 py-4 border-t flex items-center justify-end gap-3 flex-shrink-0"
              style={{
                backgroundColor: colors.bgPrimary,
                borderColor: colors.border,
              }}
            >
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="px-4 py-2 rounded-lg font-medium border transition-all duration-200"
                style={{
                  backgroundColor: colors.bgPrimary,
                  borderColor: colors.border,
                  color: colors.textPrimary,
                }}
              >
                취소
              </button>
              <button
                type="submit"
                onClick={(e) => {
                  e.preventDefault();
                  const form = e.currentTarget.closest('div')?.parentElement?.querySelector('form');
                  if (form) {
                    const formEvent = new Event('submit', { bubbles: true, cancelable: true }) as any;
                    Object.defineProperty(formEvent, 'currentTarget', { value: form, writable: false });
                    handleSaveAction(formEvent);
                  }
                }}
                className="px-4 py-2 rounded-lg font-medium transition-all duration-200"
                style={{
                  backgroundColor: '#2B8DFF',
                  color: '#FFFFFF',
                }}
              >
                {selectedAction ? '수정' : '등록'}
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}