import { Card } from '../components/common/Card';
import { Button } from '../components/common/Button';
import { Badge } from '../components/common/Badge';
import { Calendar, Plus, TrendingUp } from 'lucide-react';
import { colors } from '../constants/designSystem';

const evaluations = [
  { id: 1, period: '2024년 1월', type: '월간', score: 92.5, status: 'completed', date: '2024-02-01' },
  { id: 2, period: '2024년 Q1', type: '분기', score: 89.3, status: 'completed', date: '2024-04-01' },
  { id: 3, period: '2024년 2월', type: '월간', score: 0, status: 'scheduled', date: '2024-03-01' },
];

export function QualityEvaluationPage() {
  return (
    <div className="space-y-6 animate-fade-in-up">
      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        <Card>
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-xl" style={{ backgroundColor: colors.successLight }}>
              <TrendingUp className="w-6 h-6" style={{ color: colors.success }} />
            </div>
            <div>
              <p className="text-sm" style={{ color: colors.textSecondary }}>평균 품질 점수</p>
              <p className="text-2xl font-bold" style={{ color: colors.textPrimary }}>91.2</p>
            </div>
          </div>
        </Card>
        <Card>
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-xl" style={{ backgroundColor: colors.primaryLight }}>
              <Calendar className="w-6 h-6" style={{ color: colors.primary }} />
            </div>
            <div>
              <p className="text-sm" style={{ color: colors.textSecondary }}>완료된 평가</p>
              <p className="text-2xl font-bold" style={{ color: colors.textPrimary }}>24</p>
            </div>
          </div>
        </Card>
        <Card>
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-xl" style={{ backgroundColor: colors.warningLight }}>
              <Calendar className="w-6 h-6" style={{ color: colors.warning }} />
            </div>
            <div>
              <p className="text-sm" style={{ color: colors.textSecondary }}>예정된 평가</p>
              <p className="text-2xl font-bold" style={{ color: colors.textPrimary }}>3</p>
            </div>
          </div>
        </Card>
      </div>

      {/* Actions */}
      <Card>
        <div className="flex items-center justify-between">
          <h3 className="font-semibold" style={{ color: colors.textPrimary }}>
            정기 품질 평가 일정
          </h3>
          <Button variant="primary" icon={<Plus className="w-4 h-4" />}>
            평가 일정 등록
          </Button>
        </div>
      </Card>

      {/* Evaluation List */}
      <Card>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b" style={{ borderColor: colors.divider }}>
                <th className="text-left py-3 px-4" style={{ color: colors.textSecondary }}>평가 기간</th>
                <th className="text-center py-3 px-4" style={{ color: colors.textSecondary }}>평가 유형</th>
                <th className="text-center py-3 px-4" style={{ color: colors.textSecondary }}>품질 점수</th>
                <th className="text-center py-3 px-4" style={{ color: colors.textSecondary }}>상태</th>
                <th className="text-left py-3 px-4" style={{ color: colors.textSecondary }}>평가 일자</th>
                <th className="text-center py-3 px-4" style={{ color: colors.textSecondary }}>액션</th>
              </tr>
            </thead>
            <tbody>
              {evaluations.map((evaluation) => (
                <tr 
                  key={evaluation.id} 
                  className="border-b hover:bg-black/[0.02] transition-colors"
                  style={{ borderColor: colors.divider }}
                >
                  <td className="py-3 px-4 font-medium" style={{ color: colors.textPrimary }}>
                    {evaluation.period}
                  </td>
                  <td className="py-3 px-4 text-center">
                    <Badge variant="info">{evaluation.type}</Badge>
                  </td>
                  <td className="py-3 px-4 text-center">
                    {evaluation.status === 'completed' ? (
                      <span className="font-bold text-lg" style={{ color: colors.primary }}>
                        {evaluation.score}
                      </span>
                    ) : (
                      <span style={{ color: colors.textTertiary }}>-</span>
                    )}
                  </td>
                  <td className="py-3 px-4 text-center">
                    <Badge variant={evaluation.status === 'completed' ? 'success' : 'warning'}>
                      {evaluation.status === 'completed' ? '완료' : '예정'}
                    </Badge>
                  </td>
                  <td className="py-3 px-4" style={{ color: colors.textSecondary }}>
                    {evaluation.date}
                  </td>
                  <td className="py-3 px-4 text-center">
                    <Button variant="ghost" size="sm">
                      {evaluation.status === 'completed' ? '결과 보기' : '실행'}
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}