import { Table2, Plus, Search, Filter, Download, Upload, Database, Key, Eye, X } from 'lucide-react';
import { Card } from '../components/common/Card';
import { IconBox } from '../components/common/IconBox';
import { Button } from '../components/common/Button';
import { Badge } from '../components/common/Badge';
import { TreeView } from '../components/common/TreeView';
import { Pagination } from '../components/common/Pagination';
import { useState, useMemo, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useModal } from '../contexts/ModalContext';

export function PhysicalModelPage() {
  const { setIsModalOpen } = useModal();
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);
  const [selectedSubject, setSelectedSubject] = useState<any>(null);
  const [selectedTable, setSelectedTable] = useState<any>(null);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'basic' | 'columns' | 'indexes' | 'preview'>('basic');

  useEffect(() => {
    setIsModalOpen(isDetailModalOpen || isCreateModalOpen);
  }, [isDetailModalOpen, isCreateModalOpen, setIsModalOpen]);

  // 주제 영역 트리 데이터
  const subjectAreas = [
    {
      id: '1',
      label: '전체',
      children: [
        {
          id: '1-1',
          label: '고객 관리',
          children: [
            { id: '1-1-1', label: '고객 기본' },
            { id: '1-1-2', label: '고객 등급' },
          ]
        },
        {
          id: '1-2',
          label: '주문 관리',
          children: [
            { id: '1-2-1', label: '주문 기본' },
            { id: '1-2-2', label: '주문 상세' },
          ]
        },
        {
          id: '1-3',
          label: '상품 관리',
          children: [
            { id: '1-3-1', label: '상품 기본' },
            { id: '1-3-2', label: '상품 재고' },
          ]
        },
        {
          id: '1-4',
          label: '재무 관리',
        },
      ]
    }
  ];

  // 테이블 목록 데이터
  const tables = [
    {
      id: '1',
      subjectArea: '고객 기본',
      physicalName: 'TB_CUSTOMER',
      logicalName: '고객',
      description: '고객 기본 정보를 관리하는 테이블',
      department: '영업팀',
      owner: '김데이터',
      columnCount: 15,
      rowCount: '1,247,532',
      createdDate: '2024-01-15',
    },
    {
      id: '2',
      subjectArea: '주문 기본',
      physicalName: 'TB_ORDER',
      logicalName: '주문',
      description: '주문 정보를 관리하는 테이블',
      department: '영업팀',
      owner: '이주문',
      columnCount: 12,
      rowCount: '3,456,789',
      createdDate: '2024-01-16',
    },
    {
      id: '3',
      subjectArea: '주문 상세',
      physicalName: 'TB_ORDER_DETAIL',
      logicalName: '주문상세',
      description: '주문 상세 정보를 관리하는 테이블',
      department: '영업팀',
      owner: '이주문',
      columnCount: 8,
      rowCount: '8,234,567',
      createdDate: '2024-01-16',
    },
    {
      id: '4',
      subjectArea: '상품 기본',
      physicalName: 'TB_PRODUCT',
      logicalName: '상품',
      description: '상품 기본 정보를 관리하는 테이블',
      department: '상품팀',
      owner: '박상품',
      columnCount: 10,
      rowCount: '45,678',
      createdDate: '2024-01-17',
    },
    {
      id: '5',
      subjectArea: '고객 등급',
      physicalName: 'TB_CUSTOMER_GRADE',
      logicalName: '고객등급',
      description: '고객 등급 정보를 관리하는 테이블',
      department: '영업팀',
      owner: '김데이터',
      columnCount: 6,
      rowCount: '12',
      createdDate: '2024-01-18',
    },
  ];

  // 컬럼 목록 데이터
  const columns = [
    { 
      id: '1', 
      physicalName: 'CUST_NO', 
      logicalName: '고객번호', 
      dataType: 'VARCHAR2', 
      length: '20',
      isPK: true,
      isNull: false,
      defaultValue: '',
      description: '고객을 고유하게 식별하는 번호',
      standardTerm: '고객번호'
    },
    { 
      id: '2', 
      physicalName: 'CUST_NM', 
      logicalName: '고객명', 
      dataType: 'VARCHAR2', 
      length: '100',
      isPK: false,
      isNull: false,
      defaultValue: '',
      description: '고객의 이름',
      standardTerm: '고객명'
    },
    { 
      id: '3', 
      physicalName: 'CUST_GRADE_CD', 
      logicalName: '고객등급코드', 
      dataType: 'VARCHAR2', 
      length: '10',
      isPK: false,
      isNull: true,
      defaultValue: '',
      description: '고객의 등급 코드',
      standardTerm: '고객등급코드'
    },
    { 
      id: '4', 
      physicalName: 'REG_DT', 
      logicalName: '등록일자', 
      dataType: 'DATE', 
      length: '8',
      isPK: false,
      isNull: false,
      defaultValue: 'SYSDATE',
      description: '고객 정보가 등록된 일자',
      standardTerm: '등록일자'
    },
  ];

  const filteredTables = useMemo(() => {
    return tables.filter(table =>
      table.physicalName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      table.logicalName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      table.description.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [searchTerm]);

  const paginatedTables = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage;
    return filteredTables.slice(start, start + itemsPerPage);
  }, [filteredTables, currentPage, itemsPerPage]);

  const handleTableClick = (table: any) => {
    setSelectedTable(table);
    setIsDetailModalOpen(true);
    setActiveTab('basic');
  };

  return (
    <div className="space-y-6">
      {/* 상단 통계 */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card padding="lg" hover>
          <IconBox icon={Table2} color="blue" size="md" />
          <div className="mt-3">
            <p className="mb-1" style={{ color: '#5F6368' }}>전체 테이블</p>
            <h3 className="text-2xl font-bold" style={{ color: '#202124' }}>1,247</h3>
          </div>
        </Card>
        <Card padding="lg" hover>
          <IconBox icon={Database} color="green" size="md" />
          <div className="mt-3">
            <p className="mb-1" style={{ color: '#5F6368' }}>전체 컬럼</p>
            <h3 className="text-2xl font-bold" style={{ color: '#202124' }}>18,543</h3>
          </div>
        </Card>
        <Card padding="lg" hover>
          <IconBox icon={Key} color="orange" size="md" />
          <div className="mt-3">
            <p className="mb-1" style={{ color: '#5F6368' }}>표준 매핑율</p>
            <h3 className="text-2xl font-bold" style={{ color: '#202124' }}>87.5%</h3>
          </div>
        </Card>
        <Card padding="lg" hover>
          <IconBox icon={Table2} color="purple" size="md" />
          <div className="mt-3">
            <p className="mb-1" style={{ color: '#5F6368' }}>주제 영역</p>
            <h3 className="text-2xl font-bold" style={{ color: '#202124' }}>24</h3>
          </div>
        </Card>
      </div>

      {/* 메인 영역: 좌측 트리 + 우측 테이블 목록 */}
      <div className="grid grid-cols-12 gap-6">
        {/* 좌측: 주제 영역 트리 */}
        <div className="col-span-3">
          <Card padding="lg">
            <div className="mb-4">
              <h3 className="font-bold" style={{ color: '#202124' }}>주제 영역</h3>
            </div>
            <TreeView 
              data={subjectAreas} 
              onSelect={(node) => setSelectedSubject(node)}
              selectedId={selectedSubject?.id}
            />
          </Card>
        </div>

        {/* 우측: 테이블 목록 */}
        <div className="col-span-9">
          <Card padding="lg">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <IconBox icon={Table2} color="blue" size="md" />
                <h3 className="font-bold" style={{ color: '#202124' }}>
                  테이블 목록 {selectedSubject && `- ${selectedSubject.label}`}
                </h3>
              </div>
              <div className="flex items-center gap-2">
                <div className="relative">
                  <Search 
                    className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4" 
                    style={{ color: '#9CA3AF' }}
                  />
                  <input
                    type="text"
                    placeholder="테이블 검색..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 pr-4 py-2 rounded-lg border text-sm"
                    style={{ backgroundColor: '#F9F9F9', borderColor: '#DADCE0', color: '#202124', width: '250px' }}
                  />
                </div>
                <Button variant="ghost" icon={<Filter className="w-4 h-4" />} size="sm">필터</Button>
                <Button variant="ghost" icon={<Download className="w-4 h-4" />} size="sm">내보내기</Button>
                <Button variant="primary" icon={<Plus className="w-4 h-4" />} size="sm" onClick={() => setIsCreateModalOpen(true)}>테이블 추가</Button>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full">
                <thead style={{ backgroundColor: '#F7F8FA' }}>
                  <tr style={{ borderBottom: '1px solid #DADCE0' }}>
                    <th className="px-4 py-3 text-left text-sm" style={{ color: '#5F6368' }}>주제영역</th>
                    <th className="px-4 py-3 text-left text-sm" style={{ color: '#5F6368' }}>물리테이블명</th>
                    <th className="px-4 py-3 text-left text-sm" style={{ color: '#5F6368' }}>논리테이블명</th>
                    <th className="px-4 py-3 text-left text-sm" style={{ color: '#5F6368' }}>설명</th>
                    <th className="px-4 py-3 text-left text-sm" style={{ color: '#5F6368' }}>컬럼수</th>
                    <th className="px-4 py-3 text-left text-sm" style={{ color: '#5F6368' }}>관리부서</th>
                    <th className="px-4 py-3 text-left text-sm" style={{ color: '#5F6368' }}>오너</th>
                  </tr>
                </thead>
                <tbody>
                  {paginatedTables.map((table, idx) => (
                    <tr
                      key={table.id}
                      className="cursor-pointer transition-colors"
                      style={{ borderBottom: idx < paginatedTables.length - 1 ? '1px solid #E8EAED' : 'none' }}
                      onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#F7F8FA'}
                      onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
                      onClick={() => handleTableClick(table)}
                    >
                      <td className="px-4 py-4">
                        <Badge variant="default">{table.subjectArea}</Badge>
                      </td>
                      <td className="px-4 py-4">
                        <div className="flex items-center gap-2">
                          <Database className="w-4 h-4" style={{ color: '#2B8DFF' }} />
                          <span className="font-medium font-mono" style={{ color: '#202124' }}>{table.physicalName}</span>
                        </div>
                      </td>
                      <td className="px-4 py-4">
                        <span className="font-medium" style={{ color: '#202124' }}>{table.logicalName}</span>
                      </td>
                      <td className="px-4 py-4">
                        <span className="text-sm" style={{ color: '#5F6368' }}>{table.description}</span>
                      </td>
                      <td className="px-4 py-4">
                        <Badge variant="info">{table.columnCount}개</Badge>
                      </td>
                      <td className="px-4 py-4">
                        <span style={{ color: '#5F6368' }}>{table.department}</span>
                      </td>
                      <td className="px-4 py-4">
                        <span style={{ color: '#5F6368' }}>{table.owner}</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <Pagination
              totalItems={filteredTables.length}
              itemsPerPage={itemsPerPage}
              currentPage={currentPage}
              totalPages={Math.ceil(filteredTables.length / itemsPerPage)}
              onPageChange={setCurrentPage}
              onItemsPerPageChange={setItemsPerPage}
            />
          </Card>
        </div>
      </div>

      {/* 상세 모달 (탭 구성) */}
      <AnimatePresence>
        {isDetailModalOpen && selectedTable && (
          <motion.div
            className="fixed right-0 top-0 h-screen w-[400px] z-50 shadow-2xl overflow-hidden flex flex-col border-l"
            style={{ backgroundColor: '#FFFFFF', borderColor: '#DADCE0' }}
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 30, stiffness: 300 }}
          >
            {/* Header */}
            <div className="px-8 py-6 border-b flex items-center justify-between" style={{ borderColor: '#DADCE0' }}>
              <div>
                <h3 className="text-xl font-bold font-mono" style={{ color: '#202124' }}>{selectedTable.physicalName}</h3>
                <p className="text-sm mt-1" style={{ color: '#5F6368' }}>{selectedTable.logicalName}</p>
              </div>
              <button
                onClick={() => setIsDetailModalOpen(false)}
                className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
                style={{ color: '#5F6368' }}
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* Tabs */}
            <div className="border-b" style={{ borderColor: '#DADCE0' }}>
              <div className="flex px-8">
                {[
                  { id: 'basic', label: '기본정보' },
                  { id: 'columns', label: '컬럼목록' },
                  { id: 'indexes', label: '인덱스' },
                  { id: 'preview', label: '데이터 미리보기' },
                ].map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id as any)}
                    className="px-4 py-3 text-sm font-medium border-b-2 transition-colors"
                    style={{
                      borderColor: activeTab === tab.id ? '#2B8DFF' : 'transparent',
                      color: activeTab === tab.id ? '#2B8DFF' : '#5F6368',
                    }}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto px-8 py-6">
              {activeTab === 'basic' && (
                <div className="space-y-6">
                  <Card padding="lg">
                    <h4 className="font-bold mb-4" style={{ color: '#202124' }}>테이블 정보</h4>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-sm" style={{ color: '#5F6368' }}>주제영역:</span>
                        <Badge variant="default">{selectedTable.subjectArea}</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm" style={{ color: '#5F6368' }}>설명:</span>
                        <span className="text-sm font-medium" style={{ color: '#202124' }}>{selectedTable.description}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm" style={{ color: '#5F6368' }}>컬럼 수:</span>
                        <Badge variant="info">{selectedTable.columnCount}개</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm" style={{ color: '#5F6368' }}>데이터 건수:</span>
                        <span className="text-sm font-bold" style={{ color: '#2B8DFF' }}>{selectedTable.rowCount}건</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm" style={{ color: '#5F6368' }}>관리부서:</span>
                        <span className="text-sm" style={{ color: '#202124' }}>{selectedTable.department}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm" style={{ color: '#5F6368' }}>담당자:</span>
                        <span className="text-sm" style={{ color: '#202124' }}>{selectedTable.owner}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm" style={{ color: '#5F6368' }}>생성일:</span>
                        <span className="text-sm" style={{ color: '#202124' }}>{selectedTable.createdDate}</span>
                      </div>
                    </div>
                  </Card>
                </div>
              )}

              {activeTab === 'columns' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h4 className="font-bold" style={{ color: '#202124' }}>컬럼 목록</h4>
                    <Button variant="outline" size="sm">표준 용어 매핑</Button>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead style={{ backgroundColor: '#F7F8FA' }}>
                        <tr style={{ borderBottom: '1px solid #DADCE0' }}>
                          <th className="px-3 py-2 text-left text-xs" style={{ color: '#5F6368' }}>물리명</th>
                          <th className="px-3 py-2 text-left text-xs" style={{ color: '#5F6368' }}>논리명</th>
                          <th className="px-3 py-2 text-left text-xs" style={{ color: '#5F6368' }}>타입</th>
                          <th className="px-3 py-2 text-left text-xs" style={{ color: '#5F6368' }}>길이</th>
                          <th className="px-3 py-2 text-center text-xs" style={{ color: '#5F6368' }}>PK</th>
                          <th className="px-3 py-2 text-center text-xs" style={{ color: '#5F6368' }}>Null</th>
                          <th className="px-3 py-2 text-left text-xs" style={{ color: '#5F6368' }}>표준용어</th>
                        </tr>
                      </thead>
                      <tbody>
                        {columns.map((column, idx) => (
                          <tr
                            key={column.id}
                            style={{ borderBottom: idx < columns.length - 1 ? '1px solid #E8EAED' : 'none' }}
                          >
                            <td className="px-3 py-3">
                              <span className="text-xs font-mono font-medium" style={{ color: '#202124' }}>
                                {column.physicalName}
                              </span>
                            </td>
                            <td className="px-3 py-3">
                              <span className="text-xs" style={{ color: '#202124' }}>{column.logicalName}</span>
                            </td>
                            <td className="px-3 py-3">
                              <Badge variant="default" size="sm">{column.dataType}</Badge>
                            </td>
                            <td className="px-3 py-3">
                              <span className="text-xs" style={{ color: '#5F6368' }}>{column.length}</span>
                            </td>
                            <td className="px-3 py-3 text-center">
                              {column.isPK && <Key className="w-3.5 h-3.5 mx-auto" style={{ color: '#F59E0B' }} />}
                            </td>
                            <td className="px-3 py-3 text-center">
                              <span className="text-xs" style={{ color: column.isNull ? '#10B981' : '#EF4444' }}>
                                {column.isNull ? 'Y' : 'N'}
                              </span>
                            </td>
                            <td className="px-3 py-3">
                              <Badge variant="info" size="sm">{column.standardTerm}</Badge>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {activeTab === 'indexes' && (
                <div className="space-y-4">
                  <h4 className="font-bold" style={{ color: '#202124' }}>인덱스 목록</h4>
                  <div className="p-8 text-center" style={{ color: '#9CA3AF' }}>
                    <Key className="w-12 h-12 mx-auto mb-3 opacity-30" />
                    <p>인덱스 정보가 없습니다</p>
                  </div>
                </div>
              )}

              {activeTab === 'preview' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h4 className="font-bold" style={{ color: '#202124' }}>데이터 미리보기 (최근 10건)</h4>
                    <Button variant="outline" size="sm" icon={<Eye className="w-4 h-4" />}>새로고침</Button>
                  </div>
                  <div className="p-8 text-center" style={{ color: '#9CA3AF' }}>
                    <Database className="w-12 h-12 mx-auto mb-3 opacity-30" />
                    <p>데이터 미리보기는 개발 중입니다</p>
                  </div>
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="px-8 py-4 border-t flex items-center justify-end gap-3" style={{ borderColor: '#DADCE0' }}>
              <Button variant="ghost" onClick={() => setIsDetailModalOpen(false)}>닫기</Button>
              <Button variant="outline">수정</Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 테이블 생성 모달 */}
      <AnimatePresence>
        {isCreateModalOpen && (
          <motion.div
            className="fixed right-0 top-0 h-screen w-[400px] z-50 shadow-2xl overflow-hidden flex flex-col border-l"
            style={{ backgroundColor: '#FFFFFF', borderColor: '#DADCE0' }}
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 30, stiffness: 300 }}
          >
            {/* Header */}
            <div className="px-8 py-6 border-b flex items-center justify-between" style={{ borderColor: '#DADCE0' }}>
              <div>
                <h3 className="text-xl font-bold font-mono" style={{ color: '#202124' }}>테이블 생성</h3>
              </div>
              <button
                onClick={() => setIsCreateModalOpen(false)}
                className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
                style={{ color: '#5F6368' }}
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto px-8 py-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold" style={{ color: '#202124' }}>테이블 정보 입력</h4>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <IconBox icon={Table2} color="blue" size="md" />
                    <h5 className="font-bold" style={{ color: '#202124' }}>주제영역</h5>
                  </div>
                  <select
                    className="w-full px-4 py-2 rounded-lg border text-sm"
                    style={{ backgroundColor: '#F9F9F9', borderColor: '#DADCE0', color: '#202124' }}
                  >
                    <option value="">주제영역 선택</option>
                    {subjectAreas[0].children.map((subject) => (
                      <option key={subject.id} value={subject.id}>{subject.label}</option>
                    ))}
                  </select>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <IconBox icon={Database} color="blue" size="md" />
                    <h5 className="font-bold" style={{ color: '#202124' }}>물리테이블명</h5>
                  </div>
                  <input
                    type="text"
                    placeholder="물리테이블명 입력..."
                    className="w-full px-4 py-2 rounded-lg border text-sm"
                    style={{ backgroundColor: '#F9F9F9', borderColor: '#DADCE0', color: '#202124' }}
                  />
                </div>
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <IconBox icon={Database} color="blue" size="md" />
                    <h5 className="font-bold" style={{ color: '#202124' }}>논리테이블명</h5>
                  </div>
                  <input
                    type="text"
                    placeholder="논리테이블명 입력..."
                    className="w-full px-4 py-2 rounded-lg border text-sm"
                    style={{ backgroundColor: '#F9F9F9', borderColor: '#DADCE0', color: '#202124' }}
                  />
                </div>
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <IconBox icon={Database} color="blue" size="md" />
                    <h5 className="font-bold" style={{ color: '#202124' }}>설명</h5>
                  </div>
                  <textarea
                    placeholder="테이블 설명 입력..."
                    className="w-full px-4 py-2 rounded-lg border text-sm"
                    style={{ backgroundColor: '#F9F9F9', borderColor: '#DADCE0', color: '#202124' }}
                  />
                </div>
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <IconBox icon={Database} color="blue" size="md" />
                    <h5 className="font-bold" style={{ color: '#202124' }}>관리부서</h5>
                  </div>
                  <input
                    type="text"
                    placeholder="관리부서 입력..."
                    className="w-full px-4 py-2 rounded-lg border text-sm"
                    style={{ backgroundColor: '#F9F9F9', borderColor: '#DADCE0', color: '#202124' }}
                  />
                </div>
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <IconBox icon={Database} color="blue" size="md" />
                    <h5 className="font-bold" style={{ color: '#202124' }}>담당자</h5>
                  </div>
                  <input
                    type="text"
                    placeholder="담당자 입력..."
                    className="w-full px-4 py-2 rounded-lg border text-sm"
                    style={{ backgroundColor: '#F9F9F9', borderColor: '#DADCE0', color: '#202124' }}
                  />
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="px-8 py-4 border-t flex items-center justify-end gap-3" style={{ borderColor: '#DADCE0' }}>
              <Button variant="ghost" onClick={() => setIsCreateModalOpen(false)}>닫기</Button>
              <Button variant="primary">생성</Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}