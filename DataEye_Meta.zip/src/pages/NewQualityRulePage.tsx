import { ShieldAlert, Plus, Search, Filter, Download, X, Code, Zap, BarChart3, TrendingUp } from 'lucide-react';
import { Card } from '../components/common/Card';
import { IconBox } from '../components/common/IconBox';
import { Button } from '../components/common/Button';
import { Badge } from '../components/common/Badge';
import { Pagination } from '../components/common/Pagination';
import { useState, useMemo, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { LineChart, Line, ResponsiveContainer, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { useModal } from '../contexts/ModalContext';

export function NewQualityRulePage() {
  const { setIsModalOpen } = useModal();
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [selectedRule, setSelectedRule] = useState<any>(null);
  const [ruleType, setRuleType] = useState<'sql' | 'pattern' | 'range'>('sql');

  useEffect(() => {
    setIsModalOpen(isCreateModalOpen || isDetailModalOpen);
  }, [isCreateModalOpen, isDetailModalOpen, setIsModalOpen]);

  // 품질 규칙 데이터
  const rules = [
    {
      id: 'QR-001',
      ruleName: '필수값 검증',
      targetTable: 'TB_CUSTOMER',
      targetColumn: 'CUST_NM',
      qualityDimension: '완전성',
      ruleType: 'pattern',
      weight: 10,
      threshold: 5,
      isActive: true,
      lastRun: '2024-11-27 09:00',
      score: 98.5,
      errorCount: 15,
      history: [
        { date: '11/20', score: 97.2 },
        { date: '11/21', score: 97.8 },
        { date: '11/22', score: 98.1 },
        { date: '11/23', score: 98.3 },
        { date: '11/24', score: 98.2 },
        { date: '11/25', score: 98.4 },
        { date: '11/26', score: 98.5 },
      ]
    },
    {
      id: 'QR-002',
      ruleName: '날짜 형식 검증',
      targetTable: 'TB_ORDER',
      targetColumn: 'ORD_DT',
      qualityDimension: '유효성',
      ruleType: 'pattern',
      weight: 8,
      threshold: 3,
      isActive: true,
      lastRun: '2024-11-27 08:30',
      score: 99.2,
      errorCount: 8,
      history: [
        { date: '11/20', score: 98.9 },
        { date: '11/21', score: 99.0 },
        { date: '11/22', score: 99.1 },
        { date: '11/23', score: 99.1 },
        { date: '11/24', score: 99.2 },
        { date: '11/25', score: 99.2 },
        { date: '11/26', score: 99.2 },
      ]
    },
    {
      id: 'QR-003',
      ruleName: '금액 범위 체크',
      targetTable: 'TB_ORDER',
      targetColumn: 'ORD_AMT',
      qualityDimension: '정확성',
      ruleType: 'range',
      weight: 7,
      threshold: 10,
      isActive: true,
      lastRun: '2024-11-27 08:00',
      score: 96.8,
      errorCount: 32,
      history: [
        { date: '11/20', score: 95.5 },
        { date: '11/21', score: 96.0 },
        { date: '11/22', score: 96.2 },
        { date: '11/23', score: 96.5 },
        { date: '11/24', score: 96.6 },
        { date: '11/25', score: 96.7 },
        { date: '11/26', score: 96.8 },
      ]
    },
    {
      id: 'QR-004',
      ruleName: '참조 무결성 체크',
      targetTable: 'TB_ORDER',
      targetColumn: 'CUST_NO',
      qualityDimension: '일관성',
      ruleType: 'sql',
      weight: 9,
      threshold: 0,
      isActive: true,
      lastRun: '2024-11-27 07:30',
      score: 100.0,
      errorCount: 0,
      history: [
        { date: '11/20', score: 100.0 },
        { date: '11/21', score: 100.0 },
        { date: '11/22', score: 100.0 },
        { date: '11/23', score: 100.0 },
        { date: '11/24', score: 100.0 },
        { date: '11/25', score: 100.0 },
        { date: '11/26', score: 100.0 },
      ]
    },
  ];

  const filteredRules = useMemo(() => {
    return rules.filter(rule =>
      rule.ruleName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      rule.targetTable.toLowerCase().includes(searchTerm.toLowerCase()) ||
      rule.targetColumn.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [searchTerm]);

  const paginatedRules = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage;
    return filteredRules.slice(start, start + itemsPerPage);
  }, [filteredRules, currentPage, itemsPerPage]);

  const getQualityColor = (dimension: string) => {
    const colors: Record<string, string> = {
      '완전성': '#2B8DFF',
      '유효성': '#10B981',
      '정확성': '#F59E0B',
      '일관성': '#8B5CF6',
      '적시성': '#EC4899',
    };
    return colors[dimension] || '#6B7280';
  };

  const getScoreColor = (score: number) => {
    if (score >= 95) return '#10B981';
    if (score >= 85) return '#F59E0B';
    return '#EF4444';
  };

  return (
    <div className="space-y-4 p-0">
      <div className="flex-1 overflow-auto">
        <div className="space-y-6 p-0">
          {/* 상단 통계 */}
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            <Card padding="lg" hover>
              <IconBox icon={ShieldAlert} color="blue" size="md" />
              <div className="mt-3">
                <p className="mb-1" style={{ color: '#5F6368' }}>전체 규칙</p>
                <h3 className="text-2xl font-bold" style={{ color: '#202124' }}>127</h3>
              </div>
            </Card>
            <Card padding="lg" hover>
              <IconBox icon={ShieldAlert} color="green" size="md" />
              <div className="mt-3">
                <p className="mb-1" style={{ color: '#5F6368' }}>활성 규칙</p>
                <h3 className="text-2xl font-bold" style={{ color: '#202124' }}>98</h3>
              </div>
            </Card>
            <Card padding="lg" hover>
              <IconBox icon={TrendingUp} color="purple" size="md" />
              <div className="mt-3">
                <p className="mb-1" style={{ color: '#5F6368' }}>평균 점수</p>
                <h3 className="text-2xl font-bold" style={{ color: '#202124' }}>92.8</h3>
              </div>
            </Card>
            <Card padding="lg" hover>
              <IconBox icon={ShieldAlert} color="orange" size="md" />
              <div className="mt-3">
                <p className="mb-1" style={{ color: '#5F6368' }}>위반 건수</p>
                <h3 className="text-2xl font-bold" style={{ color: '#202124' }}>156</h3>
              </div>
            </Card>
            <Card padding="lg" hover>
              <IconBox icon={ShieldAlert} color="red" size="md" />
              <div className="mt-3">
                <p className="mb-1" style={{ color: '#5F6368' }}>비활성 규칙</p>
                <h3 className="text-2xl font-bold" style={{ color: '#202124' }}>29</h3>
              </div>
            </Card>
          </div>

          {/* 메인 테이블 */}
          <Card padding="lg">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <IconBox icon={ShieldAlert} color="blue" size="md" />
                <h3 className="font-bold" style={{ color: '#202124' }}>품질 지표(Rule) 목록</h3>
              </div>
              <div className="flex items-center gap-2">
                <div className="relative">
                  <Search 
                    className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4" 
                    style={{ color: '#9CA3AF' }}
                  />
                  <input
                    type="text"
                    placeholder="규칙명, 테이블, 컬럼 검색..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 pr-4 py-2 rounded-lg border text-sm"
                    style={{ backgroundColor: '#F9F9F9', borderColor: '#DADCE0', color: '#202124', width: '300px' }}
                  />
                </div>
                <Button variant="ghost" icon={<Filter className="w-4 h-4" />} size="sm">필터</Button>
                <Button variant="ghost" icon={<Download className="w-4 h-4" />} size="sm">내보내기</Button>
                <Button 
                  variant="primary" 
                  icon={<Plus className="w-4 h-4" />} 
                  size="sm"
                  onClick={() => setIsCreateModalOpen(true)}
                >
                  규칙 등록
                </Button>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full">
                <thead style={{ backgroundColor: '#F7F8FA' }}>
                  <tr style={{ borderBottom: '1px solid #DADCE0' }}>
                    <th className="px-4 py-3 text-left text-sm" style={{ color: '#5F6368' }}>규칙명</th>
                    <th className="px-4 py-3 text-left text-sm" style={{ color: '#5F6368' }}>대상 테이블</th>
                    <th className="px-4 py-3 text-left text-sm" style={{ color: '#5F6368' }}>대상 컬럼</th>
                    <th className="px-4 py-3 text-left text-sm" style={{ color: '#5F6368' }}>품질지표</th>
                    <th className="px-4 py-3 text-center text-sm" style={{ color: '#5F6368' }}>가중치</th>
                    <th className="px-4 py-3 text-center text-sm" style={{ color: '#5F6368' }}>점수</th>
                    <th className="px-4 py-3 text-center text-sm" style={{ color: '#5F6368' }}>위반</th>
                    <th className="px-4 py-3 text-center text-sm" style={{ color: '#5F6368' }}>사용여부</th>
                  </tr>
                </thead>
                <tbody>
                  {paginatedRules.map((rule, idx) => (
                    <tr
                      key={rule.id}
                      className="cursor-pointer transition-colors"
                      style={{ borderBottom: idx < paginatedRules.length - 1 ? '1px solid #E8EAED' : 'none' }}
                      onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#F7F8FA'}
                      onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
                      onClick={() => {
                        setSelectedRule(rule);
                        setIsDetailModalOpen(true);
                      }}
                    >
                      <td className="px-4 py-4">
                        <div className="flex items-center gap-2">
                          <IconBox 
                            icon={rule.ruleType === 'sql' ? Code : rule.ruleType === 'pattern' ? Zap : BarChart3} 
                            color="blue" 
                            size="sm" 
                          />
                          <span className="font-medium" style={{ color: '#202124' }}>{rule.ruleName}</span>
                        </div>
                      </td>
                      <td className="px-4 py-4">
                        <span className="font-mono text-sm" style={{ color: '#5F6368' }}>{rule.targetTable}</span>
                      </td>
                      <td className="px-4 py-4">
                        <span className="font-mono text-sm" style={{ color: '#5F6368' }}>{rule.targetColumn}</span>
                      </td>
                      <td className="px-4 py-4">
                        <Badge 
                          variant="default"
                          style={{ 
                            backgroundColor: `${getQualityColor(rule.qualityDimension)}20`,
                            color: getQualityColor(rule.qualityDimension)
                          }}
                        >
                          {rule.qualityDimension}
                        </Badge>
                      </td>
                      <td className="px-4 py-4 text-center">
                        <span className="font-medium" style={{ color: '#202124' }}>{rule.weight}</span>
                      </td>
                      <td className="px-4 py-4 text-center">
                        <span 
                          className="font-bold"
                          style={{ color: getScoreColor(rule.score) }}
                        >
                          {rule.score}
                        </span>
                      </td>
                      <td className="px-4 py-4 text-center">
                        <Badge variant={rule.errorCount > rule.threshold ? 'error' : 'success'}>
                          {rule.errorCount}건
                        </Badge>
                      </td>
                      <td className="px-4 py-4 text-center">
                        <Badge variant={rule.isActive ? 'success' : 'default'}>
                          {rule.isActive ? '활성' : '비활성'}
                        </Badge>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <Pagination
              totalItems={filteredRules.length}
              itemsPerPage={itemsPerPage}
              currentPage={currentPage}
              totalPages={Math.ceil(filteredRules.length / itemsPerPage)}
              onPageChange={setCurrentPage}
              onItemsPerPageChange={setItemsPerPage}
            />
          </Card>
        </div>
      </div>

      {/* 등록 모달 */}
      <AnimatePresence>
        {isCreateModalOpen && (
          <motion.div
            className="fixed right-0 top-0 h-screen w-[400px] z-50 shadow-2xl overflow-hidden flex flex-col border-l"
            style={{ backgroundColor: '#FFFFFF', borderColor: '#DADCE0' }}
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 30, stiffness: 300 }}
          >
            {/* Header */}
            <div className="px-8 py-6 border-b flex items-center justify-between" style={{ borderColor: '#DADCE0' }}>
              <div>
                <h3 className="text-xl font-bold" style={{ color: '#202124' }}>품질 규칙 등록</h3>
                <p className="text-sm mt-1" style={{ color: '#5F6368' }}>데이터 품질을 체크할 규칙을 정의합니다</p>
              </div>
              <button
                onClick={() => setIsCreateModalOpen(false)}
                className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
                style={{ color: '#5F6368' }}
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto px-8 py-6">
              <div className="space-y-6">
                {/* 규칙 유형 선택 (핵심) */}
                <Card padding="lg">
                  <h4 className="font-bold mb-4" style={{ color: '#202124' }}>규칙 유형 선택 *</h4>
                  <div className="grid grid-cols-3 gap-3">
                    {[
                      { id: 'sql', label: 'SQL 직접 입력', icon: Code, desc: '사용자 정의 SQL' },
                      { id: 'pattern', label: '패턴 매칭', icon: Zap, desc: '정규식, 형식 체크' },
                      { id: 'range', label: '범위 체크', icon: BarChart3, desc: 'Min~Max 값 체크' },
                    ].map((type) => (
                      <button
                        key={type.id}
                        onClick={() => setRuleType(type.id as any)}
                        className="p-4 rounded-lg border-2 text-left transition-all hover:shadow-md"
                        style={{
                          borderColor: ruleType === type.id ? '#2B8DFF' : '#DADCE0',
                          backgroundColor: ruleType === type.id ? '#E8F4FF' : '#FFFFFF',
                        }}
                      >
                        <type.icon 
                          className="w-6 h-6 mb-2" 
                          style={{ color: ruleType === type.id ? '#2B8DFF' : '#5F6368' }}
                        />
                        <p className="font-medium text-sm mb-1" style={{ color: '#202124' }}>{type.label}</p>
                        <p className="text-xs" style={{ color: '#5F6368' }}>{type.desc}</p>
                      </button>
                    ))}
                  </div>
                </Card>

                {/* 기본 정보 */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2" style={{ color: '#202124' }}>
                      규칙명 *
                    </label>
                    <input
                      type="text"
                      placeholder="예: 필수값 검증"
                      className="w-full px-4 py-2 rounded-lg border"
                      style={{ backgroundColor: '#F9F9F9', borderColor: '#DADCE0', color: '#202124' }}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2" style={{ color: '#202124' }}>
                      품질지표 *
                    </label>
                    <select
                      className="w-full px-4 py-2 rounded-lg border"
                      style={{ backgroundColor: '#F9F9F9', borderColor: '#DADCE0', color: '#202124' }}
                    >
                      <option value="">선택하세요</option>
                      <option value="완전성">완전성 (Completeness)</option>
                      <option value="유효성">유효성 (Validity)</option>
                      <option value="정확성">정확성 (Accuracy)</option>
                      <option value="일관성">일관성 (Consistency)</option>
                      <option value="적시성">적시성 (Timeliness)</option>
                    </select>
                  </div>
                </div>

                {/* 대상 선택 */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2" style={{ color: '#202124' }}>
                      대상 테이블 *
                    </label>
                    <input
                      type="text"
                      placeholder="TB_CUSTOMER"
                      className="w-full px-4 py-2 rounded-lg border font-mono"
                      style={{ backgroundColor: '#F9F9F9', borderColor: '#DADCE0', color: '#202124' }}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2" style={{ color: '#202124' }}>
                      대상 컬럼 *
                    </label>
                    <input
                      type="text"
                      placeholder="CUST_NM"
                      className="w-full px-4 py-2 rounded-lg border font-mono"
                      style={{ backgroundColor: '#F9F9F9', borderColor: '#DADCE0', color: '#202124' }}
                    />
                  </div>
                </div>

                {/* 규칙 정의 (타입별로 다름) */}
                {ruleType === 'sql' && (
                  <div>
                    <label className="block text-sm font-medium mb-2" style={{ color: '#202124' }}>
                      SQL 쿼리 *
                    </label>
                    <textarea
                      rows={6}
                      placeholder="SELECT COUNT(*) FROM TB_CUSTOMER WHERE CUST_NO IS NULL"
                      className="w-full px-4 py-2 rounded-lg border font-mono text-sm resize-none"
                      style={{ backgroundColor: '#F9F9F9', borderColor: '#DADCE0', color: '#202124' }}
                    />
                  </div>
                )}

                {ruleType === 'pattern' && (
                  <div>
                    <label className="block text-sm font-medium mb-2" style={{ color: '#202124' }}>
                      패턴 (정규식) *
                    </label>
                    <input
                      type="text"
                      placeholder="^[0-9]{4}-[0-9]{2}-[0-9]{2}$"
                      className="w-full px-4 py-2 rounded-lg border font-mono"
                      style={{ backgroundColor: '#F9F9F9', borderColor: '#DADCE0', color: '#202124' }}
                    />
                    <p className="text-xs mt-2" style={{ color: '#5F6368' }}>
                      예: 날짜 형식 (YYYY-MM-DD), 이메일, 전화번호 등
                    </p>
                  </div>
                )}

                {ruleType === 'range' && (
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-2" style={{ color: '#202124' }}>
                        최소값 (Min)
                      </label>
                      <input
                        type="number"
                        placeholder="0"
                        className="w-full px-4 py-2 rounded-lg border"
                        style={{ backgroundColor: '#F9F9F9', borderColor: '#DADCE0', color: '#202124' }}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2" style={{ color: '#202124' }}>
                        최대값 (Max)
                      </label>
                      <input
                        type="number"
                        placeholder="1000000"
                        className="w-full px-4 py-2 rounded-lg border"
                        style={{ backgroundColor: '#F9F9F9', borderColor: '#DADCE0', color: '#202124' }}
                      />
                    </div>
                  </div>
                )}

                {/* 임계치 설정 */}
                <Card padding="lg">
                  <h4 className="font-bold mb-4" style={{ color: '#202124' }}>임계치 설정 *</h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-2" style={{ color: '#202124' }}>
                        오류율 (%)
                      </label>
                      <input
                        type="number"
                        placeholder="5"
                        className="w-full px-4 py-2 rounded-lg border"
                        style={{ backgroundColor: '#F9F9F9', borderColor: '#DADCE0', color: '#202124' }}
                      />
                      <p className="text-xs mt-2" style={{ color: '#5F6368' }}>
                        이 값 이상이면 'Red' 경고
                      </p>
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2" style={{ color: '#202124' }}>
                        가중치
                      </label>
                      <input
                        type="number"
                        placeholder="10"
                        className="w-full px-4 py-2 rounded-lg border"
                        style={{ backgroundColor: '#F9F9F9', borderColor: '#DADCE0', color: '#202124' }}
                      />
                      <p className="text-xs mt-2" style={{ color: '#5F6368' }}>
                        전체 점수 계산 시 반영 비율
                      </p>
                    </div>
                  </div>
                </Card>
              </div>
            </div>

            {/* Footer */}
            <div className="px-8 py-4 border-t flex items-center justify-end gap-3" style={{ borderColor: '#DADCE0' }}>
              <Button variant="ghost" onClick={() => setIsCreateModalOpen(false)}>취소</Button>
              <Button variant="primary">등록</Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 상세 모달 (품질 진단 이력 차트 포함) */}
      <AnimatePresence>
        {isDetailModalOpen && selectedRule && (
          <motion.div
            className="fixed right-0 top-0 h-screen w-[400px] z-50 shadow-2xl overflow-hidden flex flex-col border-l"
            style={{ backgroundColor: '#FFFFFF', borderColor: '#DADCE0' }}
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 30, stiffness: 300 }}
          >
            {/* Header */}
            <div className="px-8 py-6 border-b flex items-center justify-between" style={{ borderColor: '#DADCE0' }}>
              <div>
                <h3 className="text-xl font-bold" style={{ color: '#202124' }}>{selectedRule.ruleName}</h3>
                <p className="text-sm mt-1" style={{ color: '#5F6368' }}>
                  {selectedRule.targetTable}.{selectedRule.targetColumn}
                </p>
              </div>
              <button
                onClick={() => setIsDetailModalOpen(false)}
                className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
                style={{ color: '#5F6368' }}
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto px-8 py-6">
              <div className="space-y-6">
                {/* 현재 상태 */}
                <Card padding="lg">
                  <h4 className="font-bold mb-4" style={{ color: '#202124' }}>현재 상태</h4>
                  <div className="grid grid-cols-3 gap-4">
                    <div className="text-center p-4 rounded-lg" style={{ backgroundColor: '#F7F8FA' }}>
                      <p className="text-sm mb-1" style={{ color: '#5F6368' }}>품질 점수</p>
                      <p 
                        className="text-2xl font-bold"
                        style={{ color: getScoreColor(selectedRule.score) }}
                      >
                        {selectedRule.score}
                      </p>
                    </div>
                    <div className="text-center p-4 rounded-lg" style={{ backgroundColor: '#F7F8FA' }}>
                      <p className="text-sm mb-1" style={{ color: '#5F6368' }}>위반 건수</p>
                      <p className="text-2xl font-bold" style={{ color: '#EF4444' }}>
                        {selectedRule.errorCount}
                      </p>
                    </div>
                    <div className="text-center p-4 rounded-lg" style={{ backgroundColor: '#F7F8FA' }}>
                      <p className="text-sm mb-1" style={{ color: '#5F6368' }}>임계치</p>
                      <p className="text-2xl font-bold" style={{ color: '#F59E0B' }}>
                        {selectedRule.threshold}%
                      </p>
                    </div>
                  </div>
                </Card>

                {/* 품질 진단 이력 차트 (핵심) */}
                <Card padding="lg">
                  <h4 className="font-bold mb-4" style={{ color: '#202124' }}>최근 7일 품질 점수 추이</h4>
                  <ResponsiveContainer width="100%" height={200}>
                    <LineChart data={selectedRule.history}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#E8EAED" />
                      <XAxis dataKey="date" stroke="#5F6368" style={{ fontSize: '12px' }} />
                      <YAxis stroke="#5F6368" style={{ fontSize: '12px' }} domain={[90, 100]} />
                      <Tooltip 
                        contentStyle={{ 
                          backgroundColor: '#FFFFFF', 
                          border: '1px solid #DADCE0',
                          borderRadius: '8px',
                          boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
                        }}
                      />
                      <Line 
                        type="monotone" 
                        dataKey="score" 
                        stroke={getScoreColor(selectedRule.score)} 
                        strokeWidth={3}
                        dot={{ fill: getScoreColor(selectedRule.score), r: 4 }}
                        activeDot={{ r: 6 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </Card>

                {/* 상세 정보 */}
                <Card padding="lg">
                  <h4 className="font-bold mb-4" style={{ color: '#202124' }}>규칙 상세</h4>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-sm" style={{ color: '#5F6368' }}>품질지표:</span>
                      <Badge 
                        variant="default"
                        style={{ 
                          backgroundColor: `${getQualityColor(selectedRule.qualityDimension)}20`,
                          color: getQualityColor(selectedRule.qualityDimension)
                        }}
                      >
                        {selectedRule.qualityDimension}
                      </Badge>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm" style={{ color: '#5F6368' }}>가중치:</span>
                      <span className="text-sm font-medium" style={{ color: '#202124' }}>{selectedRule.weight}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm" style={{ color: '#5F6368' }}>마지막 실행:</span>
                      <span className="text-sm" style={{ color: '#202124' }}>{selectedRule.lastRun}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm" style={{ color: '#5F6368' }}>상태:</span>
                      <Badge variant={selectedRule.isActive ? 'success' : 'default'}>
                        {selectedRule.isActive ? '활성' : '비활성'}
                      </Badge>
                    </div>
                  </div>
                </Card>
              </div>
            </div>

            {/* Footer */}
            <div className="px-8 py-4 border-t flex items-center justify-end gap-3" style={{ borderColor: '#DADCE0' }}>
              <Button variant="ghost" onClick={() => setIsDetailModalOpen(false)}>닫기</Button>
              <Button variant="outline">수정</Button>
              <Button variant="primary">지금 실행</Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}