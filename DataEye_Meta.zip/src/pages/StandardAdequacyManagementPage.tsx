import { CheckCircle, AlertTriangle, TrendingUp, BarChart3 } from 'lucide-react';
import { Card } from '../components/common/Card';
import { IconBox } from '../components/common/IconBox';
import { Badge } from '../components/common/Badge';

export function StandardAdequacyManagementPage() {
  const adequacyScores = [
    { category: '표준용어 적용률', score: 87, target: 90, trend: '+5%', status: 'good' },
    { category: '명명규칙 준수율', score: 92, target: 95, trend: '+3%', status: 'good' },
    { category: '데이터타입 일관성', score: 78, target: 85, trend: '-2%', status: 'warning' },
    { category: '메타데이터 완성도', score: 95, target: 90, trend: '+8%', status: 'excellent' },
  ];

  const violations = [
    { table: 'CUSTOMER', column: 'cust_name', issue: '표준용어 미사용', standard: 'CUST_NM', severity: 'high' },
    { table: 'ORDER', column: 'order_amt', issue: '데이터타입 불일치', standard: 'ORD_AMT (NUMBER)', severity: 'medium' },
    { table: 'PRODUCT', column: 'prod_desc', issue: '명명규칙 위반', standard: 'PROD_DESC', severity: 'low' },
    { table: 'PAYMENT', column: 'pay_date', issue: '표준용어 미사용', standard: 'PAY_DT', severity: 'high' },
  ];

  const systemCompliance = [
    { system: '고객관리 시스템', tables: 24, compliant: 21, complianceRate: 87.5 },
    { system: '주문관리 시스템', tables: 18, compliant: 17, complianceRate: 94.4 },
    { system: '재고관리 시스템', tables: 15, compliant: 12, complianceRate: 80.0 },
    { system: '배송관리 시스템', tables: 12, compliant: 11, complianceRate: 91.7 },
  ];

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 mb-6">
        <Card padding="lg">
          <IconBox icon={CheckCircle} color="green" size="md" />
          <div className="mt-3">
            <p className="mb-1" style={{ color: '#5F6368' }}>전체 적정성</p>
            <h3 className="font-bold" style={{ color: '#202124' }}>88%</h3>
          </div>
        </Card>
        <Card padding="lg">
          <IconBox icon={TrendingUp} color="blue" size="md" />
          <div className="mt-3">
            <p className="mb-1" style={{ color: '#5F6368' }}>개선율</p>
            <h3 className="font-bold" style={{ color: '#202124' }}>+12%</h3>
          </div>
        </Card>
        <Card padding="lg">
          <IconBox icon={AlertTriangle} color="orange" size="md" />
          <div className="mt-3">
            <p className="mb-1" style={{ color: '#5F6368' }}>위반 건수</p>
            <h3 className="font-bold" style={{ color: '#202124' }}>156</h3>
          </div>
        </Card>
        <Card padding="lg">
          <IconBox icon={BarChart3} color="indigo" size="md" />
          <div className="mt-3">
            <p className="mb-1" style={{ color: '#5F6368' }}>점검 테이블</p>
            <h3 className="font-bold" style={{ color: '#202124' }}>247</h3>
          </div>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card padding="lg">
          <div className="flex items-center gap-3 mb-6">
            <IconBox icon={BarChart3} color="blue" size="md" />
            <h3 className="font-bold" style={{ color: '#202124' }}>카테고리별 적정성 점수</h3>
          </div>
          <div className="space-y-4">
            {adequacyScores.map((item, idx) => (
              <div key={idx} className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <span className="font-bold" style={{ color: '#202124' }}>{item.category}</span>
                    <Badge variant={
                      item.status === 'excellent' ? 'success' : 
                      item.status === 'good' ? 'info' : 'warning'
                    }>
                      {item.trend}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold" style={{ color: '#202124' }}>{item.score}%</span>
                    <span style={{ color: '#5F6368' }}>/ {item.target}%</span>
                  </div>
                </div>
                <div className="relative w-full h-2 rounded-full overflow-hidden" style={{ backgroundColor: '#F1F3F4' }}>
                  <div 
                    className={`absolute top-0 left-0 h-full rounded-full ${
                      item.status === 'excellent' ? 'bg-green-500' : 
                      item.status === 'good' ? 'bg-blue-500' : 'bg-orange-500'
                    }`}
                    style={{ width: `${item.score}%` }}
                  ></div>
                  <div 
                    className="absolute top-0 h-full w-0.5 bg-gray-400"
                    style={{ left: `${item.target}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </Card>

        <Card padding="lg">
          <div className="flex items-center gap-3 mb-6">
            <IconBox icon={AlertTriangle} color="orange" size="md" />
            <h3 className="font-bold" style={{ color: '#202124' }}>표준 위반 현황</h3>
          </div>
          <div className="space-y-3">
            {violations.map((violation, idx) => (
              <div key={idx} className="p-3 rounded-xl border" style={{ backgroundColor: '#F9F9F9', borderColor: '#DADCE0' }}>
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <h4 className="font-bold" style={{ color: '#202124' }}>
                      {violation.table}.{violation.column}
                    </h4>
                    <p className="mt-1" style={{ color: '#5F6368' }}>{violation.issue}</p>
                  </div>
                  <Badge variant={
                    violation.severity === 'high' ? 'error' : 
                    violation.severity === 'medium' ? 'warning' : 'default'
                  }>
                    {violation.severity === 'high' ? '높음' : 
                     violation.severity === 'medium' ? '중간' : '낮음'}
                  </Badge>
                </div>
                <div className="text-sm">
                  <span style={{ color: '#5F6368' }}>권장:</span>
                  <span className="ml-2 font-mono font-bold" style={{ color: '#2B8DFF' }}>{violation.standard}</span>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <Card padding="lg">
        <div className="flex items-center gap-3 mb-6">
          <IconBox icon={CheckCircle} color="green" size="md" />
          <h3 className="font-bold" style={{ color: '#202124' }}>시스템별 준수율</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead style={{ backgroundColor: '#F7F8FA' }}>
              <tr style={{ borderBottom: '1px solid #DADCE0' }}>
                <th className="px-4 py-3 text-left text-sm" style={{ color: '#5F6368' }}>시스템</th>
                <th className="px-4 py-3 text-left text-sm" style={{ color: '#5F6368' }}>전체 테이블</th>
                <th className="px-4 py-3 text-left text-sm" style={{ color: '#5F6368' }}>준수 테이블</th>
                <th className="px-4 py-3 text-left text-sm" style={{ color: '#5F6368' }}>준수율</th>
                <th className="px-4 py-3 text-left text-sm" style={{ color: '#5F6368' }}>상태</th>
              </tr>
            </thead>
            <tbody>
              {systemCompliance.map((system, idx) => (
                <tr key={idx} className="border-b transition-colors" style={{ borderColor: '#DADCE0', backgroundColor: 'transparent' }} onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#F9F9F9'} onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}>
                  <td className="px-4 py-3 font-bold" style={{ color: '#202124' }}>{system.system}</td>
                  <td className="px-4 py-3" style={{ color: '#5F6368' }}>{system.tables}</td>
                  <td className="px-4 py-3" style={{ color: '#5F6368' }}>{system.compliant}</td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <div className="flex-1 max-w-[200px] h-2 rounded-full overflow-hidden" style={{ backgroundColor: '#F1F3F4' }}>
                        <div 
                          className={`h-full ${
                            system.complianceRate >= 90 ? 'bg-green-500' : 
                            system.complianceRate >= 80 ? 'bg-blue-500' : 'bg-orange-500'
                          }`}
                          style={{ width: `${system.complianceRate}%` }}
                        ></div>
                      </div>
                      <span className="font-bold" style={{ color: '#202124' }}>{system.complianceRate}%</span>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <Badge variant={
                      system.complianceRate >= 90 ? 'success' : 
                      system.complianceRate >= 80 ? 'info' : 'warning'
                    }>
                      {system.complianceRate >= 90 ? '우수' : 
                       system.complianceRate >= 80 ? '양호' : '개선필요'}
                    </Badge>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}