import { useState, useRef, useCallback } from 'react';
import { ZoomIn, ZoomOut, Maximize2, Download, Play, Pause, Info, Filter, Search } from 'lucide-react';
import { Button } from '../components/common/Button';
import { Card } from '../components/common/Card';
import { Badge } from '../components/common/Badge';
import { DataLineageNode, NodeData } from '../components/lineage/DataLineageNode';
import { DataLineageEdge } from '../components/lineage/DataLineageEdge';
import { LineageMinimap } from '../components/lineage/LineageMinimap';
import { motion, AnimatePresence } from 'motion/react';

const mockNodes: NodeData[] = [
  // Zone 1: Source
  {
    id: 'src_1',
    label: 'Legacy ERP',
    tableName: 'TB_CUST_MST',
    columns: ['CUST_ID', 'CUST_NM', 'REG_DT', 'STATUS_CD'],
    dqScore: 92,
    type: 'source',
    x: 100,
    y: 150,
    zone: 'SOURCE'
  },
  {
    id: 'src_2',
    label: 'Oracle DB',
    tableName: 'TB_ORD_DTL',
    columns: ['ORD_ID', 'CUST_ID', 'PROD_ID', 'ORD_AMT'],
    dqScore: 98,
    type: 'source',
    x: 100,
    y: 400,
    zone: 'SOURCE'
  },
  {
    id: 'src_3',
    label: 'MySQL',
    tableName: 'TB_PROD_INFO',
    columns: ['PROD_ID', 'PROD_NM', 'PRICE', 'CATEGORY'],
    dqScore: 88,
    type: 'source',
    x: 100,
    y: 650,
    zone: 'SOURCE'
  },

  // Zone 2: Warehouse
  {
    id: 'wh_1',
    label: 'Data Warehouse',
    tableName: 'DW_CUSTOMER',
    columns: ['DW_CUST_KEY', 'CUST_ID', 'CUST_NAME', 'SEGMENT'],
    dqScore: 96,
    type: 'warehouse',
    x: 700,
    y: 100,
    zone: 'WAREHOUSE'
  },
  {
    id: 'wh_2',
    label: 'Data Warehouse',
    tableName: 'DM_SALES',
    columns: ['SALES_KEY', 'CUST_KEY', 'ORD_DT', 'SALES_AMT'],
    dqScore: 94,
    type: 'warehouse',
    x: 700,
    y: 350,
    zone: 'WAREHOUSE'
  },
  {
    id: 'wh_3',
    label: 'Data Warehouse',
    tableName: 'DW_PRODUCT',
    columns: ['PROD_KEY', 'PROD_ID', 'PROD_DESC', 'CATEGORY'],
    dqScore: 91,
    type: 'warehouse',
    x: 700,
    y: 600,
    zone: 'WAREHOUSE'
  },

  // Zone 3: Consumption
  {
    id: 'cons_1',
    label: 'Tableau Report',
    tableName: 'RPT_SALES_DASH',
    columns: ['REPORT_DT', 'CUST_SEG', 'SALES_AMT', 'GROWTH_RT'],
    dqScore: 98,
    type: 'consumption',
    x: 1300,
    y: 150,
    zone: 'CONSUMPTION'
  },
  {
    id: 'cons_2',
    label: 'API Endpoint',
    tableName: 'API_CUST_PROFILE',
    columns: ['API_KEY', 'CUST_ID', 'PROFILE_DATA', 'LAST_UPD'],
    dqScore: 95,
    type: 'consumption',
    x: 1300,
    y: 400,
    zone: 'CONSUMPTION'
  },
  {
    id: 'cons_3',
    label: 'ML Model',
    tableName: 'ML_FEATURES',
    columns: ['FEATURE_ID', 'CUST_SCORE', 'PRED_VALUE', 'CONFIDENCE'],
    dqScore: 89,
    type: 'consumption',
    x: 1300,
    y: 650,
    zone: 'CONSUMPTION'
  },
];

const mockEdges = [
  // Source to Warehouse
  { id: 'e1', source: 'src_1', target: 'wh_1' },
  { id: 'e2', source: 'src_2', target: 'wh_1' },
  { id: 'e3', source: 'src_2', target: 'wh_2' },
  { id: 'e4', source: 'src_3', target: 'wh_2' },
  { id: 'e5', source: 'src_3', target: 'wh_3' },

  // Warehouse to Consumption
  { id: 'e6', source: 'wh_1', target: 'cons_1' },
  { id: 'e7', source: 'wh_1', target: 'cons_2' },
  { id: 'e8', source: 'wh_2', target: 'cons_1' },
  { id: 'e9', source: 'wh_2', target: 'cons_3' },
  { id: 'e10', source: 'wh_3', target: 'cons_3' },
];

// Predefined impact path: Oracle DB -> DW_Customer -> Tableau Report
const impactPath = ['src_2', 'wh_1', 'cons_1'];
const impactEdges = ['e2', 'e6'];

export function DataLineagePage() {
  const [scale, setScale] = useState(1);
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null);
  const [showImpactPath, setShowImpactPath] = useState(true);
  const [isAnimating, setIsAnimating] = useState(true);
  const [showNodeInfo, setShowNodeInfo] = useState(false);
  const svgRef = useRef<SVGSVGElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });

  const handleZoomIn = useCallback(() => {
    setScale(prev => Math.min(prev + 0.2, 3));
  }, []);

  const handleZoomOut = useCallback(() => {
    setScale(prev => Math.max(prev - 0.2, 0.5));
  }, []);

  const handleFitToScreen = useCallback(() => {
    setScale(1);
    setPosition({ x: 0, y: 0 });
  }, []);

  const handleExport = useCallback(() => {
    if (!svgRef.current) return;
    
    const svgData = new XMLSerializer().serializeToString(svgRef.current);
    const canvas = document.createElement('canvas');
    canvas.width = 2400;
    canvas.height = 1000;
    const ctx = canvas.getContext('2d');
    
    const img = new Image();
    img.onload = () => {
      ctx?.drawImage(img, 0, 0);
      const pngFile = canvas.toDataURL('image/png');
      const downloadLink = document.createElement('a');
      downloadLink.download = 'data-lineage.png';
      downloadLink.href = pngFile;
      downloadLink.click();
    };
    
    img.src = 'data:image/svg+xml;base64,' + btoa(unescape(encodeURIComponent(svgData)));
  }, []);

  const handleNodeClick = useCallback((nodeId: string) => {
    setSelectedNodeId(prev => prev === nodeId ? null : nodeId);
    setShowNodeInfo(true);
  }, []);

  const handleMouseDown = (e: React.MouseEvent) => {
    if (e.button === 0) {
      setIsDragging(true);
      setDragStart({ x: e.clientX - position.x, y: e.clientY - position.y });
    }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isDragging) {
      setPosition({
        x: e.clientX - dragStart.x,
        y: e.clientY - dragStart.y
      });
    }
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const handleNavigate = (x: number, y: number) => {
    setPosition({ x: -x, y: -y });
  };

  const getEdgeCoordinates = (edgeId: string) => {
    const edge = mockEdges.find(e => e.id === edgeId);
    if (!edge) return null;

    const sourceNode = mockNodes.find(n => n.id === edge.source);
    const targetNode = mockNodes.find(n => n.id === edge.target);

    if (!sourceNode || !targetNode) return null;

    return {
      id: edgeId,
      source: edge.source,
      target: edge.target,
      sourceX: sourceNode.x,
      sourceY: sourceNode.y,
      targetX: targetNode.x,
      targetY: targetNode.y,
    };
  };

  const isNodeInPath = (nodeId: string) => {
    return showImpactPath && impactPath.includes(nodeId);
  };

  const isEdgeInPath = (edgeId: string) => {
    return showImpactPath && impactEdges.includes(edgeId);
  };

  const isNodeDimmed = (nodeId: string) => {
    return showImpactPath && !impactPath.includes(nodeId);
  };

  const isEdgeDimmed = (edgeId: string) => {
    return showImpactPath && !impactEdges.includes(edgeId);
  };

  const selectedNode = mockNodes.find(n => n.id === selectedNodeId);

  return (
    <div className="h-full flex flex-col">
      {/* Top Control Panel */}
      <Card padding="md" className="mb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ backgroundColor: '#3B82F622' }}>
                <Play className="w-5 h-5" style={{ color: '#3B82F6' }} />
              </div>
              <div>
                <h3 className="font-bold" style={{ color: '#202124' }}>Data Lineage Analysis</h3>
                <p className="text-sm" style={{ color: '#5F6368' }}>Oracle DB → DW_Customer → Tableau Report</p>
              </div>
            </div>
            
            <div className="h-8 w-px" style={{ backgroundColor: '#DADCE0' }} />
            
            <div className="flex items-center gap-2">
              <Badge variant={showImpactPath ? 'info' : 'default'}>
                Impact Path {showImpactPath ? 'ON' : 'OFF'}
              </Badge>
              <Badge variant="success">9 Nodes</Badge>
              <Badge variant="warning">10 Connections</Badge>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Button 
              variant="secondary" 
              size="sm" 
              icon={<Search className="w-4 h-4" />}
            >
              Search
            </Button>
            <Button 
              variant="secondary" 
              size="sm" 
              icon={<Filter className="w-4 h-4" />}
            >
              Filter
            </Button>
            <Button
              variant={showImpactPath ? 'primary' : 'secondary'}
              size="sm"
              icon={showImpactPath ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              onClick={() => setShowImpactPath(!showImpactPath)}
            >
              {showImpactPath ? 'Hide' : 'Show'} Impact
            </Button>
          </div>
        </div>
      </Card>

      {/* Main Lineage Canvas */}
      <div 
        ref={containerRef}
        className="flex-1 relative rounded-xl overflow-hidden border"
        style={{ 
          backgroundColor: '#FFFFFF',
          borderColor: '#DADCE0',
          cursor: isDragging ? 'grabbing' : 'grab'
        }}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
      >
        {/* Grid Pattern Background */}
        <svg 
          className="absolute inset-0 w-full h-full pointer-events-none"
          style={{ zIndex: 0 }}
        >
          <defs>
            <pattern 
              id="grid" 
              width="50" 
              height="50" 
              patternUnits="userSpaceOnUse"
              patternTransform={`translate(${position.x % 50}, ${position.y % 50})`}
            >
              <path 
                d="M 50 0 L 0 0 0 50" 
                fill="none" 
                stroke="rgba(0,0,0,0.03)" 
                strokeWidth="1"
              />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid)" />
        </svg>

        {/* Main SVG Canvas */}
        <svg
          ref={svgRef}
          className="absolute inset-0"
          width="2000"
          height="1200"
          viewBox="0 0 2000 1200"
          preserveAspectRatio="xMidYMid meet"
          style={{ 
            transform: `translate(${position.x}px, ${position.y}px) scale(${scale})`,
            transformOrigin: '0 0',
            transition: isDragging ? 'none' : 'transform 0.2s ease-out'
          }}
        >
          <defs>
            {/* Glow filter */}
            <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
              <feGaussianBlur stdDeviation="4" result="coloredBlur"/>
              <feMerge>
                <feMergeNode in="coloredBlur"/>
                <feMergeNode in="SourceGraphic"/>
              </feMerge>
            </filter>

            {/* Edge glow filter */}
            <filter id="edgeGlow" x="-50%" y="-50%" width="200%" height="200%">
              <feGaussianBlur stdDeviation="6" result="coloredBlur"/>
              <feMerge>
                <feMergeNode in="coloredBlur"/>
                <feMergeNode in="SourceGraphic"/>
              </feMerge>
            </filter>

            {/* Glass gradient */}
            <linearGradient id="glassGradient" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="white" stopOpacity="0.2"/>
              <stop offset="100%" stopColor="white" stopOpacity="0"/>
            </linearGradient>
          </defs>

          {/* Zone labels */}
          <text x={200} y={80} fill="#5F6368" fontSize={16} fontWeight={700} textAnchor="middle">
            SOURCE SYSTEMS
          </text>
          <text x={800} y={80} fill="#5F6368" fontSize={16} fontWeight={700} textAnchor="middle">
            DATA WAREHOUSE
          </text>
          <text x={1400} y={80} fill="#5F6368" fontSize={16} fontWeight={700} textAnchor="middle">
            CONSUMPTION LAYER
          </text>

          {/* Zone dividers */}
          <line x1={500} y1={100} x2={500} y2={900} stroke="rgba(0,0,0,0.08)" strokeWidth={2} strokeDasharray="10,10" />
          <line x1={1100} y1={100} x2={1100} y2={900} stroke="rgba(0,0,0,0.08)" strokeWidth={2} strokeDasharray="10,10" />

          {/* Render edges first (behind nodes) */}
          <g>
            {mockEdges.map(edge => {
              const coords = getEdgeCoordinates(edge.id);
              if (!coords) return null;
              return (
                <DataLineageEdge
                  key={edge.id}
                  edge={coords}
                  isActive={isEdgeInPath(edge.id)}
                  isDimmed={isEdgeDimmed(edge.id)}
                />
              );
            })}
          </g>

          {/* Render nodes */}
          <g>
            {mockNodes.map(node => (
              <DataLineageNode
                key={node.id}
                node={node}
                isActive={isNodeInPath(node.id)}
                isDimmed={isNodeDimmed(node.id)}
                onClick={handleNodeClick}
              />
            ))}
          </g>
        </svg>

        {/* Floating Toolbar */}
        <div 
          className="absolute bottom-6 left-1/2 transform -translate-x-1/2 flex items-center gap-2 px-4 py-3 rounded-xl border"
          style={{
            backgroundColor: 'rgba(255, 255, 255, 0.95)',
            borderColor: '#DADCE0',
            backdropFilter: 'blur(10px)',
            boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)'
          }}
        >
          <Button
            variant="secondary"
            size="sm"
            icon={<ZoomOut className="w-4 h-4" />}
            onClick={handleZoomOut}
          >
            Zoom Out
          </Button>
          <div 
            className="px-3 py-1 rounded-lg"
            style={{ backgroundColor: '#F1F3F4', color: '#202124' }}
          >
            {Math.round(scale * 100)}%
          </div>
          <Button
            variant="secondary"
            size="sm"
            icon={<ZoomIn className="w-4 h-4" />}
            onClick={handleZoomIn}
          >
            Zoom In
          </Button>
          <div className="h-6 w-px" style={{ backgroundColor: '#DADCE0' }} />
          <Button
            variant="secondary"
            size="sm"
            icon={<Maximize2 className="w-4 h-4" />}
            onClick={handleFitToScreen}
          >
            Fit to Screen
          </Button>
          <Button
            variant="secondary"
            size="sm"
            icon={<Download className="w-4 h-4" />}
            onClick={handleExport}
          >
            Export Image
          </Button>
        </div>

        {/* Minimap */}
        <LineageMinimap
          nodes={mockNodes}
          viewBox={{ 
            x: -position.x / scale, 
            y: -position.y / scale, 
            width: (containerRef.current?.clientWidth || 1200) / scale,
            height: (containerRef.current?.clientHeight || 800) / scale
          }}
          scale={scale}
          onNavigate={handleNavigate}
        />

        {/* Node Info Panel */}
        <AnimatePresence>
          {selectedNode && showNodeInfo && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="absolute top-6 right-6 w-80 rounded-xl border overflow-hidden"
              style={{
                backgroundColor: 'rgba(255, 255, 255, 0.95)',
                borderColor: '#DADCE0',
                backdropFilter: 'blur(10px)',
                boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)'
              }}
            >
              <div className="px-4 py-3 border-b flex items-center justify-between" style={{ borderColor: '#DADCE0' }}>
                <div className="flex items-center gap-2">
                  <Info className="w-4 h-4" style={{ color: '#3B82F6' }} />
                  <h4 className="font-bold" style={{ color: '#202124' }}>Node Details</h4>
                </div>
                <button 
                  onClick={() => setShowNodeInfo(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  ✕
                </button>
              </div>
              <div className="p-4 space-y-3">
                <div>
                  <p className="text-xs mb-1" style={{ color: '#5F6368' }}>TABLE NAME</p>
                  <p className="font-mono font-bold" style={{ color: '#202124' }}>{selectedNode.tableName}</p>
                </div>
                <div>
                  <p className="text-xs mb-1" style={{ color: '#5F6368' }}>TYPE</p>
                  <Badge variant={
                    selectedNode.type === 'source' ? 'info' :
                    selectedNode.type === 'warehouse' ? 'warning' :
                    'success'
                  }>
                    {selectedNode.type.toUpperCase()}
                  </Badge>
                </div>
                <div>
                  <p className="text-xs mb-1" style={{ color: '#5F6368' }}>DATA QUALITY SCORE</p>
                  <div className="flex items-center gap-2">
                    <div className="flex-1 h-2 rounded-full" style={{ backgroundColor: '#E8EAED' }}>
                      <div 
                        className="h-full rounded-full"
                        style={{ 
                          width: `${selectedNode.dqScore}%`,
                          backgroundColor: selectedNode.dqScore >= 95 ? '#10B981' : selectedNode.dqScore >= 80 ? '#F59E0B' : '#EF4444'
                        }}
                      />
                    </div>
                    <span className="font-bold" style={{ color: '#202124' }}>{selectedNode.dqScore}%</span>
                  </div>
                </div>
                <div>
                  <p className="text-xs mb-2" style={{ color: '#5F6368' }}>COLUMNS ({selectedNode.columns.length})</p>
                  <div className="space-y-1">
                    {selectedNode.columns.map((col, idx) => (
                      <div key={idx} className="flex items-center gap-2 text-sm">
                        <div className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: '#3B82F6' }} />
                        <span className="font-mono" style={{ color: '#202124' }}>{col}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}