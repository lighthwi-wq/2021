import { Card } from '../components/common/Card';
import { Button } from '../components/common/Button';
import { Badge } from '../components/common/Badge';
import { Users, Plus, Search } from 'lucide-react';
import { colors } from '../constants/designSystem';

const users = [
  { id: 1, name: '김철수', email: 'kim@company.com', role: 'Admin', department: 'IT', status: 'active', lastLogin: '2024-01-27 09:30' },
  { id: 2, name: '이영희', email: 'lee@company.com', role: 'User', department: 'Marketing', status: 'active', lastLogin: '2024-01-27 08:15' },
  { id: 3, name: '박지훈', email: 'park@company.com', role: 'User', department: 'Sales', status: 'active', lastLogin: '2024-01-26 17:45' },
  { id: 4, name: '최민수', email: 'choi@company.com', role: 'User', department: 'HR', status: 'inactive', lastLogin: '2024-01-20 14:20' },
];

export function UserManagementPage() {
  return (
    <div className="space-y-6 animate-fade-in-up">
      {/* Stats */}
      <div className="grid grid-cols-4 gap-4">
        <Card>
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-xl" style={{ backgroundColor: colors.primaryLight }}>
              <Users className="w-6 h-6" style={{ color: colors.primary }} />
            </div>
            <div>
              <p className="text-sm" style={{ color: colors.textSecondary }}>전체 사용자</p>
              <p className="text-2xl font-bold" style={{ color: colors.textPrimary }}>48</p>
            </div>
          </div>
        </Card>
        <Card>
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-xl" style={{ backgroundColor: colors.successLight }}>
              <Users className="w-6 h-6" style={{ color: colors.success }} />
            </div>
            <div>
              <p className="text-sm" style={{ color: colors.textSecondary }}>활성 사용자</p>
              <p className="text-2xl font-bold" style={{ color: colors.textPrimary }}>42</p>
            </div>
          </div>
        </Card>
        <Card>
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-xl" style={{ backgroundColor: colors.errorLight }}>
              <Users className="w-6 h-6" style={{ color: colors.error }} />
            </div>
            <div>
              <p className="text-sm" style={{ color: colors.textSecondary }}>비활성 사용자</p>
              <p className="text-2xl font-bold" style={{ color: colors.textPrimary }}>6</p>
            </div>
          </div>
        </Card>
        <Card>
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-xl" style={{ backgroundColor: colors.warningLight }}>
              <Users className="w-6 h-6" style={{ color: colors.warning }} />
            </div>
            <div>
              <p className="text-sm" style={{ color: colors.textSecondary }}>관리자</p>
              <p className="text-2xl font-bold" style={{ color: colors.textPrimary }}>5</p>
            </div>
          </div>
        </Card>
      </div>

      {/* Actions */}
      <Card>
        <div className="flex items-center justify-between">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: colors.textTertiary }} />
            <input
              type="text"
              placeholder="이름, 이메일로 검색..."
              className="w-full pl-10 pr-4 py-2 rounded-lg border"
              style={{
                borderColor: colors.border,
                backgroundColor: colors.background,
              }}
            />
          </div>
          <Button variant="primary" icon={<Plus className="w-4 h-4" />}>
            사용자 추가
          </Button>
        </div>
      </Card>

      {/* User List */}
      <Card>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b" style={{ borderColor: colors.divider }}>
                <th className="text-left py-3 px-4" style={{ color: colors.textSecondary }}>이름</th>
                <th className="text-left py-3 px-4" style={{ color: colors.textSecondary }}>이메일</th>
                <th className="text-center py-3 px-4" style={{ color: colors.textSecondary }}>역할</th>
                <th className="text-left py-3 px-4" style={{ color: colors.textSecondary }}>부서</th>
                <th className="text-center py-3 px-4" style={{ color: colors.textSecondary }}>상태</th>
                <th className="text-left py-3 px-4" style={{ color: colors.textSecondary }}>마지막 로그인</th>
                <th className="text-center py-3 px-4" style={{ color: colors.textSecondary }}>액션</th>
              </tr>
            </thead>
            <tbody>
              {users.map((user) => (
                <tr 
                  key={user.id} 
                  className="border-b hover:bg-black/[0.02] transition-colors"
                  style={{ borderColor: colors.divider }}
                >
                  <td className="py-3 px-4 font-medium" style={{ color: colors.textPrimary }}>
                    {user.name}
                  </td>
                  <td className="py-3 px-4" style={{ color: colors.textSecondary }}>
                    {user.email}
                  </td>
                  <td className="py-3 px-4 text-center">
                    <Badge variant={user.role === 'Admin' ? 'primary' : 'info'}>
                      {user.role}
                    </Badge>
                  </td>
                  <td className="py-3 px-4" style={{ color: colors.textPrimary }}>
                    {user.department}
                  </td>
                  <td className="py-3 px-4 text-center">
                    <Badge variant={user.status === 'active' ? 'success' : 'error'}>
                      {user.status === 'active' ? '활성' : '비활성'}
                    </Badge>
                  </td>
                  <td className="py-3 px-4 text-sm" style={{ color: colors.textSecondary }}>
                    {user.lastLogin}
                  </td>
                  <td className="py-3 px-4 text-center">
                    <div className="flex gap-2 justify-center">
                      <Button variant="ghost" size="sm">수정</Button>
                      <Button variant="ghost" size="sm">권한</Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
