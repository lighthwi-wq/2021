import { useState, Fragment } from 'react';
import { Card } from '../components/common/Card';
import { Button } from '../components/common/Button';
import { Badge } from '../components/common/Badge';
import { Users, Search, ChevronLeft, ChevronRight, Check, Plus, Trash2, X } from 'lucide-react';
import { colors } from '../constants/designSystem';
import { motion, AnimatePresence } from 'motion/react';

const users = [
  { id: 1, userId: 'test519', userName: 'test519', position: 'DG팀' },
  { id: 2, userId: 'TEST002', userName: 'TEST002', position: 'DG팀' },
  { id: 3, userId: 'TEST003', userName: 'TEST003', position: 'DG팀' },
  { id: 4, userId: 'guest97', userName: 'guest97', position: '마케팅팀' },
  { id: 5, userId: 'TEST001', userName: 'TEST001', position: 'DG팀' },
];

const userGroups = [
  { id: 1, groupId: 'DATAEYE_ROLE', groupName: '시스템 기능', roleCount: 0 },
  { id: 2, groupId: 'META_DA_ROLE', groupName: '메타 DA', roleCount: 0 },
  { id: 3, groupId: 'META_MD_ROLE', groupName: '모델링', roleCount: 1 },
  { id: 4, groupId: 'ADMIN_ROLE', groupName: '수퍼', roleCount: 0 },
  { id: 5, groupId: 'DATAEYE_ROLE', groupName: '시스템 기능', roleCount: 0 },
];

const functionGroups = [
  { id: 1, groupId: 'DATAEYE_GRP', groupName: '시스템 기능' },
  { id: 2, groupId: 'META_DA_GRP', groupName: '메타 DA' },
  { id: 3, groupId: 'META_MD_GRP', groupName: '모델링' },
  { id: 4, groupId: 'DATAEYE_GRP', groupName: '시스템기능' },
  { id: 5, groupId: 'ADMIN', groupName: '관리자' },
];

const menuList = [
  { 
    id: 1, 
    menuName: '1st MENU (1)', 
    permissions: { create: true, read: false, update: true, delete: false, execute: true },
    children: [
      { id: 11, menuName: '비즈메타', permissions: { create: true, read: false, update: true, delete: false, execute: true } },
      { id: 12, menuName: '2st Menu', permissions: { create: true, read: false, update: true, delete: false, execute: true } },
    ]
  },
  { 
    id: 2, 
    menuName: '1st MENU (2)', 
    permissions: { create: true, read: false, update: true, delete: false, execute: true },
    children: [
      { id: 21, menuName: '데이터표준관리', permissions: { create: true, read: false, update: true, delete: false, execute: true } },
      { id: 22, menuName: '2st Menu', permissions: { create: true, read: false, update: true, delete: false, execute: true } },
    ]
  },
];

export function UserManagementPage() {
  const [selectedUserRows, setSelectedUserRows] = useState<number[]>([2]);
  const [selectedUserGroupRows, setSelectedUserGroupRows] = useState<number[]>([3]);
  const [selectedFunctionGroupRows, setSelectedFunctionGroupRows] = useState<number[]>([2]);
  const [currentStep, setCurrentStep] = useState(1);
  
  // 드롭다운 모달 상태
  const [userAddModal, setUserAddModal] = useState(false);
  const [userDeleteModal, setUserDeleteModal] = useState(false);
  const [userGroupAddModal, setUserGroupAddModal] = useState(false);
  const [userGroupDeleteModal, setUserGroupDeleteModal] = useState(false);
  const [functionGroupAddModal, setFunctionGroupAddModal] = useState(false);
  const [functionGroupDeleteModal, setFunctionGroupDeleteModal] = useState(false);
  const [menuSaveModal, setMenuSaveModal] = useState(false);
  
  // 권한 설정 추가/삭제 모달
  const [userPermissionAddModal, setUserPermissionAddModal] = useState(false);
  const [userPermissionDeleteModal, setUserPermissionDeleteModal] = useState(false);
  const [groupPermissionAddModal, setGroupPermissionAddModal] = useState(false);
  const [groupPermissionDeleteModal, setGroupPermissionDeleteModal] = useState(false);
  const [functionPermissionAddModal, setFunctionPermissionAddModal] = useState(false);
  const [functionPermissionDeleteModal, setFunctionPermissionDeleteModal] = useState(false);

  const steps = [
    { id: 1, label: '사용자권한' },
    { id: 2, label: '사용자 그룹권한' },
    { id: 3, label: '기능그룹권한' },
    { id: 4, label: '메뉴권한' },
  ];

  return (
    <div className="p-6 h-full overflow-auto">
      {/* Progress Steps */}
      <div className="mb-6">
        <div className="flex items-center gap-3">
          {steps.map((step, index) => (
            <Fragment key={step.id}>
              <motion.button
                onClick={() => setCurrentStep(step.id)}
                className="relative flex-1 cursor-pointer group"
                style={{
                  height: '64px'
                }}
                whileHover={{ 
                  scale: 1.02,
                  y: -2,
                  transition: { duration: 0.2, ease: 'easeOut' }
                }}
                whileTap={{ scale: 0.98 }}
              >
                {/* Step Container */}
                <motion.div
                  className="h-full relative transition-all duration-300"
                  style={{
                    background: currentStep >= step.id
                      ? '#FFFFFF'
                      : 'linear-gradient(135deg, #E8F4FD 0%, #D6EDFC 100%)',
                    borderRadius: '12px',
                    boxShadow: currentStep >= step.id
                      ? '0 4px 10px rgba(58, 123, 200, 0.18), 0 2px 6px rgba(0, 0, 0, 0.1)'
                      : '0 3px 8px rgba(135, 206, 250, 0.15), 0 1px 4px rgba(135, 206, 250, 0.1)',
                    borderTop: currentStep >= step.id ? '2px solid #3A7BC8' : '1px solid #C0E3F9',
                    borderLeft: currentStep >= step.id ? '2px solid #3A7BC8' : '1px solid #C0E3F9',
                    borderBottom: currentStep >= step.id ? '2px solid #3A7BC8' : '1px solid #C0E3F9',
                    borderRight: currentStep >= step.id ? '2px solid #3A7BC8' : '1px solid #C0E3F9'
                  }}
                  whileHover={{
                    boxShadow: currentStep >= step.id
                      ? '0 6px 14px rgba(58, 123, 200, 0.25), 0 2px 8px rgba(0, 0, 0, 0.12)'
                      : '0 6px 14px rgba(135, 206, 250, 0.25), 0 2px 8px rgba(135, 206, 250, 0.15)',
                    transition: { duration: 0.2 }
                  }}
                >
                  {/* Current Step Indicator - 하단 화살표 */}
                  {currentStep === step.id && (
                    <motion.div
                      className="absolute left-1/2"
                      style={{
                        bottom: '-12px',
                        transform: 'translateX(-50%)'
                      }}
                      initial={{ opacity: 0, y: -5 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3 }}
                    >
                      <svg width="16" height="8" viewBox="0 0 16 8">
                        <path
                          d="M 8 8 L 16 0 L 0 0 Z"
                          fill="#3A7BC8"
                        />
                      </svg>
                    </motion.div>
                  )}

                  {/* Content */}
                  <div className="h-full flex items-center px-5 gap-3">
                    {/* Step Number Circle */}
                    <div
                      className="flex-shrink-0 w-9 h-9 rounded-full flex items-center justify-center transition-all duration-300"
                      style={{
                        background: currentStep >= step.id
                          ? '#3A7BC8'
                          : '#FFFFFF',
                        border: currentStep >= step.id ? '2px solid #3A7BC8' : '2px solid #3A7BC8'
                      }}
                    >
                      {currentStep > step.id ? (
                        <Check 
                          className="w-4 h-4" 
                          style={{ 
                            color: '#FFFFFF', 
                            strokeWidth: 3 
                          }} 
                        />
                      ) : (
                        <span
                          style={{
                            fontWeight: 700,
                            fontSize: '14px',
                            color: currentStep >= step.id ? '#FFFFFF' : '#3A7BC8'
                          }}
                        >
                          {step.id}
                        </span>
                      )}
                    </div>

                    {/* Step Label */}
                    <div
                      className="text-sm font-medium transition-colors duration-300"
                      style={{
                        color: currentStep >= step.id ? '#333333' : '#666666',
                        fontWeight: currentStep === step.id ? 600 : 500
                      }}
                    >
                      {step.label}
                    </div>
                  </div>
                </motion.div>
              </motion.button>
            </Fragment>
          ))}
        </div>
      </div>

      {/* 4개 섹션을 가로로 배치 */}
      <div className="grid grid-cols-4 gap-5">
        {/* 1. 사용자 관리 */}
        <div className="flex flex-col gap-4">
          {/* 검색 영역 */}
          <Card padding="lg">
            <div className="space-y-3">
              <label className="block text-sm font-medium" style={{ color: '#333333' }}>
                사용자 권한 검색어입력
              </label>
              <input
                type="text"
                className="w-full px-3 py-2.5 rounded-lg border text-sm"
                style={{ 
                  borderColor: '#DADCE0',
                  backgroundColor: '#FFFFFF'
                }}
                placeholder="사용자 권한 검색"
              />
              <button 
                className="w-full px-4 py-2.5 rounded-lg text-sm font-medium transition-all"
                style={{ 
                  backgroundColor: '#2B8DFF',
                  color: '#FFFFFF'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.backgroundColor = '#1976D2';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor = '#2B8DFF';
                }}
              >
                검색
              </button>
            </div>
          </Card>

          {/* 사용자 목록 */}
          <div className="relative">
            <Card padding="none">
              <div className="px-5 py-3 border-b flex items-center justify-between" style={{ borderColor: '#E8EAED', backgroundColor: '#F8F9FA' }}>
                <h3 className="text-sm font-medium" style={{ color: '#333333' }}>사용자 목록</h3>
                <div className="flex gap-2 relative">
                  <button
                    onClick={() => {
                      setUserAddModal(!userAddModal);
                      setUserDeleteModal(false);
                    }}
                    className="px-3 py-1.5 rounded-lg text-sm font-medium transition-all flex items-center gap-1"
                    style={{ 
                      backgroundColor: userAddModal ? '#2B8DFF' : '#F1F3F4',
                      color: userAddModal ? '#FFFFFF' : '#333333'
                    }}
                    onMouseEnter={(e) => {
                      if (!userAddModal) {
                        e.currentTarget.style.backgroundColor = '#E8EAED';
                      }
                    }}
                    onMouseLeave={(e) => {
                      if (!userAddModal) {
                        e.currentTarget.style.backgroundColor = '#F1F3F4';
                      }
                    }}
                  >
                    <Plus className="w-3.5 h-3.5" />
                    추가
                  </button>
                  <button
                    onClick={() => {
                      setUserDeleteModal(!userDeleteModal);
                      setUserAddModal(false);
                    }}
                    className="px-3 py-1.5 rounded-lg text-sm font-medium transition-all flex items-center gap-1"
                    style={{ 
                      backgroundColor: userDeleteModal ? '#2B8DFF' : '#F1F3F4',
                      color: userDeleteModal ? '#FFFFFF' : '#333333'
                    }}
                    onMouseEnter={(e) => {
                      if (!userDeleteModal) {
                        e.currentTarget.style.backgroundColor = '#E8EAED';
                      }
                    }}
                    onMouseLeave={(e) => {
                      if (!userDeleteModal) {
                        e.currentTarget.style.backgroundColor = '#F1F3F4';
                      }
                    }}
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    삭제
                  </button>
                </div>
              </div>
              <div className="overflow-x-auto" style={{ maxHeight: '280px', overflowY: 'auto' }}>
                <table className="w-full">
                  <thead style={{ position: 'sticky', top: 0, backgroundColor: '#F8F9FA', zIndex: 1 }}>
                    <tr style={{ borderBottom: '1px solid #E8EAED' }}>
                      <th className="text-center px-3 py-3 text-sm font-medium" style={{ color: '#5F6368', width: '50px' }}>
                        <input type="checkbox" className="w-4 h-4" />
                      </th>
                      <th className="text-center px-3 py-3 text-sm font-medium" style={{ color: '#5F6368', width: '60px' }}>번호</th>
                      <th className="text-left px-3 py-3 text-sm font-medium" style={{ color: '#5F6368' }}>사용자ID</th>
                      <th className="text-left px-3 py-3 text-sm font-medium" style={{ color: '#5F6368' }}>사용자명</th>
                      <th className="text-left px-3 py-3 text-sm font-medium" style={{ color: '#5F6368' }}>조직</th>
                    </tr>
                  </thead>
                  <tbody>
                    {users.map((user, index) => (
                      <tr 
                        key={user.id}
                        className="cursor-pointer transition-colors"
                        style={{ 
                          borderBottom: '1px solid #E8EAED',
                          backgroundColor: selectedUserRows.includes(user.id) ? '#E8F0FE' : 'transparent'
                        }}
                        onClick={() => {
                          if (selectedUserRows.includes(user.id)) {
                            setSelectedUserRows(selectedUserRows.filter(id => id !== user.id));
                          } else {
                            setSelectedUserRows([...selectedUserRows, user.id]);
                          }
                        }}
                        onMouseEnter={(e) => {
                          if (!selectedUserRows.includes(user.id)) {
                            e.currentTarget.style.backgroundColor = '#F8F9FA';
                          }
                        }}
                        onMouseLeave={(e) => {
                          if (!selectedUserRows.includes(user.id)) {
                            e.currentTarget.style.backgroundColor = 'transparent';
                          }
                        }}
                      >
                        <td className="text-center px-3 py-2.5">
                          <input type="checkbox" className="w-4 h-4" checked={selectedUserRows.includes(user.id)} readOnly />
                        </td>
                        <td className="text-center px-3 py-2.5 text-sm" style={{ color: '#333333' }}>{index + 1}</td>
                        <td className="px-3 py-2.5 text-sm" style={{ color: '#333333' }}>{user.userId}</td>
                        <td className="px-3 py-2.5 text-sm" style={{ color: '#333333' }}>{user.userName}</td>
                        <td className="px-3 py-2.5 text-sm" style={{ color: '#333333' }}>{user.position}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="px-4 py-3 border-t flex items-center justify-between" style={{ borderColor: '#E8EAED' }}>
                <div className="flex items-center gap-2">
                  <span className="text-sm" style={{ color: '#5F6368' }}>5개씩 보기</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm" style={{ color: '#5F6368' }}>1 / 1</span>
                </div>
              </div>
            </Card>

            {/* 추가 드롭다운 모달 */}
            <AnimatePresence>
              {userAddModal && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.2 }}
                  className="absolute top-12 right-0 z-50 rounded-lg shadow-lg border"
                  style={{ 
                    backgroundColor: '#FFFFFF',
                    borderColor: '#DADCE0',
                    width: '300px'
                  }}
                >
                  <div className="p-4">
                    <div className="flex items-center justify-between mb-4">
                      <h4 className="text-sm font-medium" style={{ color: '#333333' }}>사용자 추가</h4>
                      <button onClick={() => setUserAddModal(false)}>
                        <X className="w-4 h-4" style={{ color: '#5F6368' }} />
                      </button>
                    </div>
                    <div className="space-y-3">
                      <div>
                        <label className="block text-xs font-medium mb-1" style={{ color: '#5F6368' }}>사용자 ID</label>
                        <input 
                          type="text" 
                          className="w-full px-3 py-2 rounded-lg border text-sm"
                          style={{ borderColor: '#DADCE0' }}
                          placeholder="사용자 ID 입력"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-medium mb-1" style={{ color: '#5F6368' }}>사용자명</label>
                        <input 
                          type="text" 
                          className="w-full px-3 py-2 rounded-lg border text-sm"
                          style={{ borderColor: '#DADCE0' }}
                          placeholder="사용자명 입력"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-medium mb-1" style={{ color: '#5F6368' }}>조직</label>
                        <input 
                          type="text" 
                          className="w-full px-3 py-2 rounded-lg border text-sm"
                          style={{ borderColor: '#DADCE0' }}
                          placeholder="조직 입력"
                        />
                      </div>
                      <div className="flex gap-2 pt-2">
                        <button
                          className="flex-1 px-3 py-2 rounded-lg text-sm font-medium"
                          style={{ backgroundColor: '#2B8DFF', color: '#FFFFFF' }}
                          onClick={() => setUserAddModal(false)}
                        >
                          추가
                        </button>
                        <button
                          className="flex-1 px-3 py-2 rounded-lg text-sm font-medium"
                          style={{ backgroundColor: '#F1F3F4', color: '#333333' }}
                          onClick={() => setUserAddModal(false)}
                        >
                          취소
                        </button>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* 삭제 드롭다운 모달 */}
            <AnimatePresence>
              {userDeleteModal && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.2 }}
                  className="absolute top-12 right-0 z-50 rounded-lg shadow-lg border"
                  style={{ 
                    backgroundColor: '#FFFFFF',
                    borderColor: '#DADCE0',
                    width: '300px'
                  }}
                >
                  <div className="p-4">
                    <div className="flex items-center justify-between mb-4">
                      <h4 className="text-sm font-medium" style={{ color: '#333333' }}>사용자 삭제</h4>
                      <button onClick={() => setUserDeleteModal(false)}>
                        <X className="w-4 h-4" style={{ color: '#5F6368' }} />
                      </button>
                    </div>
                    <p className="text-sm mb-4" style={{ color: '#5F6368' }}>
                      선택한 사용자를 삭제하시겠습니까?
                    </p>
                    <div className="flex gap-2">
                      <button
                        className="flex-1 px-3 py-2 rounded-lg text-sm font-medium"
                        style={{ backgroundColor: '#333333', color: '#FFFFFF' }}
                        onClick={() => setUserDeleteModal(false)}
                      >
                        삭제
                      </button>
                      <button
                        className="flex-1 px-3 py-2 rounded-lg text-sm font-medium"
                        style={{ backgroundColor: '#F1F3F4', color: '#333333' }}
                        onClick={() => setUserDeleteModal(false)}
                      >
                        취소
                      </button>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* 권한 설정 정보 - 사용자 그룹 */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-medium" style={{ color: '#333333' }}>권한 설정 정보</h3>
              <button
                className="px-3 py-1.5 rounded-lg text-sm font-medium transition-all"
                style={{ backgroundColor: '#2B8DFF', color: '#FFFFFF' }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.backgroundColor = '#1976D2';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor = '#2B8DFF';
                }}
              >
                저장
              </button>
            </div>
            <div className="text-sm mb-3" style={{ color: '#5F6368' }}>사용자 그룹</div>
            <div className="relative">
              <Card padding="none">
                <div className="px-5 py-3 border-b flex items-center justify-between" style={{ borderColor: '#E8EAED', backgroundColor: '#F8F9FA' }}>
                  <h3 className="text-sm font-medium" style={{ color: '#333333' }}>사용자 그룹 목록</h3>
                  <div className="flex gap-2">
                    <button
                      onClick={() => {
                        setUserPermissionAddModal(!userPermissionAddModal);
                        setUserPermissionDeleteModal(false);
                      }}
                      className="px-3 py-1.5 rounded-lg text-sm font-medium transition-all flex items-center gap-1"
                      style={{ 
                        backgroundColor: userPermissionAddModal ? '#2B8DFF' : '#F1F3F4',
                        color: userPermissionAddModal ? '#FFFFFF' : '#333333'
                      }}
                    >
                      <Plus className="w-3.5 h-3.5" />
                      추가
                    </button>
                    <button
                      onClick={() => {
                        setUserPermissionDeleteModal(!userPermissionDeleteModal);
                        setUserPermissionAddModal(false);
                      }}
                      className="px-3 py-1.5 rounded-lg text-sm font-medium transition-all flex items-center gap-1"
                      style={{ 
                        backgroundColor: userPermissionDeleteModal ? '#2B8DFF' : '#F1F3F4',
                        color: userPermissionDeleteModal ? '#FFFFFF' : '#333333'
                      }}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      삭제
                    </button>
                  </div>
                </div>
                <div className="overflow-x-auto" style={{ maxHeight: '200px', overflowY: 'auto' }}>
                  <table className="w-full">
                    <thead style={{ position: 'sticky', top: 0, backgroundColor: '#F8F9FA', zIndex: 1 }}>
                      <tr style={{ borderBottom: '1px solid #E8EAED' }}>
                        <th className="text-center px-3 py-3 text-sm font-medium" style={{ color: '#5F6368', width: '60px' }}>번호</th>
                        <th className="text-left px-3 py-3 text-sm font-medium" style={{ color: '#5F6368' }}>그룹ID</th>
                        <th className="text-left px-3 py-3 text-sm font-medium" style={{ color: '#5F6368' }}>그룹명</th>
                      </tr>
                    </thead>
                    <tbody>
                      {userGroups.slice(0, 3).map((group, index) => (
                        <tr key={group.id} style={{ borderBottom: '1px solid #E8EAED' }}>
                          <td className="text-center px-3 py-2.5 text-sm" style={{ color: '#333333' }}>{index + 1}</td>
                          <td className="px-3 py-2.5 text-sm" style={{ color: '#333333' }}>{group.groupId}</td>
                          <td className="px-3 py-2.5 text-sm" style={{ color: '#333333' }}>{group.groupName}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </Card>

              {/* 권한 추가 모달 */}
              <AnimatePresence>
                {userPermissionAddModal && (
                  <motion.div
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="absolute top-12 right-0 z-50 rounded-lg shadow-lg border"
                    style={{ 
                      backgroundColor: '#FFFFFF',
                      borderColor: '#DADCE0',
                      width: '280px'
                    }}
                  >
                    <div className="p-4">
                      <div className="flex items-center justify-between mb-3">
                        <h4 className="text-sm font-medium" style={{ color: '#333333' }}>그룹 추가</h4>
                        <button onClick={() => setUserPermissionAddModal(false)}>
                          <X className="w-4 h-4" style={{ color: '#5F6368' }} />
                        </button>
                      </div>
                      <div className="space-y-2 mb-3">
                        <input 
                          type="text" 
                          className="w-full px-3 py-2 rounded-lg border text-sm"
                          style={{ borderColor: '#DADCE0' }}
                          placeholder="그룹 검색"
                        />
                      </div>
                      <div className="flex gap-2">
                        <button
                          className="flex-1 px-3 py-2 rounded-lg text-sm font-medium"
                          style={{ backgroundColor: '#2B8DFF', color: '#FFFFFF' }}
                          onClick={() => setUserPermissionAddModal(false)}
                        >
                          추가
                        </button>
                        <button
                          className="flex-1 px-3 py-2 rounded-lg text-sm font-medium"
                          style={{ backgroundColor: '#F1F3F4', color: '#333333' }}
                          onClick={() => setUserPermissionAddModal(false)}
                        >
                          취소
                        </button>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* 권한 삭제 모달 */}
              <AnimatePresence>
                {userPermissionDeleteModal && (
                  <motion.div
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="absolute top-12 right-0 z-50 rounded-lg shadow-lg border"
                    style={{ 
                      backgroundColor: '#FFFFFF',
                      borderColor: '#DADCE0',
                      width: '280px'
                    }}
                  >
                    <div className="p-4">
                      <div className="flex items-center justify-between mb-3">
                        <h4 className="text-sm font-medium" style={{ color: '#333333' }}>그룹 삭제</h4>
                        <button onClick={() => setUserPermissionDeleteModal(false)}>
                          <X className="w-4 h-4" style={{ color: '#5F6368' }} />
                        </button>
                      </div>
                      <p className="text-sm mb-3" style={{ color: '#5F6368' }}>
                        선택한 그룹을 삭제하시겠습니까?
                      </p>
                      <div className="flex gap-2">
                        <button
                          className="flex-1 px-3 py-2 rounded-lg text-sm font-medium"
                          style={{ backgroundColor: '#333333', color: '#FFFFFF' }}
                          onClick={() => setUserPermissionDeleteModal(false)}
                        >
                          삭제
                        </button>
                        <button
                          className="flex-1 px-3 py-2 rounded-lg text-sm font-medium"
                          style={{ backgroundColor: '#F1F3F4', color: '#333333' }}
                          onClick={() => setUserPermissionDeleteModal(false)}
                        >
                          취소
                        </button>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>

        {/* 2. 사용자 그룹 관리 */}
        <div className="flex flex-col gap-4">
          {/* 검색 영역 */}
          <Card padding="lg">
            <div className="space-y-3">
              <label className="block text-sm font-medium" style={{ color: '#333333' }}>
                사용자 그룹 권한 검색어입력
              </label>
              <input
                type="text"
                className="w-full px-3 py-2.5 rounded-lg border text-sm"
                style={{ 
                  borderColor: '#DADCE0',
                  backgroundColor: '#FFFFFF'
                }}
                placeholder="사용자 그룹 검색"
              />
              <button 
                className="w-full px-4 py-2.5 rounded-lg text-sm font-medium transition-all"
                style={{ 
                  backgroundColor: '#2B8DFF',
                  color: '#FFFFFF'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.backgroundColor = '#1976D2';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor = '#2B8DFF';
                }}
              >
                검색
              </button>
            </div>
          </Card>

          {/* 사용자 그룹 목록 */}
          <div className="relative">
            <Card padding="none">
              <div className="px-5 py-3 border-b flex items-center justify-between" style={{ borderColor: '#E8EAED', backgroundColor: '#F8F9FA' }}>
                <h3 className="text-sm font-medium" style={{ color: '#333333' }}>사용자 그룹 목록</h3>
                <div className="flex gap-2">
                  <button
                    onClick={() => {
                      setUserGroupAddModal(!userGroupAddModal);
                      setUserGroupDeleteModal(false);
                    }}
                    className="px-3 py-1.5 rounded-lg text-sm font-medium transition-all flex items-center gap-1"
                    style={{ 
                      backgroundColor: userGroupAddModal ? '#2B8DFF' : '#F1F3F4',
                      color: userGroupAddModal ? '#FFFFFF' : '#333333'
                    }}
                  >
                    <Plus className="w-3.5 h-3.5" />
                    추가
                  </button>
                  <button
                    onClick={() => {
                      setUserGroupDeleteModal(!userGroupDeleteModal);
                      setUserGroupAddModal(false);
                    }}
                    className="px-3 py-1.5 rounded-lg text-sm font-medium transition-all flex items-center gap-1"
                    style={{ 
                      backgroundColor: userGroupDeleteModal ? '#2B8DFF' : '#F1F3F4',
                      color: userGroupDeleteModal ? '#FFFFFF' : '#333333'
                    }}
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    삭제
                  </button>
                </div>
              </div>
              <div className="overflow-x-auto" style={{ maxHeight: '280px', overflowY: 'auto' }}>
                <table className="w-full">
                  <thead style={{ position: 'sticky', top: 0, backgroundColor: '#F8F9FA', zIndex: 1 }}>
                    <tr style={{ borderBottom: '1px solid #E8EAED' }}>
                      <th className="text-center px-3 py-3 text-sm font-medium" style={{ color: '#5F6368', width: '50px' }}>
                        <input type="checkbox" className="w-4 h-4" />
                      </th>
                      <th className="text-center px-3 py-3 text-sm font-medium" style={{ color: '#5F6368', width: '60px' }}>번호</th>
                      <th className="text-left px-3 py-3 text-sm font-medium" style={{ color: '#5F6368' }}>그룹ID</th>
                      <th className="text-left px-3 py-3 text-sm font-medium" style={{ color: '#5F6368' }}>그룹명</th>
                      <th className="text-left px-3 py-3 text-sm font-medium" style={{ color: '#5F6368' }}>수정번호</th>
                    </tr>
                  </thead>
                  <tbody>
                    {userGroups.map((group, index) => (
                      <tr 
                        key={group.id}
                        className="cursor-pointer transition-colors"
                        style={{ 
                          borderBottom: '1px solid #E8EAED',
                          backgroundColor: selectedUserGroupRows.includes(group.id) ? '#E8F0FE' : 'transparent'
                        }}
                        onClick={() => {
                          if (selectedUserGroupRows.includes(group.id)) {
                            setSelectedUserGroupRows(selectedUserGroupRows.filter(id => id !== group.id));
                          } else {
                            setSelectedUserGroupRows([...selectedUserGroupRows, group.id]);
                          }
                        }}
                        onMouseEnter={(e) => {
                          if (!selectedUserGroupRows.includes(group.id)) {
                            e.currentTarget.style.backgroundColor = '#F8F9FA';
                          }
                        }}
                        onMouseLeave={(e) => {
                          if (!selectedUserGroupRows.includes(group.id)) {
                            e.currentTarget.style.backgroundColor = 'transparent';
                          }
                        }}
                      >
                        <td className="text-center px-3 py-2.5">
                          <input type="checkbox" className="w-4 h-4" checked={selectedUserGroupRows.includes(group.id)} readOnly />
                        </td>
                        <td className="text-center px-3 py-2.5 text-sm" style={{ color: '#333333' }}>{index + 1}</td>
                        <td className="px-3 py-2.5 text-sm" style={{ color: '#333333' }}>{group.groupId}</td>
                        <td className="px-3 py-2.5 text-sm" style={{ color: '#333333' }}>{group.groupName}</td>
                        <td className="px-3 py-2.5 text-sm" style={{ color: '#333333' }}>{group.roleCount}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="px-4 py-3 border-t flex items-center justify-between" style={{ borderColor: '#E8EAED' }}>
                <div className="flex items-center gap-2">
                  <span className="text-sm" style={{ color: '#5F6368' }}>5개씩 보기</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm" style={{ color: '#5F6368' }}>1 / 1</span>
                </div>
              </div>
            </Card>

            {/* 추가 모달 */}
            <AnimatePresence>
              {userGroupAddModal && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="absolute top-12 right-0 z-50 rounded-lg shadow-lg border"
                  style={{ 
                    backgroundColor: '#FFFFFF',
                    borderColor: '#DADCE0',
                    width: '300px'
                  }}
                >
                  <div className="p-4">
                    <div className="flex items-center justify-between mb-4">
                      <h4 className="text-sm font-medium" style={{ color: '#333333' }}>사용자 그룹 추가</h4>
                      <button onClick={() => setUserGroupAddModal(false)}>
                        <X className="w-4 h-4" style={{ color: '#5F6368' }} />
                      </button>
                    </div>
                    <div className="space-y-3">
                      <div>
                        <label className="block text-xs font-medium mb-1" style={{ color: '#5F6368' }}>그룹 ID</label>
                        <input 
                          type="text" 
                          className="w-full px-3 py-2 rounded-lg border text-sm"
                          style={{ borderColor: '#DADCE0' }}
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-medium mb-1" style={{ color: '#5F6368' }}>그룹명</label>
                        <input 
                          type="text" 
                          className="w-full px-3 py-2 rounded-lg border text-sm"
                          style={{ borderColor: '#DADCE0' }}
                        />
                      </div>
                      <div className="flex gap-2 pt-2">
                        <button
                          className="flex-1 px-3 py-2 rounded-lg text-sm font-medium"
                          style={{ backgroundColor: '#2B8DFF', color: '#FFFFFF' }}
                          onClick={() => setUserGroupAddModal(false)}
                        >
                          추가
                        </button>
                        <button
                          className="flex-1 px-3 py-2 rounded-lg text-sm font-medium"
                          style={{ backgroundColor: '#F1F3F4', color: '#333333' }}
                          onClick={() => setUserGroupAddModal(false)}
                        >
                          취소
                        </button>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* 삭제 모달 */}
            <AnimatePresence>
              {userGroupDeleteModal && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="absolute top-12 right-0 z-50 rounded-lg shadow-lg border"
                  style={{ 
                    backgroundColor: '#FFFFFF',
                    borderColor: '#DADCE0',
                    width: '300px'
                  }}
                >
                  <div className="p-4">
                    <div className="flex items-center justify-between mb-4">
                      <h4 className="text-sm font-medium" style={{ color: '#333333' }}>사용자 그룹 삭제</h4>
                      <button onClick={() => setUserGroupDeleteModal(false)}>
                        <X className="w-4 h-4" style={{ color: '#5F6368' }} />
                      </button>
                    </div>
                    <p className="text-sm mb-4" style={{ color: '#5F6368' }}>
                      선택한 사용자 그룹을 삭제하시겠습니까?
                    </p>
                    <div className="flex gap-2">
                      <button
                        className="flex-1 px-3 py-2 rounded-lg text-sm font-medium"
                        style={{ backgroundColor: '#333333', color: '#FFFFFF' }}
                        onClick={() => setUserGroupDeleteModal(false)}
                      >
                        삭제
                      </button>
                      <button
                        className="flex-1 px-3 py-2 rounded-lg text-sm font-medium"
                        style={{ backgroundColor: '#F1F3F4', color: '#333333' }}
                        onClick={() => setUserGroupDeleteModal(false)}
                      >
                        취소
                      </button>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* 권한 설정 정보 - 사용자 목록 */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-medium" style={{ color: '#333333' }}>권한 설정 정보</h3>
              <button
                className="px-3 py-1.5 rounded-lg text-sm font-medium transition-all"
                style={{ backgroundColor: '#2B8DFF', color: '#FFFFFF' }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.backgroundColor = '#1976D2';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor = '#2B8DFF';
                }}
              >
                저장
              </button>
            </div>
            <div className="text-sm mb-3" style={{ color: '#5F6368' }}>사용자 목록</div>
            <div className="relative">
              <Card padding="none">
                <div className="px-5 py-3 border-b flex items-center justify-between" style={{ borderColor: '#E8EAED', backgroundColor: '#F8F9FA' }}>
                  <h3 className="text-sm font-medium" style={{ color: '#333333' }}>사용자 목록</h3>
                  <div className="flex gap-2">
                    <button
                      onClick={() => {
                        setGroupPermissionAddModal(!groupPermissionAddModal);
                        setGroupPermissionDeleteModal(false);
                      }}
                      className="px-3 py-1.5 rounded-lg text-sm font-medium transition-all flex items-center gap-1"
                      style={{ 
                        backgroundColor: groupPermissionAddModal ? '#2B8DFF' : '#F1F3F4',
                        color: groupPermissionAddModal ? '#FFFFFF' : '#333333'
                      }}
                    >
                      <Plus className="w-3.5 h-3.5" />
                      추가
                    </button>
                    <button
                      onClick={() => {
                        setGroupPermissionDeleteModal(!groupPermissionDeleteModal);
                        setGroupPermissionAddModal(false);
                      }}
                      className="px-3 py-1.5 rounded-lg text-sm font-medium transition-all flex items-center gap-1"
                      style={{ 
                        backgroundColor: groupPermissionDeleteModal ? '#2B8DFF' : '#F1F3F4',
                        color: groupPermissionDeleteModal ? '#FFFFFF' : '#333333'
                      }}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      삭제
                    </button>
                  </div>
                </div>
                <div className="overflow-x-auto" style={{ maxHeight: '200px', overflowY: 'auto' }}>
                  <table className="w-full">
                    <thead style={{ position: 'sticky', top: 0, backgroundColor: '#F8F9FA', zIndex: 1 }}>
                      <tr style={{ borderBottom: '1px solid #E8EAED' }}>
                        <th className="text-center px-3 py-3 text-sm font-medium" style={{ color: '#5F6368', width: '60px' }}>번호</th>
                        <th className="text-left px-3 py-3 text-sm font-medium" style={{ color: '#5F6368' }}>사용자ID</th>
                        <th className="text-left px-3 py-3 text-sm font-medium" style={{ color: '#5F6368' }}>사용자명</th>
                        <th className="text-left px-3 py-3 text-sm font-medium" style={{ color: '#5F6368' }}>조직</th>
                      </tr>
                    </thead>
                    <tbody>
                      {users.slice(0, 3).map((user, index) => (
                        <tr key={user.id} style={{ borderBottom: '1px solid #E8EAED' }}>
                          <td className="text-center px-3 py-2.5 text-sm" style={{ color: '#333333' }}>{index + 1}</td>
                          <td className="px-3 py-2.5 text-sm" style={{ color: '#333333' }}>{user.userId}</td>
                          <td className="px-3 py-2.5 text-sm" style={{ color: '#333333' }}>{user.userName}</td>
                          <td className="px-3 py-2.5 text-sm" style={{ color: '#333333' }}>{user.position}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </Card>

              {/* 추가 모달 */}
              <AnimatePresence>
                {groupPermissionAddModal && (
                  <motion.div
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="absolute top-12 right-0 z-50 rounded-lg shadow-lg border"
                    style={{ 
                      backgroundColor: '#FFFFFF',
                      borderColor: '#DADCE0',
                      width: '280px'
                    }}
                  >
                    <div className="p-4">
                      <div className="flex items-center justify-between mb-3">
                        <h4 className="text-sm font-medium" style={{ color: '#333333' }}>사용자 추가</h4>
                        <button onClick={() => setGroupPermissionAddModal(false)}>
                          <X className="w-4 h-4" style={{ color: '#5F6368' }} />
                        </button>
                      </div>
                      <div className="space-y-2 mb-3">
                        <input 
                          type="text" 
                          className="w-full px-3 py-2 rounded-lg border text-sm"
                          style={{ borderColor: '#DADCE0' }}
                          placeholder="사용자 검색"
                        />
                      </div>
                      <div className="flex gap-2">
                        <button
                          className="flex-1 px-3 py-2 rounded-lg text-sm font-medium"
                          style={{ backgroundColor: '#2B8DFF', color: '#FFFFFF' }}
                          onClick={() => setGroupPermissionAddModal(false)}
                        >
                          추가
                        </button>
                        <button
                          className="flex-1 px-3 py-2 rounded-lg text-sm font-medium"
                          style={{ backgroundColor: '#F1F3F4', color: '#333333' }}
                          onClick={() => setGroupPermissionAddModal(false)}
                        >
                          취소
                        </button>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* 삭제 모달 */}
              <AnimatePresence>
                {groupPermissionDeleteModal && (
                  <motion.div
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="absolute top-12 right-0 z-50 rounded-lg shadow-lg border"
                    style={{ 
                      backgroundColor: '#FFFFFF',
                      borderColor: '#DADCE0',
                      width: '280px'
                    }}
                  >
                    <div className="p-4">
                      <div className="flex items-center justify-between mb-3">
                        <h4 className="text-sm font-medium" style={{ color: '#333333' }}>사용자 삭제</h4>
                        <button onClick={() => setGroupPermissionDeleteModal(false)}>
                          <X className="w-4 h-4" style={{ color: '#5F6368' }} />
                        </button>
                      </div>
                      <p className="text-sm mb-3" style={{ color: '#5F6368' }}>
                        선택한 사용자를 삭제하시겠습니까?
                      </p>
                      <div className="flex gap-2">
                        <button
                          className="flex-1 px-3 py-2 rounded-lg text-sm font-medium"
                          style={{ backgroundColor: '#333333', color: '#FFFFFF' }}
                          onClick={() => setGroupPermissionDeleteModal(false)}
                        >
                          삭제
                        </button>
                        <button
                          className="flex-1 px-3 py-2 rounded-lg text-sm font-medium"
                          style={{ backgroundColor: '#F1F3F4', color: '#333333' }}
                          onClick={() => setGroupPermissionDeleteModal(false)}
                        >
                          취소
                        </button>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>

        {/* 3. 기능 그룹 관리 */}
        <div className="flex flex-col gap-4">
          {/* 검색 영역 */}
          <Card padding="lg">
            <div className="space-y-3">
              <label className="block text-sm font-medium" style={{ color: '#333333' }}>
                기능 그룹 권한 검색어입력
              </label>
              <input
                type="text"
                className="w-full px-3 py-2.5 rounded-lg border text-sm"
                style={{ 
                  borderColor: '#DADCE0',
                  backgroundColor: '#FFFFFF'
                }}
                placeholder="기능 그룹 검색"
              />
              <button 
                className="w-full px-4 py-2.5 rounded-lg text-sm font-medium transition-all"
                style={{ 
                  backgroundColor: '#2B8DFF',
                  color: '#FFFFFF'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.backgroundColor = '#1976D2';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor = '#2B8DFF';
                }}
              >
                검색
              </button>
            </div>
          </Card>

          {/* 기능 그룹 목록 */}
          <div className="relative">
            <Card padding="none">
              <div className="px-5 py-3 border-b flex items-center justify-between" style={{ borderColor: '#E8EAED', backgroundColor: '#F8F9FA' }}>
                <h3 className="text-sm font-medium" style={{ color: '#333333' }}>기능 그룹 목록</h3>
                <div className="flex gap-2">
                  <button
                    onClick={() => {
                      setFunctionGroupAddModal(!functionGroupAddModal);
                      setFunctionGroupDeleteModal(false);
                    }}
                    className="px-3 py-1.5 rounded-lg text-sm font-medium transition-all flex items-center gap-1"
                    style={{ 
                      backgroundColor: functionGroupAddModal ? '#2B8DFF' : '#F1F3F4',
                      color: functionGroupAddModal ? '#FFFFFF' : '#333333'
                    }}
                  >
                    <Plus className="w-3.5 h-3.5" />
                    추가
                  </button>
                  <button
                    onClick={() => {
                      setFunctionGroupDeleteModal(!functionGroupDeleteModal);
                      setFunctionGroupAddModal(false);
                    }}
                    className="px-3 py-1.5 rounded-lg text-sm font-medium transition-all flex items-center gap-1"
                    style={{ 
                      backgroundColor: functionGroupDeleteModal ? '#2B8DFF' : '#F1F3F4',
                      color: functionGroupDeleteModal ? '#FFFFFF' : '#333333'
                    }}
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    삭제
                  </button>
                </div>
              </div>
              <div className="overflow-x-auto" style={{ maxHeight: '280px', overflowY: 'auto' }}>
                <table className="w-full">
                  <thead style={{ position: 'sticky', top: 0, backgroundColor: '#F8F9FA', zIndex: 1 }}>
                    <tr style={{ borderBottom: '1px solid #E8EAED' }}>
                      <th className="text-center px-3 py-3 text-sm font-medium" style={{ color: '#5F6368', width: '50px' }}>
                        <input type="checkbox" className="w-4 h-4" />
                      </th>
                      <th className="text-center px-3 py-3 text-sm font-medium" style={{ color: '#5F6368', width: '60px' }}>번호</th>
                      <th className="text-left px-3 py-3 text-sm font-medium" style={{ color: '#5F6368' }}>그룹ID</th>
                      <th className="text-left px-3 py-3 text-sm font-medium" style={{ color: '#5F6368' }}>그룹명</th>
                    </tr>
                  </thead>
                  <tbody>
                    {functionGroups.map((group, index) => (
                      <tr 
                        key={group.id}
                        className="cursor-pointer transition-colors"
                        style={{ 
                          borderBottom: '1px solid #E8EAED',
                          backgroundColor: selectedFunctionGroupRows.includes(group.id) ? '#E8F0FE' : 'transparent'
                        }}
                        onClick={() => {
                          if (selectedFunctionGroupRows.includes(group.id)) {
                            setSelectedFunctionGroupRows(selectedFunctionGroupRows.filter(id => id !== group.id));
                          } else {
                            setSelectedFunctionGroupRows([...selectedFunctionGroupRows, group.id]);
                          }
                        }}
                        onMouseEnter={(e) => {
                          if (!selectedFunctionGroupRows.includes(group.id)) {
                            e.currentTarget.style.backgroundColor = '#F8F9FA';
                          }
                        }}
                        onMouseLeave={(e) => {
                          if (!selectedFunctionGroupRows.includes(group.id)) {
                            e.currentTarget.style.backgroundColor = 'transparent';
                          }
                        }}
                      >
                        <td className="text-center px-3 py-2.5">
                          <input type="checkbox" className="w-4 h-4" checked={selectedFunctionGroupRows.includes(group.id)} readOnly />
                        </td>
                        <td className="text-center px-3 py-2.5 text-sm" style={{ color: '#333333' }}>{index + 1}</td>
                        <td className="px-3 py-2.5 text-sm" style={{ color: '#333333' }}>{group.groupId}</td>
                        <td className="px-3 py-2.5 text-sm" style={{ color: '#333333' }}>{group.groupName}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="px-4 py-3 border-t flex items-center justify-between" style={{ borderColor: '#E8EAED' }}>
                <div className="flex items-center gap-2">
                  <span className="text-sm" style={{ color: '#5F6368' }}>5개씩 보기</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm" style={{ color: '#5F6368' }}>1 / 1</span>
                </div>
              </div>
            </Card>

            {/* 추가 모달 */}
            <AnimatePresence>
              {functionGroupAddModal && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="absolute top-12 right-0 z-50 rounded-lg shadow-lg border"
                  style={{ 
                    backgroundColor: '#FFFFFF',
                    borderColor: '#DADCE0',
                    width: '300px'
                  }}
                >
                  <div className="p-4">
                    <div className="flex items-center justify-between mb-4">
                      <h4 className="text-sm font-medium" style={{ color: '#333333' }}>기능 그룹 추가</h4>
                      <button onClick={() => setFunctionGroupAddModal(false)}>
                        <X className="w-4 h-4" style={{ color: '#5F6368' }} />
                      </button>
                    </div>
                    <div className="space-y-3">
                      <div>
                        <label className="block text-xs font-medium mb-1" style={{ color: '#5F6368' }}>그룹 ID</label>
                        <input 
                          type="text" 
                          className="w-full px-3 py-2 rounded-lg border text-sm"
                          style={{ borderColor: '#DADCE0' }}
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-medium mb-1" style={{ color: '#5F6368' }}>그룹명</label>
                        <input 
                          type="text" 
                          className="w-full px-3 py-2 rounded-lg border text-sm"
                          style={{ borderColor: '#DADCE0' }}
                        />
                      </div>
                      <div className="flex gap-2 pt-2">
                        <button
                          className="flex-1 px-3 py-2 rounded-lg text-sm font-medium"
                          style={{ backgroundColor: '#2B8DFF', color: '#FFFFFF' }}
                          onClick={() => setFunctionGroupAddModal(false)}
                        >
                          추가
                        </button>
                        <button
                          className="flex-1 px-3 py-2 rounded-lg text-sm font-medium"
                          style={{ backgroundColor: '#F1F3F4', color: '#333333' }}
                          onClick={() => setFunctionGroupAddModal(false)}
                        >
                          취소
                        </button>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* 삭제 모달 */}
            <AnimatePresence>
              {functionGroupDeleteModal && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="absolute top-12 right-0 z-50 rounded-lg shadow-lg border"
                  style={{ 
                    backgroundColor: '#FFFFFF',
                    borderColor: '#DADCE0',
                    width: '300px'
                  }}
                >
                  <div className="p-4">
                    <div className="flex items-center justify-between mb-4">
                      <h4 className="text-sm font-medium" style={{ color: '#333333' }}>기능 그룹 삭제</h4>
                      <button onClick={() => setFunctionGroupDeleteModal(false)}>
                        <X className="w-4 h-4" style={{ color: '#5F6368' }} />
                      </button>
                    </div>
                    <p className="text-sm mb-4" style={{ color: '#5F6368' }}>
                      선택한 기능 그룹을 삭제하시겠습니까?
                    </p>
                    <div className="flex gap-2">
                      <button
                        className="flex-1 px-3 py-2 rounded-lg text-sm font-medium"
                        style={{ backgroundColor: '#333333', color: '#FFFFFF' }}
                        onClick={() => setFunctionGroupDeleteModal(false)}
                      >
                        삭제
                      </button>
                      <button
                        className="flex-1 px-3 py-2 rounded-lg text-sm font-medium"
                        style={{ backgroundColor: '#F1F3F4', color: '#333333' }}
                        onClick={() => setFunctionGroupDeleteModal(false)}
                      >
                        취소
                      </button>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* 권한 설정 정보 - 기능 그룹 */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-medium" style={{ color: '#333333' }}>권한 설정 정보</h3>
              <button
                className="px-3 py-1.5 rounded-lg text-sm font-medium transition-all"
                style={{ backgroundColor: '#2B8DFF', color: '#FFFFFF' }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.backgroundColor = '#1976D2';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor = '#2B8DFF';
                }}
              >
                저장
              </button>
            </div>
            <div className="text-sm mb-3" style={{ color: '#5F6368' }}>기능그룹</div>
            <div className="relative">
              <Card padding="none">
                <div className="px-5 py-3 border-b flex items-center justify-between" style={{ borderColor: '#E8EAED', backgroundColor: '#F8F9FA' }}>
                  <h3 className="text-sm font-medium" style={{ color: '#333333' }}>기능 그룹 목록</h3>
                  <div className="flex gap-2">
                    <button
                      onClick={() => {
                        setFunctionPermissionAddModal(!functionPermissionAddModal);
                        setFunctionPermissionDeleteModal(false);
                      }}
                      className="px-3 py-1.5 rounded-lg text-sm font-medium transition-all flex items-center gap-1"
                      style={{ 
                        backgroundColor: functionPermissionAddModal ? '#2B8DFF' : '#F1F3F4',
                        color: functionPermissionAddModal ? '#FFFFFF' : '#333333'
                      }}
                    >
                      <Plus className="w-3.5 h-3.5" />
                      추가
                    </button>
                    <button
                      onClick={() => {
                        setFunctionPermissionDeleteModal(!functionPermissionDeleteModal);
                        setFunctionPermissionAddModal(false);
                      }}
                      className="px-3 py-1.5 rounded-lg text-sm font-medium transition-all flex items-center gap-1"
                      style={{ 
                        backgroundColor: functionPermissionDeleteModal ? '#2B8DFF' : '#F1F3F4',
                        color: functionPermissionDeleteModal ? '#FFFFFF' : '#333333'
                      }}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      삭제
                    </button>
                  </div>
                </div>
                <div className="overflow-x-auto" style={{ maxHeight: '200px', overflowY: 'auto' }}>
                  <table className="w-full">
                    <thead style={{ position: 'sticky', top: 0, backgroundColor: '#F8F9FA', zIndex: 1 }}>
                      <tr style={{ borderBottom: '1px solid #E8EAED' }}>
                        <th className="text-center px-3 py-3 text-sm font-medium" style={{ color: '#5F6368', width: '60px' }}>번호</th>
                        <th className="text-left px-3 py-3 text-sm font-medium" style={{ color: '#5F6368' }}>그룹ID</th>
                        <th className="text-left px-3 py-3 text-sm font-medium" style={{ color: '#5F6368' }}>그룹명</th>
                      </tr>
                    </thead>
                    <tbody>
                      {functionGroups.slice(0, 3).map((group, index) => (
                        <tr key={group.id} style={{ borderBottom: '1px solid #E8EAED' }}>
                          <td className="text-center px-3 py-2.5 text-sm" style={{ color: '#333333' }}>{index + 1}</td>
                          <td className="px-3 py-2.5 text-sm" style={{ color: '#333333' }}>{group.groupId}</td>
                          <td className="px-3 py-2.5 text-sm" style={{ color: '#333333' }}>{group.groupName}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </Card>

              {/* 추가 모달 */}
              <AnimatePresence>
                {functionPermissionAddModal && (
                  <motion.div
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="absolute top-12 right-0 z-50 rounded-lg shadow-lg border"
                    style={{ 
                      backgroundColor: '#FFFFFF',
                      borderColor: '#DADCE0',
                      width: '280px'
                    }}
                  >
                    <div className="p-4">
                      <div className="flex items-center justify-between mb-3">
                        <h4 className="text-sm font-medium" style={{ color: '#333333' }}>기능 그룹 추가</h4>
                        <button onClick={() => setFunctionPermissionAddModal(false)}>
                          <X className="w-4 h-4" style={{ color: '#5F6368' }} />
                        </button>
                      </div>
                      <div className="space-y-2 mb-3">
                        <input 
                          type="text" 
                          className="w-full px-3 py-2 rounded-lg border text-sm"
                          style={{ borderColor: '#DADCE0' }}
                          placeholder="기능 그룹 검색"
                        />
                      </div>
                      <div className="flex gap-2">
                        <button
                          className="flex-1 px-3 py-2 rounded-lg text-sm font-medium"
                          style={{ backgroundColor: '#2B8DFF', color: '#FFFFFF' }}
                          onClick={() => setFunctionPermissionAddModal(false)}
                        >
                          추가
                        </button>
                        <button
                          className="flex-1 px-3 py-2 rounded-lg text-sm font-medium"
                          style={{ backgroundColor: '#F1F3F4', color: '#333333' }}
                          onClick={() => setFunctionPermissionAddModal(false)}
                        >
                          취소
                        </button>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* 삭제 모달 */}
              <AnimatePresence>
                {functionPermissionDeleteModal && (
                  <motion.div
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="absolute top-12 right-0 z-50 rounded-lg shadow-lg border"
                    style={{ 
                      backgroundColor: '#FFFFFF',
                      borderColor: '#DADCE0',
                      width: '280px'
                    }}
                  >
                    <div className="p-4">
                      <div className="flex items-center justify-between mb-3">
                        <h4 className="text-sm font-medium" style={{ color: '#333333' }}>기능 그룹 삭제</h4>
                        <button onClick={() => setFunctionPermissionDeleteModal(false)}>
                          <X className="w-4 h-4" style={{ color: '#5F6368' }} />
                        </button>
                      </div>
                      <p className="text-sm mb-3" style={{ color: '#5F6368' }}>
                        선택한 기능 그룹을 삭제하시겠습니까?
                      </p>
                      <div className="flex gap-2">
                        <button
                          className="flex-1 px-3 py-2 rounded-lg text-sm font-medium"
                          style={{ backgroundColor: '#333333', color: '#FFFFFF' }}
                          onClick={() => setFunctionPermissionDeleteModal(false)}
                        >
                          삭제
                        </button>
                        <button
                          className="flex-1 px-3 py-2 rounded-lg text-sm font-medium"
                          style={{ backgroundColor: '#F1F3F4', color: '#333333' }}
                          onClick={() => setFunctionPermissionDeleteModal(false)}
                        >
                          취소
                        </button>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>

        {/* 4. 메뉴 관리 */}
        <div className="flex flex-col gap-4">
          {/* 검색 영역 */}
          <Card padding="lg">
            <div className="space-y-3">
              <label className="block text-sm font-medium" style={{ color: '#333333' }}>
                메뉴 권한 검색어입력
              </label>
              <input
                type="text"
                className="w-full px-3 py-2.5 rounded-lg border text-sm"
                style={{ 
                  borderColor: '#DADCE0',
                  backgroundColor: '#FFFFFF'
                }}
                placeholder="메뉴 검색"
              />
              <button 
                className="w-full px-4 py-2.5 rounded-lg text-sm font-medium transition-all"
                style={{ 
                  backgroundColor: '#2B8DFF',
                  color: '#FFFFFF'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.backgroundColor = '#1976D2';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor = '#2B8DFF';
                }}
              >
                검색
              </button>
            </div>
          </Card>

          {/* APP LIST */}
          <Card padding="none">
            <div className="px-5 py-3 border-b" style={{ borderColor: '#E8EAED', backgroundColor: '#F8F9FA' }}>
              <h3 className="text-sm font-medium" style={{ color: '#333333' }}>메뉴 관리</h3>
            </div>
            <div className="overflow-x-auto" style={{ maxHeight: '630px', overflowY: 'auto' }}>
              <table className="w-full">
                <thead style={{ position: 'sticky', top: 0, backgroundColor: '#F8F9FA', zIndex: 1 }}>
                  <tr style={{ borderBottom: '1px solid #E8EAED' }}>
                    <th className="text-center px-3 py-3 text-sm font-medium" style={{ color: '#5F6368', width: '50px' }}>
                      <input type="checkbox" className="w-4 h-4" />
                    </th>
                    <th className="text-left px-3 py-3 text-sm font-medium" style={{ color: '#5F6368' }}>APP LIST</th>
                    <th className="text-left px-3 py-3 text-sm font-medium" style={{ color: '#5F6368' }}>DataEye Portal</th>
                  </tr>
                </thead>
                <tbody>
                  {menuList.map((menu) => (
                    <Fragment key={menu.id}>
                      <tr 
                        style={{ 
                          borderBottom: '1px solid #E8EAED',
                          backgroundColor: '#FAFAFA'
                        }}
                      >
                        <td className="text-center px-3 py-2.5">
                          <input type="checkbox" className="w-4 h-4" />
                        </td>
                        <td className="px-3 py-2.5 text-sm font-medium" style={{ color: '#333333' }}>{menu.menuName}</td>
                        <td className="px-3 py-2.5">
                          <div className="flex items-center gap-2">
                            {Object.entries(menu.permissions).map(([key, value]) => (
                              <label key={`${menu.id}-perm-${key}`} className="flex items-center gap-1">
                                <input type="checkbox" className="w-3.5 h-3.5" checked={value} readOnly />
                                <span className="text-xs" style={{ color: '#5F6368' }}>
                                  {key === 'create' ? 'C' : key === 'read' ? 'R' : key === 'update' ? 'U' : key === 'delete' ? 'D' : 'E'}
                                </span>
                              </label>
                            ))}
                          </div>
                        </td>
                      </tr>
                      {menu.children?.map((child) => (
                        <tr 
                          key={child.id}
                          style={{ borderBottom: '1px solid #E8EAED' }}
                        >
                          <td className="text-center px-3 py-2.5">
                            <input type="checkbox" className="w-4 h-4" />
                          </td>
                          <td className="px-3 py-2.5 pl-8 text-sm" style={{ color: '#5F6368' }}>{child.menuName}</td>
                          <td className="px-3 py-2.5">
                            <div className="flex items-center gap-2">
                              {Object.entries(child.permissions).map(([key, value]) => (
                                <label key={`${child.id}-perm-${key}`} className="flex items-center gap-1">
                                  <input type="checkbox" className="w-3.5 h-3.5" checked={value} readOnly />
                                  <span className="text-xs" style={{ color: '#5F6368' }}>
                                    {key === 'create' ? 'C' : key === 'read' ? 'R' : key === 'update' ? 'U' : key === 'delete' ? 'D' : 'E'}
                                  </span>
                                </label>
                              ))}
                            </div>
                          </td>
                        </tr>
                      ))}
                    </Fragment>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>

          {/* 저장 버튼 */}
          <div className="flex justify-end">
            <button
              className="px-4 py-2 rounded-lg text-sm font-medium transition-all"
              style={{ backgroundColor: '#2B8DFF', color: '#FFFFFF' }}
              onMouseEnter={(e) => {
                e.currentTarget.style.backgroundColor = '#1976D2';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.backgroundColor = '#2B8DFF';
              }}
            >
              저장
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
