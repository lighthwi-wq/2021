import { useState, useMemo } from 'react';
import { Search, Database, Table2, FileText, Shield, AlertCircle, Settings2, BarChart3, Book, Filter, SlidersHorizontal, ChevronDown, Clock, TrendingUp, Star } from 'lucide-react';
import { Card } from '../components/common/Card';
import { Badge } from '../components/common/Badge';
import { MenuId } from '../types';

interface SearchResult {
  id: string;
  title: string;
  description: string;
  category: string;
  icon: any;
  menuId?: MenuId;
  type: 'menu' | 'data' | 'quality' | 'feature';
  tags?: string[];
  lastUpdated?: string;
  popularity?: number;
  status?: 'active' | 'pending' | 'draft';
}

interface SearchResultsPageProps {
  searchQuery: string;
  onNavigate: (menuId: MenuId) => void;
}

export function SearchResultsPage({ searchQuery = '', onNavigate }: SearchResultsPageProps) {
  const [query, setQuery] = useState(searchQuery);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'relevance' | 'recent' | 'popular'>('relevance');

  // 전체 검색 가능한 항목들
  const allSearchItems: SearchResult[] = [
    // 메뉴 항목
    { id: 'dashboard', title: '대시보드', description: '전체 시스템 현황 및 주요 지표를 한눈에 확인', category: '메뉴', icon: BarChart3, menuId: 'dashboard', type: 'menu', tags: ['통계', '현황', 'KPI'], lastUpdated: '2시간 전', popularity: 95, status: 'active' },
    { id: 'table-mgmt', title: '테이블 관리', description: '데이터베이스 테이블 메타데이터 관리', category: '메뉴', icon: Table2, menuId: 'table-mgmt', type: 'menu', tags: ['메타데이터', 'DB'], lastUpdated: '1일 전', popularity: 87, status: 'active' },
    { id: 'column-mgmt', title: '컬럼 관리', description: '테이블 컬럼 메타데이터 관리', category: '메뉴', icon: Database, menuId: 'column-mgmt', type: 'menu', tags: ['메타데이터', 'DB'], lastUpdated: '1일 전', popularity: 82, status: 'active' },
    { id: 'standard-word', title: '표준단어 사전', description: '표준화된 단어 및 용어 관리', category: '메뉴', icon: Book, menuId: 'standard-word', type: 'menu', tags: ['표준화', '사전'], lastUpdated: '3시간 전', popularity: 78, status: 'active' },
    { id: 'standard-domain', title: '표준도메인 사전', description: '데이터 도메인 표준 관리', category: '메뉴', icon: Book, menuId: 'standard-domain', type: 'menu', tags: ['표준화', '도메인'], lastUpdated: '5시간 전', popularity: 72, status: 'active' },
    { id: 'standard-code', title: '표준코드', description: '표준 코드 체계 관리', category: '메뉴', icon: FileText, menuId: 'standard-code', type: 'menu', tags: ['표준화', '코드'], lastUpdated: '1일 전', popularity: 68, status: 'active' },
    { id: 'standard-term', title: '표준용어 사전', description: '비즈니스 표준용어 관리', category: '메뉴', icon: Book, menuId: 'standard-term', type: 'menu', tags: ['표준화', '용어'], lastUpdated: '2시간 전', popularity: 85, status: 'active' },
    { id: 'biz-term', title: '업무용어 사전', description: '업무 도메인 용어 관리', category: '메뉴', icon: Book, menuId: 'biz-term', type: 'menu', tags: ['업무', '용어'], lastUpdated: '6시간 전', popularity: 75, status: 'active' },
    { id: 'biz-glossary', title: '용어집', description: '전사 용어 통합 관리', category: '메뉴', icon: Book, menuId: 'biz-glossary', type: 'menu', tags: ['용어', '통합'], lastUpdated: '1일 전', popularity: 70, status: 'active' },
    { id: 'quality-rule', title: '품질 규칙관리', description: '데이터 품질 규칙 정의 및 관리', category: '메뉴', icon: Shield, menuId: 'quality-rule', type: 'menu', tags: ['품질', '규칙'], lastUpdated: '4시간 전', popularity: 88, status: 'active' },
    { id: 'quality-diagnosis', title: '품질 진단관리', description: '품질 진단 실행 및 모니터링', category: '메뉴', icon: AlertCircle, menuId: 'quality-diagnosis', type: 'menu', tags: ['품질', '진단'], lastUpdated: '30분 전', popularity: 92, status: 'active' },
    { id: 'quality-violation', title: '품질 위반관리', description: '품질 위반 사항 추적 및 관리', category: '메뉴', icon: AlertCircle, menuId: 'quality-violation', type: 'menu', tags: ['품질', '위반'], lastUpdated: '1시간 전', popularity: 90, status: 'active' },
    { id: 'quality-action', title: '조치관리', description: '품질 개선 조치 사항 관리', category: '메뉴', icon: Settings2, menuId: 'quality-action', type: 'menu', tags: ['품질', '조치'], lastUpdated: '2시간 전', popularity: 84, status: 'active' },
    
    // 데이터 관련
    { id: 'data-catalog', title: '데이터 카탈로그', description: '전사 데이터 자산 카탈로그', category: '데이터', icon: Database, type: 'data', tags: ['카탈로그', '자산'], lastUpdated: '3일 전', popularity: 80, status: 'active' },
    { id: 'data-lineage', title: '데이터 계보', description: '데이터 흐름 및 의존성 추적', category: '데이터', icon: BarChart3, type: 'data', tags: ['계보', '흐름'], lastUpdated: '2일 전', popularity: 77, status: 'active' },
    { id: 'metadata-repository', title: '메타데이터 저장소', description: '메타데이터 통합 저장소', category: '데이터', icon: Database, type: 'data', tags: ['메타데이터', '저장소'], lastUpdated: '1일 전', popularity: 73, status: 'active' },
    { id: 'data-dictionary', title: '데이터 사전', description: '전사 데이터 정의 및 설명', category: '데이터', icon: Book, type: 'data', tags: ['사전', '정의'], lastUpdated: '4일 전', popularity: 65, status: 'active' },
    { id: 'data-model', title: '데이터 모델', description: '논리/물리 데이터 모델 관리', category: '데이터', icon: Database, type: 'data', tags: ['모델', 'ERD'], lastUpdated: '5일 전', popularity: 60, status: 'draft' },
    
    // 품질 관련
    { id: 'quality-score', title: '품질 점수', description: '전체 데이터 품질 점수 현황', category: '품질', icon: BarChart3, menuId: 'dashboard', type: 'quality', tags: ['점수', '지표'], lastUpdated: '1시간 전', popularity: 93, status: 'active' },
    { id: 'quality-completeness', title: '완전성 검증', description: 'NULL 값 및 필수값 검증', category: '품질', icon: Shield, type: 'quality', tags: ['완전성', '검증'], lastUpdated: '2시간 전', popularity: 86, status: 'active' },
    { id: 'quality-validity', title: '유효성 검증', description: '데이터 형식 및 범위 검증', category: '품질', icon: Shield, type: 'quality', tags: ['유효성', '검증'], lastUpdated: '3시간 전', popularity: 84, status: 'active' },
    { id: 'quality-accuracy', title: '정확성 검증', description: '데이터 정확도 검증', category: '품질', icon: Shield, type: 'quality', tags: ['정확성', '검증'], lastUpdated: '4시간 전', popularity: 82, status: 'active' },
    { id: 'quality-consistency', title: '일관성 검증', description: '데이터 일관성 검증', category: '품질', icon: Shield, type: 'quality', tags: ['일관성', '검증'], lastUpdated: '5시간 전', popularity: 80, status: 'active' },
    { id: 'quality-timeliness', title: '적시성 검증', description: '데이터 최신성 검증', category: '품질', icon: Shield, type: 'quality', tags: ['적시성', '검증'], lastUpdated: '6시간 전', popularity: 78, status: 'active' },
    
    // 기능
    { id: 'export-excel', title: '엑셀 내보내기', description: '데이터를 엑셀 형식으로 내보내기', category: '기능', icon: FileText, type: 'feature', tags: ['엑셀', '내보내기'], lastUpdated: '1일 전', popularity: 75, status: 'active' },
    { id: 'import-metadata', title: '메타데이터 가져오기', description: '외부 메타데이터 임포트', category: '기능', icon: Database, type: 'feature', tags: ['��져오기', '임포트'], lastUpdated: '2일 전', popularity: 70, status: 'active' },
    { id: 'schedule-diagnosis', title: '진단 스케줄링', description: '품질 진단 일정 설정', category: '기능', icon: Settings2, type: 'feature', tags: ['스케줄', '일정'], lastUpdated: '3일 전', popularity: 68, status: 'active' },
    { id: 'notification-config', title: '알림 설정', description: '품질 이슈 알림 설정', category: '기능', icon: Settings2, type: 'feature', tags: ['알림', '설정'], lastUpdated: '4일 전', popularity: 65, status: 'active' },
    { id: 'api-integration', title: 'API 연동', description: '외부 시스템 API 연동', category: '기능', icon: Settings2, type: 'feature', tags: ['API', '연동'], lastUpdated: '5일 전', popularity: 62, status: 'pending' },
  ];

  // 검색 필터링
  const filteredItems = useMemo(() => {
    let results = allSearchItems;

    // 검색어 필터
    if (query.trim() !== '') {
      results = results.filter(item => 
        item.title.toLowerCase().includes(query.toLowerCase()) ||
        item.description.toLowerCase().includes(query.toLowerCase()) ||
        item.category.toLowerCase().includes(query.toLowerCase()) ||
        item.tags?.some(tag => tag.toLowerCase().includes(query.toLowerCase()))
      );
    }

    // 카테고리 필터
    if (selectedCategory !== 'all') {
      results = results.filter(item => item.category === selectedCategory);
    }

    // 정렬
    if (sortBy === 'recent') {
      results.sort((a, b) => {
        const aTime = a.lastUpdated || '';
        const bTime = b.lastUpdated || '';
        return aTime.localeCompare(bTime);
      });
    } else if (sortBy === 'popular') {
      results.sort((a, b) => (b.popularity || 0) - (a.popularity || 0));
    }

    return results;
  }, [query, selectedCategory, sortBy]);

  // 카테고리 통계
  const categoryStats = useMemo(() => {
    const stats: Record<string, number> = { all: allSearchItems.length };
    allSearchItems.forEach(item => {
      stats[item.category] = (stats[item.category] || 0) + 1;
    });
    return stats;
  }, []);

  // 카테고리별 색상
  const getCategoryStyles = (category: string) => {
    switch (category) {
      case '메뉴': return { bg: 'bg-blue-50', text: 'text-blue-600', border: 'border-blue-200' };
      case '데이터': return { bg: 'bg-teal-50', text: 'text-teal-600', border: 'border-teal-200' };
      case '품질': return { bg: 'bg-orange-50', text: 'text-orange-600', border: 'border-orange-200' };
      case '기능': return { bg: 'bg-indigo-50', text: 'text-indigo-600', border: 'border-indigo-200' };
      default: return { bg: 'bg-gray-50', text: 'text-gray-600', border: 'border-gray-200' };
    }
  };

  // 항목 클릭 처리
  const handleItemClick = (item: SearchResult) => {
    if (item.menuId) {
      onNavigate(item.menuId);
    }
  };

  return (
    <div className="h-full flex flex-col gap-4 overflow-hidden">
      {/* 상단: 검색 헤더 */}
      <Card padding="md" className="flex-shrink-0">
        <div className="flex items-center justify-between gap-4">
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-2">
              <Search className="w-5 h-5" style={{ color: '#5F6368' }} />
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="검색어를 입력하세요..."
                className="flex-1 text-lg outline-none bg-transparent"
                style={{ color: '#202124' }}
                autoFocus
              />
            </div>
            <p className="text-sm" style={{ color: '#5F6368' }}>
              <span style={{ color: '#2B8DFF' }} className="font-bold">{filteredItems.length}개</span>의 결과를 찾았습니다
            </p>
          </div>

          {/* 정렬 옵션 */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setSortBy('relevance')}
              className={`px-3 py-1.5 rounded-lg text-sm transition-all duration-200 ${
                sortBy === 'relevance' 
                  ? 'bg-blue-50 text-blue-600 border border-blue-200' 
                  : 'bg-gray-50 text-gray-600 hover:bg-gray-100'
              }`}
            >
              관련성
            </button>
            <button
              onClick={() => setSortBy('recent')}
              className={`px-3 py-1.5 rounded-lg text-sm transition-all duration-200 flex items-center gap-1 ${
                sortBy === 'recent' 
                  ? 'bg-blue-50 text-blue-600 border border-blue-200' 
                  : 'bg-gray-50 text-gray-600 hover:bg-gray-100'
              }`}
            >
              <Clock className="w-3.5 h-3.5" />
              최신순
            </button>
            <button
              onClick={() => setSortBy('popular')}
              className={`px-3 py-1.5 rounded-lg text-sm transition-all duration-200 flex items-center gap-1 ${
                sortBy === 'popular' 
                  ? 'bg-blue-50 text-blue-600 border border-blue-200' 
                  : 'bg-gray-50 text-gray-600 hover:bg-gray-100'
              }`}
            >
              <TrendingUp className="w-3.5 h-3.5" />
              인기순
            </button>
          </div>
        </div>
      </Card>

      <div className="flex-1 flex gap-4 overflow-hidden">
        {/* 좌측: 카테고리 필터 */}
        <Card padding="md" className="w-64 flex-shrink-0 overflow-y-auto">
          <div className="flex items-center gap-2 mb-4">
            <Filter className="w-4 h-4" style={{ color: '#5F6368' }} />
            <h3 className="font-bold" style={{ color: '#202124' }}>필터</h3>
          </div>

          <div className="space-y-1">
            {[
              { key: 'all', label: '전체' },
              { key: '메뉴', label: '메뉴' },
              { key: '데이터', label: '데이터' },
              { key: '품질', label: '품질' },
              { key: '기능', label: '기능' },
            ].map(category => (
              <button
                key={category.key}
                onClick={() => setSelectedCategory(category.key)}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-sm transition-all duration-200 ${
                  selectedCategory === category.key
                    ? 'bg-blue-50 text-blue-600 border border-blue-200'
                    : 'hover:bg-gray-50 text-gray-700'
                }`}
              >
                <span>{category.label}</span>
                <span className={`px-2 py-0.5 rounded-full text-xs ${
                  selectedCategory === category.key ? 'bg-blue-100' : 'bg-gray-100'
                }`}>
                  {categoryStats[category.key] || 0}
                </span>
              </button>
            ))}
          </div>
        </Card>

        {/* 우측: 검색 결과 */}
        <div className="flex-1 overflow-y-auto">
          {filteredItems.length === 0 ? (
            <Card padding="lg" className="text-center">
              <Search className="w-16 h-16 mx-auto mb-4" style={{ color: '#DADCE0' }} />
              <h3 className="text-lg font-bold mb-2" style={{ color: '#202124' }}>
                검색 결과가 없습니다
              </h3>
              <p className="text-sm" style={{ color: '#5F6368' }}>
                다른 검색어로 다시 시도해보세요
              </p>
            </Card>
          ) : (
            <div className="space-y-3">
              {filteredItems.map((item, index) => {
                const Icon = item.icon;
                const styles = getCategoryStyles(item.category);
                
                return (
                  <Card 
                    key={item.id} 
                    padding="md"
                    className="group cursor-pointer transition-all duration-300 hover:shadow-lg"
                    style={{
                      animation: `fadeInUp 0.4s ease-out ${index * 0.05}s both`,
                    }}
                    onClick={() => handleItemClick(item)}
                  >
                    <div className="flex items-start gap-4">
                      <div className={`p-3 rounded-xl ${styles.bg} border ${styles.border} transition-all duration-300 group-hover:scale-110 group-hover:shadow-md`}>
                        <Icon className={`w-6 h-6 ${styles.text}`} />
                      </div>
                      
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-4 mb-2">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <h3 className="font-bold transition-colors duration-200 group-hover:text-blue-600" style={{ color: '#202124' }}>
                                {item.title}
                              </h3>
                              {item.status === 'pending' && (
                                <Badge variant="warning" size="sm">대기중</Badge>
                              )}
                              {item.status === 'draft' && (
                                <Badge variant="secondary" size="sm">임시저장</Badge>
                              )}
                            </div>
                            <p className="text-sm mb-2" style={{ color: '#5F6368' }}>
                              {item.description}
                            </p>
                            
                            {/* 태그 */}
                            {item.tags && item.tags.length > 0 && (
                              <div className="flex flex-wrap gap-1.5">
                                {item.tags.map(tag => (
                                  <span
                                    key={tag}
                                    className="px-2 py-0.5 rounded-full text-xs bg-gray-100"
                                    style={{ color: '#5F6368' }}
                                  >
                                    #{tag}
                                  </span>
                                ))}
                              </div>
                            )}
                          </div>
                          
                          <div className="flex flex-col items-end gap-2">
                            <span className={`px-2.5 py-1 rounded-lg text-xs border ${styles.bg} ${styles.text} ${styles.border}`}>
                              {item.category}
                            </span>
                            {item.popularity && (
                              <div className="flex items-center gap-1">
                                <Star className="w-3 h-3" style={{ color: '#F59E0B', fill: '#F59E0B' }} />
                                <span className="text-xs" style={{ color: '#5F6368' }}>
                                  {item.popularity}
                                </span>
                              </div>
                            )}
                          </div>
                        </div>
                        
                        {/* 메타 정보 */}
                        <div className="flex items-center gap-3 text-xs" style={{ color: '#5F6368' }}>
                          <div className="flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            <span>{item.lastUpdated}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </Card>
                );
              })}
            </div>
          )}
        </div>
      </div>

      <style>{`
        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(10px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>
    </div>
  );
}
