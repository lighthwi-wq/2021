import { BarChart3, TrendingUp, Users } from 'lucide-react';
import { Card } from '../components/common/Card';
import { IconBox } from '../components/common/IconBox';
import { TrendChart } from '../components/dashboard/TrendChart';
import { ApiChart } from '../components/dashboard/ApiChart';

export function AnalyticsPage() {
  const metrics = [
    { label: '총 이벤트', value: '2.4M', icon: BarChart3, color: 'indigo' as const },
    { label: '성장률', value: '+24.5%', icon: TrendingUp, color: 'blue' as const },
    { label: '활성 사용자', value: '12.8K', icon: Users, color: 'green' as const },
  ];

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {metrics.map((metric, idx) => (
          <Card key={idx} padding="lg">
            <div className="flex items-center gap-4 mb-4">
              <IconBox icon={metric.icon} color={metric.color} size="lg" />
              <div>
                <p style={{ color: '#5F6368' }}>{metric.label}</p>
                <h3 className="font-bold" style={{ color: '#202124' }}>{metric.value}</h3>
              </div>
            </div>
          </Card>
        ))}
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <TrendChart />
        <ApiChart />
      </div>
    </div>
  );
}