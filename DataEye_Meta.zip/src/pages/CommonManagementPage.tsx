import { FolderCog, Settings as SettingsIcon, Bell, History, User, Database } from 'lucide-react';
import { Card } from '../components/common/Card';
import { IconBox } from '../components/common/IconBox';
import { Badge } from '../components/common/Badge';

export function CommonManagementPage() {
  const systemSettings = [
    { name: '시스템 설정', desc: '기본 설정, 권한관리, 코드관리', icon: SettingsIcon, color: 'blue' as const },
    { name: '알림 관리', desc: '알림설정, 알림이력', icon: Bell, color: 'orange' as const },
    { name: '이력 관리', desc: '작업 이력 조회, 변경 이력 추적', icon: History, color: 'green' as const },
  ];

  const notifications = [
    { type: '시스템', message: '데이터 품질 점검 완료', time: '5분 전', status: 'success' },
    { type: '알림', message: '표준용어 승인 요청', time: '15분 전', status: 'info' },
    { type: '경고', message: '품질 규칙 위반 감지', time: '1시간 전', status: 'warning' },
    { type: '시스템', message: '자동 동기화 완료', time: '2시간 전', status: 'success' },
  ];

  const recentHistory = [
    { user: '김민지', action: '표준용어 수정', target: 'CUST_NM', time: '10분 전' },
    { user: '이지훈', action: '품질규칙 추가', target: '필수값 검증', time: '25분 전' },
    { user: '박서윤', action: '업무영역 승인', target: '고객관리', time: '1시간 전' },
    { user: '최동현', action: '데이터 연계 매핑', target: '주문 테이블', time: '2시간 전' },
  ];

  const systemStats = [
    { label: '활성 사용자', value: '24', icon: User },
    { label: '데이터 소스', value: '12', icon: Database },
    { label: '오늘 알림', value: '38', icon: Bell },
    { label: '이력 기록', value: '1,247', icon: History },
  ];

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 mb-6">
        {systemStats.map((stat, idx) => (
          <Card key={idx} padding="lg">
            <div className="flex items-center gap-4">
              <IconBox icon={stat.icon} color="gray" size="md" />
              <div>
                <p className="mb-1" style={{ color: '#5F6368' }}>{stat.label}</p>
                <h3 className="font-bold" style={{ color: '#202124' }}>{stat.value}</h3>
              </div>
            </div>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card padding="lg">
          <div className="flex items-center gap-3 mb-6">
            <IconBox icon={FolderCog} color="blue" size="md" />
            <h3 className="font-bold" style={{ color: '#202124' }}>공통 관리 기능</h3>
          </div>
          <div className="space-y-4">
            {systemSettings.map((setting, idx) => (
              <div 
                key={idx} 
                className="p-4 rounded-xl border transition-all cursor-pointer"
                style={{ backgroundColor: '#F9F9F9', borderColor: '#DADCE0' }}
                onMouseEnter={(e) => e.currentTarget.style.borderColor = '#2B8DFF'}
                onMouseLeave={(e) => e.currentTarget.style.borderColor = '#DADCE0'}
              >
                <div className="flex items-start gap-4">
                  <IconBox icon={setting.icon} color={setting.color} size="sm" />
                  <div>
                    <h4 className="font-bold mb-1" style={{ color: '#202124' }}>{setting.name}</h4>
                    <p style={{ color: '#5F6368' }}>{setting.desc}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </Card>

        <Card padding="lg">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <IconBox icon={Bell} color="orange" size="md" />
              <h3 className="font-bold" style={{ color: '#202124' }}>알림 관리</h3>
            </div>
            <Badge variant="error">4</Badge>
          </div>
          <div className="space-y-3">
            {notifications.map((notif, idx) => (
              <div key={idx} className="p-3 rounded-xl border" style={{ backgroundColor: '#F9F9F9', borderColor: '#DADCE0' }}>
                <div className="flex items-start justify-between mb-2">
                  <Badge variant={
                    notif.status === 'success' ? 'success' : 
                    notif.status === 'warning' ? 'warning' : 'info'
                  }>
                    {notif.type}
                  </Badge>
                  <span className="text-xs" style={{ color: '#5F6368' }}>{notif.time}</span>
                </div>
                <p style={{ color: '#202124' }}>{notif.message}</p>
              </div>
            ))}
          </div>
        </Card>

        <Card padding="lg">
          <div className="flex items-center gap-3 mb-6">
            <IconBox icon={History} color="green" size="md" />
            <h3 className="font-bold" style={{ color: '#202124' }}>이력 관리</h3>
          </div>
          <div className="space-y-3">
            {recentHistory.map((history, idx) => (
              <div key={idx} className="pb-3 border-b last:border-0" style={{ borderColor: '#DADCE0' }}>
                <div className="flex items-start justify-between mb-1">
                  <h4 className="font-bold" style={{ color: '#202124' }}>{history.action}</h4>
                  <span className="text-xs" style={{ color: '#5F6368' }}>{history.time}</span>
                </div>
                <p className="mb-1" style={{ color: '#5F6368' }}>{history.target}</p>
                <p style={{ color: '#5F6368' }}>by {history.user}</p>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <Card padding="lg">
        <div className="flex items-center gap-3 mb-6">
          <IconBox icon={SettingsIcon} color="gray" size="md" />
          <h3 className="font-bold" style={{ color: '#202124' }}>시스템 설정</h3>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[
            { label: '기본 설정', value: '시스템 기본 구성' },
            { label: '권한 관리', value: '사용자 역할 및 권한' },
            { label: '코드 관리', value: '공통 코드 관리' },
            { label: '백업 설정', value: '자동 백업 구성' },
            { label: '로그 설정', value: '시스템 로그 관리' },
            { label: '보안 설정', value: '보안 정책 구성' },
          ].map((setting, idx) => (
            <div key={idx} className="p-4 rounded-xl border" style={{ backgroundColor: '#F9F9F9', borderColor: '#DADCE0' }}>
              <h4 className="font-bold mb-1" style={{ color: '#202124' }}>{setting.label}</h4>
              <p style={{ color: '#5F6368' }}>{setting.value}</p>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
