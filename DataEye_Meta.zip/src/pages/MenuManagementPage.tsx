import { Menu, Plus, Filter, MoveVertical, Folder, ChevronRight, ArrowUpDown, ChevronUp, ChevronDown, Edit, Trash2, X, Settings } from 'lucide-react';
import { Card } from '../components/common/Card';
import { IconBox } from '../components/common/IconBox';
import { Button } from '../components/common/Button';
import { Badge } from '../components/common/Badge';
import { Pagination } from '../components/common/Pagination';
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { colors } from '../constants/designSystem';

interface MenuFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  mode: 'create' | 'edit';
  menuData?: any;
}

function MenuFormModal({ isOpen, onClose, mode, menuData }: MenuFormModalProps) {
  const [formData, setFormData] = useState({
    id: menuData?.id || '',
    name: menuData?.name || '',
    parentMenu: menuData?.parentMenu || '',
    level: menuData?.level || 1,
    order: menuData?.order || 1,
    status: menuData?.status || '사용',
    description: menuData?.description || '',
    icon: '',
    route: ''
  });

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  const handleChange = (field: string, value: string | number) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('메뉴 저장:', formData);
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          className="fixed right-0 top-0 h-screen w-[600px] z-50 shadow-2xl overflow-hidden flex flex-col border-l"
          style={{
            backgroundColor: colors.bgPrimary,
            borderColor: colors.border,
          }}
          initial={{ x: '100%' }}
          animate={{ x: 0 }}
          exit={{ x: '100%' }}
          transition={{ 
            type: 'spring',
            damping: 30,
            stiffness: 300
          }}
        >
          {/* Header */}
          <div
            className="px-8 py-6 border-b flex items-center justify-between flex-shrink-0"
            style={{
              backgroundColor: colors.bgPrimary,
              borderColor: colors.border,
            }}
          >
            <div>
              <h2 className="text-xl font-bold" style={{ color: colors.textPrimary }}>
                {mode === 'create' ? '메뉴 추가' : '메뉴 수정'}
              </h2>
              <p className="text-sm mt-1" style={{ color: colors.textSecondary }}>
                {mode === 'create'
                  ? '새로운 메뉴를 시스템에 추가합니다'
                  : '기존 메뉴의 정보를 수정합니다'}
              </p>
            </div>
            <button
              onClick={onClose}
              className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
              style={{ color: colors.textSecondary }}
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto px-8 py-6">
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* 헤더 정보 */}
              <div 
                className="flex items-start gap-4 p-6 rounded-xl border"
                style={{
                  backgroundColor: colors.bgSecondary,
                  borderColor: colors.border
                }}
              >
                <div 
                  className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0"
                  style={{
                    backgroundColor: 'rgba(43, 141, 255, 0.15)'
                  }}
                >
                  <Settings className="w-6 h-6" style={{ color: '#2B8DFF' }} />
                </div>
                <div className="flex-1">
                  <h3 
                    className="font-bold mb-1"
                    style={{ color: colors.textPrimary }}
                  >
                    {mode === 'create' ? '새로운 메뉴 등록' : '메뉴 정보 수정'}
                  </h3>
                  <p 
                    className="text-sm"
                    style={{ color: colors.textSecondary }}
                  >
                    {mode === 'create' 
                      ? '시스템의 메뉴 구조를 설정합니다' 
                      : '기존 메뉴의 정보를 업데이트합니다'}
                  </p>
                </div>
              </div>

              {/* 기본 정보 섹션 */}
              <div 
                className="rounded-xl p-6 border space-y-5"
                style={{
                  backgroundColor: colors.bgSecondary,
                  borderColor: colors.border
                }}
              >
                <h4 
                  className="font-bold mb-4 flex items-center gap-2"
                  style={{ color: colors.textPrimary }}
                >
                  <div className="w-1.5 h-5 rounded-full" style={{ backgroundColor: '#2B8DFF' }}></div>
                  기본 정보
                </h4>

                <div>
                  <label className="block mb-2 font-bold" style={{ color: colors.textSecondary }}>
                    메뉴 ID <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    className="w-full px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent font-mono transition-all"
                    style={{
                      backgroundColor: colors.bgPrimary,
                      borderWidth: '1px',
                      borderStyle: 'solid',
                      borderColor: colors.border,
                      color: colors.textPrimary
                    }}
                    placeholder="M001"
                    value={formData.id}
                    onChange={(e) => handleChange('id', e.target.value)}
                    required
                  />
                </div>

                <div>
                  <label className="block mb-2 font-bold" style={{ color: colors.textSecondary }}>
                    메뉴명 <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    className="w-full px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                    style={{
                      backgroundColor: colors.bgPrimary,
                      borderWidth: '1px',
                      borderStyle: 'solid',
                      borderColor: colors.border,
                      color: colors.textPrimary
                    }}
                    placeholder="메뉴명 입력"
                    value={formData.name}
                    onChange={(e) => handleChange('name', e.target.value)}
                    required
                  />
                </div>

                <div>
                  <label className="block mb-2 font-bold" style={{ color: colors.textSecondary }}>
                    상위 메뉴
                  </label>
                  <select 
                    className="w-full px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                    style={{
                      backgroundColor: colors.bgPrimary,
                      borderWidth: '1px',
                      borderStyle: 'solid',
                      borderColor: colors.border,
                      color: colors.textPrimary
                    }}
                    value={formData.parentMenu}
                    onChange={(e) => handleChange('parentMenu', e.target.value)}
                  >
                    <option value="">없음 (최상위)</option>
                    <option value="M001">데이터 표준화</option>
                    <option value="M002">비즈메타</option>
                    <option value="M003">데이터 품질</option>
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block mb-2 font-bold" style={{ color: colors.textSecondary }}>
                      레벨 <span className="text-red-500">*</span>
                    </label>
                    <select 
                      className="w-full px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                      style={{
                        backgroundColor: colors.bgPrimary,
                        borderWidth: '1px',
                        borderStyle: 'solid',
                        borderColor: colors.border,
                        color: colors.textPrimary
                      }}
                      value={formData.level}
                      onChange={(e) => handleChange('level', parseInt(e.target.value))}
                    >
                      <option value="1">Level 1</option>
                      <option value="2">Level 2</option>
                      <option value="3">Level 3</option>
                    </select>
                  </div>

                  <div>
                    <label className="block mb-2 font-bold" style={{ color: colors.textSecondary }}>
                      순서 <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="number"
                      className="w-full px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                      style={{
                        backgroundColor: colors.bgPrimary,
                        borderWidth: '1px',
                        borderStyle: 'solid',
                        borderColor: colors.border,
                        color: colors.textPrimary
                      }}
                      placeholder="1"
                      value={formData.order}
                      onChange={(e) => handleChange('order', parseInt(e.target.value))}
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block mb-2 font-bold" style={{ color: colors.textSecondary }}>
                    상태
                  </label>
                  <select 
                    className="w-full px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                    style={{
                      backgroundColor: colors.bgPrimary,
                      borderWidth: '1px',
                      borderStyle: 'solid',
                      borderColor: colors.border,
                      color: colors.textPrimary
                    }}
                    value={formData.status}
                    onChange={(e) => handleChange('status', e.target.value)}
                  >
                    <option value="사용">사용</option>
                    <option value="미사용">미사용</option>
                  </select>
                </div>
              </div>

              {/* 상세 정보 섹션 */}
              <div 
                className="rounded-xl p-6 border space-y-5"
                style={{
                  backgroundColor: colors.bgSecondary,
                  borderColor: colors.border
                }}
              >
                <h4 
                  className="font-bold mb-4 flex items-center gap-2"
                  style={{ color: colors.textPrimary }}
                >
                  <div className="w-1.5 h-5 bg-green-500 rounded-full"></div>
                  상세 정보
                </h4>

                <div>
                  <label className="block mb-2 font-bold" style={{ color: colors.textSecondary }}>
                    설명
                  </label>
                  <textarea
                    className="w-full px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all resize-none"
                    style={{
                      backgroundColor: colors.bgPrimary,
                      borderWidth: '1px',
                      borderStyle: 'solid',
                      borderColor: colors.border,
                      color: colors.textPrimary
                    }}
                    rows={3}
                    placeholder="메뉴 설명 입력"
                    value={formData.description}
                    onChange={(e) => handleChange('description', e.target.value)}
                  />
                </div>

                <div>
                  <label className="block mb-2 font-bold" style={{ color: colors.textSecondary }}>
                    아이콘
                  </label>
                  <input
                    type="text"
                    className="w-full px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent font-mono transition-all"
                    style={{
                      backgroundColor: colors.bgPrimary,
                      borderWidth: '1px',
                      borderStyle: 'solid',
                      borderColor: colors.border,
                      color: colors.textPrimary
                    }}
                    placeholder="lucide-react 아이콘명"
                    value={formData.icon}
                    onChange={(e) => handleChange('icon', e.target.value)}
                  />
                </div>

                <div>
                  <label className="block mb-2 font-bold" style={{ color: colors.textSecondary }}>
                    라우트 경로
                  </label>
                  <input
                    type="text"
                    className="w-full px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent font-mono transition-all"
                    style={{
                      backgroundColor: colors.bgPrimary,
                      borderWidth: '1px',
                      borderStyle: 'solid',
                      borderColor: colors.border,
                      color: colors.textPrimary
                    }}
                    placeholder="/path/to/page"
                    value={formData.route}
                    onChange={(e) => handleChange('route', e.target.value)}
                  />
                </div>
              </div>
            </form>
          </div>

          {/* Footer */}
          <div
            className="px-8 py-4 border-t flex items-center justify-end gap-3 flex-shrink-0"
            style={{
              backgroundColor: colors.bgPrimary,
              borderColor: colors.border,
            }}
          >
            <Button type="button" variant="secondary" onClick={onClose}>
              취소
            </Button>
            <Button type="submit" variant="primary" onClick={handleSubmit}>
              {mode === 'create' ? '추가' : '수정'}
            </Button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

export function MenuManagementPage() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState<'create' | 'edit'>('create');
  const [selectedMenu, setSelectedMenu] = useState<any>(null);
  const [sortField, setSortField] = useState<string>('');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [filters, setFilters] = useState<Record<string, string>>({});
  const [activeFilterColumn, setActiveFilterColumn] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);

  const handleAddClick = () => {
    setModalMode('create');
    setSelectedMenu(null);
    setIsModalOpen(true);
  };

  const handleEditClick = (menu: any) => {
    setModalMode('edit');
    setSelectedMenu(menu);
    setIsModalOpen(true);
  };

  const handleSort = (field: string) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const handleFilter = (field: string, value: string) => {
    setFilters(prev => {
      const newFilters = { ...prev };
      if (value === '') {
        delete newFilters[field];
      } else {
        newFilters[field] = value;
      }
      return newFilters;
    });
    setActiveFilterColumn(null);
  };

  const getUniqueValues = (field: string) => {
    const values = menus.map(menu => String(menu[field as keyof typeof menu]));
    return Array.from(new Set(values)).sort();
  };

  const FilterDropdown = ({ field }: { field: string }) => {
    if (activeFilterColumn !== field) return null;
    
    const uniqueValues = getUniqueValues(field);
    
    return (
      <div 
        className="absolute top-full left-0 mt-1 bg-white rounded-lg shadow-lg border border-gray-200 z-50 min-w-[200px]"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-2 max-h-[300px] overflow-y-auto">
          <div
            className="px-3 py-2 hover:bg-gray-50 cursor-pointer rounded text-sm"
            onClick={() => handleFilter(field, '')}
            style={{ color: filters[field] === '' || !filters[field] ? '#2B8DFF' : '#5F6368' }}
          >
            전체
          </div>
          {uniqueValues.map((value) => (
            <div
              key={value}
              className="px-3 py-2 hover:bg-gray-50 cursor-pointer rounded text-sm"
              onClick={() => handleFilter(field, value)}
              style={{ color: filters[field] === value ? '#2B8DFF' : '#5F6368' }}
            >
              {value}
            </div>
          ))}
        </div>
      </div>
    );
  };

  const SortIcon = ({ field }: { field: string }) => {
    if (sortField !== field) {
      return <ArrowUpDown className="w-3.5 h-3.5 text-gray-400 ml-1" />;
    }
    return sortDirection === 'asc' ? (
      <ChevronUp className="w-3.5 h-3.5 ml-1" style={{ color: '#2B8DFF' }} />
    ) : (
      <ChevronDown className="w-3.5 h-3.5 ml-1" style={{ color: '#2B8DFF' }} />
    );
  };

  const menus = [
    { id: 'M001', name: '데이터 표준화', parentMenu: '-', level: 1, order: 1, status: '사용', description: '데이터 표준화 관리 메뉴' },
    { id: 'M001-1', name: '표준용어관리', parentMenu: '데이터 표준화', level: 2, order: 1, status: '사용', description: '표준용어 등록 및 관리' },
    { id: 'M001-2', name: '메뉴관리', parentMenu: '데이터 표준화', level: 2, order: 2, status: '사용', description: '메뉴 구조 관리' },
    { id: 'M002', name: '비즈메타', parentMenu: '-', level: 1, order: 2, status: '사용', description: '비즈니스 메타데이터 관리' },
    { id: 'M002-1', name: '업무 영역 관리', parentMenu: '비즈메타', level: 2, order: 1, status: '사용', description: '업무 영역 정의 및 관리' },
    { id: 'M003', name: '데이터 품질', parentMenu: '-', level: 1, order: 3, status: '사용', description: '데이터 품질 관리' },
  ];

  const filteredMenus = menus.filter(menu => {
    return Object.entries(filters).every(([field, value]) => {
      return String(menu[field as keyof typeof menu]) === value;
    });
  });

  const sortedMenus = [...filteredMenus].sort((a, b) => {
    if (!sortField) return 0;
    
    let aVal = a[sortField as keyof typeof a];
    let bVal = b[sortField as keyof typeof b];
    
    if (typeof aVal === 'number' && typeof bVal === 'number') {
      return sortDirection === 'asc' ? aVal - bVal : bVal - aVal;
    }
    
    const aStr = String(aVal).toLowerCase();
    const bStr = String(bVal).toLowerCase();
    
    if (sortDirection === 'asc') {
      return aStr < bStr ? -1 : aStr > bStr ? 1 : 0;
    } else {
      return aStr > bStr ? -1 : aStr < bStr ? 1 : 0;
    }
  });

  const totalPages = Math.ceil(sortedMenus.length / itemsPerPage);
  const currentMenus = sortedMenus.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  return (
    <div className="flex gap-0 h-full relative">
      {/* 메인 콘텐츠 영역 */}
      <motion.div
        className="flex-1 overflow-auto"
        animate={{
          marginRight: isModalOpen ? '600px' : '0px'
        }}
        transition={{ 
          type: 'spring',
          damping: 30,
          stiffness: 300
        }}
      >
        <div className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 mb-6">
            <Card padding="lg">
              <IconBox icon={Menu} color="blue" size="md" />
              <div className="mt-3">
                <p className="mb-1" style={{ color: '#5F6368' }}>전체 메뉴</p>
                <h3 className="font-bold" style={{ color: '#202124' }}>48</h3>
              </div>
            </Card>
            <Card padding="lg">
              <IconBox icon={Menu} color="green" size="md" />
              <div className="mt-3">
                <p className="mb-1" style={{ color: '#5F6368' }}>1레벨 메뉴</p>
                <h3 className="font-bold" style={{ color: '#202124' }}>6</h3>
              </div>
            </Card>
            <Card padding="lg">
              <IconBox icon={Menu} color="indigo" size="md" />
              <div className="mt-3">
                <p className="mb-1" style={{ color: '#5F6368' }}>2레벨 메뉴</p>
                <h3 className="font-bold" style={{ color: '#202124' }}>28</h3>
              </div>
            </Card>
            <Card padding="lg">
              <IconBox icon={Menu} color="orange" size="md" />
              <div className="mt-3">
                <p className="mb-1" style={{ color: '#5F6368' }}>3레벨 메뉴</p>
                <h3 className="font-bold" style={{ color: '#202124' }}>14</h3>
              </div>
            </Card>
          </div>

          <Card padding="lg">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <IconBox icon={Menu} color="blue" size="md" />
                <h3 className="font-bold" style={{ color: '#202124' }}>메뉴 구조 관리</h3>
              </div>
              <div className="flex gap-3">
                <Button variant="secondary" icon={<MoveVertical className="w-4 h-4" />} size="sm">순서변경</Button>
                <Button variant="primary" icon={<Plus className="w-4 h-4" />} size="sm" onClick={handleAddClick}>메뉴 추가</Button>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full">
                <thead style={{ backgroundColor: '#F7F8FA' }}>
                  <tr style={{ borderBottom: '1px solid #DADCE0' }}>
                    <th 
                      className="px-4 py-3 text-left text-sm hover:bg-gray-100 transition-colors relative" 
                      style={{ color: '#5F6368' }}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center cursor-pointer" onClick={() => handleSort('id')}>
                          메뉴ID
                          <SortIcon field="id" />
                        </div>
                        <Filter 
                          className="w-3.5 h-3.5 ml-2 cursor-pointer hover:text-blue-600" 
                          style={{ color: filters['id'] ? '#2B8DFF' : '#9CA3AF' }}
                          onClick={(e) => {
                            e.stopPropagation();
                            setActiveFilterColumn(activeFilterColumn === 'id' ? null : 'id');
                          }}
                        />
                        <FilterDropdown field="id" />
                      </div>
                    </th>
                    <th 
                      className="px-4 py-3 text-left text-sm hover:bg-gray-100 transition-colors relative" 
                      style={{ color: '#5F6368' }}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center cursor-pointer" onClick={() => handleSort('name')}>
                          메뉴명
                          <SortIcon field="name" />
                        </div>
                        <Filter 
                          className="w-3.5 h-3.5 ml-2 cursor-pointer hover:text-blue-600" 
                          style={{ color: filters['name'] ? '#2B8DFF' : '#9CA3AF' }}
                          onClick={(e) => {
                            e.stopPropagation();
                            setActiveFilterColumn(activeFilterColumn === 'name' ? null : 'name');
                          }}
                        />
                        <FilterDropdown field="name" />
                      </div>
                    </th>
                    <th 
                      className="px-4 py-3 text-left text-sm hover:bg-gray-100 transition-colors relative" 
                      style={{ color: '#5F6368' }}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center cursor-pointer" onClick={() => handleSort('parentMenu')}>
                          상위메뉴
                          <SortIcon field="parentMenu" />
                        </div>
                        <Filter 
                          className="w-3.5 h-3.5 ml-2 cursor-pointer hover:text-blue-600" 
                          style={{ color: filters['parentMenu'] ? '#2B8DFF' : '#9CA3AF' }}
                          onClick={(e) => {
                            e.stopPropagation();
                            setActiveFilterColumn(activeFilterColumn === 'parentMenu' ? null : 'parentMenu');
                          }}
                        />
                        <FilterDropdown field="parentMenu" />
                      </div>
                    </th>
                    <th 
                      className="px-4 py-3 text-left text-sm hover:bg-gray-100 transition-colors relative" 
                      style={{ color: '#5F6368' }}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center cursor-pointer" onClick={() => handleSort('level')}>
                          레벨
                          <SortIcon field="level" />
                        </div>
                        <Filter 
                          className="w-3.5 h-3.5 ml-2 cursor-pointer hover:text-blue-600" 
                          style={{ color: filters['level'] ? '#2B8DFF' : '#9CA3AF' }}
                          onClick={(e) => {
                            e.stopPropagation();
                            setActiveFilterColumn(activeFilterColumn === 'level' ? null : 'level');
                          }}
                        />
                        <FilterDropdown field="level" />
                      </div>
                    </th>
                    <th className="px-4 py-3 text-left text-sm" style={{ color: '#5F6368' }}>순서</th>
                    <th 
                      className="px-4 py-3 text-left text-sm hover:bg-gray-100 transition-colors relative" 
                      style={{ color: '#5F6368' }}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center cursor-pointer" onClick={() => handleSort('status')}>
                          상태
                          <SortIcon field="status" />
                        </div>
                        <Filter 
                          className="w-3.5 h-3.5 ml-2 cursor-pointer hover:text-blue-600" 
                          style={{ color: filters['status'] ? '#2B8DFF' : '#9CA3AF' }}
                          onClick={(e) => {
                            e.stopPropagation();
                            setActiveFilterColumn(activeFilterColumn === 'status' ? null : 'status');
                          }}
                        />
                        <FilterDropdown field="status" />
                      </div>
                    </th>
                    <th className="px-4 py-3 text-left text-sm" style={{ color: '#5F6368' }}>설명</th>
                    <th className="px-4 py-3 text-left text-sm" style={{ color: '#5F6368' }}>액션</th>
                  </tr>
                </thead>
                <tbody>
                  {currentMenus.map((menu, idx) => (
                    <tr key={idx} className="border-b transition-colors" style={{ borderColor: '#DADCE0', backgroundColor: 'transparent' }} onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#F9F9F9'} onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}>
                      <td className="px-4 py-3 font-mono text-sm" style={{ color: '#5F6368' }}>{menu.id}</td>
                      <td className={`px-4 py-3 font-bold ${menu.level === 2 ? 'pl-8' : ''}`} style={{ color: '#202124' }}>
                        <div className="flex items-center gap-2">
                          {menu.level === 1 ? (
                            <Folder className="w-4 h-4" style={{ color: '#2B8DFF' }} />
                          ) : (
                            <ChevronRight className="w-4 h-4" style={{ color: '#9CA3AF' }} />
                          )}
                          {menu.name}
                        </div>
                      </td>
                      <td className="px-4 py-3" style={{ color: '#5F6368' }}>{menu.parentMenu}</td>
                      <td className="px-4 py-3">
                        <Badge variant={menu.level === 1 ? 'info' : menu.level === 2 ? 'success' : 'warning'}>
                          Level {menu.level}
                        </Badge>
                      </td>
                      <td className="px-4 py-3 text-center" style={{ color: '#5F6368' }}>{menu.order}</td>
                      <td className="px-4 py-3">
                        <Badge variant="success">{menu.status}</Badge>
                      </td>
                      <td className="px-4 py-3" style={{ color: '#5F6368' }}>{menu.description}</td>
                      <td className="px-4 py-3">
                        <div className="flex gap-2">
                          <button 
                            className="p-1.5 rounded-lg transition-colors"
                            style={{ backgroundColor: 'transparent' }}
                            onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#F1F3F4'}
                            onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
                            onClick={() => handleEditClick(menu)}
                          >
                            <Edit className="w-4 h-4" style={{ color: '#2B8DFF' }} />
                          </button>
                          <button 
                            className="p-1.5 rounded-lg transition-colors"
                            style={{ backgroundColor: 'transparent' }}
                            onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#F1F3F4'}
                            onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
                          >
                            <Trash2 className="w-4 h-4" style={{ color: '#EA4335' }} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <Pagination
              currentPage={currentPage}
              totalPages={totalPages}
              totalItems={sortedMenus.length}
              itemsPerPage={itemsPerPage}
              onPageChange={setCurrentPage}
              onItemsPerPageChange={setItemsPerPage}
            />
          </Card>
        </div>
      </motion.div>

      <MenuFormModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        mode={modalMode}
        menuData={selectedMenu}
      />
    </div>
  );
}