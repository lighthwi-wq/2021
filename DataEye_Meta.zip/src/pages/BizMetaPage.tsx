import { Briefcase, Workflow, BookText, GitBranch, CheckCircle2, Plus } from 'lucide-react';
import { Card } from '../components/common/Card';
import { IconBox } from '../components/common/IconBox';
import { Button } from '../components/common/Button';
import { Badge } from '../components/common/Badge';
import { BusinessAreaFormModal } from '../components/modals/BusinessAreaFormModal';
import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { useModal } from '../contexts/ModalContext';

export function BizMetaPage() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState<'create' | 'edit'>('create');
  const [selectedArea, setSelectedArea] = useState<any>(null);

  const handleAddClick = () => {
    setModalMode('create');
    setSelectedArea(null);
    setIsModalOpen(true);
  };

  const handleAreaClick = (area: any) => {
    setModalMode('edit');
    setSelectedArea(area);
    setIsModalOpen(true);
  };

  const businessAreas = [
    { name: '고객관리', processes: 12, terms: 145, status: '운영중' },
    { name: '주문/결제', processes: 8, terms: 98, status: '운영중' },
    { name: '재고관리', processes: 6, terms: 67, status: '검토중' },
    { name: '배송관리', processes: 5, terms: 54, status: '운영중' },
  ];

  const processes = [
    { 
      name: '업무영역 등록', 
      desc: '업무 영역 등록, 업무 영역 변경 및 삭제',
      icon: Briefcase,
      color: 'blue' as const
    },
    { 
      name: '업무 프로세스 관리', 
      desc: '업무 프로세스 등록, 프로세스 흐름 설계',
      icon: Workflow,
      color: 'indigo' as const
    },
    { 
      name: '업무 용어 관리', 
      desc: '업무 용어 추가 (한자/정의), AI 중복/유사 용어 자동 검출',
      icon: BookText,
      color: 'green' as const
    },
    { 
      name: '데이터 연계 관리', 
      desc: '업무용어-데이터 연계 매핑, 시스템/테이블/컬럼 매핑',
      icon: GitBranch,
      color: 'orange' as const
    },
  ];

  const recentActivities = [
    { title: '업무영역 승인', area: '고객관리', time: '10분 전', status: 'success' },
    { title: '정보분석 검토', area: '주문/결제', time: '25분 전', status: 'info' },
    { title: '데이터 연계 매핑', area: '재고관리', time: '1시간 전', status: 'success' },
  ];

  return (
    <div className="space-y-4 p-0">
      <div className="flex-1 overflow-auto">
        <div className="space-y-4 p-0">
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 mb-6">
            <Card padding="lg">
              <IconBox icon={Briefcase} color="blue" size="md" />
              <div className="mt-3">
                <p className="text-gray-500 dark:text-gray-400 mb-1">업무 영역</p>
                <h3 className="text-gray-900 dark:text-white font-bold">24</h3>
              </div>
            </Card>
            <Card padding="lg">
              <IconBox icon={Workflow} color="indigo" size="md" />
              <div className="mt-3">
                <p className="text-gray-500 dark:text-gray-400 mb-1">업무 프로세스</p>
                <h3 className="text-gray-900 dark:text-white font-bold">89</h3>
              </div>
            </Card>
            <Card padding="lg">
              <IconBox icon={BookText} color="green" size="md" />
              <div className="mt-3">
                <p className="text-gray-500 dark:text-gray-400 mb-1">업무 용어</p>
                <h3 className="text-gray-900 dark:text-white font-bold">1,456</h3>
              </div>
            </Card>
            <Card padding="lg">
              <IconBox icon={GitBranch} color="orange" size="md" />
              <div className="mt-3">
                <p className="text-gray-500 dark:text-gray-400 mb-1">데이터 연계</p>
                <h3 className="text-gray-900 dark:text-white font-bold">567</h3>
              </div>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <div className="lg:col-span-2 space-y-4">
              <Card padding="lg">
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-3">
                    <IconBox icon={Briefcase} color="blue" size="md" />
                    <h3 className="text-gray-900 dark:text-white font-bold">업무 영역 관리</h3>
                  </div>
                  <Button variant="primary" size="sm" onClick={handleAddClick}>+ 영역 추가</Button>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead style={{ backgroundColor: '#F7F8FA' }}>
                      <tr style={{ borderBottom: '1px solid #DADCE0' }}>
                        <th className="px-4 py-3 text-left text-sm" style={{ color: '#5F6368' }}>영역명</th>
                        <th className="px-4 py-3 text-left text-sm" style={{ color: '#5F6368' }}>프로세스</th>
                        <th className="px-4 py-3 text-left text-sm" style={{ color: '#5F6368' }}>용어</th>
                        <th className="px-4 py-3 text-left text-sm" style={{ color: '#5F6368' }}>상태</th>
                      </tr>
                    </thead>
                    <tbody>
                      {businessAreas.map((area, idx) => (
                        <tr 
                          key={idx} 
                          className="border-b border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700/30 transition-colors cursor-pointer"
                          onClick={() => handleAreaClick(area)}
                        >
                          <td className="px-4 py-3 text-gray-900 dark:text-gray-100 font-bold">{area.name}</td>
                          <td className="px-4 py-3 text-gray-600 dark:text-gray-400">{area.processes}</td>
                          <td className="px-4 py-3 text-gray-600 dark:text-gray-400">{area.terms}</td>
                          <td className="px-4 py-3">
                            <Badge variant={area.status === '운영중' ? 'success' : 'warning'}>
                              {area.status}
                            </Badge>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </Card>

              <Card padding="lg">
                <div className="flex items-center gap-3 mb-6">
                  <IconBox icon={Workflow} color="indigo" size="md" />
                  <h3 className="text-gray-900 dark:text-white font-bold">비즈메타 관리 프로세스</h3>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {processes.map((process, idx) => (
                    <div key={idx} className="p-4 bg-gray-50 dark:bg-gray-700/50 rounded-xl border border-gray-200 dark:border-gray-600 hover:border-blue-500 dark:hover:border-blue-500 transition-all cursor-pointer">
                      <IconBox icon={process.icon} color={process.color} size="sm" />
                      <h4 className="text-gray-900 dark:text-white font-bold mt-3 mb-2">{process.name}</h4>
                      <p className="text-gray-600 dark:text-gray-400">{process.desc}</p>
                    </div>
                  ))}
                </div>
              </Card>
            </div>

            <Card padding="lg">
              <div className="flex items-center gap-3 mb-6">
                <IconBox icon={CheckCircle2} color="green" size="md" />
                <h3 className="text-gray-900 dark:text-white font-bold">최근 활동</h3>
              </div>
              <div className="space-y-4">
                {recentActivities.map((activity, idx) => (
                  <div key={idx} className="p-4 bg-gray-50 dark:bg-gray-700/50 rounded-xl border border-gray-200 dark:border-gray-600">
                    <div className="flex items-start justify-between mb-2">
                      <h4 className="text-gray-900 dark:text-white font-bold">{activity.title}</h4>
                      <Badge variant={activity.status as any}>{activity.area}</Badge>
                    </div>
                    <p className="text-gray-500 dark:text-gray-400">{activity.time}</p>
                  </div>
                ))}
              </div>
            </Card>
          </div>
        </div>
      </div>

      {/* 모달 영역 */}
      <BusinessAreaFormModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        mode={modalMode}
        initialData={selectedArea}
      />
    </div>
  );
}