import { Database, FileCheck2, TrendingUp, ShieldCheck, MoreVertical, ChevronRight, AlertCircle, CheckCircle2, Clock, Users, Target, Activity, Zap, GitBranch, FileText, BarChart3, GripVertical } from 'lucide-react';
import { Card } from '../components/common/Card';
import { Badge } from '../components/common/Badge';
import { Button } from '../components/common/Button';
import { LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, ResponsiveContainer, XAxis, YAxis, Tooltip, CartesianGrid, Legend, Area, AreaChart, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, ComposedChart } from 'recharts';
import { useState, useRef } from 'react';
import { DndProvider, useDrag, useDrop } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';

const CARD_TYPE = 'DASHBOARD_CARD';

interface DraggableCardProps {
  id: string;
  index: number;
  moveCard: (dragIndex: number, hoverIndex: number) => void;
  children: React.ReactNode;
  className?: string;
}

function DraggableCard({ id, index, moveCard, children, className }: DraggableCardProps) {
  const ref = useRef<HTMLDivElement>(null);

  const [{ isDragging }, drag] = useDrag({
    type: CARD_TYPE,
    item: { id, index },
    collect: (monitor) => ({
      isDragging: monitor.isDragging(),
    }),
  });

  const [{ isOver }, drop] = useDrop({
    accept: CARD_TYPE,
    hover: (item: { id: string; index: number }) => {
      if (!ref.current) return;
      
      const dragIndex = item.index;
      const hoverIndex = index;

      if (dragIndex === hoverIndex) return;

      moveCard(dragIndex, hoverIndex);
      item.index = hoverIndex;
    },
    collect: (monitor) => ({
      isOver: monitor.isOver(),
    }),
  });

  drop(drag(ref));

  return (
    <div
      ref={ref}
      className={className}
      style={{
        opacity: isDragging ? 0.5 : 1,
        transition: 'opacity 0.2s',
      }}
    >
      <div className="relative">
        <div className="absolute top-3 right-3 z-10 cursor-move">
          <div className="p-1.5 rounded-lg bg-white shadow-sm border hover:border-blue-300 hover:shadow-md transition-all" style={{ borderColor: '#DADCE0' }}>
            <GripVertical className="w-4 h-4" style={{ color: '#5F6368' }} />
          </div>
        </div>
        {children}
      </div>
    </div>
  );
}

export function NewDashboardPage() {
  // 상단 6개 핵심 KPI 카드
  const kpiData = [
    {
      label: '총 테이블',
      value: '1,247',
      change: '+2.3%',
      icon: Database,
      color: '#3B82F6',
      chartData: [
        { value: 120 }, { value: 132 }, { value: 141 }, { value: 152 }, 
        { value: 148 }, { value: 165 }, { value: 178 }, { value: 192 },
        { value: 201 }, { value: 215 }, { value: 228 }, { value: 247 }
      ]
    },
    {
      label: '표준용어',
      value: '856',
      change: '+5.2%',
      icon: FileText,
      color: '#F59E0B',
      chartData: [
        { value: 45 }, { value: 52 }, { value: 48 }, { value: 61 }, 
        { value: 58 }, { value: 67 }, { value: 72 }, { value: 69 },
        { value: 75 }, { value: 78 }, { value: 82 }, { value: 86 }
      ]
    },
    {
      label: '표준단어',
      value: '643',
      change: '+1.8%',
      icon: FileCheck2,
      color: '#10B981',
      chartData: [
        { value: 52 }, { value: 55 }, { value: 57 }, { value: 59 }, 
        { value: 58 }, { value: 60 }, { value: 61 }, { value: 62 },
        { value: 63 }, { value: 63 }, { value: 64 }, { value: 64 }
      ]
    },
    {
      label: '데이터 품질',
      value: '92.5',
      change: '+0.8%',
      icon: ShieldCheck,
      color: '#8B5CF6',
      chartData: [
        { value: 88 }, { value: 87 }, { value: 89 }, { value: 90 }, 
        { value: 89 }, { value: 91 }, { value: 90 }, { value: 92 },
        { value: 91 }, { value: 92 }, { value: 93 }, { value: 92.5 }
      ]
    },
    {
      label: '활성 워크플로우',
      value: '24',
      change: '+12.5%',
      icon: GitBranch,
      color: '#EC4899',
      chartData: [
        { value: 18 }, { value: 19 }, { value: 17 }, { value: 20 }, 
        { value: 21 }, { value: 19 }, { value: 22 }, { value: 23 },
        { value: 21 }, { value: 24 }, { value: 23 }, { value: 24 }
      ]
    },
    {
      label: '월간 작업',
      value: '342',
      change: '+8.3%',
      icon: Activity,
      color: '#06B6D4',
      chartData: [
        { value: 280 }, { value: 295 }, { value: 301 }, { value: 288 }, 
        { value: 310 }, { value: 298 }, { value: 315 }, { value: 322 },
        { value: 308 }, { value: 335 }, { value: 328 }, { value: 342 }
      ]
    }
  ];

  // 표준용어 승인 현황
  const termApprovalData = [
    { status: '승인대기', count: 45, color: '#F59E0B' },
    { status: '검토중', count: 28, color: '#3B82F6' },
    { status: '승인완료', count: 783, color: '#10B981' },
    { status: '반려', count: 12, color: '#EF4444' },
  ];

  // 데이터 품질 추이 (월별)
  const qualityTrendData = [
    { month: '1월', 완전성: 85, 유효성: 88, 정확성: 82, 일관성: 86 },
    { month: '2월', 완전성: 87, 유효성: 89, 정확성: 84, 일관성: 87 },
    { month: '3월', 완전성: 86, 유효성: 90, 정확성: 86, 일관성: 88 },
    { month: '4월', 완전성: 89, 유효성: 91, 정확성: 87, 일관성: 89 },
    { month: '5월', 완전성: 90, 유효성: 92, 정확성: 88, 일관성: 90 },
    { month: '6월', 완전성: 91, 유효성: 93, 정확성: 89, 일관성: 91 },
    { month: '7월', 완전성: 93, 유효성: 94, 정확성: 90, 일관성: 92 },
    { month: '8월', 완전성: 92, 유효성: 93, 정확성: 91, 일관성: 93 },
    { month: '9월', 완전성: 94, 유효성: 95, 정확성: 92, 일관성: 94 },
    { month: '10월', 완전성: 95, 유효성: 96, 정확성: 93, 일관성: 95 },
    { month: '11월', 완전성: 96, 유효성: 97, 정확성: 94, 일관성: 96 },
  ];

  // 시스템별 표준화율 및 품질점수
  const systemStandardData = [
    { system: '고객관리', 표준화율: 95, 품질점수: 93, 테이블수: 87 },
    { system: '주문관리', 표준화율: 88, 품질점수: 89, 테이블수: 142 },
    { system: '재고관리', 표준화율: 92, 품질점수: 91, 테이블수: 68 },
    { system: '배송관리', 표준화율: 85, 품질점수: 87, 테이블수: 54 },
    { system: '정산관리', 표준화율: 90, 품질점수: 92, 테이블수: 95 },
    { system: 'ERP시스템', 표준화율: 94, 품질점수: 94, 테이블수: 234 },
    { system: '마케팅', 표준화율: 87, 품질점수: 86, 테이블수: 78 },
    { system: '분석시스템', 표준화율: 91, 품질점수: 90, 테이블수: 112 },
  ];

  // 워크플로우 처리 현황
  const workflowData = [
    { name: '표준용어 승인', total: 45, completed: 32, inProgress: 10, pending: 3 },
    { name: '데이터 모델 검토', total: 28, completed: 18, inProgress: 8, pending: 2 },
    { name: '품질 평가', total: 67, completed: 52, inProgress: 12, pending: 3 },
    { name: '메타데이터 등록', total: 34, completed: 28, inProgress: 5, pending: 1 },
    { name: '스키마 변경', total: 19, completed: 15, inProgress: 3, pending: 1 },
  ];

  // 데이터 카테고리 분포
  const categoryData = [
    { name: '고객데이터', value: 245, percent: 19.7, color: '#3B82F6', tables: 245, columns: 3254 },
    { name: '거래데이터', value: 312, percent: 25.0, color: '#8B5CF6', tables: 312, columns: 4186 },
    { name: '상품데이터', value: 189, percent: 15.2, color: '#EC4899', tables: 189, columns: 2547 },
    { name: '운영데이터', value: 267, percent: 21.4, color: '#10B981', tables: 267, columns: 3721 },
    { name: '마케팅데이터', value: 156, percent: 12.5, color: '#F59E0B', tables: 156, columns: 2034 },
    { name: '기타', value: 78, percent: 6.2, color: '#6B7280', tables: 78, columns: 982 },
  ];

  // 품질 지표 레이더 차트
  const qualityRadarData = [
    { metric: '완전성', value: 95, fullMark: 100, color: '#3B82F6' },
    { metric: '유효성', value: 92, fullMark: 100, color: '#10B981' },
    { metric: '정확성', value: 88, fullMark: 100, color: '#F59E0B' },
    { metric: '일관성', value: 90, fullMark: 100, color: '#8B5CF6' },
    { metric: '적시성', value: 87, fullMark: 100, color: '#EC4899' },
    { metric: '유일성', value: 93, fullMark: 100, color: '#06B6D4' },
  ];

  // 최근 활동
  const recentActivities = [
    { id: 1, title: '고객정보 테이블 표준용어 승인', user: '김민지', time: '5분 전', type: 'approval', status: 'success' },
    { id: 2, title: 'DW_CUSTOMER 스키마 변경 요청', user: '이준호', time: '1시간 전', type: 'change', status: 'pending' },
    { id: 3, title: '거래데이터 품질 평가 완료 (92점)', user: '박서연', time: '2시간 전', type: 'quality', status: 'success' },
    { id: 4, title: 'TB_PRODUCT_MST 테이블 신규 등록', user: '최동욱', time: '3시간 전', type: 'new', status: 'success' },
    { id: 5, title: '주문관리_주문번호 표준단어 수정', user: '정수진', time: '4시간 전', type: 'edit', status: 'warning' },
    { id: 6, title: '마케팅시스템 데이터 프로파일링 실행', user: '강태희', time: '5시간 전', type: 'profiling', status: 'info' },
  ];

  // 주요 이슈 및 알림
  const criticalIssues = [
    { id: 1, severity: 'high', title: '고객정보 테이블 중복 데이터 발견', count: 1247, system: '고객관리' },
    { id: 2, severity: 'medium', title: '주문 테이블 NULL 값 증가', count: 342, system: '주문관리' },
    { id: 3, severity: 'low', title: '표준용어 미승인 건 대기중', count: 45, system: '전체' },
    { id: 4, severity: 'high', title: '재고 데이터 정합성 오류', count: 89, system: '재고관리' },
  ];

  // 기술 모델 현황
  const technicalModelStats = [
    { category: '논리 모델', total: 156, approved: 142, draft: 14 },
    { category: '물리 모델', total: 234, approved: 221, draft: 13 },
    { category: 'ERD', total: 89, approved: 78, draft: 11 },
  ];

  // 드래그 앤 드롭을 위한 카드 순서 state
  const [row2Cards, setRow2Cards] = useState([
    { id: 'quality-trend', span: 5 },
    { id: 'system-standard', span: 5 },
    { id: 'term-approval', span: 2 },
  ]);

  const [row3Cards, setRow3Cards] = useState([
    { id: 'workflow', span: 5 },
    { id: 'category', span: 5 },
    { id: 'quality-radar', span: 2 },
  ]);

  const [row4Cards, setRow4Cards] = useState([
    { id: 'technical-model', span: 5 },
    { id: 'recent-activities', span: 7 },
  ]);

  const moveCardInRow = (setCards: any) => (dragIndex: number, hoverIndex: number) => {
    setCards((prevCards: any[]) => {
      const draggedCard = prevCards[dragIndex];
      const newCards = [...prevCards];
      newCards.splice(dragIndex, 1);
      newCards.splice(hoverIndex, 0, draggedCard);
      return newCards;
    });
  };

  const renderCard = (card: typeof row2Cards[0], index: number, setCards: any) => {
    const baseClasses = `col-span-${card.span}`;
    
    switch (card.id) {
      case 'quality-trend':
        return (
          <DraggableCard key={card.id} id={card.id} index={index} moveCard={moveCardInRow(setCards)} className={baseClasses}>
            <Card padding="lg" className="h-[420px]">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h3 className="font-bold mb-1" style={{ color: '#202124' }}>데이터 품질 추이 분석</h3>
                  <p className="text-sm" style={{ color: '#5F6368' }}>최근 11개월 품질 지표 변화</p>
                </div>
                <div className="flex items-center gap-2">
                  <Button variant="secondary" size="sm">월간</Button>
                  <Button variant="ghost" size="sm">주간</Button>
                </div>
              </div>
              <ResponsiveContainer width="100%" height={280}>
                <LineChart data={qualityTrendData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E8EAED" />
                  <XAxis 
                    dataKey="month" 
                    stroke="#5F6368" 
                    style={{ fontSize: '12px' }}
                    axisLine={false}
                    tickLine={false}
                  />
                  <YAxis 
                    stroke="#5F6368" 
                    style={{ fontSize: '12px' }}
                    axisLine={false}
                    tickLine={false}
                    domain={[70, 100]}
                  />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: '#FFFFFF', 
                      border: '1px solid #DADCE0',
                      borderRadius: '8px',
                      boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
                    }}
                  />
                  <Legend 
                    verticalAlign="bottom"
                    height={36}
                    iconType="line"
                  />
                  <Line type="monotone" dataKey="완전성" stroke="#3B82F6" strokeWidth={2} dot={{ fill: '#3B82F6', r: 3 }} />
                  <Line type="monotone" dataKey="유효성" stroke="#10B981" strokeWidth={2} dot={{ fill: '#10B981', r: 3 }} />
                  <Line type="monotone" dataKey="정확성" stroke="#F59E0B" strokeWidth={2} dot={{ fill: '#F59E0B', r: 3 }} />
                  <Line type="monotone" dataKey="일관성" stroke="#8B5CF6" strokeWidth={2} dot={{ fill: '#8B5CF6', r: 3 }} />
                </LineChart>
              </ResponsiveContainer>
            </Card>
          </DraggableCard>
        );

      case 'system-standard':
        return (
          <DraggableCard key={card.id} id={card.id} index={index} moveCard={moveCardInRow(setCards)} className={baseClasses}>
            <Card padding="lg" className="h-[420px]">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h3 className="font-bold mb-1" style={{ color: '#202124' }}>시스템별 표준화율</h3>
                  <p className="text-sm" style={{ color: '#5F6368' }}>8개 시스템 현황</p>
                </div>
              </div>
              <div className="space-y-3" style={{ maxHeight: '280px', overflowY: 'auto' }}>
                {systemStandardData.map((sys, idx) => (
                  <div key={idx} className="p-3 rounded-lg hover:bg-gray-50 transition-colors">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium" style={{ color: '#202124' }}>{sys.system}</span>
                      <Badge variant="info" size="sm">{sys.테이블수}개</Badge>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <p className="text-xs mb-1" style={{ color: '#5F6368' }}>표준화율</p>
                        <div className="flex items-center gap-2">
                          <div className="flex-1 h-1.5 rounded-full" style={{ backgroundColor: '#E8EAED' }}>
                            <div 
                              className="h-full rounded-full"
                              style={{ width: `${sys.표준화율}%`, backgroundColor: '#3B82F6' }}
                            />
                          </div>
                          <span className="text-xs font-bold" style={{ color: '#202124' }}>{sys.표준화율}%</span>
                        </div>
                      </div>
                      <div>
                        <p className="text-xs mb-1" style={{ color: '#5F6368' }}>품질점수</p>
                        <div className="flex items-center gap-2">
                          <div className="flex-1 h-1.5 rounded-full" style={{ backgroundColor: '#E8EAED' }}>
                            <div 
                              className="h-full rounded-full"
                              style={{ width: `${sys.품질점수}%`, backgroundColor: '#10B981' }}
                            />
                          </div>
                          <span className="text-xs font-bold" style={{ color: '#202124' }}>{sys.품질점수}%</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </DraggableCard>
        );

      case 'term-approval':
        return (
          <DraggableCard key={card.id} id={card.id} index={index} moveCard={moveCardInRow(setCards)} className={baseClasses}>
            <Card padding="lg" className="h-[420px]">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h3 className="font-bold mb-1" style={{ color: '#202124' }}>표준용어 승인 현황</h3>
                  <p className="text-sm" style={{ color: '#5F6368' }}>총 868건</p>
                </div>
              </div>
              <ResponsiveContainer width="100%" height={180}>
                <PieChart>
                  <Pie
                    data={termApprovalData}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={80}
                    paddingAngle={3}
                    dataKey="count"
                  >
                    {termApprovalData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
              <div className="grid grid-cols-2 gap-3 mt-4">
                {termApprovalData.map((item, idx) => (
                  <div key={idx} className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-sm" style={{ backgroundColor: item.color }} />
                    <div className="flex-1">
                      <p className="text-xs" style={{ color: '#5F6368' }}>{item.status}</p>
                      <p className="text-sm font-bold" style={{ color: '#202124' }}>{item.count}건</p>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </DraggableCard>
        );

      case 'workflow':
        return (
          <DraggableCard key={card.id} id={card.id} index={index} moveCard={moveCardInRow(setCards)} className={baseClasses}>
            <Card padding="lg" className="h-[420px]">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h3 className="font-bold mb-1" style={{ color: '#202124' }}>워크플로우 처리 현황</h3>
                  <p className="text-sm" style={{ color: '#5F6368' }}>진행중인 작업 현황</p>
                </div>
              </div>
              <div className="space-y-4">
                {workflowData.map((wf, idx) => (
                  <div key={idx}>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium" style={{ color: '#202124' }}>{wf.name}</span>
                      <span className="text-sm" style={{ color: '#5F6368' }}>
                        {wf.completed}/{wf.total}
                      </span>
                    </div>
                    <div className="flex gap-1 h-2">
                      <div 
                        className="rounded-full transition-all"
                        style={{ 
                          width: `${(wf.completed / wf.total) * 100}%`,
                          backgroundColor: '#10B981'
                        }}
                      />
                      <div 
                        className="rounded-full transition-all"
                        style={{ 
                          width: `${(wf.inProgress / wf.total) * 100}%`,
                          backgroundColor: '#3B82F6'
                        }}
                      />
                      <div 
                        className="rounded-full transition-all"
                        style={{ 
                          width: `${(wf.pending / wf.total) * 100}%`,
                          backgroundColor: '#F59E0B'
                        }}
                      />
                    </div>
                    <div className="flex items-center gap-3 mt-1">
                      <div className="flex items-center gap-1">
                        <div className="w-2 h-2 rounded-full" style={{ backgroundColor: '#10B981' }} />
                        <span className="text-xs" style={{ color: '#5F6368' }}>완료 {wf.completed}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <div className="w-2 h-2 rounded-full" style={{ backgroundColor: '#3B82F6' }} />
                        <span className="text-xs" style={{ color: '#5F6368' }}>진행 {wf.inProgress}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <div className="w-2 h-2 rounded-full" style={{ backgroundColor: '#F59E0B' }} />
                        <span className="text-xs" style={{ color: '#5F6368' }}>대기 {wf.pending}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </DraggableCard>
        );

      case 'category':
        return (
          <DraggableCard key={card.id} id={card.id} index={index} moveCard={moveCardInRow(setCards)} className={baseClasses}>
            <Card padding="lg" className="h-[420px]">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h3 className="font-bold mb-1" style={{ color: '#202124' }}>데이터 카테고리 분포</h3>
                  <p className="text-sm" style={{ color: '#5F6368' }}>전체 1,247개 테이블</p>
                </div>
              </div>
              <div className="space-y-4 flex-1 overflow-y-auto">
                {categoryData.map((item, idx) => (
                  <div key={idx}>
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-sm" style={{ backgroundColor: item.color }} />
                        <span className="text-sm font-medium" style={{ color: '#202124' }}>{item.name}</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="text-xs" style={{ color: '#5F6368' }}>{item.columns.toLocaleString()} 컬럼</span>
                        <span className="text-sm font-bold" style={{ color: '#202124' }}>{item.percent}%</span>
                      </div>
                    </div>
                    <div className="h-2 rounded-full" style={{ backgroundColor: '#F1F3F4' }}>
                      <div 
                        className="h-full rounded-full transition-all duration-500"
                        style={{ width: `${item.percent}%`, backgroundColor: item.color }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </DraggableCard>
        );

      case 'quality-radar':
        return (
          <DraggableCard key={card.id} id={card.id} index={index} moveCard={moveCardInRow(setCards)} className={baseClasses}>
            <Card padding="lg" className="h-[420px]">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h3 className="font-bold mb-1" style={{ color: '#202124' }}>품질 지표 분석</h3>
                  <p className="text-sm" style={{ color: '#5F6368' }}>6개 차원 평가</p>
                </div>
              </div>
              <ResponsiveContainer width="100%" height={240}>
                <RadarChart data={qualityRadarData}>
                  <PolarGrid stroke="#E8EAED" strokeWidth={1} />
                  <PolarAngleAxis 
                    dataKey="metric" 
                    tick={{ fill: '#5F6368', fontSize: 11 }}
                    stroke="#E8EAED"
                  />
                  <PolarRadiusAxis 
                    angle={90} 
                    domain={[0, 100]}
                    tick={{ fill: '#5F6368', fontSize: 10 }}
                    stroke="#E8EAED"
                  />
                  <Radar 
                    name="품질 점수"
                    dataKey="value" 
                    stroke="#3B82F6"
                    fill="#3B82F6"
                    fillOpacity={0.25}
                    strokeWidth={2.5}
                  />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: '#FFFFFF', 
                      border: '1px solid #DADCE0',
                      borderRadius: '8px',
                      boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
                    }}
                  />
                </RadarChart>
              </ResponsiveContainer>
              <div className="grid grid-cols-3 gap-2 mt-4">
                {qualityRadarData.map((item, idx) => (
                  <div key={idx} className="flex items-center gap-1.5">
                    <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: item.color }} />
                    <div className="flex-1 min-w-0">
                      <p className="text-xs truncate" style={{ color: '#5F6368' }}>{item.metric}</p>
                      <p className="text-sm font-bold" style={{ color: '#202124' }}>{item.value}</p>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </DraggableCard>
        );

      case 'technical-model':
        return (
          <DraggableCard key={card.id} id={card.id} index={index} moveCard={moveCardInRow(setCards)} className={baseClasses}>
            <Card padding="lg" className="h-[360px] flex flex-col">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="font-bold mb-1" style={{ color: '#202124' }}>기술 모델 현황</h3>
                  <p className="text-sm" style={{ color: '#5F6368' }}>총 479개 모델</p>
                </div>
              </div>
              <div className="space-y-3 flex-1 overflow-y-auto">
                {technicalModelStats.map((model, idx) => (
                  <div key={idx} className="p-4 rounded-lg" style={{ backgroundColor: '#F8F9FA' }}>
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <BarChart3 className="w-4 h-4" style={{ color: '#3B82F6' }} />
                        <span className="font-medium" style={{ color: '#202124' }}>{model.category}</span>
                      </div>
                      <Badge variant="info">{model.total}개</Badge>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4" style={{ color: '#10B981' }} />
                        <div>
                          <p className="text-xs" style={{ color: '#5F6368' }}>승인완료</p>
                          <p className="font-bold" style={{ color: '#202124' }}>{model.approved}개</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4" style={{ color: '#F59E0B' }} />
                        <div>
                          <p className="text-xs" style={{ color: '#5F6368' }}>작성중</p>
                          <p className="font-bold" style={{ color: '#202124' }}>{model.draft}개</p>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </DraggableCard>
        );

      case 'recent-activities':
        return (
          <DraggableCard key={card.id} id={card.id} index={index} moveCard={moveCardInRow(setCards)} className={baseClasses}>
            <Card padding="lg" className="h-[360px] flex flex-col">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="font-bold mb-1" style={{ color: '#202124' }}>최근 활동</h3>
                  <p className="text-sm" style={{ color: '#5F6368' }}>실시간 업데이트</p>
                </div>
                <Button variant="secondary" size="sm">전체 보기</Button>
              </div>
              <div className="grid grid-cols-2 gap-3 flex-1 overflow-y-auto">
                {recentActivities.map((activity) => (
                  <div 
                    key={activity.id}
                    className="flex items-start gap-3 p-3 rounded-lg hover:bg-gray-50 transition-colors cursor-pointer h-fit"
                  >
                    <div 
                      className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 text-xs font-bold"
                      style={{ 
                        backgroundColor: 
                          activity.status === 'success' ? '#10B98122' :
                          activity.status === 'warning' ? '#F59E0B22' :
                          activity.status === 'info' ? '#3B82F622' : '#6B728022',
                        color: 
                          activity.status === 'success' ? '#10B981' :
                          activity.status === 'warning' ? '#F59E0B' :
                          activity.status === 'info' ? '#3B82F6' : '#6B7280'
                      }}
                    >
                      {activity.user.substring(0, 2)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium mb-1 truncate" style={{ color: '#202124' }}>
                        {activity.title}
                      </p>
                      <div className="flex items-center gap-2">
                        <p className="text-xs" style={{ color: '#5F6368' }}>
                          {activity.user}
                        </p>
                        <span style={{ color: '#DADCE0' }}>·</span>
                        <p className="text-xs" style={{ color: '#5F6368' }}>
                          {activity.time}
                        </p>
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4 flex-shrink-0" style={{ color: '#DADCE0' }} />
                  </div>
                ))}
              </div>
            </Card>
          </DraggableCard>
        );

      default:
        return null;
    }
  };

  return (
    <DndProvider backend={HTML5Backend}>
      <div className="space-y-5">
        {/* 상단 6개 KPI 카드 */}
        <div className="grid grid-cols-6 gap-4">
          {kpiData.map((kpi, idx) => {
            const Icon = kpi.icon;
            return (
              <Card key={idx} padding="md">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <div 
                        className="w-8 h-8 rounded-lg flex items-center justify-center"
                        style={{ backgroundColor: `${kpi.color}22` }}
                      >
                        <Icon className="w-4 h-4" style={{ color: kpi.color }} />
                      </div>
                    </div>
                    <p className="text-xs mb-1" style={{ color: '#5F6368' }}>{kpi.label}</p>
                    <div className="flex items-end gap-1">
                      <h3 className="text-2xl font-bold" style={{ color: '#202124' }}>{kpi.value}</h3>
                      <span className="text-xs mb-1" style={{ color: kpi.change.startsWith('+') ? '#10B981' : '#EF4444' }}>
                        {kpi.change}
                      </span>
                    </div>
                  </div>
                </div>
                <ResponsiveContainer width="100%" height={40}>
                  <AreaChart data={kpi.chartData}>
                    <defs>
                      <linearGradient id={`gradient${idx}`} x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor={kpi.color} stopOpacity={0.3}/>
                        <stop offset="95%" stopColor={kpi.color} stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <Area 
                      type="monotone" 
                      dataKey="value" 
                      stroke={kpi.color} 
                      strokeWidth={2}
                      fill={`url(#gradient${idx})`}
                      dot={false}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </Card>
            );
          })}
        </div>

        {/* 주요 이슈 및 알림 배너 */}
        <Card padding="md" className="border-l-4" style={{ borderLeftColor: '#EF4444' }}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <AlertCircle className="w-5 h-5" style={{ color: '#EF4444' }} />
              <div>
                <h4 className="font-bold mb-1" style={{ color: '#202124' }}>주요 이슈 모니터링</h4>
                <div className="flex items-center gap-4">
                  {criticalIssues.slice(0, 3).map((issue, idx) => (
                    <div key={idx} className="flex items-center gap-2">
                      <Badge 
                        variant={issue.severity === 'high' ? 'danger' : issue.severity === 'medium' ? 'warning' : 'info'}
                      >
                        {issue.severity === 'high' ? '높음' : issue.severity === 'medium' ? '중간' : '낮음'}
                      </Badge>
                      <span className="text-sm" style={{ color: '#5F6368' }}>
                        {issue.title} ({issue.count}건)
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            <Button variant="secondary" size="sm">
              전체 보기
            </Button>
          </div>
        </Card>

        {/* 2행: 품질 추이 + 시스템별 현황 + 표준용어 승인 */}
        <div className="grid grid-cols-12 gap-5 items-start">
          {row2Cards.map((card, index) => renderCard(card, index, setRow2Cards))}
        </div>

        {/* 3행: 워크플로우 + 카테고리 분포 + 품질 레이더 */}
        <div className="grid grid-cols-12 gap-5 items-start">
          {row3Cards.map((card, index) => renderCard(card, index, setRow3Cards))}
        </div>

        {/* 4행: 기술모델 현황 + 최근 활동 */}
        <div className="grid grid-cols-12 gap-5 items-start">
          {row4Cards.map((card, index) => renderCard(card, index, setRow4Cards))}
        </div>
      </div>
    </DndProvider>
  );
}
