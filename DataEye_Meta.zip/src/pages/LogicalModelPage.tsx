import { useState, useEffect } from 'react';
import { Card } from '../components/common/Card';
import { Button } from '../components/common/Button';
import { Badge } from '../components/common/Badge';
import { Plus, Search, Database, Save, X, ChevronRight, History, FileText, List } from 'lucide-react';
import { colors } from '../constants/designSystem';
import { motion, AnimatePresence } from 'motion/react';
import { useModal } from '../contexts/ModalContext';

interface Entity {
  id: number;
  entityName: string;
  entityLogicalName: string;
  subjectArea: string;
  attributeCount: number;
  description: string;
  owner: string;
}

const mockEntities: Entity[] = [
  { id: 1, entityName: 'Customer', entityLogicalName: '고객', subjectArea: '고객관리', attributeCount: 15, description: '고객 기본 정보 엔터티', owner: '김철수' },
  { id: 2, entityName: 'Product', entityLogicalName: '상품', subjectArea: '상품관리', attributeCount: 12, description: '상품 마스터 정보', owner: '이영희' },
  { id: 3, entityName: 'Order', entityLogicalName: '주문', subjectArea: '주문관리', attributeCount: 20, description: '주문 헤더 정보', owner: '박지훈' },
  { id: 4, entityName: 'OrderDetail', entityLogicalName: '주문상세', subjectArea: '주문관리', attributeCount: 8, description: '주문 아이템 상세 정보', owner: '박지훈' },
  { id: 5, entityName: 'Payment', entityLogicalName: '결제', subjectArea: '주문관리', attributeCount: 10, description: '결제 정보', owner: '최민수' },
  { id: 6, entityName: 'Inventory', entityLogicalName: '재고', subjectArea: '상품관리', attributeCount: 7, description: '재고 관리 정보', owner: '이영희' },
];

const mockAttributes = [
  { name: 'CUST_ID', logicalName: '고객ID', type: 'VARCHAR(20)', pk: true },
  { name: 'CUST_NM', logicalName: '고객명', type: 'VARCHAR(100)', pk: false },
  { name: 'EMAIL', logicalName: '이메일', type: 'VARCHAR(100)', pk: false },
  { name: 'PHONE', logicalName: '전화번호', type: 'VARCHAR(20)', pk: false },
];

export function LogicalModelPage() {
  const { setIsModalOpen } = useModal();
  const [selectedEntity, setSelectedEntity] = useState<Entity | null>(null);
  const [activeTab, setActiveTab] = useState<'basic' | 'attributes' | 'history'>('basic');

  useEffect(() => {
    setIsModalOpen(!!selectedEntity);
  }, [selectedEntity, setIsModalOpen]);

  const handleRowClick = (entity: Entity) => {
    setSelectedEntity(entity);
    setActiveTab('basic');
  };

  const handleClose = () => {
    setSelectedEntity(null);
  };

  return (
    <div className="h-full flex gap-0 overflow-hidden">
      {/* Main Grid */}
      <motion.div
        className="flex flex-col"
        initial={{ width: '100%' }}
        animate={{ width: selectedEntity ? '60%' : '100%' }}
        transition={{ duration: 0.4, ease: [0.4, 0, 0.2, 1] }}
      >
        <div className="space-y-6 p-6 overflow-auto h-full">
          {/* Actions Bar */}
          <Card>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3 flex-1">
                <div className="relative flex-1 max-w-md">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: colors.textTertiary }} />
                  <input
                    type="text"
                    placeholder="엔터티명으로 검색..."
                    className="w-full pl-10 pr-4 py-2 rounded-lg border"
                    style={{
                      borderColor: colors.border,
                      backgroundColor: colors.background,
                    }}
                  />
                </div>
              </div>
              <div className="flex gap-2">
                <Button variant="primary" icon={<Plus className="w-4 h-4" />}>
                  신규 엔터티 등록
                </Button>
              </div>
            </div>
          </Card>

          {/* Entity List */}
          <Card>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b" style={{ borderColor: colors.divider }}>
                    <th className="text-left py-3 px-4" style={{ color: colors.textSecondary }}>엔터티명</th>
                    <th className="text-left py-3 px-4" style={{ color: colors.textSecondary }}>논리명</th>
                    <th className="text-left py-3 px-4" style={{ color: colors.textSecondary }}>주제영역</th>
                    <th className="text-center py-3 px-4" style={{ color: colors.textSecondary }}>속성 수</th>
                    <th className="text-left py-3 px-4" style={{ color: colors.textSecondary }}>설명</th>
                    <th className="text-left py-3 px-4" style={{ color: colors.textSecondary }}>담당자</th>
                  </tr>
                </thead>
                <tbody>
                  {mockEntities.map((entity) => (
                    <motion.tr 
                      key={entity.id}
                      onClick={() => handleRowClick(entity)}
                      className="border-b cursor-pointer transition-colors"
                      style={{ 
                        borderColor: colors.divider,
                        backgroundColor: selectedEntity?.id === entity.id ? colors.primaryLight : 'transparent'
                      }}
                      whileHover={{ 
                        backgroundColor: colors.primaryLight,
                        transition: { duration: 0.2 }
                      }}
                    >
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2">
                          <Database className="w-4 h-4" style={{ color: colors.primary }} />
                          <span className="font-medium font-mono" style={{ color: colors.textPrimary }}>
                            {entity.entityName}
                          </span>
                          {selectedEntity?.id === entity.id && (
                            <ChevronRight className="w-4 h-4" style={{ color: colors.primary }} />
                          )}
                        </div>
                      </td>
                      <td className="py-3 px-4" style={{ color: colors.textPrimary }}>
                        {entity.entityLogicalName}
                      </td>
                      <td className="py-3 px-4">
                        <Badge variant="info">{entity.subjectArea}</Badge>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <Badge variant="primary">{entity.attributeCount}</Badge>
                      </td>
                      <td className="py-3 px-4" style={{ color: colors.textSecondary }}>
                        {entity.description}
                      </td>
                      <td className="py-3 px-4" style={{ color: colors.textPrimary }}>
                        {entity.owner}
                      </td>
                    </motion.tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </div>
      </motion.div>

      {/* Glass Separator */}
      <AnimatePresence>
        {selectedEntity && (
          <motion.div
            initial={{ opacity: 0, scaleX: 0 }}
            animate={{ opacity: 1, scaleX: 1 }}
            exit={{ opacity: 0, scaleX: 0 }}
            transition={{ duration: 0.3 }}
            className="w-px"
            style={{
              background: `linear-gradient(180deg, transparent, ${colors.border}, transparent)`,
              transformOrigin: 'left'
            }}
          />
        )}
      </AnimatePresence>

      {/* Right Detail Panel */}
      <AnimatePresence>
        {selectedEntity && (
          <motion.div
            initial={{ x: '100%', opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: '100%', opacity: 0 }}
            transition={{ duration: 0.4, ease: [0.4, 0, 0.2, 1] }}
            className="flex flex-col overflow-hidden"
            style={{
              width: '40%',
              backgroundColor: colors.background,
              backdropFilter: 'blur(20px)',
              boxShadow: '-4px 0 24px rgba(0, 0, 0, 0.08)'
            }}
          >
            {/* Sticky Header */}
            <div 
              className="sticky top-0 z-10 px-6 py-4 border-b"
              style={{ 
                backgroundColor: colors.background,
                borderColor: colors.divider,
                backdropFilter: 'blur(20px)'
              }}
            >
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold" style={{ color: colors.textPrimary }}>
                  Edit Entity Details
                </h2>
                <div className="flex items-center gap-2">
                  <Button 
                    variant="primary" 
                    icon={<Save className="w-4 h-4" />}
                    glow
                  >
                    Save Changes
                  </Button>
                  <button
                    onClick={handleClose}
                    className="p-2 rounded-lg hover:bg-black/5 transition-colors"
                  >
                    <X className="w-5 h-5" style={{ color: colors.textSecondary }} />
                  </button>
                </div>
              </div>

              {/* Tabs */}
              <div className="flex gap-1">
                {[
                  { id: 'basic' as const, label: 'Basic Info', icon: FileText },
                  { id: 'attributes' as const, label: 'Attributes', icon: List },
                  { id: 'history' as const, label: 'History', icon: History },
                ].map((tab) => {
                  const Icon = tab.icon;
                  const isActive = activeTab === tab.id;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      className="flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all duration-200 relative"
                      style={{
                        color: isActive ? colors.primary : colors.textSecondary,
                        backgroundColor: isActive ? colors.primaryLight : 'transparent'
                      }}
                    >
                      <Icon className="w-4 h-4" />
                      <span className="text-sm">{tab.label}</span>
                      {isActive && (
                        <motion.div
                          layoutId="activeTabEntity"
                          className="absolute bottom-0 left-0 right-0 h-0.5"
                          style={{ backgroundColor: colors.primary }}
                        />
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Panel Body */}
            <div className="flex-1 overflow-auto p-6">
              <AnimatePresence mode="wait">
                {activeTab === 'basic' && (
                  <motion.div
                    key="basic"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    transition={{ duration: 0.3 }}
                    className="space-y-4"
                  >
                    <div className="grid grid-cols-2 gap-4">
                      <div className="relative">
                        <input
                          type="text"
                          defaultValue={selectedEntity.entityName}
                          className="peer w-full px-4 pt-6 pb-2 rounded-xl border-2 font-mono transition-all duration-200 focus:outline-none"
                          style={{
                            borderColor: colors.border,
                            backgroundColor: colors.background
                          }}
                          onFocus={(e) => {
                            e.currentTarget.style.borderColor = colors.primary;
                            e.currentTarget.style.boxShadow = `0 0 0 4px ${colors.primaryLight}`;
                          }}
                          onBlur={(e) => {
                            e.currentTarget.style.borderColor = colors.border;
                            e.currentTarget.style.boxShadow = 'none';
                          }}
                        />
                        <label
                          className="absolute left-4 top-2 text-xs font-medium transition-all"
                          style={{ color: colors.textSecondary }}
                        >
                          엔터티명 (영문)
                        </label>
                      </div>

                      <div className="relative">
                        <input
                          type="text"
                          defaultValue={selectedEntity.entityLogicalName}
                          className="peer w-full px-4 pt-6 pb-2 rounded-xl border-2 transition-all duration-200 focus:outline-none"
                          style={{
                            borderColor: colors.border,
                            backgroundColor: colors.background
                          }}
                          onFocus={(e) => {
                            e.currentTarget.style.borderColor = colors.primary;
                            e.currentTarget.style.boxShadow = `0 0 0 4px ${colors.primaryLight}`;
                          }}
                          onBlur={(e) => {
                            e.currentTarget.style.borderColor = colors.border;
                            e.currentTarget.style.boxShadow = 'none';
                          }}
                        />
                        <label
                          className="absolute left-4 top-2 text-xs font-medium transition-all"
                          style={{ color: colors.textSecondary }}
                        >
                          엔터티 논리명
                        </label>
                      </div>
                    </div>

                    <div className="relative">
                      <select
                        defaultValue={selectedEntity.subjectArea}
                        className="peer w-full px-4 pt-6 pb-2 rounded-xl border-2 transition-all duration-200 focus:outline-none"
                        style={{
                          borderColor: colors.border,
                          backgroundColor: colors.background
                        }}
                        onFocus={(e) => {
                          e.currentTarget.style.borderColor = colors.primary;
                          e.currentTarget.style.boxShadow = `0 0 0 4px ${colors.primaryLight}`;
                        }}
                        onBlur={(e) => {
                          e.currentTarget.style.borderColor = colors.border;
                          e.currentTarget.style.boxShadow = 'none';
                        }}
                      >
                        <option value="고객관리">고객관리</option>
                        <option value="상품관리">상품관리</option>
                        <option value="주문관리">주문관리</option>
                        <option value="재무관리">재무관리</option>
                      </select>
                      <label
                        className="absolute left-4 top-2 text-xs font-medium transition-all"
                        style={{ color: colors.textSecondary }}
                      >
                        주제 영역
                      </label>
                    </div>

                    <div className="relative">
                      <textarea
                        defaultValue={selectedEntity.description}
                        className="peer w-full px-4 pt-6 pb-2 rounded-xl border-2 transition-all duration-200 focus:outline-none resize-none"
                        style={{
                          borderColor: colors.border,
                          backgroundColor: colors.background
                        }}
                        rows={4}
                        onFocus={(e) => {
                          e.currentTarget.style.borderColor = colors.primary;
                          e.currentTarget.style.boxShadow = `0 0 0 4px ${colors.primaryLight}`;
                        }}
                        onBlur={(e) => {
                          e.currentTarget.style.borderColor = colors.border;
                          e.currentTarget.style.boxShadow = 'none';
                        }}
                      />
                      <label
                        className="absolute left-4 top-2 text-xs font-medium transition-all"
                        style={{ color: colors.textSecondary }}
                      >
                        설명
                      </label>
                    </div>

                    <div className="relative">
                      <input
                        type="text"
                        defaultValue={selectedEntity.owner}
                        className="peer w-full px-4 pt-6 pb-2 rounded-xl border-2 transition-all duration-200 focus:outline-none"
                        style={{
                          borderColor: colors.border,
                          backgroundColor: colors.background
                        }}
                        onFocus={(e) => {
                          e.currentTarget.style.borderColor = colors.primary;
                          e.currentTarget.style.boxShadow = `0 0 0 4px ${colors.primaryLight}`;
                        }}
                        onBlur={(e) => {
                          e.currentTarget.style.borderColor = colors.border;
                          e.currentTarget.style.boxShadow = 'none';
                        }}
                      />
                      <label
                        className="absolute left-4 top-2 text-xs font-medium transition-all"
                        style={{ color: colors.textSecondary }}
                      >
                        담당자
                      </label>
                    </div>
                  </motion.div>
                )}

                {activeTab === 'attributes' && (
                  <motion.div
                    key="attributes"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    className="space-y-3"
                  >
                    <div className="flex items-center justify-between mb-3">
                      <p className="font-medium" style={{ color: colors.textPrimary }}>
                        속성 목록 ({mockAttributes.length})
                      </p>
                      <Button variant="ghost" size="sm" icon={<Plus className="w-3 h-3" />}>
                        추가
                      </Button>
                    </div>
                    {mockAttributes.map((attr, idx) => (
                      <div
                        key={idx}
                        className="p-3 rounded-lg border"
                        style={{ borderColor: colors.divider }}
                      >
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-mono font-medium" style={{ color: colors.textPrimary }}>
                            {attr.name}
                          </span>
                          {attr.pk && <Badge variant="error" size="sm">PK</Badge>}
                        </div>
                        <div className="text-sm" style={{ color: colors.textSecondary }}>
                          {attr.logicalName} · {attr.type}
                        </div>
                      </div>
                    ))}
                  </motion.div>
                )}

                {activeTab === 'history' && (
                  <motion.div
                    key="history"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    className="space-y-3"
                  >
                    <div className="p-4 rounded-lg border" style={{ borderColor: colors.divider }}>
                      <div className="flex items-center gap-2 mb-2">
                        <Badge variant="primary">등록</Badge>
                        <span className="text-sm" style={{ color: colors.textSecondary }}>
                          by {selectedEntity.owner}
                        </span>
                      </div>
                      <p className="text-sm mb-1" style={{ color: colors.textPrimary }}>
                        신규 엔터티 등록
                      </p>
                      <p className="text-xs" style={{ color: colors.textTertiary }}>
                        2024-01-15 09:00
                      </p>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
