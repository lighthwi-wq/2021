import { Tag, Plus, Search, Filter, Download, X, ChevronRight, Save, History, Database, FileText } from 'lucide-react';
import { Card } from '../components/common/Card';
import { Button } from '../components/common/Button';
import { Badge } from '../components/common/Badge';
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { colors } from '../constants/designSystem';
import { useModal } from '../contexts/ModalContext';

interface Term {
  id: string;
  termName: string;
  englishName: string;
  domain: string;
  definition: string;
  composition: string[];
  status: string;
  usageCount: number;
  createdDate: string;
  createdBy: string;
}

const mockTerms: Term[] = [
  { 
    id: '1', 
    termName: '고객번호', 
    englishName: 'CUST_NO', 
    domain: '번호타입', 
    definition: '고객을 고유하게 식별하는 번호',
    composition: ['고객', '번호'],
    status: '표준', 
    usageCount: 45,
    createdDate: '2024-01-15', 
    createdBy: '김표준' 
  },
  { 
    id: '2', 
    termName: '계약일자', 
    englishName: 'CNTR_DT', 
    domain: '일자타입', 
    definition: '계약이 체결된 일자',
    composition: ['계약', '일자'],
    status: '표준', 
    usageCount: 32,
    createdDate: '2024-01-16', 
    createdBy: '이표준' 
  },
  { 
    id: '3', 
    termName: '주문금액', 
    englishName: 'ORD_AMT', 
    domain: '금액타입', 
    definition: '주문의 총 금액',
    composition: ['주문', '금액'],
    status: '표준', 
    usageCount: 28,
    createdDate: '2024-01-17', 
    createdBy: '박표준' 
  },
  { 
    id: '4', 
    termName: '상품코드', 
    englishName: 'PROD_CD', 
    domain: '코드타입', 
    definition: '상품을 구분하는 코드',
    composition: ['상품', '코드'],
    status: '표준', 
    usageCount: 67,
    createdDate: '2024-01-18', 
    createdBy: '최표준' 
  },
  { 
    id: '5', 
    termName: '고객명', 
    englishName: 'CUST_NM', 
    domain: '명칭타입', 
    definition: '고객의 이름',
    composition: ['고객', '명'],
    status: '표준', 
    usageCount: 52,
    createdDate: '2024-01-19', 
    createdBy: '정표준' 
  },
];

const relatedTables = [
  { table: 'TB_CUSTOMER', column: 'CUST_NO', usage: 'Primary Key' },
  { table: 'TB_ORDER', column: 'CUST_NO', usage: 'Foreign Key' },
  { table: 'TB_ACCOUNT', column: 'CUST_NO', usage: 'Foreign Key' },
];

const historyData = [
  { date: '2024-01-26 14:30', user: '김표준', action: '수정', description: '도메인 타입 변경' },
  { date: '2024-01-20 10:15', user: '이표준', action: '승인', description: '표준 용어로 승인됨' },
  { date: '2024-01-15 09:00', user: '김표준', action: '등록', description: '신규 용어 등록' },
];

export function StandardTermPage() {
  const { setIsModalOpen } = useModal();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedTerm, setSelectedTerm] = useState<Term | null>(null);
  const [activeTab, setActiveTab] = useState<'basic' | 'attributes' | 'related' | 'history'>('basic');
  const [showCreateModal, setShowCreateModal] = useState(false);

  useEffect(() => {
    setIsModalOpen(!!selectedTerm || showCreateModal);
  }, [selectedTerm, showCreateModal, setIsModalOpen]);

  const handleRowClick = (term: Term) => {
    setSelectedTerm(term);
    setActiveTab('basic');
  };

  const handleClose = () => {
    setSelectedTerm(null);
  };

  const filteredTerms = mockTerms.filter(term =>
    term.termName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    term.englishName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="h-full flex gap-0 overflow-hidden">
      {/* Main Data Grid - Dynamic Width */}
      <motion.div
        className="flex flex-col"
        initial={{ width: '100%' }}
        animate={{ width: selectedTerm ? '60%' : '100%' }}
        transition={{ duration: 0.4, ease: [0.4, 0, 0.2, 1] }}
      >
        <div className="space-y-6 p-6 overflow-auto h-full">
          {/* Stats Cards */}
          <div className="grid grid-cols-4 gap-4">
            <Card>
              <div className="flex items-center gap-3">
                <div 
                  className="p-3 rounded-xl"
                  style={{ backgroundColor: colors.primaryLight }}
                >
                  <Tag className="w-6 h-6" style={{ color: colors.primary }} />
                </div>
                <div>
                  <p className="text-sm" style={{ color: colors.textSecondary }}>전체 용어</p>
                  <p className="text-2xl font-bold" style={{ color: colors.textPrimary }}>247</p>
                </div>
              </div>
            </Card>
            <Card>
              <div className="flex items-center gap-3">
                <div 
                  className="p-3 rounded-xl"
                  style={{ backgroundColor: colors.successLight }}
                >
                  <Tag className="w-6 h-6" style={{ color: colors.success }} />
                </div>
                <div>
                  <p className="text-sm" style={{ color: colors.textSecondary }}>표준 용어</p>
                  <p className="text-2xl font-bold" style={{ color: colors.textPrimary }}>198</p>
                </div>
              </div>
            </Card>
            <Card>
              <div className="flex items-center gap-3">
                <div 
                  className="p-3 rounded-xl"
                  style={{ backgroundColor: colors.warningLight }}
                >
                  <Tag className="w-6 h-6" style={{ color: colors.warning }} />
                </div>
                <div>
                  <p className="text-sm" style={{ color: colors.textSecondary }}>검토중</p>
                  <p className="text-2xl font-bold" style={{ color: colors.textPrimary }}>32</p>
                </div>
              </div>
            </Card>
            <Card>
              <div className="flex items-center gap-3">
                <div 
                  className="p-3 rounded-xl"
                  style={{ backgroundColor: colors.errorLight }}
                >
                  <Tag className="w-6 h-6" style={{ color: colors.error }} />
                </div>
                <div>
                  <p className="text-sm" style={{ color: colors.textSecondary }}>반려</p>
                  <p className="text-2xl font-bold" style={{ color: colors.textPrimary }}>17</p>
                </div>
              </div>
            </Card>
          </div>

          {/* Actions Bar */}
          <Card>
            <div className="flex items-center justify-between">
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: colors.textTertiary }} />
                <input
                  type="text"
                  placeholder="용어명으로 검색..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 rounded-lg border"
                  style={{
                    borderColor: colors.border,
                    backgroundColor: colors.background,
                  }}
                />
              </div>
              <div className="flex gap-2">
                <Button variant="ghost" icon={<Filter className="w-4 h-4" />}>
                  필터
                </Button>
                <Button variant="secondary" icon={<Download className="w-4 h-4" />}>
                  Export
                </Button>
                <Button variant="primary" icon={<Plus className="w-4 h-4" />} onClick={() => setShowCreateModal(true)}>
                  용어 추가
                </Button>
              </div>
            </div>
          </Card>

          {/* Terms Table */}
          <Card>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b" style={{ borderColor: colors.divider }}>
                    <th className="text-left py-3 px-4" style={{ color: colors.textSecondary }}>용어명</th>
                    <th className="text-left py-3 px-4" style={{ color: colors.textSecondary }}>영문명</th>
                    <th className="text-left py-3 px-4" style={{ color: colors.textSecondary }}>도메인</th>
                    <th className="text-left py-3 px-4" style={{ color: colors.textSecondary }}>구성단어</th>
                    <th className="text-center py-3 px-4" style={{ color: colors.textSecondary }}>사용처</th>
                    <th className="text-center py-3 px-4" style={{ color: colors.textSecondary }}>상태</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredTerms.map((term) => (
                    <motion.tr
                      key={term.id}
                      onClick={() => handleRowClick(term)}
                      className="border-b cursor-pointer transition-colors"
                      style={{ 
                        borderColor: colors.divider,
                        backgroundColor: selectedTerm?.id === term.id ? colors.primaryLight : 'transparent'
                      }}
                      whileHover={{ 
                        backgroundColor: colors.primaryLight,
                        transition: { duration: 0.2 }
                      }}
                    >
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2">
                          <span className="font-medium" style={{ color: colors.textPrimary }}>
                            {term.termName}
                          </span>
                          {selectedTerm?.id === term.id && (
                            <ChevronRight className="w-4 h-4" style={{ color: colors.primary }} />
                          )}
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        <span className="font-mono text-sm" style={{ color: colors.textSecondary }}>
                          {term.englishName}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <Badge variant="info">{term.domain}</Badge>
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex gap-1">
                          {term.composition.map((word, idx) => (
                            <span
                              key={idx}
                              className="px-2 py-0.5 rounded text-xs"
                              style={{
                                backgroundColor: colors.backgroundSecondary,
                                color: colors.textSecondary
                              }}
                            >
                              {word}
                            </span>
                          ))}
                        </div>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <Badge variant="primary">{term.usageCount}</Badge>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <Badge variant="success">{term.status}</Badge>
                      </td>
                    </motion.tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </div>
      </motion.div>

      {/* Glass Separator */}
      <AnimatePresence>
        {selectedTerm && (
          <motion.div
            initial={{ opacity: 0, scaleX: 0 }}
            animate={{ opacity: 1, scaleX: 1 }}
            exit={{ opacity: 0, scaleX: 0 }}
            transition={{ duration: 0.3 }}
            className="w-px"
            style={{
              background: `linear-gradient(180deg, transparent, ${colors.border}, transparent)`,
              transformOrigin: 'left'
            }}
          />
        )}
      </AnimatePresence>

      {/* Right Detail Panel - 40% Width */}
      <AnimatePresence>
        {selectedTerm && (
          <motion.div
            initial={{ x: '100%', opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: '100%', opacity: 0 }}
            transition={{ duration: 0.4, ease: [0.4, 0, 0.2, 1] }}
            className="flex flex-col overflow-hidden"
            style={{
              width: '40%',
              backgroundColor: colors.background,
              backdropFilter: 'blur(20px)',
              boxShadow: '-4px 0 24px rgba(0, 0, 0, 0.08)'
            }}
          >
            {/* Sticky Header */}
            <div 
              className="sticky top-0 z-10 px-6 py-4 border-b"
              style={{ 
                backgroundColor: colors.background,
                borderColor: colors.divider,
                backdropFilter: 'blur(20px)'
              }}
            >
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold" style={{ color: colors.textPrimary }}>
                  Edit Term Details
                </h2>
                <div className="flex items-center gap-2">
                  <Button 
                    variant="primary" 
                    icon={<Save className="w-4 h-4" />}
                    glow
                  >
                    Save Changes
                  </Button>
                  <button
                    onClick={handleClose}
                    className="p-2 rounded-lg hover:bg-black/5 transition-colors"
                  >
                    <X className="w-5 h-5" style={{ color: colors.textSecondary }} />
                  </button>
                </div>
              </div>

              {/* Tabs */}
              <div className="flex gap-1">
                {[
                  { id: 'basic' as const, label: 'Basic Info', icon: FileText },
                  { id: 'attributes' as const, label: 'Attributes', icon: Tag },
                  { id: 'related' as const, label: 'Related Tables', icon: Database },
                  { id: 'history' as const, label: 'History', icon: History },
                ].map((tab) => {
                  const Icon = tab.icon;
                  const isActive = activeTab === tab.id;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      className="flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all duration-200 relative"
                      style={{
                        color: isActive ? colors.primary : colors.textSecondary,
                        backgroundColor: isActive ? colors.primaryLight : 'transparent'
                      }}
                    >
                      <Icon className="w-4 h-4" />
                      <span className="text-sm">{tab.label}</span>
                      {isActive && (
                        <motion.div
                          layoutId="activeTab"
                          className="absolute bottom-0 left-0 right-0 h-0.5"
                          style={{ backgroundColor: colors.primary }}
                        />
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Panel Body */}
            <div className="flex-1 overflow-auto p-6">
              <AnimatePresence mode="wait">
                {activeTab === 'basic' && (
                  <motion.div
                    key="basic"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    transition={{ duration: 0.3 }}
                    className="space-y-6"
                  >
                    {/* Floating Label Inputs */}
                    <div className="space-y-4">
                      <div className="relative">
                        <input
                          type="text"
                          defaultValue={selectedTerm.termName}
                          className="peer w-full px-4 pt-6 pb-2 rounded-xl border-2 transition-all duration-200 focus:outline-none"
                          style={{
                            borderColor: colors.border,
                            backgroundColor: colors.background
                          }}
                          onFocus={(e) => {
                            e.currentTarget.style.borderColor = colors.primary;
                            e.currentTarget.style.boxShadow = `0 0 0 4px ${colors.primaryLight}`;
                          }}
                          onBlur={(e) => {
                            e.currentTarget.style.borderColor = colors.border;
                            e.currentTarget.style.boxShadow = 'none';
                          }}
                        />
                        <label
                          className="absolute left-4 top-2 text-xs font-medium transition-all"
                          style={{ color: colors.textSecondary }}
                        >
                          용어명 (한글)
                        </label>
                      </div>

                      <div className="relative">
                        <input
                          type="text"
                          defaultValue={selectedTerm.englishName}
                          className="peer w-full px-4 pt-6 pb-2 rounded-xl border-2 font-mono transition-all duration-200 focus:outline-none"
                          style={{
                            borderColor: colors.border,
                            backgroundColor: colors.background
                          }}
                          onFocus={(e) => {
                            e.currentTarget.style.borderColor = colors.primary;
                            e.currentTarget.style.boxShadow = `0 0 0 4px ${colors.primaryLight}`;
                          }}
                          onBlur={(e) => {
                            e.currentTarget.style.borderColor = colors.border;
                            e.currentTarget.style.boxShadow = 'none';
                          }}
                        />
                        <label
                          className="absolute left-4 top-2 text-xs font-medium transition-all"
                          style={{ color: colors.textSecondary }}
                        >
                          영문 약어
                        </label>
                      </div>

                      <div className="relative">
                        <textarea
                          defaultValue={selectedTerm.definition}
                          rows={4}
                          className="peer w-full px-4 pt-6 pb-2 rounded-xl border-2 transition-all duration-200 focus:outline-none resize-none"
                          style={{
                            borderColor: colors.border,
                            backgroundColor: colors.background
                          }}
                          onFocus={(e) => {
                            e.currentTarget.style.borderColor = colors.primary;
                            e.currentTarget.style.boxShadow = `0 0 0 4px ${colors.primaryLight}`;
                          }}
                          onBlur={(e) => {
                            e.currentTarget.style.borderColor = colors.border;
                            e.currentTarget.style.boxShadow = 'none';
                          }}
                        />
                        <label
                          className="absolute left-4 top-2 text-xs font-medium transition-all"
                          style={{ color: colors.textSecondary }}
                        >
                          용어 정의
                        </label>
                      </div>
                    </div>

                    {/* Related Domain Info - Read Only Reference */}
                    <div 
                      className="p-4 rounded-xl border"
                      style={{ 
                        backgroundColor: colors.backgroundSecondary,
                        borderColor: colors.divider
                      }}
                    >
                      <div className="flex items-center gap-2 mb-3">
                        <Database className="w-4 h-4" style={{ color: colors.primary }} />
                        <h4 className="font-medium" style={{ color: colors.textPrimary }}>
                          Related Domain
                        </h4>
                        <Badge variant="info" size="sm">Reference</Badge>
                      </div>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span style={{ color: colors.textSecondary }}>도메인명</span>
                          <span className="font-medium" style={{ color: colors.textPrimary }}>
                            {selectedTerm.domain}
                          </span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span style={{ color: colors.textSecondary }}>데이터 타입</span>
                          <span className="font-mono" style={{ color: colors.textPrimary }}>VARCHAR(20)</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span style={{ color: colors.textSecondary }}>Nullable</span>
                          <Badge variant="error" size="sm">Not Null</Badge>
                        </div>
                      </div>
                    </div>

                    {/* Composition */}
                    <div>
                      <label className="block mb-3 font-medium" style={{ color: colors.textPrimary }}>
                        구성 단어
                      </label>
                      <div className="flex flex-wrap gap-2">
                        {selectedTerm.composition.map((word, idx) => (
                          <div
                            key={idx}
                            className="px-4 py-2 rounded-lg border-2"
                            style={{
                              borderColor: colors.primary,
                              backgroundColor: colors.primaryLight,
                              color: colors.primary
                            }}
                          >
                            {word}
                          </div>
                        ))}
                      </div>
                    </div>
                  </motion.div>
                )}

                {activeTab === 'attributes' && (
                  <motion.div
                    key="attributes"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    className="space-y-4"
                  >
                    <p style={{ color: colors.textSecondary }}>
                      속성 정보를 관리할 수 있습니다.
                    </p>
                  </motion.div>
                )}

                {activeTab === 'related' && (
                  <motion.div
                    key="related"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    className="space-y-4"
                  >
                    <h4 className="font-medium mb-3" style={{ color: colors.textPrimary }}>
                      이 용어를 사용하는 테이블 ({relatedTables.length})
                    </h4>
                    <div className="space-y-2">
                      {relatedTables.map((rel, idx) => (
                        <div
                          key={idx}
                          className="p-4 rounded-lg border"
                          style={{ borderColor: colors.divider }}
                        >
                          <div className="flex items-center justify-between mb-2">
                            <span className="font-mono font-medium" style={{ color: colors.textPrimary }}>
                              {rel.table}
                            </span>
                            <Badge variant="info">{rel.usage}</Badge>
                          </div>
                          <div className="text-sm font-mono" style={{ color: colors.textSecondary }}>
                            Column: {rel.column}
                          </div>
                        </div>
                      ))}
                    </div>
                  </motion.div>
                )}

                {activeTab === 'history' && (
                  <motion.div
                    key="history"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    className="space-y-3"
                  >
                    {historyData.map((item, idx) => (
                      <div
                        key={idx}
                        className="p-4 rounded-lg border"
                        style={{ borderColor: colors.divider }}
                      >
                        <div className="flex items-center gap-2 mb-2">
                          <Badge variant="primary">{item.action}</Badge>
                          <span className="text-sm" style={{ color: colors.textSecondary }}>
                            by {item.user}
                          </span>
                        </div>
                        <p className="text-sm mb-1" style={{ color: colors.textPrimary }}>
                          {item.description}
                        </p>
                        <p className="text-xs" style={{ color: colors.textTertiary }}>
                          {item.date}
                        </p>
                      </div>
                    ))}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Create Modal */}
      <AnimatePresence>
        {showCreateModal && (
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 30, stiffness: 300 }}
            className="fixed top-0 right-0 bottom-0 z-50 shadow-2xl border-l overflow-hidden flex flex-col"
            style={{
              width: '400px',
              backgroundColor: colors.background,
              borderColor: colors.divider
            }}
          >
            {/* Header */}
            <div className="px-6 py-4 border-b flex items-center justify-between" style={{ borderColor: colors.divider }}>
              <div>
                <h3 className="text-xl font-bold" style={{ color: colors.textPrimary }}>신규 표준 용어 등록</h3>
                <p className="text-sm mt-1" style={{ color: colors.textSecondary }}>새로운 표준 용어를 등록합니다</p>
              </div>
              <button
                onClick={() => setShowCreateModal(false)}
                className="p-2 rounded-lg hover:bg-black/5 transition-colors"
              >
                <X className="w-5 h-5" style={{ color: colors.textSecondary }} />
              </button>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto p-6 space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium" style={{ color: colors.textSecondary }}>
                  표준 용어명 <span style={{ color: colors.error }}>*</span>
                </label>
                <input
                  type="text"
                  placeholder="예: 고객번호"
                  className="w-full px-4 py-2 rounded-lg border focus:outline-none focus:ring-2"
                  style={{
                    borderColor: colors.border,
                    backgroundColor: colors.background
                  }}
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium" style={{ color: colors.textSecondary }}>
                  영문명 <span style={{ color: colors.error }}>*</span>
                </label>
                <input
                  type="text"
                  placeholder="예: CUSTOMER_NO"
                  className="w-full px-4 py-2 rounded-lg border font-mono focus:outline-none focus:ring-2"
                  style={{
                    borderColor: colors.border,
                    backgroundColor: colors.background
                  }}
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium" style={{ color: colors.textSecondary }}>
                  용어 설명 <span style={{ color: colors.error }}>*</span>
                </label>
                <textarea
                  rows={4}
                  placeholder="표준 용어에 대한 설명을 입력하세요"
                  className="w-full px-4 py-2 rounded-lg border focus:outline-none focus:ring-2 resize-none"
                  style={{
                    borderColor: colors.border,
                    backgroundColor: colors.background
                  }}
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium" style={{ color: colors.textSecondary }}>
                  도메인 <span style={{ color: colors.error }}>*</span>
                </label>
                <select
                  className="w-full px-4 py-2 rounded-lg border focus:outline-none focus:ring-2"
                  style={{
                    borderColor: colors.border,
                    backgroundColor: colors.background
                  }}
                >
                  <option value="">선택하세요</option>
                  <option value="VARCHAR200">VARCHAR200</option>
                  <option value="NUMBER10">NUMBER10</option>
                  <option value="DATE8">DATE8</option>
                </select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium" style={{ color: colors.textSecondary }}>
                  업무 영역
                </label>
                <select
                  className="w-full px-4 py-2 rounded-lg border focus:outline-none focus:ring-2"
                  style={{
                    borderColor: colors.border,
                    backgroundColor: colors.background
                  }}
                >
                  <option value="">선택하세요</option>
                  <option value="고객관리">고객관리</option>
                  <option value="주문관리">주문관리</option>
                  <option value="상품관리">상품관리</option>
                </select>
              </div>
            </div>

            {/* Footer */}
            <div className="px-6 py-4 border-t flex items-center justify-end gap-3" style={{ borderColor: colors.divider }}>
              <Button variant="ghost" onClick={() => setShowCreateModal(false)}>
                취소
              </Button>
              <Button variant="primary" glow>
                등록
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}