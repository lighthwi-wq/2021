import { Card } from '../components/common/Card';
import { Button } from '../components/common/Button';
import { Badge } from '../components/common/Badge';
import { GitBranch, Search } from 'lucide-react';
import { colors } from '../constants/designSystem';

const changes = [
  { id: 1, type: '컬럼 추가', target: 'TB_CUSTOMER.ADDRESS2', requester: '김철수', status: 'approved', date: '2024-01-27' },
  { id: 2, type: '테이블 생성', target: 'TB_PAYMENT_HISTORY', requester: '이영희', status: 'pending', date: '2024-01-26' },
  { id: 3, type: '컬럼 타입 변경', target: 'TB_ORDER.ORDER_AMT', requester: '박지훈', status: 'rejected', date: '2024-01-25' },
  { id: 4, type: '인덱스 추가', target: 'TB_PRODUCT.CATEGORY_CD', requester: '최민수', status: 'approved', date: '2024-01-24' },
];

export function ChangeManagementPage() {
  return (
    <div className="space-y-6 animate-fade-in-up">
      {/* Stats */}
      <div className="grid grid-cols-4 gap-4">
        <Card>
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-xl" style={{ backgroundColor: colors.primaryLight }}>
              <GitBranch className="w-6 h-6" style={{ color: colors.primary }} />
            </div>
            <div>
              <p className="text-sm" style={{ color: colors.textSecondary }}>전체 변경</p>
              <p className="text-2xl font-bold" style={{ color: colors.textPrimary }}>127</p>
            </div>
          </div>
        </Card>
        <Card>
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-xl" style={{ backgroundColor: colors.successLight }}>
              <GitBranch className="w-6 h-6" style={{ color: colors.success }} />
            </div>
            <div>
              <p className="text-sm" style={{ color: colors.textSecondary }}>승인</p>
              <p className="text-2xl font-bold" style={{ color: colors.textPrimary }}>89</p>
            </div>
          </div>
        </Card>
        <Card>
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-xl" style={{ backgroundColor: colors.warningLight }}>
              <GitBranch className="w-6 h-6" style={{ color: colors.warning }} />
            </div>
            <div>
              <p className="text-sm" style={{ color: colors.textSecondary }}>대기중</p>
              <p className="text-2xl font-bold" style={{ color: colors.textPrimary }}>23</p>
            </div>
          </div>
        </Card>
        <Card>
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-xl" style={{ backgroundColor: colors.errorLight }}>
              <GitBranch className="w-6 h-6" style={{ color: colors.error }} />
            </div>
            <div>
              <p className="text-sm" style={{ color: colors.textSecondary }}>반려</p>
              <p className="text-2xl font-bold" style={{ color: colors.textPrimary }}>15</p>
            </div>
          </div>
        </Card>
      </div>

      {/* Actions */}
      <Card>
        <div className="flex items-center justify-between">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: colors.textTertiary }} />
            <input
              type="text"
              placeholder="변경 대상으로 검색..."
              className="w-full pl-10 pr-4 py-2 rounded-lg border"
              style={{
                borderColor: colors.border,
                backgroundColor: colors.background,
              }}
            />
          </div>
        </div>
      </Card>

      {/* Change List */}
      <Card>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b" style={{ borderColor: colors.divider }}>
                <th className="text-left py-3 px-4" style={{ color: colors.textSecondary }}>변경 유형</th>
                <th className="text-left py-3 px-4" style={{ color: colors.textSecondary }}>변경 대상</th>
                <th className="text-left py-3 px-4" style={{ color: colors.textSecondary }}>신청자</th>
                <th className="text-center py-3 px-4" style={{ color: colors.textSecondary }}>상태</th>
                <th className="text-left py-3 px-4" style={{ color: colors.textSecondary }}>신청일</th>
                <th className="text-center py-3 px-4" style={{ color: colors.textSecondary }}>액션</th>
              </tr>
            </thead>
            <tbody>
              {changes.map((change) => (
                <tr 
                  key={change.id} 
                  className="border-b hover:bg-black/[0.02] transition-colors"
                  style={{ borderColor: colors.divider }}
                >
                  <td className="py-3 px-4">
                    <Badge variant="info">{change.type}</Badge>
                  </td>
                  <td className="py-3 px-4 font-mono font-medium" style={{ color: colors.textPrimary }}>
                    {change.target}
                  </td>
                  <td className="py-3 px-4" style={{ color: colors.textPrimary }}>
                    {change.requester}
                  </td>
                  <td className="py-3 px-4 text-center">
                    <Badge 
                      variant={
                        change.status === 'approved' ? 'success' : 
                        change.status === 'pending' ? 'warning' : 
                        'error'
                      }
                    >
                      {change.status === 'approved' ? '승인' : change.status === 'pending' ? '대기' : '반려'}
                    </Badge>
                  </td>
                  <td className="py-3 px-4" style={{ color: colors.textSecondary }}>
                    {change.date}
                  </td>
                  <td className="py-3 px-4 text-center">
                    <Button variant="ghost" size="sm">
                      상세 보기
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
