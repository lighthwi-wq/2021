import { Users, Search } from 'lucide-react';
import { Button } from '../components/common/Button';
import { Badge } from '../components/common/Badge';
import { Card } from '../components/common/Card';

export function UsersPage() {
  const users = [
    { name: '김민지', email: 'minji.kim@dataeye.com', role: '관리자', status: '활성', lastActive: '5분 전' },
    { name: '이지훈', email: 'jihoon.lee@dataeye.com', role: '편집자', status: '활성', lastActive: '12분 전' },
    { name: '박서윤', email: 'seoyoon.park@dataeye.com', role: '뷰어', status: '활성', lastActive: '1시간 전' },
    { name: '최동현', email: 'donghyun.choi@dataeye.com', role: '편집자', status: '비활성', lastActive: '2일 전' },
  ];

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center mb-6">
        <Button variant="primary" icon={<Users className="w-4 h-4" />}>
          사용자 초대
        </Button>
        <div className="flex items-center gap-3 rounded-xl px-4 py-2.5 border" style={{ backgroundColor: '#F9F9F9', borderColor: '#DADCE0' }}>
          <Search className="w-4 h-4 text-gray-400" />
          <input 
            type="text" 
            placeholder="사용자 검색..."
            className="bg-transparent border-none outline-none placeholder-gray-400 w-64"
            style={{ color: '#202124' }}
          />
        </div>
      </div>
      <Card padding="sm">
        <table className="w-full">
          <thead>
            <tr className="border-b" style={{ borderColor: '#DADCE0', backgroundColor: '#F7F8FA' }}>
              <th className="px-6 py-4 text-left" style={{ color: '#5F6368' }}>이름</th>
              <th className="px-6 py-4 text-left" style={{ color: '#5F6368' }}>이메일</th>
              <th className="px-6 py-4 text-left" style={{ color: '#5F6368' }}>역할</th>
              <th className="px-6 py-4 text-left" style={{ color: '#5F6368' }}>상태</th>
              <th className="px-6 py-4 text-left" style={{ color: '#5F6368' }}>마지막 활동</th>
            </tr>
          </thead>
          <tbody>
            {users.map((user, idx) => (
              <tr 
                key={idx} 
                className="border-b transition-colors" 
                style={{ borderColor: '#DADCE0', backgroundColor: 'transparent' }}
                onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#F9F9F9'}
                onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
              >
                <td className="px-6 py-4" style={{ color: '#202124' }}>{user.name}</td>
                <td className="px-6 py-4" style={{ color: '#5F6368' }}>{user.email}</td>
                <td className="px-6 py-4">
                  <Badge variant="info">{user.role}</Badge>
                </td>
                <td className="px-6 py-4">
                  <Badge variant={user.status === '활성' ? 'success' : 'default'} dot>
                    {user.status}
                  </Badge>
                </td>
                <td className="px-6 py-4" style={{ color: '#5F6368' }}>{user.lastActive}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </div>
  );
}