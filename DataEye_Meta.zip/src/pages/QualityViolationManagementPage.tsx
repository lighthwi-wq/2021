import { AlertTriangle, Search, Plus, CheckCircle, XCircle, Clock, ArrowUpDown, ChevronUp, ChevronDown, Filter, FileText, Table, Database } from 'lucide-react';
import { Card } from '../components/common/Card';
import { IconBox } from '../components/common/IconBox';
import { Button } from '../components/common/Button';
import { Badge } from '../components/common/Badge';
import { Pagination } from '../components/common/Pagination';
import { ViolationActionFormModal } from '../components/modals/ViolationActionFormModal';
import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { useModal } from '../contexts/ModalContext';

export function QualityViolationManagementPage() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedViolation, setSelectedViolation] = useState<any>(null);
  const [sortField, setSortField] = useState<string>('');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [filters, setFilters] = useState<Record<string, string>>({});
  const [activeFilterColumn, setActiveFilterColumn] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);

  const handleActionClick = (violation: any) => {
    setSelectedViolation(violation);
    setIsModalOpen(true);
  };

  const violations = [
    {
      id: 'V-2024-0156',
      rule: '필수값 검증',
      ruleId: 'QR-001',
      table: 'CUSTOMER',
      column: 'CUST_NM',
      violationType: '빈값 발견',
      severity: 'high',
      detectedDate: '2024-11-20 09:05',
      recordCount: 3,
      sampleData: 'CUST_NO: C001234, C001567, C002341',
      status: '미조치',
      assignee: null
    },
    {
      id: 'V-2024-0157',
      rule: '이메일 형식 검증',
      ruleId: 'QR-002',
      table: 'CUSTOMER',
      column: 'EMAIL',
      violationType: '형식 오류',
      severity: 'medium',
      detectedDate: '2024-11-20 09:05',
      recordCount: 12,
      sampleData: 'invalid@email, test@, @domain.com',
      status: '조치중',
      assignee: '이지훈'
    },
    {
      id: 'V-2024-0158',
      rule: '중복 데이터 검사',
      ruleId: 'QR-004',
      table: 'CUSTOMER',
      column: 'CUST_NO',
      violationType: '중복 데이터',
      severity: 'high',
      detectedDate: '2024-11-20 09:05',
      recordCount: 5,
      sampleData: 'CUST_NO: C003456 (2건), C004567 (3건)',
      status: '미조치',
      assignee: null
    },
    {
      id: 'V-2024-0159',
      rule: '금액 범위 검증',
      ruleId: 'QR-005',
      table: 'TRANSACTION',
      column: 'TRX_AMT',
      violationType: '범위 초과',
      severity: 'medium',
      detectedDate: '2024-11-20 09:05',
      recordCount: 8,
      sampleData: 'TRX_AMT: -1000, -500, -250',
      status: '조치완료',
      assignee: '박서윤'
    },
    {
      id: 'V-2024-0160',
      rule: '날짜 범위 검증',
      ruleId: 'QR-003',
      table: 'ORDER',
      column: 'ORD_DT',
      violationType: '미래 날짜',
      severity: 'high',
      detectedDate: '2024-11-20 09:05',
      recordCount: 2,
      sampleData: 'ORD_DT: 2025-01-15, 2025-02-20',
      status: '조치중',
      assignee: '최동현'
    },
  ];

  const violationStats = [
    { label: '전체 위반', value: '156', icon: AlertTriangle, color: 'red' as const },
    { label: '높음', value: '45', icon: AlertTriangle, color: 'red' as const },
    { label: '중간', value: '78', icon: AlertTriangle, color: 'orange' as const },
    { label: '낮음', value: '33', icon: AlertTriangle, color: 'blue' as const },
  ];

  const tableViolations = [
    { table: 'CUSTOMER', violations: 45, high: 15, medium: 25, low: 5 },
    { table: 'ORDER', violations: 32, high: 8, medium: 18, low: 6 },
    { table: 'PRODUCT', violations: 28, high: 12, medium: 10, low: 6 },
    { table: 'TRANSACTION', violations: 24, high: 5, medium: 15, low: 4 },
    { table: 'INVENTORY', violations: 18, high: 3, medium: 8, low: 7 },
  ];

  const getSeverityVariant = (severity: string) => {
    switch (severity) {
      case 'high': return 'error';
      case 'medium': return 'warning';
      case 'low': return 'default';
      default: return 'default';
    }
  };

  const getSeverityLabel = (severity: string) => {
    switch (severity) {
      case 'high': return '높음';
      case 'medium': return '중간';
      case 'low': return '낮음';
      default: return severity;
    }
  };

  const getStatusVariant = (status: string) => {
    switch (status) {
      case '미조치': return 'error';
      case '조치중': return 'warning';
      case '조치완료': return 'success';
      default: return 'default';
    }
  };

  return (
    <div className="space-y-4 p-0">
      <div className="flex-1 overflow-auto">
        <div className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 mb-6">
            {violationStats.map((stat, idx) => (
              <Card key={idx} padding="lg">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="mb-1" style={{ color: '#5F6368' }}>{stat.label}</p>
                    <h3 className="font-bold" style={{ color: '#202124' }}>{stat.value}</h3>
                  </div>
                  <div className="text-right">
                    <IconBox icon={stat.icon} color={stat.color} size="md" />
                  </div>
                </div>
              </Card>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <div className="lg:col-span-2 space-y-4">
              <Card padding="lg">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
                  <div className="flex items-center gap-3">
                    <IconBox icon={AlertTriangle} color="red" size="md" />
                    <h3 className="font-bold" style={{ color: '#202124' }}>품질 위반 목록</h3>
                  </div>
                  <div className="flex items-center gap-3">
                    <Button variant="secondary" icon={<Filter className="w-4 h-4" />} size="sm">필터</Button>
                    <Button variant="secondary" icon={<FileText className="w-4 h-4" />} size="sm">리포트 생성</Button>
                  </div>
                </div>

                <div className="space-y-3">
                  {violations.map((violation, idx) => (
                    <div key={idx} className="p-4 rounded-xl border-l-4"
                      style={{
                        backgroundColor: '#F9F9F9',
                        borderLeftColor: violation.severity === 'high' ? '#ef4444' : 
                                        violation.severity === 'medium' ? '#f59e0b' : '#6b7280',
                        borderRightColor: '#DADCE0',
                        borderTopColor: '#DADCE0',
                        borderBottomColor: '#DADCE0'
                      }}
                    >
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <h4 className="font-bold" style={{ color: '#202124' }}>{violation.rule}</h4>
                            <Badge variant={getSeverityVariant(violation.severity) as any}>
                              {getSeverityLabel(violation.severity)}
                            </Badge>
                            <Badge variant={getStatusVariant(violation.status) as any}>
                              {violation.status}
                            </Badge>
                            <span className="text-sm" style={{ color: '#5F6368' }}>#{violation.id}</span>
                          </div>
                          
                          <div className="grid grid-cols-2 gap-4 text-sm mb-3">
                            <div>
                              <span style={{ color: '#5F6368' }}>테이블:</span>
                              <span className="ml-2 font-bold font-mono" style={{ color: '#202124' }}>{violation.table}</span>
                            </div>
                            <div>
                              <span style={{ color: '#5F6368' }}>컬럼:</span>
                              <span className="ml-2 font-bold font-mono" style={{ color: '#202124' }}>{violation.column}</span>
                            </div>
                            <div>
                              <span style={{ color: '#5F6368' }}>위반 유형:</span>
                              <span className="ml-2 font-bold" style={{ color: '#202124' }}>{violation.violationType}</span>
                            </div>
                            <div>
                              <span style={{ color: '#5F6368' }}>위반 건수:</span>
                              <span className="ml-2 font-bold" style={{ color: '#EA4335' }}>{violation.recordCount}건</span>
                            </div>
                          </div>

                          <div className="rounded-lg p-3 mb-3" style={{ backgroundColor: '#F1F3F4' }}>
                            <p className="text-xs mb-1" style={{ color: '#5F6368' }}>샘플 데이터:</p>
                            <p className="font-mono text-sm" style={{ color: '#202124' }}>{violation.sampleData}</p>
                          </div>

                          <div className="flex items-center justify-between text-sm">
                            <div>
                              <span style={{ color: '#5F6368' }}>발견일시:</span>
                              <span className="ml-2" style={{ color: '#202124' }}>{violation.detectedDate}</span>
                            </div>
                            {violation.assignee && (
                              <div>
                                <span style={{ color: '#5F6368' }}>담당자:</span>
                                <span className="ml-2 font-bold" style={{ color: '#202124' }}>{violation.assignee}</span>
                              </div>
                            )}
                          </div>
                        </div>
                        <Button variant="secondary" size="sm" onClick={() => handleActionClick(violation)}>조치 등록</Button>
                      </div>
                    </div>
                  ))}
                </div>
                <Pagination totalPages={5} currentPage={1} onPageChange={() => {}} />
              </Card>
            </div>

            <div className="space-y-4">
              <Card padding="lg">
                <div className="flex items-center gap-3 mb-6">
                  <IconBox icon={Table} color="indigo" size="md" />
                  <h3 className="font-bold" style={{ color: '#202124' }}>테이블별 위반 현황</h3>
                </div>
                <div className="space-y-3">
                  {tableViolations.map((item, idx) => (
                    <div key={idx} className="p-3 rounded-xl border" style={{ backgroundColor: '#F9F9F9', borderColor: '#DADCE0' }}>
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-bold font-mono" style={{ color: '#202124' }}>{item.table}</h4>
                        <span className="font-bold" style={{ color: '#EA4335' }}>{item.violations}건</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <div className="flex items-center gap-1">
                          <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                          <span style={{ color: '#5F6368' }}>{item.high}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                          <span style={{ color: '#5F6368' }}>{item.medium}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <div className="w-2 h-2 bg-gray-500 rounded-full"></div>
                          <span style={{ color: '#5F6368' }}>{item.low}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>

              <Card padding="lg">
                <div className="flex items-center gap-3 mb-6">
                  <IconBox icon={Database} color="blue" size="md" />
                  <h3 className="font-bold" style={{ color: '#202124' }}>위반 통계</h3>
                </div>
                <div className="space-y-4">
                  <div className="p-4 rounded-xl border" style={{ backgroundColor: '#FEF2F2', borderColor: '#FECACA' }}>
                    <p className="mb-1" style={{ color: '#DC2626' }}>미조치</p>
                    <h3 className="font-bold" style={{ color: '#991B1B' }}>68건</h3>
                  </div>
                  <div className="p-4 rounded-xl border" style={{ backgroundColor: '#FFFBEB', borderColor: '#FED7AA' }}>
                    <p className="mb-1" style={{ color: '#D97706' }}>조치중</p>
                    <h3 className="font-bold" style={{ color: '#92400E' }}>56건</h3>
                  </div>
                  <div className="p-4 rounded-xl border" style={{ backgroundColor: '#F0FDF4', borderColor: '#BBF7D0' }}>
                    <p className="mb-1" style={{ color: '#16A34A' }}>조치완료</p>
                    <h3 className="font-bold" style={{ color: '#15803D' }}>32건</h3>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        </div>
      </div>

      <ViolationActionFormModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        violationData={selectedViolation || { id: '', rule: '', table: '', column: '', severity: 'high' }}
      />
    </div>
  );
}