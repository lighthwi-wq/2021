import { useState, useEffect } from 'react';
import { Card } from '../components/common/Card';
import { Button } from '../components/common/Button';
import { Badge } from '../components/common/Badge';
import { Plus, Search, Download, Save, X, ChevronRight, History, FileText, Code2 } from 'lucide-react';
import { colors } from '../constants/designSystem';
import { motion, AnimatePresence } from 'motion/react';
import { useModal } from '../contexts/ModalContext';

interface Code {
  id: number;
  codeGroup: string;
  codeValue: string;
  codeName: string;
  description: string;
  order: number;
  useYn: boolean;
}

const mockCodes: Code[] = [
  { id: 1, codeGroup: 'GENDER', codeValue: 'M', codeName: '남성', description: '성별 - 남성', order: 1, useYn: true },
  { id: 2, codeGroup: 'GENDER', codeValue: 'F', codeName: '여성', description: '성별 - 여성', order: 2, useYn: true },
  { id: 3, codeGroup: 'STATUS', codeValue: 'ACT', codeName: '활성', description: '상태 - 활성', order: 1, useYn: true },
  { id: 4, codeGroup: 'STATUS', codeValue: 'INA', codeName: '비활성', description: '상태 - 비활성', order: 2, useYn: true },
  { id: 5, codeGroup: 'STATUS', codeValue: 'DEL', codeName: '삭제', description: '상태 - 삭제됨', order: 3, useYn: false },
  { id: 6, codeGroup: 'PAYMENT', codeValue: 'CARD', codeName: '카드결제', description: '결제수단 - 카드', order: 1, useYn: true },
  { id: 7, codeGroup: 'PAYMENT', codeValue: 'CASH', codeName: '현금결제', description: '결제수단 - 현금', order: 2, useYn: true },
];

export function StandardCodePage() {
  const { setIsModalOpen } = useModal();
  const [selectedCode, setSelectedCode] = useState<Code | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [activeTab, setActiveTab] = useState<'basic' | 'usage' | 'history'>('basic');
  const [showCreateModal, setShowCreateModal] = useState(false);

  useEffect(() => {
    setIsModalOpen(!!selectedCode || showCreateModal);
  }, [selectedCode, showCreateModal, setIsModalOpen]);

  const filteredCodes = mockCodes.filter(code => 
    code.codeGroup.toLowerCase().includes(searchTerm.toLowerCase()) ||
    code.codeName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleRowClick = (code: Code) => {
    setSelectedCode(code);
    setActiveTab('basic');
  };

  const handleClose = () => {
    setSelectedCode(null);
  };

  return (
    <div className="h-full flex gap-0 overflow-hidden">
      {/* Main Data Grid */}
      <motion.div
        className="flex flex-col"
        initial={{ width: '100%' }}
        animate={{ width: selectedCode ? '60%' : '100%' }}
        transition={{ duration: 0.4, ease: [0.4, 0, 0.2, 1] }}
      >
        <div className="space-y-6 p-6 overflow-auto h-full">
          {/* Actions Bar */}
          <Card>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3 flex-1">
                <div className="relative flex-1 max-w-md">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: colors.textTertiary }} />
                  <input
                    type="text"
                    placeholder="코드 그룹, 코드명으로 검색..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 rounded-lg border"
                    style={{
                      borderColor: colors.border,
                      backgroundColor: colors.background,
                    }}
                  />
                </div>
              </div>
              <div className="flex gap-2">
                <Button variant="secondary" icon={<Download className="w-4 h-4" />}>
                  Export
                </Button>
                <Button variant="primary" icon={<Plus className="w-4 h-4" />} onClick={() => setShowCreateModal(true)}>
                  신규 코드 등록
                </Button>
              </div>
            </div>
          </Card>

          {/* Code List */}
          <Card>
            <div className="mb-4">
              <h3 className="font-semibold" style={{ color: colors.textPrimary }}>
                표준 코드 목록 ({filteredCodes.length}건)
              </h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b" style={{ borderColor: colors.divider }}>
                    <th className="text-left py-3 px-4" style={{ color: colors.textSecondary }}>코드 그룹</th>
                    <th className="text-left py-3 px-4" style={{ color: colors.textSecondary }}>코드값</th>
                    <th className="text-left py-3 px-4" style={{ color: colors.textSecondary }}>코드명</th>
                    <th className="text-left py-3 px-4" style={{ color: colors.textSecondary }}>설명</th>
                    <th className="text-center py-3 px-4" style={{ color: colors.textSecondary }}>정렬순서</th>
                    <th className="text-center py-3 px-4" style={{ color: colors.textSecondary }}>사용여부</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredCodes.map((code) => (
                    <motion.tr 
                      key={code.id}
                      onClick={() => handleRowClick(code)}
                      className="border-b cursor-pointer transition-colors"
                      style={{ 
                        borderColor: colors.divider,
                        backgroundColor: selectedCode?.id === code.id ? colors.primaryLight : 'transparent'
                      }}
                      whileHover={{ 
                        backgroundColor: colors.primaryLight,
                        transition: { duration: 0.2 }
                      }}
                    >
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2">
                          <Badge variant="info">{code.codeGroup}</Badge>
                          {selectedCode?.id === code.id && (
                            <ChevronRight className="w-4 h-4" style={{ color: colors.primary }} />
                          )}
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        <span className="font-mono font-medium" style={{ color: colors.textPrimary }}>
                          {code.codeValue}
                        </span>
                      </td>
                      <td className="py-3 px-4" style={{ color: colors.textPrimary }}>
                        {code.codeName}
                      </td>
                      <td className="py-3 px-4" style={{ color: colors.textSecondary }}>
                        {code.description}
                      </td>
                      <td className="py-3 px-4 text-center" style={{ color: colors.textSecondary }}>
                        {code.order}
                      </td>
                      <td className="py-3 px-4 text-center">
                        <Badge variant={code.useYn ? 'success' : 'error'}>
                          {code.useYn ? '사용' : '미사용'}
                        </Badge>
                      </td>
                    </motion.tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </div>
      </motion.div>

      {/* Glass Separator */}
      <AnimatePresence>
        {selectedCode && (
          <motion.div
            initial={{ opacity: 0, scaleX: 0 }}
            animate={{ opacity: 1, scaleX: 1 }}
            exit={{ opacity: 0, scaleX: 0 }}
            transition={{ duration: 0.3 }}
            className="w-px"
            style={{
              background: `linear-gradient(180deg, transparent, ${colors.border}, transparent)`,
              transformOrigin: 'left'
            }}
          />
        )}
      </AnimatePresence>

      {/* Right Detail Panel */}
      <AnimatePresence>
        {selectedCode && (
          <motion.div
            initial={{ x: '100%', opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: '100%', opacity: 0 }}
            transition={{ duration: 0.4, ease: [0.4, 0, 0.2, 1] }}
            className="flex flex-col overflow-hidden"
            style={{
              width: '40%',
              backgroundColor: colors.background,
              backdropFilter: 'blur(20px)',
              boxShadow: '-4px 0 24px rgba(0, 0, 0, 0.08)'
            }}
          >
            {/* Sticky Header */}
            <div 
              className="sticky top-0 z-10 px-6 py-4 border-b"
              style={{ 
                backgroundColor: colors.background,
                borderColor: colors.divider,
                backdropFilter: 'blur(20px)'
              }}
            >
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold" style={{ color: colors.textPrimary }}>
                  Edit Code Details
                </h2>
                <div className="flex items-center gap-2">
                  <Button 
                    variant="primary" 
                    icon={<Save className="w-4 h-4" />}
                    glow
                  >
                    Save Changes
                  </Button>
                  <button
                    onClick={handleClose}
                    className="p-2 rounded-lg hover:bg-black/5 transition-colors"
                  >
                    <X className="w-5 h-5" style={{ color: colors.textSecondary }} />
                  </button>
                </div>
              </div>

              {/* Tabs */}
              <div className="flex gap-1">
                {[
                  { id: 'basic' as const, label: 'Basic Info', icon: FileText },
                  { id: 'usage' as const, label: 'Usage', icon: Code2 },
                  { id: 'history' as const, label: 'History', icon: History },
                ].map((tab) => {
                  const Icon = tab.icon;
                  const isActive = activeTab === tab.id;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      className="flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all duration-200 relative"
                      style={{
                        color: isActive ? colors.primary : colors.textSecondary,
                        backgroundColor: isActive ? colors.primaryLight : 'transparent'
                      }}
                    >
                      <Icon className="w-4 h-4" />
                      <span className="text-sm">{tab.label}</span>
                      {isActive && (
                        <motion.div
                          layoutId="activeTabCode"
                          className="absolute bottom-0 left-0 right-0 h-0.5"
                          style={{ backgroundColor: colors.primary }}
                        />
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Panel Body */}
            <div className="flex-1 overflow-auto p-6">
              <AnimatePresence mode="wait">
                {activeTab === 'basic' && (
                  <motion.div
                    key="basic"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    transition={{ duration: 0.3 }}
                    className="space-y-4"
                  >
                    <div className="relative">
                      <input
                        type="text"
                        defaultValue={selectedCode.codeGroup}
                        className="peer w-full px-4 pt-6 pb-2 rounded-xl border-2 transition-all duration-200 focus:outline-none font-mono"
                        style={{
                          borderColor: colors.border,
                          backgroundColor: colors.background
                        }}
                        onFocus={(e) => {
                          e.currentTarget.style.borderColor = colors.primary;
                          e.currentTarget.style.boxShadow = `0 0 0 4px ${colors.primaryLight}`;
                        }}
                        onBlur={(e) => {
                          e.currentTarget.style.borderColor = colors.border;
                          e.currentTarget.style.boxShadow = 'none';
                        }}
                      />
                      <label
                        className="absolute left-4 top-2 text-xs font-medium transition-all"
                        style={{ color: colors.textSecondary }}
                      >
                        코드 그룹
                      </label>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="relative">
                        <input
                          type="text"
                          defaultValue={selectedCode.codeValue}
                          className="peer w-full px-4 pt-6 pb-2 rounded-xl border-2 transition-all duration-200 focus:outline-none font-mono"
                          style={{
                            borderColor: colors.border,
                            backgroundColor: colors.background
                          }}
                          onFocus={(e) => {
                            e.currentTarget.style.borderColor = colors.primary;
                            e.currentTarget.style.boxShadow = `0 0 0 4px ${colors.primaryLight}`;
                          }}
                          onBlur={(e) => {
                            e.currentTarget.style.borderColor = colors.border;
                            e.currentTarget.style.boxShadow = 'none';
                          }}
                        />
                        <label
                          className="absolute left-4 top-2 text-xs font-medium transition-all"
                          style={{ color: colors.textSecondary }}
                        >
                          코드값
                        </label>
                      </div>

                      <div className="relative">
                        <input
                          type="text"
                          defaultValue={selectedCode.codeName}
                          className="peer w-full px-4 pt-6 pb-2 rounded-xl border-2 transition-all duration-200 focus:outline-none"
                          style={{
                            borderColor: colors.border,
                            backgroundColor: colors.background
                          }}
                          onFocus={(e) => {
                            e.currentTarget.style.borderColor = colors.primary;
                            e.currentTarget.style.boxShadow = `0 0 0 4px ${colors.primaryLight}`;
                          }}
                          onBlur={(e) => {
                            e.currentTarget.style.borderColor = colors.border;
                            e.currentTarget.style.boxShadow = 'none';
                          }}
                        />
                        <label
                          className="absolute left-4 top-2 text-xs font-medium transition-all"
                          style={{ color: colors.textSecondary }}
                        >
                          코드명
                        </label>
                      </div>
                    </div>

                    <div className="relative">
                      <textarea
                        defaultValue={selectedCode.description}
                        className="peer w-full px-4 pt-6 pb-2 rounded-xl border-2 transition-all duration-200 focus:outline-none resize-none"
                        style={{
                          borderColor: colors.border,
                          backgroundColor: colors.background
                        }}
                        rows={3}
                        onFocus={(e) => {
                          e.currentTarget.style.borderColor = colors.primary;
                          e.currentTarget.style.boxShadow = `0 0 0 4px ${colors.primaryLight}`;
                        }}
                        onBlur={(e) => {
                          e.currentTarget.style.borderColor = colors.border;
                          e.currentTarget.style.boxShadow = 'none';
                        }}
                      />
                      <label
                        className="absolute left-4 top-2 text-xs font-medium transition-all"
                        style={{ color: colors.textSecondary }}
                      >
                        설명
                      </label>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="relative">
                        <input
                          type="number"
                          defaultValue={selectedCode.order}
                          className="peer w-full px-4 pt-6 pb-2 rounded-xl border-2 transition-all duration-200 focus:outline-none"
                          style={{
                            borderColor: colors.border,
                            backgroundColor: colors.background
                          }}
                          onFocus={(e) => {
                            e.currentTarget.style.borderColor = colors.primary;
                            e.currentTarget.style.boxShadow = `0 0 0 4px ${colors.primaryLight}`;
                          }}
                          onBlur={(e) => {
                            e.currentTarget.style.borderColor = colors.border;
                            e.currentTarget.style.boxShadow = 'none';
                          }}
                        />
                        <label
                          className="absolute left-4 top-2 text-xs font-medium transition-all"
                          style={{ color: colors.textSecondary }}
                        >
                          정렬순서
                        </label>
                      </div>

                      <div className="relative">
                        <select
                          defaultValue={selectedCode.useYn ? 'Y' : 'N'}
                          className="peer w-full px-4 pt-6 pb-2 rounded-xl border-2 transition-all duration-200 focus:outline-none"
                          style={{
                            borderColor: colors.border,
                            backgroundColor: colors.background
                          }}
                          onFocus={(e) => {
                            e.currentTarget.style.borderColor = colors.primary;
                            e.currentTarget.style.boxShadow = `0 0 0 4px ${colors.primaryLight}`;
                          }}
                          onBlur={(e) => {
                            e.currentTarget.style.borderColor = colors.border;
                            e.currentTarget.style.boxShadow = 'none';
                          }}
                        >
                          <option value="Y">사용</option>
                          <option value="N">미사용</option>
                        </select>
                        <label
                          className="absolute left-4 top-2 text-xs font-medium transition-all"
                          style={{ color: colors.textSecondary }}
                        >
                          사용여부
                        </label>
                      </div>
                    </div>
                  </motion.div>
                )}

                {activeTab === 'usage' && (
                  <motion.div
                    key="usage"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    className="space-y-4"
                  >
                    <p style={{ color: colors.textSecondary }}>
                      이 코드를 사용하는 시스템 정보를 확인할 수 있습니다.
                    </p>
                  </motion.div>
                )}

                {activeTab === 'history' && (
                  <motion.div
                    key="history"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    className="space-y-3"
                  >
                    <div className="p-4 rounded-lg border" style={{ borderColor: colors.divider }}>
                      <div className="flex items-center gap-2 mb-2">
                        <Badge variant="primary">등록</Badge>
                        <span className="text-sm" style={{ color: colors.textSecondary }}>
                          by 김표준
                        </span>
                      </div>
                      <p className="text-sm mb-1" style={{ color: colors.textPrimary }}>
                        신규 코드 등록
                      </p>
                      <p className="text-xs" style={{ color: colors.textTertiary }}>
                        2024-01-15 09:00
                      </p>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Create Modal */}
      <AnimatePresence>
        {showCreateModal && (
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 30, stiffness: 300 }}
            className="fixed top-0 right-0 bottom-0 z-50 shadow-2xl border-l overflow-hidden flex flex-col"
            style={{
              width: '400px',
              backgroundColor: colors.background,
              borderColor: colors.divider
            }}
          >
            {/* Header */}
            <div className="px-6 py-4 border-b flex items-center justify-between" style={{ borderColor: colors.divider }}>
              <div>
                <h3 className="text-xl font-bold" style={{ color: colors.textPrimary }}>신규 표준 코드 등록</h3>
                <p className="text-sm mt-1" style={{ color: colors.textSecondary }}>새로운 표준 코드를 등록합니다</p>
              </div>
              <button
                onClick={() => setShowCreateModal(false)}
                className="p-2 rounded-lg hover:bg-black/5 transition-colors"
              >
                <X className="w-5 h-5" style={{ color: colors.textSecondary }} />
              </button>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto p-6 space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium" style={{ color: colors.textSecondary }}>
                  코드 그룹 <span style={{ color: colors.error }}>*</span>
                </label>
                <input
                  type="text"
                  placeholder="예: GENDER"
                  className="w-full px-4 py-2 rounded-lg border font-mono focus:outline-none focus:ring-2"
                  style={{
                    borderColor: colors.border,
                    backgroundColor: colors.background
                  }}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium" style={{ color: colors.textSecondary }}>
                    코드값 <span style={{ color: colors.error }}>*</span>
                  </label>
                  <input
                    type="text"
                    placeholder="예: M"
                    className="w-full px-4 py-2 rounded-lg border font-mono focus:outline-none focus:ring-2"
                    style={{
                      borderColor: colors.border,
                      backgroundColor: colors.background
                    }}
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium" style={{ color: colors.textSecondary }}>
                    코드명 <span style={{ color: colors.error }}>*</span>
                  </label>
                  <input
                    type="text"
                    placeholder="예: 남성"
                    className="w-full px-4 py-2 rounded-lg border focus:outline-none focus:ring-2"
                    style={{
                      borderColor: colors.border,
                      backgroundColor: colors.background
                    }}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium" style={{ color: colors.textSecondary }}>
                  설명 <span style={{ color: colors.error }}>*</span>
                </label>
                <textarea
                  rows={3}
                  placeholder="코드에 대한 설명을 입력하세요"
                  className="w-full px-4 py-2 rounded-lg border focus:outline-none focus:ring-2 resize-none"
                  style={{
                    borderColor: colors.border,
                    backgroundColor: colors.background
                  }}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium" style={{ color: colors.textSecondary }}>
                    정렬순서 <span style={{ color: colors.error }}>*</span>
                  </label>
                  <input
                    type="number"
                    placeholder="1"
                    defaultValue={1}
                    className="w-full px-4 py-2 rounded-lg border focus:outline-none focus:ring-2"
                    style={{
                      borderColor: colors.border,
                      backgroundColor: colors.background
                    }}
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium" style={{ color: colors.textSecondary }}>
                    사용여부 <span style={{ color: colors.error }}>*</span>
                  </label>
                  <select
                    className="w-full px-4 py-2 rounded-lg border focus:outline-none focus:ring-2"
                    style={{
                      borderColor: colors.border,
                      backgroundColor: colors.background
                    }}
                    defaultValue="Y"
                  >
                    <option value="Y">사용</option>
                    <option value="N">미사용</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="px-6 py-4 border-t flex items-center justify-end gap-3" style={{ borderColor: colors.divider }}>
              <Button variant="ghost" onClick={() => setShowCreateModal(false)}>
                취소
              </Button>
              <Button variant="primary" glow>
                등록
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}