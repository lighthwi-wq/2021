import { ShieldCheck, AlertTriangle, CheckCircle2, XCircle, Sparkles, BarChart4 } from 'lucide-react';
import { Card } from '../components/common/Card';
import { IconBox } from '../components/common/IconBox';
import { Button } from '../components/common/Button';
import { Badge } from '../components/common/Badge';

export function DataQualityPage() {
  const qualityMetrics = [
    { label: '품질 규칙', value: '234', icon: ShieldCheck, color: 'blue' as const, change: '+12' },
    { label: 'AI 추천 규칙', value: '45', icon: Sparkles, color: 'indigo' as const, change: '+8' },
    { label: '품질 위반', value: '18', icon: AlertTriangle, color: 'red' as const, change: '-5' },
    { label: '조치 완료', value: '156', icon: CheckCircle2, color: 'green' as const, change: '+23' },
  ];

  const qualityRules = [
    { name: '필수값 검증', target: '고객 테이블', status: '활성', violations: 3, lastCheck: '5분 전' },
    { name: '데이터 형식 검증', target: '주문 테이블', status: '활성', violations: 0, lastCheck: '10분 전' },
    { name: '중복 데이터 검사', target: '상품 테이블', status: '활성', violations: 12, lastCheck: '15분 전' },
    { name: '참조 무결성 검증', target: '재고 테이블', status: '검토중', violations: 5, lastCheck: '20분 전' },
  ];

  const violationStats = [
    { type: '필수값 누락', count: 8, severity: 'high' },
    { type: '중복 데이터', count: 12, severity: 'medium' },
    { type: '형식 오류', count: 3, severity: 'low' },
    { type: '범위 초과', count: 5, severity: 'medium' },
  ];

  const aiRecommendations = [
    { title: '이메일 형식 검증 규칙 추천', desc: '고객 이메일 필드에 85%의 유효성 패턴 감지', confidence: '85%' },
    { title: '날짜 범위 검증 추천', desc: '주문일자가 미래 날짜인 케이스 발견', confidence: '92%' },
    { title: '금액 범위 검증 추천', desc: '거래 금액의 이상치 패턴 감지', confidence: '78%' },
  ];

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 mb-6">
        {qualityMetrics.map((metric, idx) => (
          <Card key={idx} padding="lg">
            <div className="flex items-center justify-between mb-3">
              <IconBox icon={metric.icon} color={metric.color} size="md" />
              <span className="text-sm font-bold" style={{ color: '#10B981' }}>{metric.change}</span>
            </div>
            <p className="mb-1" style={{ color: '#5F6368' }}>{metric.label}</p>
            <h3 className="font-bold" style={{ color: '#202124' }}>{metric.value}</h3>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 space-y-4">
          <Card padding="lg">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <IconBox icon={ShieldCheck} color="blue" size="md" />
                <h3 className="font-bold" style={{ color: '#202124' }}>품질 규칙 관리</h3>
              </div>
              <Button variant="primary" size="sm">+ 규칙 추가</Button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead style={{ backgroundColor: '#F7F8FA' }}>
                  <tr style={{ borderBottom: '1px solid #DADCE0' }}>
                    <th className="px-4 py-3 text-left text-sm" style={{ color: '#5F6368' }}>규칙명</th>
                    <th className="px-4 py-3 text-left text-sm" style={{ color: '#5F6368' }}>대상</th>
                    <th className="px-4 py-3 text-left text-sm" style={{ color: '#5F6368' }}>상태</th>
                    <th className="px-4 py-3 text-left text-sm" style={{ color: '#5F6368' }}>위반</th>
                  </tr>
                </thead>
                <tbody>
                  {qualityRules.map((rule, idx) => (
                    <tr 
                      key={idx} 
                      className="border-b transition-colors"
                      style={{ borderColor: '#DADCE0', backgroundColor: 'transparent' }}
                      onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#F9F9F9'}
                      onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
                    >
                      <td className="px-4 py-3 font-bold" style={{ color: '#202124' }}>{rule.name}</td>
                      <td className="px-4 py-3" style={{ color: '#5F6368' }}>{rule.target}</td>
                      <td className="px-4 py-3">
                        <Badge variant={rule.status === '활성' ? 'success' : 'warning'}>
                          {rule.status}
                        </Badge>
                      </td>
                      <td className="px-4 py-3">
                        {rule.violations > 0 ? (
                          <span className="font-bold" style={{ color: '#EA4335' }}>{rule.violations}</span>
                        ) : (
                          <span className="font-bold" style={{ color: '#10B981' }}>{rule.violations}</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>

          <Card padding="lg">
            <div className="flex items-center gap-3 mb-6">
              <IconBox icon={AlertTriangle} color="red" size="md" />
              <h3 className="font-bold" style={{ color: '#202124' }}>품질 위반 현황</h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {violationStats.map((violation, idx) => (
                <div key={idx} className="p-4 rounded-xl border" style={{ backgroundColor: '#F9F9F9', borderColor: '#DADCE0' }}>
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-bold" style={{ color: '#202124' }}>{violation.type}</h4>
                    <Badge variant={
                      violation.severity === 'high' ? 'error' : 
                      violation.severity === 'medium' ? 'warning' : 'default'
                    }>
                      {violation.severity === 'high' ? '높음' : 
                       violation.severity === 'medium' ? '중간' : '낮음'}
                    </Badge>
                  </div>
                  <p className="font-bold" style={{ color: '#202124' }}>{violation.count}건</p>
                </div>
              ))}
            </div>
          </Card>
        </div>

        <div className="space-y-4">
          <Card padding="lg">
            <div className="flex items-center gap-3 mb-6">
              <IconBox icon={Sparkles} color="indigo" size="md" />
              <h3 className="font-bold" style={{ color: '#202124' }}>AI 규칙 추천</h3>
            </div>
            <div className="space-y-4">
              {aiRecommendations.map((rec, idx) => (
                <div key={idx} className="p-4 rounded-xl border" style={{ background: 'linear-gradient(to bottom right, #EEF2FF, #DBEAFE)', borderColor: '#C7D2FE' }}>
                  <div className="flex items-start justify-between mb-2">
                    <h4 className="font-bold flex-1" style={{ color: '#202124' }}>{rec.title}</h4>
                    <Badge variant="info">{rec.confidence}</Badge>
                  </div>
                  <p className="mb-3" style={{ color: '#5F6368' }}>{rec.desc}</p>
                  <Button variant="secondary" size="sm" fullWidth>규칙 적용</Button>
                </div>
              ))}
            </div>
          </Card>

          <Card padding="lg">
            <div className="flex items-center gap-3 mb-4">
              <IconBox icon={BarChart4} color="green" size="md" />
              <h3 className="font-bold" style={{ color: '#202124' }}>품질 점수</h3>
            </div>
            <div className="text-center py-6">
              <div className="relative inline-flex items-center justify-center w-32 h-32 mb-4">
                <svg className="w-full h-full transform -rotate-90">
                  <circle cx="64" cy="64" r="56" stroke="#E8EAED" strokeWidth="8" fill="none" />
                  <circle cx="64" cy="64" r="56" stroke="#10B981" strokeWidth="8" fill="none" strokeDasharray="351.86" strokeDashoffset="70.37" />
                </svg>
                <div className="absolute">
                  <span className="font-bold" style={{ color: '#202124' }}>80%</span>
                </div>
              </div>
              <p style={{ color: '#5F6368' }}>전체 데이터 품질 점수</p>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}