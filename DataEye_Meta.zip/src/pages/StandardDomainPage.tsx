import { useState, useEffect } from 'react';
import { Card } from '../components/common/Card';
import { Button } from '../components/common/Button';
import { Badge } from '../components/common/Badge';
import { Plus, Search, Download, Save, X, ChevronRight, History, FileText, Database } from 'lucide-react';
import { colors } from '../constants/designSystem';
import { motion, AnimatePresence } from 'motion/react';
import { useModal } from '../contexts/ModalContext';

interface Domain {
  id: number;
  name: string;
  type: string;
  length: string;
  description: string;
  usage: number;
  nullable: boolean;
}

const mockDomains: Domain[] = [
  { id: 1, name: 'VARCHAR200', type: 'VARCHAR', length: '200', description: '200자 이내 가변 문자열', usage: 156, nullable: true },
  { id: 2, name: 'NUMBER10', type: 'NUMBER', length: '10', description: '10자리 숫자', usage: 89, nullable: false },
  { id: 3, name: 'DATE8', type: 'DATE', length: '8', description: 'YYYYMMDD 형식 날짜', usage: 234, nullable: true },
  { id: 4, name: 'AMOUNT15', type: 'NUMBER', length: '15,2', description: '금액(소수점 2자리)', usage: 67, nullable: false },
  { id: 5, name: 'CODE20', type: 'VARCHAR', length: '20', description: '코드값 20자', usage: 143, nullable: false },
  { id: 6, name: 'TIMESTAMP', type: 'TIMESTAMP', length: '-', description: '타임스탬프', usage: 98, nullable: true },
];

export function StandardDomainPage() {
  const { setIsModalOpen } = useModal();
  const [selectedDomain, setSelectedDomain] = useState<Domain | null>(null);
  const [activeTab, setActiveTab] = useState<'basic' | 'usage' | 'history'>('basic');
  const [showCreateModal, setShowCreateModal] = useState(false);

  useEffect(() => {
    setIsModalOpen(!!selectedDomain || showCreateModal);
  }, [selectedDomain, showCreateModal, setIsModalOpen]);

  const handleRowClick = (domain: Domain) => {
    setSelectedDomain(domain);
    setActiveTab('basic');
  };

  const handleClose = () => {
    setSelectedDomain(null);
  };

  return (
    <div className="h-full flex gap-0 overflow-hidden">
      {/* Main Grid */}
      <motion.div
        className="flex flex-col"
        initial={{ width: '100%' }}
        animate={{ width: selectedDomain ? '60%' : '100%' }}
        transition={{ duration: 0.4, ease: [0.4, 0, 0.2, 1] }}
      >
        <div className="space-y-6 p-6 overflow-auto h-full">
          {/* Actions Bar */}
          <Card>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3 flex-1">
                <div className="relative flex-1 max-w-md">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: colors.textTertiary }} />
                  <input
                    type="text"
                    placeholder="도메인명, 데이터 타입으로 검색..."
                    className="w-full pl-10 pr-4 py-2 rounded-lg border"
                    style={{
                      borderColor: colors.border,
                      backgroundColor: colors.background,
                    }}
                  />
                </div>
              </div>
              <div className="flex gap-2">
                <Button variant="secondary" icon={<Download className="w-4 h-4" />}>
                  Export
                </Button>
                <Button variant="primary" icon={<Plus className="w-4 h-4" />} onClick={() => setShowCreateModal(true)}>
                  신규 도메인 등록
                </Button>
              </div>
            </div>
          </Card>

          {/* Domain List */}
          <Card>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b" style={{ borderColor: colors.divider }}>
                    <th className="text-left py-3 px-4" style={{ color: colors.textSecondary }}>도메인명</th>
                    <th className="text-left py-3 px-4" style={{ color: colors.textSecondary }}>데이터 타입</th>
                    <th className="text-left py-3 px-4" style={{ color: colors.textSecondary }}>길이</th>
                    <th className="text-left py-3 px-4" style={{ color: colors.textSecondary }}>설명</th>
                    <th className="text-center py-3 px-4" style={{ color: colors.textSecondary }}>Nullable</th>
                    <th className="text-center py-3 px-4" style={{ color: colors.textSecondary }}>사용 횟수</th>
                  </tr>
                </thead>
                <tbody>
                  {mockDomains.map((domain) => (
                    <motion.tr 
                      key={domain.id}
                      onClick={() => handleRowClick(domain)}
                      className="border-b cursor-pointer transition-colors"
                      style={{ 
                        borderColor: colors.divider,
                        backgroundColor: selectedDomain?.id === domain.id ? colors.primaryLight : 'transparent'
                      }}
                      whileHover={{ 
                        backgroundColor: colors.primaryLight,
                        transition: { duration: 0.2 }
                      }}
                    >
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2">
                          <span className="font-medium font-mono" style={{ color: colors.textPrimary }}>
                            {domain.name}
                          </span>
                          {selectedDomain?.id === domain.id && (
                            <ChevronRight className="w-4 h-4" style={{ color: colors.primary }} />
                          )}
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        <Badge variant="info">{domain.type}</Badge>
                      </td>
                      <td className="py-3 px-4" style={{ color: colors.textSecondary }}>
                        {domain.length}
                      </td>
                      <td className="py-3 px-4" style={{ color: colors.textSecondary }}>
                        {domain.description}
                      </td>
                      <td className="py-3 px-4 text-center">
                        <Badge variant={domain.nullable ? 'warning' : 'error'}>
                          {domain.nullable ? 'NULL' : 'NOT NULL'}
                        </Badge>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <Badge variant="primary">{domain.usage}</Badge>
                      </td>
                    </motion.tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </div>
      </motion.div>

      {/* Glass Separator */}
      <AnimatePresence>
        {selectedDomain && (
          <motion.div
            initial={{ opacity: 0, scaleX: 0 }}
            animate={{ opacity: 1, scaleX: 1 }}
            exit={{ opacity: 0, scaleX: 0 }}
            transition={{ duration: 0.3 }}
            className="w-px"
            style={{
              background: `linear-gradient(180deg, transparent, ${colors.border}, transparent)`,
              transformOrigin: 'left'
            }}
          />
        )}
      </AnimatePresence>

      {/* Right Detail Panel */}
      <AnimatePresence>
        {selectedDomain && (
          <motion.div
            initial={{ x: '100%', opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: '100%', opacity: 0 }}
            transition={{ duration: 0.4, ease: [0.4, 0, 0.2, 1] }}
            className="flex flex-col overflow-hidden"
            style={{
              width: '40%',
              backgroundColor: colors.background,
              backdropFilter: 'blur(20px)',
              boxShadow: '-4px 0 24px rgba(0, 0, 0, 0.08)'
            }}
          >
            {/* Sticky Header */}
            <div 
              className="sticky top-0 z-10 px-6 py-4 border-b"
              style={{ 
                backgroundColor: colors.background,
                borderColor: colors.divider,
                backdropFilter: 'blur(20px)'
              }}
            >
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold" style={{ color: colors.textPrimary }}>
                  Edit Domain Details
                </h2>
                <div className="flex items-center gap-2">
                  <Button 
                    variant="primary" 
                    icon={<Save className="w-4 h-4" />}
                    glow
                  >
                    Save Changes
                  </Button>
                  <button
                    onClick={handleClose}
                    className="p-2 rounded-lg hover:bg-black/5 transition-colors"
                  >
                    <X className="w-5 h-5" style={{ color: colors.textSecondary }} />
                  </button>
                </div>
              </div>

              {/* Tabs */}
              <div className="flex gap-1">
                {[
                  { id: 'basic' as const, label: 'Basic Info', icon: FileText },
                  { id: 'usage' as const, label: 'Usage', icon: Database },
                  { id: 'history' as const, label: 'History', icon: History },
                ].map((tab) => {
                  const Icon = tab.icon;
                  const isActive = activeTab === tab.id;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      className="flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all duration-200 relative"
                      style={{
                        color: isActive ? colors.primary : colors.textSecondary,
                        backgroundColor: isActive ? colors.primaryLight : 'transparent'
                      }}
                    >
                      <Icon className="w-4 h-4" />
                      <span className="text-sm">{tab.label}</span>
                      {isActive && (
                        <motion.div
                          layoutId="activeTabDomain"
                          className="absolute bottom-0 left-0 right-0 h-0.5"
                          style={{ backgroundColor: colors.primary }}
                        />
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Panel Body */}
            <div className="flex-1 overflow-auto p-6">
              <AnimatePresence mode="wait">
                {activeTab === 'basic' && (
                  <motion.div
                    key="basic"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    transition={{ duration: 0.3 }}
                    className="space-y-4"
                  >
                    <div className="relative">
                      <input
                        type="text"
                        defaultValue={selectedDomain.name}
                        className="peer w-full px-4 pt-6 pb-2 rounded-xl border-2 font-mono transition-all duration-200 focus:outline-none"
                        style={{
                          borderColor: colors.border,
                          backgroundColor: colors.background
                        }}
                        onFocus={(e) => {
                          e.currentTarget.style.borderColor = colors.primary;
                          e.currentTarget.style.boxShadow = `0 0 0 4px ${colors.primaryLight}`;
                        }}
                        onBlur={(e) => {
                          e.currentTarget.style.borderColor = colors.border;
                          e.currentTarget.style.boxShadow = 'none';
                        }}
                      />
                      <label
                        className="absolute left-4 top-2 text-xs font-medium transition-all"
                        style={{ color: colors.textSecondary }}
                      >
                        도메인명
                      </label>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="relative">
                        <select
                          defaultValue={selectedDomain.type}
                          className="peer w-full px-4 pt-6 pb-2 rounded-xl border-2 transition-all duration-200 focus:outline-none"
                          style={{
                            borderColor: colors.border,
                            backgroundColor: colors.background
                          }}
                          onFocus={(e) => {
                            e.currentTarget.style.borderColor = colors.primary;
                            e.currentTarget.style.boxShadow = `0 0 0 4px ${colors.primaryLight}`;
                          }}
                          onBlur={(e) => {
                            e.currentTarget.style.borderColor = colors.border;
                            e.currentTarget.style.boxShadow = 'none';
                          }}
                        >
                          <option value="VARCHAR">VARCHAR</option>
                          <option value="NUMBER">NUMBER</option>
                          <option value="DATE">DATE</option>
                          <option value="TIMESTAMP">TIMESTAMP</option>
                          <option value="CLOB">CLOB</option>
                        </select>
                        <label
                          className="absolute left-4 top-2 text-xs font-medium transition-all"
                          style={{ color: colors.textSecondary }}
                        >
                          데이터 타입
                        </label>
                      </div>

                      <div className="relative">
                        <input
                          type="text"
                          defaultValue={selectedDomain.length}
                          className="peer w-full px-4 pt-6 pb-2 rounded-xl border-2 transition-all duration-200 focus:outline-none"
                          style={{
                            borderColor: colors.border,
                            backgroundColor: colors.background
                          }}
                          onFocus={(e) => {
                            e.currentTarget.style.borderColor = colors.primary;
                            e.currentTarget.style.boxShadow = `0 0 0 4px ${colors.primaryLight}`;
                          }}
                          onBlur={(e) => {
                            e.currentTarget.style.borderColor = colors.border;
                            e.currentTarget.style.boxShadow = 'none';
                          }}
                        />
                        <label
                          className="absolute left-4 top-2 text-xs font-medium transition-all"
                          style={{ color: colors.textSecondary }}
                        >
                          길이/정밀도
                        </label>
                      </div>
                    </div>

                    <div className="relative">
                      <textarea
                        defaultValue={selectedDomain.description}
                        className="peer w-full px-4 pt-6 pb-2 rounded-xl border-2 transition-all duration-200 focus:outline-none resize-none"
                        style={{
                          borderColor: colors.border,
                          backgroundColor: colors.background
                        }}
                        rows={3}
                        onFocus={(e) => {
                          e.currentTarget.style.borderColor = colors.primary;
                          e.currentTarget.style.boxShadow = `0 0 0 4px ${colors.primaryLight}`;
                        }}
                        onBlur={(e) => {
                          e.currentTarget.style.borderColor = colors.border;
                          e.currentTarget.style.boxShadow = 'none';
                        }}
                      />
                      <label
                        className="absolute left-4 top-2 text-xs font-medium transition-all"
                        style={{ color: colors.textSecondary }}
                      >
                        설명
                      </label>
                    </div>

                    <div className="relative">
                      <select
                        defaultValue={selectedDomain.nullable ? 'Y' : 'N'}
                        className="peer w-full px-4 pt-6 pb-2 rounded-xl border-2 transition-all duration-200 focus:outline-none"
                        style={{
                          borderColor: colors.border,
                          backgroundColor: colors.background
                        }}
                        onFocus={(e) => {
                          e.currentTarget.style.borderColor = colors.primary;
                          e.currentTarget.style.boxShadow = `0 0 0 4px ${colors.primaryLight}`;
                        }}
                        onBlur={(e) => {
                          e.currentTarget.style.borderColor = colors.border;
                          e.currentTarget.style.boxShadow = 'none';
                        }}
                      >
                        <option value="Y">NULL 허용</option>
                        <option value="N">NOT NULL</option>
                      </select>
                      <label
                        className="absolute left-4 top-2 text-xs font-medium transition-all"
                        style={{ color: colors.textSecondary }}
                      >
                        NULL 허용 여부
                      </label>
                    </div>

                    {/* Statistics */}
                    <div 
                      className="p-4 rounded-xl border"
                      style={{ 
                        backgroundColor: colors.backgroundSecondary,
                        borderColor: colors.divider
                      }}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-medium" style={{ color: colors.textSecondary }}>
                          사용 횟수
                        </span>
                        <span className="text-2xl font-bold" style={{ color: colors.primary }}>
                          {selectedDomain.usage}
                        </span>
                      </div>
                    </div>
                  </motion.div>
                )}

                {activeTab === 'usage' && (
                  <motion.div
                    key="usage"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    className="space-y-3"
                  >
                    <p className="font-medium mb-3" style={{ color: colors.textPrimary }}>
                      이 도메인을 사용하는 표준 용어
                    </p>
                    {['고객번호', '주문번호', '상품코드'].map((term, idx) => (
                      <div
                        key={idx}
                        className="p-3 rounded-lg border"
                        style={{ borderColor: colors.divider }}
                      >
                        <span style={{ color: colors.textPrimary }}>{term}</span>
                      </div>
                    ))}
                  </motion.div>
                )}

                {activeTab === 'history' && (
                  <motion.div
                    key="history"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    className="space-y-3"
                  >
                    <div className="p-4 rounded-lg border" style={{ borderColor: colors.divider }}>
                      <div className="flex items-center gap-2 mb-2">
                        <Badge variant="primary">등록</Badge>
                        <span className="text-sm" style={{ color: colors.textSecondary }}>
                          by 김표준
                        </span>
                      </div>
                      <p className="text-sm mb-1" style={{ color: colors.textPrimary }}>
                        신규 도메인 등록
                      </p>
                      <p className="text-xs" style={{ color: colors.textTertiary }}>
                        2024-01-15 09:00
                      </p>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Create Modal */}
      <AnimatePresence>
        {showCreateModal && (
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 30, stiffness: 300 }}
            className="fixed top-0 right-0 bottom-0 z-50 shadow-2xl border-l overflow-hidden flex flex-col"
            style={{
              width: '400px',
              backgroundColor: colors.background,
              borderColor: colors.divider
            }}
          >
            {/* Header */}
            <div className="px-6 py-4 border-b flex items-center justify-between" style={{ borderColor: colors.divider }}>
              <div>
                <h3 className="text-xl font-bold" style={{ color: colors.textPrimary }}>신규 표준 도메인 등록</h3>
                <p className="text-sm mt-1" style={{ color: colors.textSecondary }}>새로운 표준 도메인을 등록합니다</p>
              </div>
              <button
                onClick={() => setShowCreateModal(false)}
                className="p-2 rounded-lg hover:bg-black/5 transition-colors"
              >
                <X className="w-5 h-5" style={{ color: colors.textSecondary }} />
              </button>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto p-6 space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium" style={{ color: colors.textSecondary }}>
                  도메인명 <span style={{ color: colors.error }}>*</span>
                </label>
                <input
                  type="text"
                  placeholder="예: VARCHAR200"
                  className="w-full px-4 py-2 rounded-lg border font-mono focus:outline-none focus:ring-2"
                  style={{
                    borderColor: colors.border,
                    backgroundColor: colors.background
                  }}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium" style={{ color: colors.textSecondary }}>
                    데이터 타입 <span style={{ color: colors.error }}>*</span>
                  </label>
                  <select
                    className="w-full px-4 py-2 rounded-lg border focus:outline-none focus:ring-2"
                    style={{
                      borderColor: colors.border,
                      backgroundColor: colors.background
                    }}
                  >
                    <option value="">선택하세요</option>
                    <option value="VARCHAR">VARCHAR</option>
                    <option value="NUMBER">NUMBER</option>
                    <option value="DATE">DATE</option>
                    <option value="TIMESTAMP">TIMESTAMP</option>
                    <option value="CLOB">CLOB</option>
                  </select>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium" style={{ color: colors.textSecondary }}>
                    길이/정밀도 <span style={{ color: colors.error }}>*</span>
                  </label>
                  <input
                    type="text"
                    placeholder="예: 200 또는 15,2"
                    className="w-full px-4 py-2 rounded-lg border focus:outline-none focus:ring-2"
                    style={{
                      borderColor: colors.border,
                      backgroundColor: colors.background
                    }}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium" style={{ color: colors.textSecondary }}>
                  설명 <span style={{ color: colors.error }}>*</span>
                </label>
                <textarea
                  rows={3}
                  placeholder="도메인에 대한 설명을 입력하세요"
                  className="w-full px-4 py-2 rounded-lg border focus:outline-none focus:ring-2 resize-none"
                  style={{
                    borderColor: colors.border,
                    backgroundColor: colors.background
                  }}
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium" style={{ color: colors.textSecondary }}>
                  NULL 허용 여부 <span style={{ color: colors.error }}>*</span>
                </label>
                <select
                  className="w-full px-4 py-2 rounded-lg border focus:outline-none focus:ring-2"
                  style={{
                    borderColor: colors.border,
                    backgroundColor: colors.background
                  }}
                >
                  <option value="Y">NULL 허용</option>
                  <option value="N">NOT NULL</option>
                </select>
              </div>
            </div>

            {/* Footer */}
            <div className="px-6 py-4 border-t flex items-center justify-end gap-3" style={{ borderColor: colors.divider }}>
              <Button variant="ghost" onClick={() => setShowCreateModal(false)}>
                취소
              </Button>
              <Button variant="primary" glow>
                등록
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}