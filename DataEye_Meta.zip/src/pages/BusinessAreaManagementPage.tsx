import { Building2, Search, Plus, Edit, Trash2, ArrowUpDown, ChevronUp, ChevronDown, Workflow, Users, Filter } from 'lucide-react';
import { Card } from '../components/common/Card';
import { IconBox } from '../components/common/IconBox';
import { Button } from '../components/common/Button';
import { Badge } from '../components/common/Badge';
import { Pagination } from '../components/common/Pagination';
import { BusinessAreaFormModal } from '../components/modals/BusinessAreaFormModal';
import { useState, useMemo } from 'react';
import { motion } from 'framer-motion';

export function BusinessAreaManagementPage() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState<'create' | 'edit'>('create');
  const [selectedArea, setSelectedArea] = useState<any>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);
  const [sortField, setSortField] = useState<string>('');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [filters, setFilters] = useState<Record<string, string>>({});
  const [activeFilterColumn, setActiveFilterColumn] = useState<string | null>(null);

  const handleAddClick = () => {
    setModalMode('create');
    setSelectedArea(null);
    setIsModalOpen(true);
  };

  const handleAreaClick = (area: any) => {
    setModalMode('edit');
    setSelectedArea(area);
    setIsModalOpen(true);
  };

  const businessAreas = [
    { 
      name: '고객관리', 
      code: 'BA-001', 
      description: '고객 정보 및 고객 관계 관리', 
      owner: '김민지',
      processes: 12, 
      terms: 145, 
      systems: 3,
      status: '운영중',
      lastUpdated: '2024-11-15'
    },
    { 
      name: '주문/결제', 
      code: 'BA-002', 
      description: '주문 처리 및 결제 관리', 
      owner: '이지훈',
      processes: 8, 
      terms: 98, 
      systems: 2,
      status: '운영중',
      lastUpdated: '2024-11-10'
    },
    { 
      name: '재고관리', 
      code: 'BA-003', 
      description: '재고 현황 및 입출고 관리', 
      owner: '박서윤',
      processes: 6, 
      terms: 67, 
      systems: 2,
      status: '검토중',
      lastUpdated: '2024-11-18'
    },
    { 
      name: '배송관리', 
      code: 'BA-004', 
      description: '배송 프로세스 및 물류 관리', 
      owner: '최동현',
      processes: 5, 
      terms: 54, 
      systems: 1,
      status: '운영중',
      lastUpdated: '2024-11-12'
    },
  ];

  const sortedBusinessAreas = useMemo(() => {
    let sorted = [...businessAreas];
    if (sortField) {
      sorted = sorted.sort((a, b) => {
        if (a[sortField] < b[sortField]) return sortDirection === 'asc' ? -1 : 1;
        if (a[sortField] > b[sortField]) return sortDirection === 'asc' ? 1 : -1;
        return 0;
      });
    }
    return sorted;
  }, [businessAreas, sortField, sortDirection]);

  const filteredBusinessAreas = useMemo(() => {
    let filtered = [...sortedBusinessAreas];
    for (const [key, value] of Object.entries(filters)) {
      if (value) {
        filtered = filtered.filter(area => area[key]?.toString().includes(value));
      }
    }
    return filtered;
  }, [sortedBusinessAreas, filters]);

  const paginatedBusinessAreas = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage;
    const end = start + itemsPerPage;
    return filteredBusinessAreas.slice(start, end);
  }, [filteredBusinessAreas, currentPage, itemsPerPage]);

  const handleSort = (field: string) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const handleFilter = (field: string, value: string) => {
    setFilters(prev => ({
      ...prev,
      [field]: value
    }));
    setActiveFilterColumn(field);
  };

  const handleClearFilter = (field: string) => {
    setFilters(prev => ({
      ...prev,
      [field]: ''
    }));
    setActiveFilterColumn(null);
  };

  return (
    <div className="flex gap-0 h-full relative">
      {/* 메인 콘텐츠 영역 */}
      <motion.div
        className="flex-1 overflow-auto"
        animate={{
          marginRight: isModalOpen ? '600px' : '0px'
        }}
        transition={{
          type: 'spring',
          damping: 30,
          stiffness: 300
        }}
      >
        <div className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 mb-6">
            <Card padding="lg">
              <IconBox icon={Building2} color="blue" size="md" />
              <div className="mt-3">
                <p className="mb-1" style={{ color: '#5F6368' }}>전체 업무 영역</p>
                <h3 className="font-bold" style={{ color: '#202124' }}>24</h3>
              </div>
            </Card>
            <Card padding="lg">
              <IconBox icon={Workflow} color="indigo" size="md" />
              <div className="mt-3">
                <p className="mb-1" style={{ color: '#5F6368' }}>총 프로세스</p>
                <h3 className="font-bold" style={{ color: '#202124' }}>89</h3>
              </div>
            </Card>
            <Card padding="lg">
              <IconBox icon={Users} color="green" size="md" />
              <div className="mt-3">
                <p className="mb-1" style={{ color: '#5F6368' }}>담당자</p>
                <h3 className="font-bold" style={{ color: '#202124' }}>18</h3>
              </div>
            </Card>
            <Card padding="lg">
              <IconBox icon={Building2} color="orange" size="md" />
              <div className="mt-3">
                <p className="mb-1" style={{ color: '#5F6368' }}>연계 시스템</p>
                <h3 className="font-bold" style={{ color: '#202124' }}>12</h3>
              </div>
            </Card>
          </div>

          <Card padding="lg">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <IconBox icon={Building2} color="blue" size="md" />
                <h3 className="font-bold" style={{ color: '#202124' }}>업무 영역 목록</h3>
              </div>
              <Button variant="primary" icon={<Plus className="w-4 h-4" />} size="sm" onClick={handleAddClick}>영역 추가</Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {paginatedBusinessAreas.map((area, idx) => (
                <div 
                  key={idx} 
                  className="p-5 rounded-xl border transition-all cursor-pointer"
                  style={{ backgroundColor: '#F9F9F9', borderColor: '#DADCE0' }}
                  onMouseEnter={(e) => e.currentTarget.style.borderColor = '#2B8DFF'}
                  onMouseLeave={(e) => e.currentTarget.style.borderColor = '#DADCE0'}
                  onClick={() => handleAreaClick(area)}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <IconBox icon={Building2} color="blue" size="sm" />
                      <div>
                        <h4 className="font-bold" style={{ color: '#202124' }}>{area.name}</h4>
                        <p className="text-sm" style={{ color: '#5F6368' }}>{area.code}</p>
                      </div>
                    </div>
                    <Badge variant={area.status === '운영중' ? 'success' : 'warning'}>
                      {area.status}
                    </Badge>
                  </div>
                  
                  <p className="mb-4" style={{ color: '#5F6368' }}>{area.description}</p>
                  
                  <div className="grid grid-cols-3 gap-4 mb-4">
                    <div className="text-center p-2 rounded-lg" style={{ backgroundColor: '#FFFFFF' }}>
                      <p className="text-xs mb-1" style={{ color: '#5F6368' }}>프로세스</p>
                      <p className="font-bold" style={{ color: '#202124' }}>{area.processes}</p>
                    </div>
                    <div className="text-center p-2 rounded-lg" style={{ backgroundColor: '#FFFFFF' }}>
                      <p className="text-xs mb-1" style={{ color: '#5F6368' }}>용어</p>
                      <p className="font-bold" style={{ color: '#202124' }}>{area.terms}</p>
                    </div>
                    <div className="text-center p-2 rounded-lg" style={{ backgroundColor: '#FFFFFF' }}>
                      <p className="text-xs mb-1" style={{ color: '#5F6368' }}>시스템</p>
                      <p className="font-bold" style={{ color: '#202124' }}>{area.systems}</p>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-sm pt-3 border-t" style={{ borderColor: '#DADCE0' }}>
                    <div>
                      <span style={{ color: '#5F6368' }}>담당자:</span>
                      <span className="ml-2 font-bold" style={{ color: '#202124' }}>{area.owner}</span>
                    </div>
                    <span style={{ color: '#5F6368' }}>{area.lastUpdated}</span>
                  </div>
                </div>
              ))}
            </div>

            <Pagination
              totalItems={filteredBusinessAreas.length}
              itemsPerPage={itemsPerPage}
              currentPage={currentPage}
              totalPages={Math.ceil(filteredBusinessAreas.length / itemsPerPage)}
              onPageChange={setCurrentPage}
              onItemsPerPageChange={setItemsPerPage}
            />
          </Card>
        </div>
      </motion.div>

      {/* 모달 영역 */}
      <BusinessAreaFormModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        mode={modalMode}
        initialData={selectedArea}
      />
    </div>
  );
}