import { FileCheck2, BookOpen, Menu, Send, CheckCircle } from 'lucide-react';
import { Card } from '../components/common/Card';
import { IconBox } from '../components/common/IconBox';
import { Button } from '../components/common/Button';
import { Badge } from '../components/common/Badge';

export function DataStandardizationPage() {
  const standardTerms = [
    { term: '고객명', standard: 'CUST_NM', type: '일반용어', status: '승인', usage: 156 },
    { term: '주문번호', standard: 'ORD_NO', type: '일반용어', status: '승인', usage: 243 },
    { term: '상품코드', standard: 'PROD_CD', type: '일반용어', status: '검토중', usage: 89 },
    { term: '거래금액', standard: 'TRX_AMT', type: '일반용어', status: '승인', usage: 198 },
  ];

  const processSteps = [
    { step: '수집/분석', desc: '컬럼 메타 스캔, 시스템/데이블/컬럼', status: 'completed' },
    { step: '추천 메달 생성', desc: '유사도 스코어', status: 'completed' },
    { step: '자동/수동 매핑/리뷰', desc: '', status: 'in-progress' },
    { step: '배포/배치', desc: '', status: 'pending' },
  ];

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 mb-6">
        <Card padding="lg">
          <IconBox icon={BookOpen} color="blue" size="md" />
          <div className="mt-3">
            <p className="text-gray-500 dark:text-gray-400 mb-1">표준용어</p>
            <h3 className="text-gray-900 dark:text-white font-bold">1,247</h3>
          </div>
        </Card>
        <Card padding="lg">
          <IconBox icon={FileCheck2} color="green" size="md" />
          <div className="mt-3">
            <p className="text-gray-500 dark:text-gray-400 mb-1">승인된 용어</p>
            <h3 className="text-gray-900 dark:text-white font-bold">1,089</h3>
          </div>
        </Card>
        <Card padding="lg">
          <IconBox icon={Menu} color="orange" size="md" />
          <div className="mt-3">
            <p className="text-gray-500 dark:text-gray-400 mb-1">검토중</p>
            <h3 className="text-gray-900 dark:text-white font-bold">158</h3>
          </div>
        </Card>
        <Card padding="lg">
          <IconBox icon={Send} color="indigo" size="md" />
          <div className="mt-3">
            <p className="text-gray-500 dark:text-gray-400 mb-1">배포 대기</p>
            <h3 className="text-gray-900 dark:text-white font-bold">24</h3>
          </div>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card padding="lg">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <IconBox icon={FileCheck2} color="blue" size="md" />
              <h3 className="text-gray-900 dark:text-white font-bold">표준화 프로세스</h3>
            </div>
            <Button variant="primary" size="sm">프로세스 시작</Button>
          </div>
          <div className="space-y-4">
            {processSteps.map((step, idx) => (
              <div key={idx} className="flex items-start gap-4 pb-4 border-b border-gray-200 dark:border-gray-700 last:border-0">
                <div className="mt-1">
                  {step.status === 'completed' ? (
                    <CheckCircle className="w-5 h-5 text-green-500" />
                  ) : step.status === 'in-progress' ? (
                    <div className="w-5 h-5 rounded-full border-2 border-blue-500 border-t-transparent animate-spin"></div>
                  ) : (
                    <div className="w-5 h-5 rounded-full border-2 border-gray-300 dark:border-gray-600"></div>
                  )}
                </div>
                <div className="flex-1">
                  <h4 className="text-gray-900 dark:text-white font-bold mb-1">{step.step}</h4>
                  <p className="text-gray-500 dark:text-gray-400">{step.desc || '대기중'}</p>
                </div>
              </div>
            ))}
          </div>
        </Card>

        <Card padding="lg">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <IconBox icon={BookOpen} color="green" size="md" />
              <h3 className="text-gray-900 dark:text-white font-bold">표준용어 관리</h3>
            </div>
            <Button variant="secondary" size="sm">+ 용어 추가</Button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead style={{ backgroundColor: '#F7F8FA' }}>
                <tr style={{ borderBottom: '1px solid #DADCE0' }}>
                  <th className="px-3 py-3 text-left text-sm" style={{ color: '#5F6368' }}>용어</th>
                  <th className="px-3 py-3 text-left text-sm" style={{ color: '#5F6368' }}>표준명</th>
                  <th className="px-3 py-3 text-left text-sm" style={{ color: '#5F6368' }}>상태</th>
                  <th className="px-3 py-3 text-left text-sm" style={{ color: '#5F6368' }}>사용</th>
                </tr>
              </thead>
              <tbody>
                {standardTerms.map((term, idx) => (
                  <tr key={idx} className="border-b border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700/30 transition-colors">
                    <td className="px-3 py-3 text-gray-900 dark:text-gray-100">{term.term}</td>
                    <td className="px-3 py-3 text-gray-600 dark:text-gray-400 font-mono text-sm">{term.standard}</td>
                    <td className="px-3 py-3">
                      <Badge variant={term.status === '승인' ? 'success' : 'warning'}>
                        {term.status}
                      </Badge>
                    </td>
                    <td className="px-3 py-3 text-gray-600 dark:text-gray-400">{term.usage}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      </div>
    </div>
  );
}