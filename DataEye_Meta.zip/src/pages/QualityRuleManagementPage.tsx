import { ShieldAlert, Search, Plus, Download, Filter, ArrowUpDown, ChevronUp, ChevronDown, Play, Pause, Copy, Edit, Trash2 } from 'lucide-react';
import { Card } from '../components/common/Card';
import { IconBox } from '../components/common/IconBox';
import { Button } from '../components/common/Button';
import { Badge } from '../components/common/Badge';
import { Pagination } from '../components/common/Pagination';
import { QualityRuleFormModal } from '../components/modals/QualityRuleFormModal';
import { useState } from 'react';
import { motion } from 'motion/react';

export function QualityRuleManagementPage() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState<'create' | 'edit'>('create');
  const [selectedRule, setSelectedRule] = useState<any>(null);
  const [sortField, setSortField] = useState<string>('');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [runningRuleId, setRunningRuleId] = useState<string | null>(null);
  const [filters, setFilters] = useState<Record<string, string>>({});
  const [activeFilterColumn, setActiveFilterColumn] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);

  const handleRunRule = (ruleId: string, ruleName: string) => {
    setRunningRuleId(ruleId);
    setTimeout(() => {
      setRunningRuleId(null);
      alert(`'${ruleName}' 규칙 실행이 완료되었습니다.\n품질진단관리 페이지에서 결과를 확인할 수 있습니다.`);
    }, 1500);
  };

  const handleCopyRule = (rule: any) => {
    alert(`'${rule.name}' 규칙이 복사되었습니다.\n새로운 규칙으로 생성됩니다.`);
  };

  const handleDeleteRule = (rule: any) => {
    if (confirm(`'${rule.name}' 규칙을 삭제하시겠습니까?`)) {
      alert('규칙이 삭제되었습니다.');
    }
  };

  const qualityRules = [
    {
      id: 'QR-001',
      name: '필수값 검증',
      description: 'NOT NULL 컬럼의 빈값 검사',
      category: '완전성',
      target: '고객 테이블 - CUST_NM, CUST_NO',
      condition: 'IS NOT NULL',
      severity: 'high',
      status: '활성',
      violations: 3,
      lastRun: '2024-11-20 09:00',
      createdBy: '김민지',
      createdDate: '2024-10-15'
    },
    {
      id: 'QR-002',
      name: '이메일 형 검증',
      description: '이메일 주소 형식 유효성 검사',
      category: '유효성',
      target: '고객 테이블 - EMAIL',
      condition: "REGEXP_LIKE(EMAIL, '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Z|a-z]{2,}$')",
      severity: 'medium',
      status: '활성',
      violations: 12,
      lastRun: '2024-11-20 09:00',
      createdBy: '이지훈',
      createdDate: '2024-10-18'
    },
    {
      id: 'QR-003',
      name: '날짜 범위 검증',
      description: '주문일자가 현재일자 이전인지 검사',
      category: '정확성',
      target: '주문 테이블 - ORD_DT',
      condition: 'ORD_DT <= SYSDATE',
      severity: 'high',
      status: '활성',
      violations: 0,
      lastRun: '2024-11-20 09:00',
      createdBy: '박서윤',
      createdDate: '2024-11-01'
    },
    {
      id: 'QR-004',
      name: '중복 데이터 검사',
      description: '고객번호 중복 체크',
      category: '유일성',
      target: '고객 테이블 - CUST_NO',
      condition: 'COUNT(CUST_NO) = 1 GROUP BY CUST_NO',
      severity: 'high',
      status: '활성',
      violations: 5,
      lastRun: '2024-11-20 09:00',
      createdBy: '최동현',
      createdDate: '2024-10-20'
    },
    {
      id: 'QR-005',
      name: '금액 범위 검증',
      description: '거래금액이 0 이상인지 검사',
      category: '정확성',
      target: '거래 테이블 - TRX_AMT',
      condition: 'TRX_AMT >= 0',
      severity: 'medium',
      status: '일시정지',
      violations: 8,
      lastRun: '2024-11-19 15:00',
      createdBy: '김민지',
      createdDate: '2024-11-05'
    },
  ];

  const ruleCategories = [
    { name: '전체 규칙', count: 234, icon: ShieldAlert, color: 'blue' as const },
    { name: '활성', count: 198, icon: ShieldAlert, color: 'green' as const },
    { name: '일시정지', count: 36, icon: ShieldAlert, color: 'orange' as const },
    { name: '위반 발견', count: 28, icon: ShieldAlert, color: 'red' as const },
  ];

  const getSeverityVariant = (severity: string) => {
    switch (severity) {
      case 'high': return 'error';
      case 'medium': return 'warning';
      case 'low': return 'default';
      default: return 'default';
    }
  };

  const getSeverityLabel = (severity: string) => {
    switch (severity) {
      case 'high': return '높음';
      case 'medium': return '중간';
      case 'low': return '낮음';
      default: return severity;
    }
  };

  const handleSort = (field: string) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const SortIcon = ({ field }: { field: string }) => {
    if (sortField !== field) {
      return <ArrowUpDown className="w-3.5 h-3.5 text-gray-400 ml-1" />;
    }
    return sortDirection === 'asc' ? (
      <ChevronUp className="w-3.5 h-3.5 ml-1" style={{ color: '#2B8DFF' }} />
    ) : (
      <ChevronDown className="w-3.5 h-3.5 ml-1" style={{ color: '#2B8DFF' }} />
    );
  };

  const sortedQualityRules = [...qualityRules].sort((a, b) => {
    if (sortField) {
      const aValue = a[sortField as keyof typeof a];
      const bValue = b[sortField as keyof typeof b];
      if (typeof aValue === 'string' && typeof bValue === 'string') {
        return sortDirection === 'asc' ? aValue.localeCompare(bValue) : bValue.localeCompare(aValue);
      } else if (typeof aValue === 'number' && typeof bValue === 'number') {
        return sortDirection === 'asc' ? aValue - bValue : bValue - aValue;
      }
    }
    return 0;
  });

  const paginatedQualityRules = sortedQualityRules.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  return (
    <div className="flex gap-0 h-full relative">
      {/* 메인 콘텐츠 영역 */}
      <motion.div
        className="flex-1 overflow-auto"
        animate={{
          marginRight: isModalOpen ? '600px' : '0px'
        }}
        transition={{
          type: 'spring',
          damping: 30,
          stiffness: 300
        }}
      >
        <div className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 mb-6">
            {ruleCategories.map((category, idx) => (
              <Card key={idx} padding="lg">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="mb-1" style={{ color: '#5F6368' }}>{category.name}</p>
                    <h3 className="font-bold" style={{ color: '#202124' }}>{category.count}</h3>
                  </div>
                  <IconBox icon={category.icon} color={category.color} size="md" />
                </div>
              </Card>
            ))}
          </div>

          <Card padding="lg">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
              <div className="flex items-center gap-3">
                <IconBox icon={ShieldAlert} color="blue" size="md" />
                <h3 className="font-bold" style={{ color: '#202124' }}>품질 규칙 목록</h3>
              </div>
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-3 rounded-xl px-4 py-2 border" style={{ backgroundColor: '#F9F9F9', borderColor: '#DADCE0' }}>
                  <Search className="w-4 h-4 text-gray-400" />
                  <input 
                    type="text" 
                    placeholder="규칙 검색..."
                    className="bg-transparent border-none outline-none placeholder-gray-400 w-48"
                    style={{ color: '#202124' }}
                  />
                </div>
                <Button variant="primary" icon={<Plus className="w-4 h-4" />} size="sm" onClick={() => { setIsModalOpen(true); setModalMode('create'); }}>규칙 추가</Button>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full">
                <thead style={{ backgroundColor: '#F7F8FA' }}>
                  <tr style={{ borderBottom: '1px solid #DADCE0' }}>
                    <th 
                      className="px-4 py-3 text-left text-sm cursor-pointer hover:bg-gray-100 transition-colors" 
                      style={{ color: '#5F6368' }}
                      onClick={() => handleSort('id')}
                    >
                      <div className="flex items-center">
                        규칙ID
                        <SortIcon field="id" />
                      </div>
                    </th>
                    <th 
                      className="px-4 py-3 text-left text-sm cursor-pointer hover:bg-gray-100 transition-colors" 
                      style={{ color: '#5F6368' }}
                      onClick={() => handleSort('name')}
                    >
                      <div className="flex items-center">
                        규칙명
                        <SortIcon field="name" />
                      </div>
                    </th>
                    <th 
                      className="px-4 py-3 text-left text-sm cursor-pointer hover:bg-gray-100 transition-colors" 
                      style={{ color: '#5F6368' }}
                      onClick={() => handleSort('category')}
                    >
                      <div className="flex items-center">
                        카테고리
                        <SortIcon field="category" />
                      </div>
                    </th>
                    <th 
                      className="px-4 py-3 text-left text-sm cursor-pointer hover:bg-gray-100 transition-colors" 
                      style={{ color: '#5F6368' }}
                      onClick={() => handleSort('target')}
                    >
                      <div className="flex items-center">
                        대상
                        <SortIcon field="target" />
                      </div>
                    </th>
                    <th 
                      className="px-4 py-3 text-left text-sm cursor-pointer hover:bg-gray-100 transition-colors" 
                      style={{ color: '#5F6368' }}
                      onClick={() => handleSort('severity')}
                    >
                      <div className="flex items-center">
                        심각도
                        <SortIcon field="severity" />
                      </div>
                    </th>
                    <th 
                      className="px-4 py-3 text-left text-sm cursor-pointer hover:bg-gray-100 transition-colors" 
                      style={{ color: '#5F6368' }}
                      onClick={() => handleSort('status')}
                    >
                      <div className="flex items-center">
                        상태
                        <SortIcon field="status" />
                      </div>
                    </th>
                    <th 
                      className="px-4 py-3 text-left text-sm cursor-pointer hover:bg-gray-100 transition-colors" 
                      style={{ color: '#5F6368' }}
                      onClick={() => handleSort('violations')}
                    >
                      <div className="flex items-center">
                        위반
                        <SortIcon field="violations" />
                      </div>
                    </th>
                    <th 
                      className="px-4 py-3 text-left text-sm cursor-pointer hover:bg-gray-100 transition-colors" 
                      style={{ color: '#5F6368' }}
                      onClick={() => handleSort('lastRun')}
                    >
                      <div className="flex items-center">
                        마지막 실행
                        <SortIcon field="lastRun" />
                      </div>
                    </th>
                    <th className="px-4 py-3 text-left text-sm" style={{ color: '#5F6368' }}>
                      액션
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {paginatedQualityRules.map((rule, idx) => (
                    <tr 
                      key={idx} 
                      className="border-b transition-colors"
                      style={{ borderColor: '#DADCE0', backgroundColor: 'transparent' }}
                      onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#F9F9F9'}
                      onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
                    >
                      <td className="px-4 py-3 font-mono text-sm" style={{ color: '#5F6368' }}>{rule.id}</td>
                      <td className="px-4 py-3">
                        <div>
                          <p className="font-bold" style={{ color: '#202124' }}>{rule.name}</p>
                          <p className="text-sm" style={{ color: '#5F6368' }}>{rule.description}</p>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <Badge variant="info">{rule.category}</Badge>
                      </td>
                      <td className="px-4 py-3 text-sm max-w-xs" style={{ color: '#5F6368' }}>
                        {rule.target}
                      </td>
                      <td className="px-4 py-3">
                        <Badge variant={getSeverityVariant(rule.severity) as any}>
                          {getSeverityLabel(rule.severity)}
                        </Badge>
                      </td>
                      <td className="px-4 py-3">
                        <Badge variant={rule.status === '활성' ? 'success' : 'default'}>
                          {rule.status}
                        </Badge>
                      </td>
                      <td className="px-4 py-3">
                        {rule.violations > 0 ? (
                          <span className="font-bold" style={{ color: '#EA4335' }}>{rule.violations}</span>
                        ) : (
                          <span className="font-bold" style={{ color: '#10B981' }}>{rule.violations}</span>
                        )}
                      </td>
                      <td className="px-4 py-3 text-sm" style={{ color: '#5F6368' }}>{rule.lastRun}</td>
                      <td className="px-4 py-3">
                        <div className="flex gap-2">
                          <button 
                            className="p-1.5 rounded-lg transition-colors" 
                            title="실행" 
                            onClick={() => handleRunRule(rule.id, rule.name)}
                            onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#F9F9F9'}
                            onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
                          >
                            {runningRuleId === rule.id ? (
                              <Pause className="w-4 h-4" style={{ color: '#10B981' }} />
                            ) : (
                              <Play className="w-4 h-4" style={{ color: '#10B981' }} />
                            )}
                          </button>
                          <button 
                            className="p-1.5 rounded-lg transition-colors" 
                            title="복사" 
                            onClick={() => handleCopyRule(rule)}
                            onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#F9F9F9'}
                            onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
                          >
                            <Copy className="w-4 h-4" style={{ color: '#2B8DFF' }} />
                          </button>
                          <button 
                            className="p-1.5 rounded-lg transition-colors" 
                            title="수정" 
                            onClick={() => { setIsModalOpen(true); setModalMode('edit'); setSelectedRule(rule); }}
                            onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#F9F9F9'}
                            onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
                          >
                            <Edit className="w-4 h-4" style={{ color: '#F59E0B' }} />
                          </button>
                          <button 
                            className="p-1.5 rounded-lg transition-colors" 
                            title="삭제" 
                            onClick={() => handleDeleteRule(rule)}
                            onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#F9F9F9'}
                            onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
                          >
                            <Trash2 className="w-4 h-4" style={{ color: '#EA4335' }} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <Pagination
              currentPage={currentPage}
              totalPages={Math.ceil(sortedQualityRules.length / itemsPerPage)}
              totalItems={sortedQualityRules.length}
              itemsPerPage={itemsPerPage}
              onPageChange={setCurrentPage}
              onItemsPerPageChange={setItemsPerPage}
            />
          </Card>

          <Card padding="lg">
            <div className="flex items-center gap-3 mb-4">
              <IconBox icon={ShieldAlert} color="indigo" size="md" />
              <h3 className="font-bold" style={{ color: '#202124' }}>규칙 상세 조건</h3>
            </div>
            <div className="grid grid-cols-1 gap-4">
              {qualityRules.slice(0, 3).map((rule, idx) => (
                <div
                  key={idx}
                  className="rounded-xl p-5 border transition-all duration-200"
                  style={{
                    backgroundColor: '#F7F8FA',
                    borderColor: '#E9EAEC',
                  }}
                >
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div
                        className="p-2 rounded-lg"
                        style={{
                          backgroundColor: '#2B8DFF20',
                        }}
                      >
                        <ShieldAlert className="w-4 h-4" style={{ color: '#2B8DFF' }} />
                      </div>
                      <div>
                        <p className="font-bold text-sm" style={{ color: '#37352F' }}>
                          {rule.name}
                        </p>
                        <p className="text-xs font-mono" style={{ color: '#787774' }}>
                          {rule.id}
                        </p>
                      </div>
                    </div>
                    <Badge variant={
                      rule.status === '활성' ? 'success' : 
                      rule.status === '일시중지' ? 'warning' : 'default'
                    }>
                      {rule.status}
                    </Badge>
                  </div>
                  <div
                    className="rounded-lg p-3"
                    style={{
                      backgroundColor: '#FFFFFF',
                      border: '1px solid #E9EAEC',
                    }}
                  >
                    <p className="text-xs mb-1 font-medium" style={{ color: '#787774' }}>
                      조건식
                    </p>
                    <code className="text-sm font-mono" style={{ color: '#37352F' }}>
                      {rule.condition}
                    </code>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </motion.div>

      {/* 모달 영역 */}
      <QualityRuleFormModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        mode={modalMode}
        initialData={selectedRule}
      />
    </div>
  );
}