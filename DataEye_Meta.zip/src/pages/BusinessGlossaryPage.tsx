import { useState, useEffect } from 'react';
import { Card } from '../components/common/Card';
import { Button } from '../components/common/Button';
import { Badge } from '../components/common/Badge';
import { Plus, Search, Download, BookOpen, Save, X, ChevronRight, History, FileText, Database } from 'lucide-react';
import { colors } from '../constants/designSystem';
import { motion, AnimatePresence } from 'motion/react';
import { useModal } from '../contexts/ModalContext';

interface Glossary {
  id: number;
  term: string;
  category: string;
  businessDefinition: string;
  technicalDefinition: string;
  owner: string;
  status: string;
}

const mockGlossary: Glossary[] = [
  { 
    id: 1, 
    term: '고객', 
    category: '고객관리',
    businessDefinition: '회사의 제품이나 서비스를 구매하거나 이용하는 개인 또는 법인',
    technicalDefinition: 'TB_CUSTOMER 테이블에 저장되는 고객 마스터 정보',
    owner: '김철수',
    status: 'Approved'
  },
  { 
    id: 2, 
    term: '주문', 
    category: '주문관리',
    businessDefinition: '고객이 상품이나 서비스를 구매하기 위해 요청하는 행위',
    technicalDefinition: 'TB_ORDER 테이블에 기록되는 주문 거래 정보',
    owner: '이영희',
    status: 'Approved'
  },
  { 
    id: 3, 
    term: '매출', 
    category: '��무',
    businessDefinition: '제품이나 서비스 판매를 통해 발생하는 수익',
    technicalDefinition: 'TB_SALES 테이블의 금액 합계로 계산',
    owner: '박지훈',
    status: 'Draft'
  },
  { 
    id: 4, 
    term: '재고', 
    category: '상품관리',
    businessDefinition: '판매 가능한 상품의 현재 보유량',
    technicalDefinition: 'TB_INVENTORY 테이블의 현재고 수량',
    owner: '최민수',
    status: 'Approved'
  },
];

export function BusinessGlossaryPage() {
  const { setIsModalOpen } = useModal();
  const [selectedTerm, setSelectedTerm] = useState<Glossary | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [activeTab, setActiveTab] = useState<'basic' | 'technical' | 'history'>('basic');

  useEffect(() => {
    setIsModalOpen(!!selectedTerm);
  }, [selectedTerm, setIsModalOpen]);

  const filteredGlossary = mockGlossary.filter(item => 
    item.term.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleCardClick = (item: Glossary) => {
    setSelectedTerm(item);
    setActiveTab('basic');
  };

  const handleClose = () => {
    setSelectedTerm(null);
  };

  return (
    <div className="h-full flex gap-0 overflow-hidden">
      {/* Main Content Grid */}
      <motion.div
        className="flex flex-col"
        initial={{ width: '100%' }}
        animate={{ width: selectedTerm ? '60%' : '100%' }}
        transition={{ duration: 0.4, ease: [0.4, 0, 0.2, 1] }}
      >
        <div className="space-y-6 p-6 overflow-auto h-full">
          {/* Actions Bar */}
          <Card>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3 flex-1">
                <div className="relative flex-1 max-w-md">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: colors.textTertiary }} />
                  <input
                    type="text"
                    placeholder="용어, 카테고리로 검색..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 rounded-lg border"
                    style={{
                      borderColor: colors.border,
                      backgroundColor: colors.background,
                    }}
                  />
                </div>
              </div>
              <div className="flex gap-2">
                <Button variant="secondary" icon={<Download className="w-4 h-4" />}>
                  Export
                </Button>
                <Button variant="primary" icon={<Plus className="w-4 h-4" />}>
                  신규 용어 등록
                </Button>
              </div>
            </div>
          </Card>

          {/* Glossary Cards */}
          <div className="grid grid-cols-1 gap-4">
            {filteredGlossary.map((item) => (
              <motion.div
                key={item.id}
                onClick={() => handleCardClick(item)}
                whileHover={{ scale: 1.01 }}
                transition={{ duration: 0.2 }}
              >
                <Card 
                  hover 
                  className="cursor-pointer"
                  style={{
                    backgroundColor: selectedTerm?.id === item.id ? colors.primaryLight : colors.background,
                    borderColor: selectedTerm?.id === item.id ? colors.primary : colors.border,
                  }}
                >
                  <div className="flex items-start gap-4">
                    <div 
                      className="p-3 rounded-xl flex-shrink-0"
                      style={{ backgroundColor: colors.primaryLight }}
                    >
                      <BookOpen className="w-6 h-6" style={{ color: colors.primary }} />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="text-xl font-bold" style={{ color: colors.textPrimary }}>
                          {item.term}
                        </h3>
                        <Badge variant="info">{item.category}</Badge>
                        <Badge variant={item.status === 'Approved' ? 'success' : 'warning'}>
                          {item.status}
                        </Badge>
                        {selectedTerm?.id === item.id && (
                          <ChevronRight className="w-5 h-5 ml-auto" style={{ color: colors.primary }} />
                        )}
                      </div>
                      <div className="space-y-2">
                        <div>
                          <span className="text-sm font-medium" style={{ color: colors.textSecondary }}>
                            업무 정의:
                          </span>
                          <p style={{ color: colors.textPrimary }}>{item.businessDefinition}</p>
                        </div>
                        <div>
                          <span className="text-sm font-medium" style={{ color: colors.textSecondary }}>
                            기술 정의:
                          </span>
                          <p className="font-mono text-sm" style={{ color: colors.textSecondary }}>
                            {item.technicalDefinition}
                          </p>
                        </div>
                        <div className="flex items-center gap-4 pt-2">
                          <span className="text-sm" style={{ color: colors.textSecondary }}>
                            담당자: <span style={{ color: colors.textPrimary }}>{item.owner}</span>
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </motion.div>

      {/* Glass Separator */}
      <AnimatePresence>
        {selectedTerm && (
          <motion.div
            initial={{ opacity: 0, scaleX: 0 }}
            animate={{ opacity: 1, scaleX: 1 }}
            exit={{ opacity: 0, scaleX: 0 }}
            transition={{ duration: 0.3 }}
            className="w-px"
            style={{
              background: `linear-gradient(180deg, transparent, ${colors.border}, transparent)`,
              transformOrigin: 'left'
            }}
          />
        )}
      </AnimatePresence>

      {/* Right Detail Panel */}
      <AnimatePresence>
        {selectedTerm && (
          <motion.div
            initial={{ x: '100%', opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: '100%', opacity: 0 }}
            transition={{ duration: 0.4, ease: [0.4, 0, 0.2, 1] }}
            className="flex flex-col overflow-hidden"
            style={{
              width: '40%',
              backgroundColor: colors.background,
              backdropFilter: 'blur(20px)',
              boxShadow: '-4px 0 24px rgba(0, 0, 0, 0.08)'
            }}
          >
            {/* Sticky Header */}
            <div 
              className="sticky top-0 z-10 px-6 py-4 border-b"
              style={{ 
                backgroundColor: colors.background,
                borderColor: colors.divider,
                backdropFilter: 'blur(20px)'
              }}
            >
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold" style={{ color: colors.textPrimary }}>
                  Edit Glossary Term
                </h2>
                <div className="flex items-center gap-2">
                  <Button 
                    variant="primary" 
                    icon={<Save className="w-4 h-4" />}
                    glow
                  >
                    Save Changes
                  </Button>
                  <button
                    onClick={handleClose}
                    className="p-2 rounded-lg hover:bg-black/5 transition-colors"
                  >
                    <X className="w-5 h-5" style={{ color: colors.textSecondary }} />
                  </button>
                </div>
              </div>

              {/* Tabs */}
              <div className="flex gap-1">
                {[
                  { id: 'basic' as const, label: 'Business Definition', icon: FileText },
                  { id: 'technical' as const, label: 'Technical Definition', icon: Database },
                  { id: 'history' as const, label: 'History', icon: History },
                ].map((tab) => {
                  const Icon = tab.icon;
                  const isActive = activeTab === tab.id;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      className="flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all duration-200 relative"
                      style={{
                        color: isActive ? colors.primary : colors.textSecondary,
                        backgroundColor: isActive ? colors.primaryLight : 'transparent'
                      }}
                    >
                      <Icon className="w-4 h-4" />
                      <span className="text-sm">{tab.label}</span>
                      {isActive && (
                        <motion.div
                          layoutId="activeTabGlossary"
                          className="absolute bottom-0 left-0 right-0 h-0.5"
                          style={{ backgroundColor: colors.primary }}
                        />
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Panel Body */}
            <div className="flex-1 overflow-auto p-6">
              <AnimatePresence mode="wait">
                {activeTab === 'basic' && (
                  <motion.div
                    key="basic"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    transition={{ duration: 0.3 }}
                    className="space-y-4"
                  >
                    <div className="relative">
                      <input
                        type="text"
                        defaultValue={selectedTerm.term}
                        className="peer w-full px-4 pt-6 pb-2 rounded-xl border-2 transition-all duration-200 focus:outline-none"
                        style={{
                          borderColor: colors.border,
                          backgroundColor: colors.background
                        }}
                        onFocus={(e) => {
                          e.currentTarget.style.borderColor = colors.primary;
                          e.currentTarget.style.boxShadow = `0 0 0 4px ${colors.primaryLight}`;
                        }}
                        onBlur={(e) => {
                          e.currentTarget.style.borderColor = colors.border;
                          e.currentTarget.style.boxShadow = 'none';
                        }}
                      />
                      <label
                        className="absolute left-4 top-2 text-xs font-medium transition-all"
                        style={{ color: colors.textSecondary }}
                      >
                        용어명
                      </label>
                    </div>

                    <div className="relative">
                      <select
                        defaultValue={selectedTerm.category}
                        className="peer w-full px-4 pt-6 pb-2 rounded-xl border-2 transition-all duration-200 focus:outline-none"
                        style={{
                          borderColor: colors.border,
                          backgroundColor: colors.background
                        }}
                        onFocus={(e) => {
                          e.currentTarget.style.borderColor = colors.primary;
                          e.currentTarget.style.boxShadow = `0 0 0 4px ${colors.primaryLight}`;
                        }}
                        onBlur={(e) => {
                          e.currentTarget.style.borderColor = colors.border;
                          e.currentTarget.style.boxShadow = 'none';
                        }}
                      >
                        <option>고객관리</option>
                        <option>주문관리</option>
                        <option>재무</option>
                        <option>인사</option>
                        <option>상품관리</option>
                      </select>
                      <label
                        className="absolute left-4 top-2 text-xs font-medium transition-all"
                        style={{ color: colors.textSecondary }}
                      >
                        카테고리
                      </label>
                    </div>

                    <div className="relative">
                      <textarea
                        defaultValue={selectedTerm.businessDefinition}
                        className="peer w-full px-4 pt-6 pb-2 rounded-xl border-2 transition-all duration-200 focus:outline-none resize-none"
                        style={{
                          borderColor: colors.border,
                          backgroundColor: colors.background
                        }}
                        rows={4}
                        onFocus={(e) => {
                          e.currentTarget.style.borderColor = colors.primary;
                          e.currentTarget.style.boxShadow = `0 0 0 4px ${colors.primaryLight}`;
                        }}
                        onBlur={(e) => {
                          e.currentTarget.style.borderColor = colors.border;
                          e.currentTarget.style.boxShadow = 'none';
                        }}
                      />
                      <label
                        className="absolute left-4 top-2 text-xs font-medium transition-all"
                        style={{ color: colors.textSecondary }}
                      >
                        업무 정의
                      </label>
                    </div>

                    <div className="relative">
                      <input
                        type="text"
                        defaultValue={selectedTerm.owner}
                        className="peer w-full px-4 pt-6 pb-2 rounded-xl border-2 transition-all duration-200 focus:outline-none"
                        style={{
                          borderColor: colors.border,
                          backgroundColor: colors.background
                        }}
                        onFocus={(e) => {
                          e.currentTarget.style.borderColor = colors.primary;
                          e.currentTarget.style.boxShadow = `0 0 0 4px ${colors.primaryLight}`;
                        }}
                        onBlur={(e) => {
                          e.currentTarget.style.borderColor = colors.border;
                          e.currentTarget.style.boxShadow = 'none';
                        }}
                      />
                      <label
                        className="absolute left-4 top-2 text-xs font-medium transition-all"
                        style={{ color: colors.textSecondary }}
                      >
                        담당자
                      </label>
                    </div>
                  </motion.div>
                )}

                {activeTab === 'technical' && (
                  <motion.div
                    key="technical"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    className="space-y-4"
                  >
                    <div className="relative">
                      <textarea
                        defaultValue={selectedTerm.technicalDefinition}
                        className="peer w-full px-4 pt-6 pb-2 rounded-xl border-2 font-mono transition-all duration-200 focus:outline-none resize-none"
                        style={{
                          borderColor: colors.border,
                          backgroundColor: colors.background
                        }}
                        rows={6}
                        onFocus={(e) => {
                          e.currentTarget.style.borderColor = colors.primary;
                          e.currentTarget.style.boxShadow = `0 0 0 4px ${colors.primaryLight}`;
                        }}
                        onBlur={(e) => {
                          e.currentTarget.style.borderColor = colors.border;
                          e.currentTarget.style.boxShadow = 'none';
                        }}
                      />
                      <label
                        className="absolute left-4 top-2 text-xs font-medium transition-all"
                        style={{ color: colors.textSecondary }}
                      >
                        기술 정의 (시스템 구현 방식)
                      </label>
                    </div>

                    <div 
                      className="p-4 rounded-xl border"
                      style={{ 
                        backgroundColor: colors.backgroundSecondary,
                        borderColor: colors.divider
                      }}
                    >
                      <h4 className="font-medium mb-2" style={{ color: colors.textPrimary }}>
                        관련 테이블
                      </h4>
                      <div className="space-y-1">
                        <div className="font-mono text-sm" style={{ color: colors.textSecondary }}>
                          TB_CUSTOMER
                        </div>
                        <div className="font-mono text-sm" style={{ color: colors.textSecondary }}>
                          TB_ORDER
                        </div>
                      </div>
                    </div>
                  </motion.div>
                )}

                {activeTab === 'history' && (
                  <motion.div
                    key="history"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    className="space-y-3"
                  >
                    <div className="p-4 rounded-lg border" style={{ borderColor: colors.divider }}>
                      <div className="flex items-center gap-2 mb-2">
                        <Badge variant="primary">승인</Badge>
                        <span className="text-sm" style={{ color: colors.textSecondary }}>
                          by {selectedTerm.owner}
                        </span>
                      </div>
                      <p className="text-sm mb-1" style={{ color: colors.textPrimary }}>
                        비즈니스 용어로 승인됨
                      </p>
                      <p className="text-xs" style={{ color: colors.textTertiary }}>
                        2024-01-20 10:15
                      </p>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
