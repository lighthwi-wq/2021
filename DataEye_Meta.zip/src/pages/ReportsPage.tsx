import { FileText, Filter, Download } from 'lucide-react';
import { Button } from '../components/common/Button';
import { Card } from '../components/common/Card';
import { IconBox } from '../components/common/IconBox';
import { Badge } from '../components/common/Badge';

export function ReportsPage() {
  const reports = [
    { title: '월간 성능 리포트', date: '2024-11-01', status: '완료' },
    { title: '사용자 분석 요약', date: '2024-11-15', status: '완료' },
    { title: '데이터 품질 감사', date: '2024-11-18', status: '처리 중' },
    { title: '주간 API 사용량', date: '2024-11-20', status: '예정' },
  ];

  const getStatusVariant = (status: string) => {
    switch (status) {
      case '완료': return 'success';
      case '처리 중': return 'info';
      default: return 'default';
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center mb-6">
        <Button variant="primary" icon={<FileText className="w-4 h-4" />}>
          리포트 생성
        </Button>
        <div className="flex gap-3">
          <Button variant="secondary" icon={<Filter className="w-4 h-4" />} />
          <Button variant="secondary" icon={<Download className="w-4 h-4" />} />
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {reports.map((report, idx) => (
          <Card key={idx} padding="lg" className="hover:shadow-lg transition-all cursor-pointer">
            <div className="flex items-start justify-between mb-4">
              <IconBox icon={FileText} color="blue" size="md" />
              <Badge variant={getStatusVariant(report.status)}>
                {report.status}
              </Badge>
            </div>
            <h4 className="font-bold mb-2" style={{ color: '#202124' }}>{report.title}</h4>
            <p style={{ color: '#5F6368' }}>{report.date}</p>
          </Card>
        ))}
      </div>
    </div>
  );
}