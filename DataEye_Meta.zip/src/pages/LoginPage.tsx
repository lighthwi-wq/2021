import { useState } from 'react';
import { Lock, Mail, Eye, EyeOff, Shield, User, Database, CheckCircle2, AlertCircle } from 'lucide-react';
import { motion } from 'motion/react';
import logoLight from 'figma:asset/1bbf2e3946f645f8509820f2f9de933f45359ffc.png';

interface LoginPageProps {
  onLogin: (userType: 'admin' | 'user') => void;
}

export function LoginPage({ onLogin }: LoginPageProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!email || !password) {
      setError('이메일과 비밀번호를 입력해주세요.');
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      setError('올바른 이메일 형식이 아닙니다.');
      return;
    }

    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      onLogin('user');
    }, 1000);
  };

  const handleQuickLogin = (role: 'admin' | 'user') => {
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      onLogin(role);
    }, 800);
  };

  return (
    <div 
      className="min-h-screen flex flex-col items-center justify-center p-4"
      style={{ 
        backgroundColor: '#F9F9F9',
        backgroundImage: 'radial-gradient(circle at 20% 50%, rgba(43, 141, 255, 0.03) 0%, transparent 50%), radial-gradient(circle at 80% 80%, rgba(245, 158, 11, 0.03) 0%, transparent 50%)'
      }}
    >
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="p-10 rounded-2xl w-full max-w-md"
        style={{
          backgroundColor: '#FFFFFF',
          border: '1px solid #DADCE0',
          boxShadow: '0 4px 16px rgba(0, 0, 0, 0.06)'
        }}
      >
        {/* 상단: 로고 및 카피 */}
        <div className="mb-8 text-center">
          <img 
            src={logoLight} 
            alt="DataEye Meta" 
            className="h-7 object-contain mb-4 mx-auto"
          />
        </div>

        <div>
          {/* 로그인 폼 */}
          <div>
            <div className="mb-6">
              <p className="text-center" style={{ color: '#5F6368', fontSize: '14px' }}>
                계정에 로그인하여 시스템을 이용하세요
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              {/* 이메일 입력 */}
              <div>
                <label 
                  htmlFor="email"
                  className="block mb-2 font-medium"
                  style={{ color: '#202124', fontSize: '14px' }}
                >
                  이메일 주소
                </label>
                <div className="relative">
                  <Mail 
                    className="absolute left-3.5 top-1/2 transform -translate-y-1/2 w-5 h-5"
                    style={{ color: '#5F6368' }}
                  />
                  <input
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="your.email@company.com"
                    className="w-full pl-11 pr-4 py-3 rounded-xl border outline-none transition-all"
                    style={{
                      backgroundColor: '#F9F9F9',
                      borderColor: '#DADCE0',
                      color: '#202124',
                      fontSize: '14px'
                    }}
                    onFocus={(e) => {
                      e.target.style.borderColor = '#2B8DFF';
                      e.target.style.boxShadow = '0 0 0 3px rgba(43, 141, 255, 0.1)';
                      e.target.style.backgroundColor = '#FFFFFF';
                    }}
                    onBlur={(e) => {
                      e.target.style.borderColor = '#DADCE0';
                      e.target.style.boxShadow = 'none';
                      e.target.style.backgroundColor = '#F9F9F9';
                    }}
                  />
                </div>
              </div>

              {/* 비밀번호 입력 */}
              <div>
                <label 
                  htmlFor="password"
                  className="block mb-2 font-medium"
                  style={{ color: '#202124', fontSize: '14px' }}
                >
                  비밀번호
                </label>
                <div className="relative">
                  <Lock 
                    className="absolute left-3.5 top-1/2 transform -translate-y-1/2 w-5 h-5"
                    style={{ color: '#5F6368' }}
                  />
                  <input
                    id="password"
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-11 pr-11 py-3 rounded-xl border outline-none transition-all"
                    style={{
                      backgroundColor: '#F9F9F9',
                      borderColor: '#DADCE0',
                      color: '#202124',
                      fontSize: '14px'
                    }}
                    onFocus={(e) => {
                      e.target.style.borderColor = '#2B8DFF';
                      e.target.style.boxShadow = '0 0 0 3px rgba(43, 141, 255, 0.1)';
                      e.target.style.backgroundColor = '#FFFFFF';
                    }}
                    onBlur={(e) => {
                      e.target.style.borderColor = '#DADCE0';
                      e.target.style.boxShadow = 'none';
                      e.target.style.backgroundColor = '#F9F9F9';
                    }}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3.5 top-1/2 transform -translate-y-1/2 p-1 rounded-lg hover:bg-gray-100 transition-colors"
                  >
                    {showPassword ? (
                      <EyeOff className="w-5 h-5" style={{ color: '#5F6368' }} />
                    ) : (
                      <Eye className="w-5 h-5" style={{ color: '#5F6368' }} />
                    )}
                  </button>
                </div>
              </div>

              {/* 에러 메시지 */}
              {error && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex items-center gap-2 px-4 py-3 rounded-xl"
                  style={{
                    backgroundColor: '#FEF2F2',
                    border: '1px solid #FCA5A5'
                  }}
                >
                  <AlertCircle className="w-4 h-4 flex-shrink-0" style={{ color: '#DC2626' }} />
                  <p style={{ color: '#DC2626', fontSize: '13px' }}>
                    {error}
                  </p>
                </motion.div>
              )}
            </form>

            {/* 로그인 버튼들 */}
            <div className="space-y-3 mt-4">
              {/* 일반로그인 버튼 */}
              <motion.button
                onClick={handleSubmit}
                disabled={isLoading}
                className="w-full py-3.5 rounded-xl font-medium transition-all"
                style={{
                  backgroundColor: isLoading ? '#94C5FF' : '#2B8DFF',
                  color: '#FFFFFF',
                  fontSize: '15px',
                  cursor: isLoading ? 'not-allowed' : 'pointer',
                  boxShadow: isLoading ? 'none' : '0 2px 8px rgba(43, 141, 255, 0.25)'
                }}
                whileHover={!isLoading ? { scale: 1.01 } : {}}
                whileTap={!isLoading ? { scale: 0.99 } : {}}
              >
                {isLoading ? (
                  <div className="flex items-center justify-center gap-2">
                    <motion.div
                      className="w-5 h-5 border-2 border-white border-t-transparent rounded-full"
                      animate={{ rotate: 360 }}
                      transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                    />
                    <span>인증 중...</span>
                  </div>
                ) : (
                  '일반 로그인'
                )}
              </motion.button>

              {/* 통합로그인 버튼 */}
              <motion.button
                onClick={handleSubmit}
                disabled={isLoading}
                className="w-full py-3.5 rounded-xl font-medium transition-all"
                style={{
                  backgroundColor: isLoading ? '#4A5F9A' : '#1E3A8A',
                  color: '#FFFFFF',
                  fontSize: '15px',
                  cursor: isLoading ? 'not-allowed' : 'pointer',
                  boxShadow: isLoading ? 'none' : '0 2px 8px rgba(30, 58, 138, 0.25)'
                }}
                whileHover={!isLoading ? { scale: 1.01 } : {}}
                whileTap={!isLoading ? { scale: 0.99 } : {}}
              >
                통합 로그인
              </motion.button>
            </div>

            {/* 구분선 */}
            <div className="flex items-center gap-4 my-5">
              <div className="flex-1 h-px" style={{ backgroundColor: '#DADCE0' }} />
              <span style={{ color: '#80868B', fontSize: '12px' }}>빠른 접속</span>
              <div className="flex-1 h-px" style={{ backgroundColor: '#DADCE0' }} />
            </div>

            {/* 빠른 로그인 버튼들 */}
            <div className="grid grid-cols-2 gap-3">
              <motion.button
                onClick={() => handleQuickLogin('admin')}
                disabled={isLoading}
                className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg border font-medium transition-all"
                style={{
                  backgroundColor: '#FFF7ED',
                  borderColor: '#FED7AA',
                  color: '#202124'
                }}
                whileHover={!isLoading ? { scale: 1.02, borderColor: '#F59E0B' } : {}}
                whileTap={!isLoading ? { scale: 0.98 } : {}}
              >
                <Shield className="w-4 h-4" style={{ color: '#F59E0B' }} />
                <span style={{ fontSize: '13px', fontWeight: '600' }}>관리자</span>
              </motion.button>

              <motion.button
                onClick={() => handleQuickLogin('user')}
                disabled={isLoading}
                className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg border font-medium transition-all"
                style={{
                  backgroundColor: '#F0F7FF',
                  borderColor: '#BFDBFE',
                  color: '#202124'
                }}
                whileHover={!isLoading ? { scale: 1.02, borderColor: '#2B8DFF' } : {}}
                whileTap={!isLoading ? { scale: 0.98 } : {}}
              >
                <User className="w-4 h-4" style={{ color: '#2B8DFF' }} />
                <span style={{ fontSize: '13px', fontWeight: '600' }}>사용자</span>
              </motion.button>
            </div>

            {/* 하단 안내 */}
            <div className="mt-5 text-center">
            </div>
          </div>
        </div>
      </motion.div>

      {/* 카피라이트 */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5, delay: 0.2 }}
        className="mt-8 text-center"
      >
        <p style={{ color: '#80868B', fontSize: '12px' }}>
          Copyright © 2025 PentaSystem Technology Corp.
        </p>
      </motion.div>
    </div>
  );
}