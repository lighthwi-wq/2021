import { FilePlus, Search, Filter, Download, X, MessageCircle, CheckCircle, XCircle, Clock } from 'lucide-react';
import { Card } from '../components/common/Card';
import { IconBox } from '../components/common/IconBox';
import { Button } from '../components/common/Button';
import { Badge } from '../components/common/Badge';
import { Pagination } from '../components/common/Pagination';
import { DiffView } from '../components/common/DiffView';
import { useState, useMemo, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useModal } from '../contexts/ModalContext';

export function WorkflowRequestPage() {
  const { setIsModalOpen } = useModal();
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [selectedRequest, setSelectedRequest] = useState<any>(null);
  const [comment, setComment] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');

  useEffect(() => {
    setIsModalOpen(isDetailModalOpen);
  }, [isDetailModalOpen, setIsModalOpen]);

  // 신청/결재 데이터
  const requests = [
    {
      id: 'REQ-2024-001',
      title: '신규 표준 용어 등록 신청',
      requestType: '표준신규',
      requester: '김개발',
      department: '개발팀',
      requestDate: '2024-11-27 09:30',
      approver: '수석님',
      currentStage: '결재대기',
      status: '결재중',
      priority: 'high',
      before: {},
      after: {
        termName: '고객등급코드',
        englishName: 'CUST_GRADE_CD',
        domain: '코드타입',
        description: '고객의 등급을 구분하는 코드',
        department: '영업팀',
        owner: '김개발',
      },
      comments: [
        { 
          id: 1, 
          author: '김개발', 
          content: '신규 고객 등급 관리를 위한 표준 용어가 필요합니다.', 
          date: '2024-11-27 09:30',
          type: 'request'
        }
      ]
    },
    {
      id: 'REQ-2024-002',
      title: '고객번호 정의 변경 요청',
      requestType: '표준변경',
      requester: '이데이터',
      department: '데이터팀',
      requestDate: '2024-11-27 08:15',
      approver: '수석님',
      currentStage: '결재대기',
      status: '결재중',
      priority: 'medium',
      before: {
        termName: '고객번호',
        englishName: 'CUST_NO',
        domain: '번호타입',
        description: '고객을 식별하는 번호',
        length: '10',
      },
      after: {
        termName: '고객번호',
        englishName: 'CUST_NO',
        domain: '번호타입',
        description: '고객을 고유하게 식별하는 번호',
        length: '20',
      },
      comments: []
    },
    {
      id: 'REQ-2024-003',
      title: '주문일자 컬럼 추가 승인',
      requestType: '모델변경',
      requester: '박시스템',
      department: 'IT팀',
      requestDate: '2024-11-26 16:45',
      approver: '수석님',
      currentStage: '승인완료',
      status: '승인',
      priority: 'high',
      before: {},
      after: {
        tableName: 'TB_ORDER',
        columnName: 'ORD_DT',
        dataType: 'DATE',
        length: '8',
        description: '주문이 발생한 일자',
      },
      comments: [
        { 
          id: 1, 
          author: '수석님', 
          content: '표준 용어와 매핑되었으며, 승인합니다.', 
          date: '2024-11-26 17:00',
          type: 'approve'
        }
      ]
    },
    {
      id: 'REQ-2024-004',
      title: '상품명 길이 확대 요청',
      requestType: '표준변경',
      requester: '최상품',
      department: '상품팀',
      requestDate: '2024-11-26 14:20',
      approver: '수석님',
      currentStage: '반려',
      status: '반려',
      priority: 'low',
      before: {
        termName: '상품명',
        length: '50',
      },
      after: {
        termName: '상품명',
        length: '200',
      },
      comments: [
        { 
          id: 1, 
          author: '수석님', 
          content: '길이 확대 사유가 불충분합니다. 구체적인 사례를 추가하여 재신청해주세요.', 
          date: '2024-11-26 15:00',
          type: 'reject'
        }
      ]
    },
  ];

  const filteredRequests = useMemo(() => {
    let filtered = requests.filter(req =>
      req.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      req.requester.toLowerCase().includes(searchTerm.toLowerCase()) ||
      req.department.toLowerCase().includes(searchTerm.toLowerCase())
    );
    
    if (filterStatus !== 'all') {
      filtered = filtered.filter(req => req.status === filterStatus);
    }
    
    return filtered;
  }, [searchTerm, filterStatus]);

  const paginatedRequests = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage;
    return filteredRequests.slice(start, start + itemsPerPage);
  }, [filteredRequests, currentPage, itemsPerPage]);

  const getStatusBadge = (status: string) => {
    switch (status) {
      case '임시저장':
        return <Badge variant="default">임시저장</Badge>;
      case '결재중':
        return <Badge variant="warning">결재중</Badge>;
      case '반려':
        return <Badge variant="error">반려</Badge>;
      case '승인':
        return <Badge variant="success">승인</Badge>;
      case '적용완료':
        return <Badge variant="info">적용완료</Badge>;
      default:
        return <Badge variant="default">{status}</Badge>;
    }
  };

  const getPriorityBadge = (priority: string) => {
    switch (priority) {
      case 'high':
        return <Badge variant="error">높음</Badge>;
      case 'medium':
        return <Badge variant="warning">보통</Badge>;
      case 'low':
        return <Badge variant="default">낮음</Badge>;
      default:
        return <Badge variant="default">{priority}</Badge>;
    }
  };

  const getRequestTypeIcon = (type: string) => {
    return FilePlus;
  };

  const handleApprove = () => {
    if (!comment.trim()) {
      alert('승인 의견을 입력해주세요.');
      return;
    }
    alert('승인되었습니다.');
    setIsDetailModalOpen(false);
  };

  const handleReject = () => {
    if (!comment.trim()) {
      alert('반려 사유를 입력해주세요.');
      return;
    }
    alert('반려되었습니다.');
    setIsDetailModalOpen(false);
  };

  return (
    <div className="space-y-4 p-0">
      <div className="flex-1 overflow-auto">
        <div className="space-y-6 p-0">
          {/* 상단 통계 */}
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            <Card padding="lg" hover>
              <IconBox icon={FilePlus} color="blue" size="md" />
              <div className="mt-3">
                <p className="mb-1" style={{ color: '#5F6368' }}>전체 신청</p>
                <h3 className="text-2xl font-bold" style={{ color: '#202124' }}>247</h3>
              </div>
            </Card>
            <Card padding="lg" hover>
              <IconBox icon={Clock} color="orange" size="md" />
              <div className="mt-3">
                <p className="mb-1" style={{ color: '#5F6368' }}>결재중</p>
                <h3 className="text-2xl font-bold" style={{ color: '#202124' }}>23</h3>
              </div>
            </Card>
            <Card padding="lg" hover>
              <IconBox icon={CheckCircle} color="green" size="md" />
              <div className="mt-3">
                <p className="mb-1" style={{ color: '#5F6368' }}>승인</p>
                <h3 className="text-2xl font-bold" style={{ color: '#202124' }}>198</h3>
              </div>
            </Card>
            <Card padding="lg" hover>
              <IconBox icon={XCircle} color="red" size="md" />
              <div className="mt-3">
                <p className="mb-1" style={{ color: '#5F6368' }}>반려</p>
                <h3 className="text-2xl font-bold" style={{ color: '#202124' }}>17</h3>
              </div>
            </Card>
            <Card padding="lg" hover>
              <IconBox icon={FilePlus} color="gray" size="md" />
              <div className="mt-3">
                <p className="mb-1" style={{ color: '#5F6368' }}>임시저장</p>
                <h3 className="text-2xl font-bold" style={{ color: '#202124' }}>9</h3>
              </div>
            </Card>
          </div>

          {/* 메인 테이블 */}
          <Card padding="lg">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <IconBox icon={FilePlus} color="blue" size="md" />
                <h3 className="font-bold" style={{ color: '#202124' }}>나의 신청/결재함</h3>
              </div>
              <div className="flex items-center gap-2">
                <select
                  value={filterStatus}
                  onChange={(e) => setFilterStatus(e.target.value)}
                  className="px-3 py-2 rounded-lg border text-sm"
                  style={{ backgroundColor: '#F9F9F9', borderColor: '#DADCE0', color: '#202124' }}
                >
                  <option value="all">전체 상태</option>
                  <option value="임시저장">임시저장</option>
                  <option value="결재중">결재중</option>
                  <option value="반려">반려</option>
                  <option value="승인">승인</option>
                  <option value="적용완료">적용완료</option>
                </select>
                <div className="relative">
                  <Search 
                    className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4" 
                    style={{ color: '#9CA3AF' }}
                  />
                  <input
                    type="text"
                    placeholder="신청 제목, 신청자 검색..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 pr-4 py-2 rounded-lg border text-sm"
                    style={{ backgroundColor: '#F9F9F9', borderColor: '#DADCE0', color: '#202124', width: '250px' }}
                  />
                </div>
                <Button variant="ghost" icon={<Filter className="w-4 h-4" />} size="sm">필터</Button>
                <Button variant="ghost" icon={<Download className="w-4 h-4" />} size="sm">내보내기</Button>
                <Button variant="primary" icon={<FilePlus className="w-4 h-4" />} size="sm">신규 신청</Button>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full">
                <thead style={{ backgroundColor: '#F7F8FA' }}>
                  <tr style={{ borderBottom: '1px solid #DADCE0' }}>
                    <th className="px-4 py-3 text-left text-sm" style={{ color: '#5F6368' }}>신청번호</th>
                    <th className="px-4 py-3 text-left text-sm" style={{ color: '#5F6368' }}>신청제목</th>
                    <th className="px-4 py-3 text-left text-sm" style={{ color: '#5F6368' }}>신청유형</th>
                    <th className="px-4 py-3 text-left text-sm" style={{ color: '#5F6368' }}>신청자</th>
                    <th className="px-4 py-3 text-left text-sm" style={{ color: '#5F6368' }}>부서</th>
                    <th className="px-4 py-3 text-left text-sm" style={{ color: '#5F6368' }}>결재자</th>
                    <th className="px-4 py-3 text-left text-sm" style={{ color: '#5F6368' }}>현재단계</th>
                    <th className="px-4 py-3 text-center text-sm" style={{ color: '#5F6368' }}>상태</th>
                    <th className="px-4 py-3 text-center text-sm" style={{ color: '#5F6368' }}>우선순위</th>
                  </tr>
                </thead>
                <tbody>
                  {paginatedRequests.map((request, idx) => (
                    <tr
                      key={request.id}
                      className="cursor-pointer transition-colors"
                      style={{ borderBottom: idx < paginatedRequests.length - 1 ? '1px solid #E8EAED' : 'none' }}
                      onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#F7F8FA'}
                      onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
                      onClick={() => {
                        setSelectedRequest(request);
                        setIsDetailModalOpen(true);
                        setComment('');
                      }}
                    >
                      <td className="px-4 py-4">
                        <span className="font-mono text-sm font-medium" style={{ color: '#2B8DFF' }}>{request.id}</span>
                      </td>
                      <td className="px-4 py-4">
                        <span className="font-medium" style={{ color: '#202124' }}>{request.title}</span>
                      </td>
                      <td className="px-4 py-4">
                        <Badge variant="info">{request.requestType}</Badge>
                      </td>
                      <td className="px-4 py-4">
                        <span style={{ color: '#5F6368' }}>{request.requester}</span>
                      </td>
                      <td className="px-4 py-4">
                        <span style={{ color: '#5F6368' }}>{request.department}</span>
                      </td>
                      <td className="px-4 py-4">
                        <span style={{ color: '#5F6368' }}>{request.approver}</span>
                      </td>
                      <td className="px-4 py-4">
                        <span className="text-sm" style={{ color: '#202124' }}>{request.currentStage}</span>
                      </td>
                      <td className="px-4 py-4 text-center">
                        {getStatusBadge(request.status)}
                      </td>
                      <td className="px-4 py-4 text-center">
                        {getPriorityBadge(request.priority)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <Pagination
              totalItems={filteredRequests.length}
              itemsPerPage={itemsPerPage}
              currentPage={currentPage}
              totalPages={Math.ceil(filteredRequests.length / itemsPerPage)}
              onPageChange={setCurrentPage}
              onItemsPerPageChange={setItemsPerPage}
            />
          </Card>
        </div>
      </div>

      {/* 상세 모달 (Diff View + 코멘트) */}
      <AnimatePresence>
        {isDetailModalOpen && selectedRequest && (
          <motion.div
            className="fixed right-0 top-0 h-screen w-[400px] z-50 shadow-2xl overflow-hidden flex flex-col border-l"
            style={{ backgroundColor: '#FFFFFF', borderColor: '#DADCE0' }}
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 30, stiffness: 300 }}
          >
            {/* Header */}
            <div className="px-8 py-6 border-b flex items-center justify-between" style={{ borderColor: '#DADCE0' }}>
              <div>
                <div className="flex items-center gap-3 mb-2">
                  <h3 className="text-xl font-bold" style={{ color: '#202124' }}>{selectedRequest.title}</h3>
                  {getStatusBadge(selectedRequest.status)}
                </div>
                <p className="text-sm" style={{ color: '#5F6368' }}>
                  신청번호: {selectedRequest.id} • 신청일: {selectedRequest.requestDate}
                </p>
              </div>
              <button
                onClick={() => setIsDetailModalOpen(false)}
                className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
                style={{ color: '#5F6368' }}
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto px-8 py-6">
              <div className="space-y-6">
                {/* 신청 정보 */}
                <Card padding="lg">
                  <h4 className="font-bold mb-4" style={{ color: '#202124' }}>신청 정보</h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="flex justify-between">
                      <span className="text-sm" style={{ color: '#5F6368' }}>신청유형:</span>
                      <Badge variant="info">{selectedRequest.requestType}</Badge>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm" style={{ color: '#5F6368' }}>우선순위:</span>
                      {getPriorityBadge(selectedRequest.priority)}
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm" style={{ color: '#5F6368' }}>신청자:</span>
                      <span className="text-sm font-medium" style={{ color: '#202124' }}>{selectedRequest.requester}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm" style={{ color: '#5F6368' }}>부서:</span>
                      <span className="text-sm" style={{ color: '#202124' }}>{selectedRequest.department}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm" style={{ color: '#5F6368' }}>결재자:</span>
                      <span className="text-sm font-medium" style={{ color: '#202124' }}>{selectedRequest.approver}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm" style={{ color: '#5F6368' }}>현재단계:</span>
                      <span className="text-sm" style={{ color: '#202124' }}>{selectedRequest.currentStage}</span>
                    </div>
                  </div>
                </Card>

                {/* Diff View (핵심 기능) */}
                <Card padding="lg">
                  <DiffView 
                    before={selectedRequest.before}
                    after={selectedRequest.after}
                    title="변경 내역"
                  />
                </Card>

                {/* 코멘트 영역 */}
                <Card padding="lg">
                  <h4 className="font-bold mb-4" style={{ color: '#202124' }}>의견 및 코멘트</h4>
                  <div className="space-y-3 mb-4">
                    {selectedRequest.comments.length > 0 ? (
                      selectedRequest.comments.map((cmt: any) => (
                        <div 
                          key={cmt.id}
                          className="p-4 rounded-lg border"
                          style={{ 
                            backgroundColor: '#F7F8FA',
                            borderColor: cmt.type === 'reject' ? '#FEE2E2' : cmt.type === 'approve' ? '#D1FAE5' : '#DADCE0'
                          }}
                        >
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-2">
                              <span className="text-sm font-bold" style={{ color: '#202124' }}>{cmt.author}</span>
                              {cmt.type === 'approve' && <Badge variant="success">승인</Badge>}
                              {cmt.type === 'reject' && <Badge variant="error">반려</Badge>}
                              {cmt.type === 'request' && <Badge variant="info">신청</Badge>}
                            </div>
                            <span className="text-xs" style={{ color: '#5F6368' }}>{cmt.date}</span>
                          </div>
                          <p className="text-sm" style={{ color: '#202124' }}>{cmt.content}</p>
                        </div>
                      ))
                    ) : (
                      <p className="text-center text-sm py-4" style={{ color: '#9CA3AF' }}>
                        아직 코멘트가 없습니다
                      </p>
                    )}
                  </div>

                  {/* 코멘트 입력 */}
                  {selectedRequest.status === '결재중' && (
                    <div>
                      <label className="block text-sm font-medium mb-2" style={{ color: '#202124' }}>
                        {selectedRequest.status === '결재중' ? '결재 의견' : '코멘트'}
                      </label>
                      <textarea
                        value={comment}
                        onChange={(e) => setComment(e.target.value)}
                        rows={4}
                        placeholder="의견을 입력하세요..."
                        className="w-full px-4 py-2 rounded-lg border resize-none"
                        style={{ backgroundColor: '#F9F9F9', borderColor: '#DADCE0', color: '#202124' }}
                      />
                    </div>
                  )}
                </Card>
              </div>
            </div>

            {/* Footer */}
            <div className="px-8 py-4 border-t flex items-center justify-between" style={{ borderColor: '#DADCE0' }}>
              <Button variant="ghost" onClick={() => setIsDetailModalOpen(false)}>닫기</Button>
              {selectedRequest.status === '결재중' && (
                <div className="flex gap-3">
                  <Button 
                    variant="error"
                    icon={<XCircle className="w-4 h-4" />}
                    onClick={handleReject}
                  >
                    반려
                  </Button>
                  <Button 
                    variant="success"
                    icon={<CheckCircle className="w-4 h-4" />}
                    onClick={handleApprove}
                  >
                    승인
                  </Button>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}