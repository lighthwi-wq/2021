import { Code2, Search, Plus, Download, Upload, ArrowUpDown, ChevronUp, ChevronDown, Filter, Edit2, Trash2, Settings } from 'lucide-react';
import { Card } from '../components/common/Card';
import { IconBox } from '../components/common/IconBox';
import { Button } from '../components/common/Button';
import { Badge } from '../components/common/Badge';
import { Pagination } from '../components/common/Pagination';
import { SystemCodeFormModal } from '../components/modals/SystemCodeFormModal';
import { useState } from 'react';
import { motion } from 'motion/react';

export function SystemCodeManagementPage() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState<'create' | 'edit'>('create');
  const [selectedCode, setSelectedCode] = useState<any>(null);
  const [sortField, setSortField] = useState<string>('');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);

  const handleAddClick = () => {
    setModalMode('create');
    setSelectedCode(null);
    setIsModalOpen(true);
  };

  const handleCodeClick = (code: any) => {
    setModalMode('edit');
    setSelectedCode(code);
    setIsModalOpen(true);
  };

  const systemCodes = [
    { 
      codeGroup: 'APPR_STAT', 
      codeGroupName: '승인상태', 
      code: 'APPR', 
      codeName: '승인완료', 
      orderNo: 1, 
      useYn: 'Y', 
      description: '승인이 완료된 상태', 
      createdDate: '2024-01-15',
      updatedDate: '2024-01-15'
    },
    { 
      codeGroup: 'APPR_STAT', 
      codeGroupName: '승인상태', 
      code: 'RJCT', 
      codeName: '반려', 
      orderNo: 2, 
      useYn: 'Y', 
      description: '승인이 반려된 상태', 
      createdDate: '2024-01-15',
      updatedDate: '2024-01-15'
    },
    { 
      codeGroup: 'APPR_STAT', 
      codeGroupName: '승인상태', 
      code: 'WAIT', 
      codeName: '승인대기', 
      orderNo: 3, 
      useYn: 'Y', 
      description: '승인 대기중인 상태', 
      createdDate: '2024-01-15',
      updatedDate: '2024-01-15'
    },
    { 
      codeGroup: 'DATA_TYPE', 
      codeGroupName: '데이터타입', 
      code: 'VARCHAR', 
      codeName: '문자열', 
      orderNo: 1, 
      useYn: 'Y', 
      description: '가변 길이 문자열 타입', 
      createdDate: '2024-01-20',
      updatedDate: '2024-01-20'
    },
    { 
      codeGroup: 'DATA_TYPE', 
      codeGroupName: '데이터타입', 
      code: 'NUMBER', 
      codeName: '숫자', 
      orderNo: 2, 
      useYn: 'Y', 
      description: '숫자 타입', 
      createdDate: '2024-01-20',
      updatedDate: '2024-01-20'
    },
    { 
      codeGroup: 'DATA_TYPE', 
      codeGroupName: '데이터타입', 
      code: 'DATE', 
      codeName: '날짜', 
      orderNo: 3, 
      useYn: 'Y', 
      description: '날짜 타입', 
      createdDate: '2024-01-20',
      updatedDate: '2024-01-20'
    },
    { 
      codeGroup: 'QUALITY_RULE', 
      codeGroupName: '품질규칙', 
      code: 'NOT_NULL', 
      codeName: 'NOT NULL', 
      orderNo: 1, 
      useYn: 'Y', 
      description: 'NULL 값 허용 안함', 
      createdDate: '2024-02-01',
      updatedDate: '2024-02-01'
    },
    { 
      codeGroup: 'QUALITY_RULE', 
      codeGroupName: '품질규칙', 
      code: 'UNIQUE', 
      codeName: '유일성', 
      orderNo: 2, 
      useYn: 'Y', 
      description: '중복값 허용 안함', 
      createdDate: '2024-02-01',
      updatedDate: '2024-02-01'
    },
    { 
      codeGroup: 'SYSTEM_TYPE', 
      codeGroupName: '시스템유형', 
      code: 'ERP', 
      codeName: 'ERP시스템', 
      orderNo: 1, 
      useYn: 'Y', 
      description: '전사자원관리 시스템', 
      createdDate: '2024-02-10',
      updatedDate: '2024-02-10'
    },
    { 
      codeGroup: 'SYSTEM_TYPE', 
      codeGroupName: '시스템유형', 
      code: 'CRM', 
      codeName: 'CRM시스템', 
      orderNo: 2, 
      useYn: 'Y', 
      description: '고객관계관리 시스템', 
      createdDate: '2024-02-10',
      updatedDate: '2024-02-10'
    },
  ];

  const codeStats = [
    { label: '코드그룹 수', value: '48', color: 'blue' as const },
    { label: '전체 코드', value: '342', color: 'green' as const },
    { label: '사용중', value: '318', color: 'orange' as const },
    { label: '미사용', value: '24', color: 'red' as const },
  ];

  const handleSort = (field: string) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const SortIcon = ({ field }: { field: string }) => {
    if (sortField !== field) {
      return <ArrowUpDown className="w-3.5 h-3.5 text-gray-400 ml-1" />;
    }
    return sortDirection === 'asc' ? (
      <ChevronUp className="w-3.5 h-3.5 ml-1" style={{ color: '#2B8DFF' }} />
    ) : (
      <ChevronDown className="w-3.5 h-3.5 ml-1" style={{ color: '#2B8DFF' }} />
    );
  };

  const handleExport = () => {
    const headers = ['코드그룹', '그룹명', '코드', '코드명', '순서', '사용여부', '설명', '등록일'];
    const csvContent = [
      headers.join(','),
      ...systemCodes.map(code => 
        [code.codeGroup, code.codeGroupName, code.code, code.codeName, code.orderNo, code.useYn, code.description, code.createdDate].join(',')
      )
    ].join('\n');

    const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `시스템코드목록_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleImport = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.csv,.xlsx,.xls';
    input.onchange = (e: any) => {
      const file = e.target.files[0];
      if (file) {
        console.log('파일 가져오기:', file.name);
        alert(`${file.name} 파일을 가져왔습니다.\n실제 구현시 파일 파싱 및 데이터 임포트 로직이 실행됩니다.`);
      }
    };
    input.click();
  };

  const totalPages = Math.ceil(systemCodes.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const currentItems = systemCodes.slice(startIndex, endIndex);

  return (
    <>
      <div className="p-6 space-y-6">
        {/* 헤더 영역 */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <IconBox icon={Code2} variant="blue" />
            <div>
              <h1 className="font-bold mb-1" style={{ color: '#202124' }}>시스템 코드 관리</h1>
              <p className="text-sm" style={{ color: '#5F6368' }}>시스템에서 사용하는 공통 코드를 관리합니다</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="secondary" size="md" onClick={handleImport}>
              <Upload className="w-4 h-4" />
              가져오기
            </Button>
            <Button variant="secondary" size="md" onClick={handleExport}>
              <Download className="w-4 h-4" />
              내보내기
            </Button>
            <Button variant="primary" size="md" onClick={handleAddClick}>
              <Plus className="w-4 h-4" />
              코드 추가
            </Button>
          </div>
        </div>

        {/* 통계 카드 */}
        <div className="grid grid-cols-4 gap-4">
          {codeStats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: index * 0.1 }}
            >
              <Card padding="lg" hover>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm mb-2" style={{ color: '#5F6368' }}>{stat.label}</p>
                    <p className="font-bold" style={{ fontSize: '24px', color: '#202124' }}>{stat.value}</p>
                  </div>
                  <div 
                    className="w-12 h-12 rounded-xl flex items-center justify-center"
                    style={{ 
                      backgroundColor: stat.color === 'blue' ? '#E8F0FE' :
                                     stat.color === 'green' ? '#E6F4EA' :
                                     stat.color === 'orange' ? '#FEF7E0' : '#FCE8E6'
                    }}
                  >
                    <Settings 
                      className="w-6 h-6"
                      style={{ 
                        color: stat.color === 'blue' ? '#1967D2' :
                               stat.color === 'green' ? '#137333' :
                               stat.color === 'orange' ? '#E37400' : '#C5221F'
                      }}
                    />
                  </div>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* 검색 및 필터 */}
        <Card padding="lg">
          <div className="flex items-center gap-4">
            <div className="flex-1 relative">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2" style={{ color: '#5F6368' }} />
              <input
                type="text"
                placeholder="코드그룹, 코드명, 설명으로 검색..."
                className="w-full pl-10 pr-4 py-2.5 rounded-lg border text-sm"
                style={{ 
                  borderColor: '#DADCE0',
                  backgroundColor: '#FFFFFF'
                }}
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Button variant="secondary" size="md">
              <Filter className="w-4 h-4" />
              필터
            </Button>
          </div>
        </Card>

        {/* 테이블 */}
        <Card padding="none">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr style={{ borderBottom: '2px solid #E8EAED' }}>
                  <th className="text-left px-6 py-4 text-sm font-medium" style={{ color: '#5F6368', backgroundColor: '#F8F9FA' }}>
                    <button onClick={() => handleSort('codeGroup')} className="flex items-center hover:text-blue-600">
                      코드그룹 <SortIcon field="codeGroup" />
                    </button>
                  </th>
                  <th className="text-left px-6 py-4 text-sm font-medium" style={{ color: '#5F6368', backgroundColor: '#F8F9FA' }}>
                    <button onClick={() => handleSort('codeGroupName')} className="flex items-center hover:text-blue-600">
                      그룹명 <SortIcon field="codeGroupName" />
                    </button>
                  </th>
                  <th className="text-left px-6 py-4 text-sm font-medium" style={{ color: '#5F6368', backgroundColor: '#F8F9FA' }}>
                    <button onClick={() => handleSort('code')} className="flex items-center hover:text-blue-600">
                      코드 <SortIcon field="code" />
                    </button>
                  </th>
                  <th className="text-left px-6 py-4 text-sm font-medium" style={{ color: '#5F6368', backgroundColor: '#F8F9FA' }}>
                    <button onClick={() => handleSort('codeName')} className="flex items-center hover:text-blue-600">
                      코드명 <SortIcon field="codeName" />
                    </button>
                  </th>
                  <th className="text-left px-6 py-4 text-sm font-medium" style={{ color: '#5F6368', backgroundColor: '#F8F9FA' }}>
                    순서
                  </th>
                  <th className="text-left px-6 py-4 text-sm font-medium" style={{ color: '#5F6368', backgroundColor: '#F8F9FA' }}>
                    사용여부
                  </th>
                  <th className="text-left px-6 py-4 text-sm font-medium" style={{ color: '#5F6368', backgroundColor: '#F8F9FA' }}>
                    설명
                  </th>
                  <th className="text-left px-6 py-4 text-sm font-medium" style={{ color: '#5F6368', backgroundColor: '#F8F9FA' }}>
                    등록일
                  </th>
                </tr>
              </thead>
              <tbody>
                {currentItems.map((code, index) => (
                  <motion.tr
                    key={`${code.codeGroup}-${code.code}`}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ duration: 0.3, delay: index * 0.05 }}
                    onClick={() => handleCodeClick(code)}
                    className="cursor-pointer transition-colors"
                    style={{ borderBottom: '1px solid #E8EAED' }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.backgroundColor = '#F8F9FA';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.backgroundColor = 'transparent';
                    }}
                  >
                    <td className="px-6 py-4">
                      <span className="font-mono text-sm" style={{ color: '#202124' }}>{code.codeGroup}</span>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-sm" style={{ color: '#202124' }}>{code.codeGroupName}</span>
                    </td>
                    <td className="px-6 py-4">
                      <span className="font-mono text-sm font-medium" style={{ color: '#1967D2' }}>{code.code}</span>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-sm" style={{ color: '#202124' }}>{code.codeName}</span>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-sm" style={{ color: '#5F6368' }}>{code.orderNo}</span>
                    </td>
                    <td className="px-6 py-4">
                      <Badge variant={code.useYn === 'Y' ? 'success' : 'default'}>
                        {code.useYn === 'Y' ? '사용' : '미사용'}
                      </Badge>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-sm" style={{ color: '#5F6368' }}>{code.description}</span>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-sm" style={{ color: '#5F6368' }}>{code.createdDate}</span>
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>

        {/* Pagination */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-sm" style={{ color: '#5F6368' }}>페이지당 표시:</span>
            <select
              value={itemsPerPage}
              onChange={(e) => {
                setItemsPerPage(Number(e.target.value));
                setCurrentPage(1);
              }}
              className="px-3 py-1.5 rounded-lg border text-sm"
              style={{ borderColor: '#DADCE0', backgroundColor: '#FFFFFF' }}
            >
              <option value={10}>10개</option>
              <option value={20}>20개</option>
              <option value={50}>50개</option>
            </select>
          </div>
          <Pagination
            currentPage={currentPage}
            totalPages={totalPages}
            onPageChange={setCurrentPage}
          />
        </div>
      </div>

      <SystemCodeFormModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        mode={modalMode}
        initialData={selectedCode}
      />
    </>
  );
}
