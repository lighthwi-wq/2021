import { BookText, Search, Plus, Download, Upload, ArrowUpDown, ChevronUp, ChevronDown, Filter } from 'lucide-react';
import { Card } from '../components/common/Card';
import { IconBox } from '../components/common/IconBox';
import { Button } from '../components/common/Button';
import { Badge } from '../components/common/Badge';
import { Pagination } from '../components/common/Pagination';
import { BusinessTermFormModal } from '../components/modals/BusinessTermFormModal';
import { useState } from 'react';
import { motion } from 'motion/react';

export function BusinessTermManagementPage() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState<'create' | 'edit'>('create');
  const [selectedTerm, setSelectedTerm] = useState<any>(null);
  const [sortField, setSortField] = useState<string>('');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);
  const [filters, setFilters] = useState<Record<string, string>>({});
  const [activeFilterColumn, setActiveFilterColumn] = useState<string | null>(null);

  const handleAddClick = () => {
    setModalMode('create');
    setSelectedTerm(null);
    setIsModalOpen(true);
  };

  const handleTermClick = (term: any) => {
    setModalMode('edit');
    setSelectedTerm(term);
    setIsModalOpen(true);
  };

  const businessTerms = [
    { term: '고객 등급', englishName: 'Customer Grade', domain: '고객관리', definition: '고객의 구매 이력 및 충성도에 따른  분류', status: '승인완료', owner: '김민지', updatedDate: '2024-11-18' },
    { term: '주문 상태', englishName: 'Order Status', domain: '주문관리', definition: '주문의 현재 처리 단계 및 상태 정보', status: '승인완료', owner: '이지훈', updatedDate: '2024-11-17' },
    { term: '상품 카테고리', englishName: 'Product Category', domain: '상품관리', definition: '상품의 분류 체계 및 카테고리 정보', status: '검토중', owner: '박서윤', updatedDate: '2024-11-15' },
    { term: '배송 방법', englishName: 'Delivery Method', domain: '배송관리', definition: '상품 배송을 위한 배송 수단 및 방법', status: '승인완료', owner: '최도현', updatedDate: '2024-11-14' },
    { term: '결제 수단', englishName: 'Payment Method', domain: '결제관리', definition: '고객이 선택 가능한 결제 방법 및 수단', status: '작성중', owner: '정유진', updatedDate: '2024-11-12' },
  ];

  const termStats = [
    { label: '전체 업무용어', value: '643', color: 'indigo' as const },
    { label: '승인완료', value: '512', color: 'green' as const },
    { label: '검토/작성중', value: '131', color: 'orange' as const },
  ];

  const handleSort = (field: string) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const SortIcon = ({ field }: { field: string }) => {
    if (sortField !== field) {
      return <ArrowUpDown className="w-3.5 h-3.5 text-gray-400 ml-1" />;
    }
    return sortDirection === 'asc' ? (
      <ChevronUp className="w-3.5 h-3.5 ml-1" style={{ color: '#2B8DFF' }} />
    ) : (
      <ChevronDown className="w-3.5 h-3.5 ml-1" style={{ color: '#2B8DFF' }} />
    );
  };

  const handleImport = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.csv,.xlsx,.xls';
    input.onchange = (e: any) => {
      const file = e.target.files[0];
      if (file) {
        console.log('파일 가져오기:', file.name);
        alert(`${file.name} 파일을 가져왔습니다.\n실제 구현시 파일 파싱 및 데이터 임포트 로직이 실행됩니다.`);
      }
    };
    input.click();
  };

  const handleExport = () => {
    const headers = ['한글명', '영문명', '도메인', '설명', '담당부서', '등록일'];
    const csvContent = [
      headers.join(','),
      ...businessTerms.map(term => 
        [term.term, term.englishName, term.domain, term.description, term.department, term.createdDate].join(',')
      )
    ].join('\n');

    const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `업무용어목록_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const sortedBusinessTerms = [...businessTerms].sort((a, b) => {
    if (sortField) {
      const aValue = a[sortField as keyof typeof a];
      const bValue = b[sortField as keyof typeof b];
      if (typeof aValue === 'string' && typeof bValue === 'string') {
        return sortDirection === 'asc' ? aValue.localeCompare(bValue) : bValue.localeCompare(aValue);
      }
    }
    return 0;
  });

  const filteredBusinessTerms = sortedBusinessTerms.filter(term => {
    return Object.entries(filters).every(([key, value]) => {
      const termValue = term[key as keyof typeof term] as string;
      return termValue.toLowerCase().includes(value.toLowerCase());
    });
  });

  const paginatedBusinessTerms = filteredBusinessTerms.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  const handleFilterChange = (field: string, value: string) => {
    setFilters(prevFilters => ({
      ...prevFilters,
      [field]: value,
    }));
    setActiveFilterColumn(field);
  };

  const handleFilterClear = (field: string) => {
    setFilters(prevFilters => {
      const { [field]: _, ...rest } = prevFilters;
      return rest;
    });
    setActiveFilterColumn(null);
  };

  return (
    <div className="space-y-4 p-0">
      <div className="flex-1 overflow-auto">
        <div className="space-y-4 p-0">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">
            {termStats.map((stat, idx) => (
              <Card key={idx} padding="lg">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="mb-1" style={{ color: '#5F6368' }}>{stat.label}</p>
                    <h3 className="font-bold" style={{ color: '#202124' }}>{stat.value}</h3>
                  </div>
                  <IconBox icon={BookText} color={stat.color} size="md" />
                </div>
              </Card>
            ))}
          </div>

          <Card padding="lg">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
              <div className="flex items-center gap-3">
                <IconBox icon={BookText} color="indigo" size="md" />
                <h3 className="font-bold" style={{ color: '#202124' }}>업무용어 목록</h3>
              </div>
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-3 rounded-xl px-4 py-2 border" style={{ backgroundColor: '#F9F9F9', borderColor: '#DADCE0' }}>
                  <Search className="w-4 h-4 text-gray-400" />
                  <input 
                    type="text" 
                    placeholder="업무용어 검색..."
                    className="bg-transparent border-none outline-none placeholder-gray-400 w-48"
                    style={{ color: '#202124' }}
                  />
                </div>
                <Button variant="secondary" icon={<Upload className="w-4 h-4" />} size="sm" onClick={handleImport}>가져오기</Button>
                <Button variant="secondary" icon={<Download className="w-4 h-4" />} size="sm" onClick={handleExport}>내보내기</Button>
                <Button 
                  variant="primary" 
                  icon={<Plus className="w-4 h-4" />} 
                  size="sm" 
                  onClick={handleAddClick}
                >
                  신규 용어 등록
                </Button>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full">
                <thead style={{ backgroundColor: '#F7F8FA' }}>
                  <tr style={{ borderBottom: '1px solid #DADCE0' }}>
                    <th 
                      className="px-4 py-3 text-left text-sm cursor-pointer hover:bg-gray-100 transition-colors" 
                      style={{ color: '#5F6368' }}
                      onClick={() => handleSort('term')}
                    >
                      <div className="flex items-center">
                        업무용어
                        <SortIcon field="term" />
                      </div>
                    </th>
                    <th 
                      className="px-4 py-3 text-left text-sm cursor-pointer hover:bg-gray-100 transition-colors" 
                      style={{ color: '#5F6368' }}
                      onClick={() => handleSort('englishName')}
                    >
                      <div className="flex items-center">
                        영문명
                        <SortIcon field="englishName" />
                      </div>
                    </th>
                    <th 
                      className="px-4 py-3 text-left text-sm cursor-pointer hover:bg-gray-100 transition-colors" 
                      style={{ color: '#5F6368' }}
                      onClick={() => handleSort('domain')}
                    >
                      <div className="flex items-center">
                        업무 도메인
                        <SortIcon field="domain" />
                      </div>
                    </th>
                    <th 
                      className="px-4 py-3 text-left text-sm cursor-pointer hover:bg-gray-100 transition-colors" 
                      style={{ color: '#5F6368' }}
                      onClick={() => handleSort('definition')}
                    >
                      <div className="flex items-center">
                        정의
                        <SortIcon field="definition" />
                      </div>
                    </th>
                    <th 
                      className="px-4 py-3 text-left text-sm cursor-pointer hover:bg-gray-100 transition-colors" 
                      style={{ color: '#5F6368' }}
                      onClick={() => handleSort('status')}
                    >
                      <div className="flex items-center">
                        상태
                        <SortIcon field="status" />
                      </div>
                    </th>
                    <th 
                      className="px-4 py-3 text-left text-sm cursor-pointer hover:bg-gray-100 transition-colors" 
                      style={{ color: '#5F6368' }}
                      onClick={() => handleSort('updatedDate')}
                    >
                      <div className="flex items-center">
                        등록일
                        <SortIcon field="updatedDate" />
                      </div>
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {paginatedBusinessTerms.map((term, idx) => (
                    <tr 
                      key={idx} 
                      className="border-b transition-colors cursor-pointer"
                      style={{ borderColor: '#DADCE0', backgroundColor: 'transparent' }}
                      onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#F9F9F9'}
                      onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
                      onClick={() => {
                        setSelectedTerm(term);
                        setModalMode('edit');
                        setIsModalOpen(true);
                      }}
                    >
                      <td className="px-4 py-3 font-bold" style={{ color: '#202124' }}>{term.term}</td>
                      <td className="px-4 py-3" style={{ color: '#5F6368' }}>{term.englishName}</td>
                      <td className="px-4 py-3">
                        <Badge variant="default">{term.domain}</Badge>
                      </td>
                      <td className="px-4 py-3 max-w-xs truncate" style={{ color: '#5F6368' }}>{term.definition}</td>
                      <td className="px-4 py-3">
                        <Badge variant={
                          term.status === '승인완료' ? 'success' : 
                          term.status === '검토중' ? 'warning' : 'default'
                        }>
                          {term.status}
                        </Badge>
                      </td>
                      <td className="px-4 py-3" style={{ color: '#5F6368' }}>{term.updatedDate}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <Pagination
              currentPage={currentPage}
              totalPages={Math.ceil(filteredBusinessTerms.length / itemsPerPage)}
              totalItems={filteredBusinessTerms.length}
              itemsPerPage={itemsPerPage}
              onPageChange={setCurrentPage}
              onItemsPerPageChange={setItemsPerPage}
            />
          </Card>
        </div>
      </div>

      <BusinessTermFormModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        mode={modalMode}
        initialData={selectedTerm}
      />
    </div>
  );
}