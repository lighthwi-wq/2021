import { Card } from '../components/common/Card';
import { Button } from '../components/common/Button';
import { Badge } from '../components/common/Badge';
import { AlertCircle, Search, Download } from 'lucide-react';
import { colors } from '../constants/designSystem';

const errors = [
  { id: 1, table: 'TB_CUSTOMER', column: 'EMAIL', rule: '이메일 형식', errorCount: 23, severity: 'high', date: '2024-01-27' },
  { id: 2, table: 'TB_ORDER', column: 'ORDER_AMT', rule: '금액 범위', errorCount: 5, severity: 'medium', date: '2024-01-27' },
  { id: 3, table: 'TB_PRODUCT', column: 'PRICE', rule: 'NOT NULL', errorCount: 12, severity: 'high', date: '2024-01-26' },
  { id: 4, table: 'TB_CUSTOMER', column: 'PHONE', rule: '전화번호 형식', errorCount: 8, severity: 'low', date: '2024-01-26' },
];

export function ErrorDataPage() {
  return (
    <div className="space-y-6 animate-fade-in-up">
      {/* Stats */}
      <div className="grid grid-cols-4 gap-4">
        <Card>
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-xl" style={{ backgroundColor: colors.errorLight }}>
              <AlertCircle className="w-6 h-6" style={{ color: colors.error }} />
            </div>
            <div>
              <p className="text-sm" style={{ color: colors.textSecondary }}>전체 오류</p>
              <p className="text-2xl font-bold" style={{ color: colors.textPrimary }}>156</p>
            </div>
          </div>
        </Card>
        <Card>
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-xl" style={{ backgroundColor: colors.errorLight }}>
              <AlertCircle className="w-6 h-6" style={{ color: colors.error }} />
            </div>
            <div>
              <p className="text-sm" style={{ color: colors.textSecondary }}>높음</p>
              <p className="text-2xl font-bold" style={{ color: colors.textPrimary }}>35</p>
            </div>
          </div>
        </Card>
        <Card>
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-xl" style={{ backgroundColor: colors.warningLight }}>
              <AlertCircle className="w-6 h-6" style={{ color: colors.warning }} />
            </div>
            <div>
              <p className="text-sm" style={{ color: colors.textSecondary }}>중간</p>
              <p className="text-2xl font-bold" style={{ color: colors.textPrimary }}>67</p>
            </div>
          </div>
        </Card>
        <Card>
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-xl" style={{ backgroundColor: colors.infoLight }}>
              <AlertCircle className="w-6 h-6" style={{ color: colors.info }} />
            </div>
            <div>
              <p className="text-sm" style={{ color: colors.textSecondary }}>낮음</p>
              <p className="text-2xl font-bold" style={{ color: colors.textPrimary }}>54</p>
            </div>
          </div>
        </Card>
      </div>

      {/* Actions */}
      <Card>
        <div className="flex items-center justify-between">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: colors.textTertiary }} />
            <input
              type="text"
              placeholder="테이블, 컬럼명으로 검색..."
              className="w-full pl-10 pr-4 py-2 rounded-lg border"
              style={{
                borderColor: colors.border,
                backgroundColor: colors.background,
              }}
            />
          </div>
          <Button variant="secondary" icon={<Download className="w-4 h-4" />}>
            Export
          </Button>
        </div>
      </Card>

      {/* Error List */}
      <Card>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b" style={{ borderColor: colors.divider }}>
                <th className="text-left py-3 px-4" style={{ color: colors.textSecondary }}>테이블명</th>
                <th className="text-left py-3 px-4" style={{ color: colors.textSecondary }}>컬럼명</th>
                <th className="text-left py-3 px-4" style={{ color: colors.textSecondary }}>위반 규칙</th>
                <th className="text-center py-3 px-4" style={{ color: colors.textSecondary }}>오류 건수</th>
                <th className="text-center py-3 px-4" style={{ color: colors.textSecondary }}>심각도</th>
                <th className="text-left py-3 px-4" style={{ color: colors.textSecondary }}>발견 일자</th>
                <th className="text-center py-3 px-4" style={{ color: colors.textSecondary }}>액션</th>
              </tr>
            </thead>
            <tbody>
              {errors.map((error) => (
                <tr 
                  key={error.id} 
                  className="border-b hover:bg-black/[0.02] transition-colors"
                  style={{ borderColor: colors.divider }}
                >
                  <td className="py-3 px-4 font-mono font-medium" style={{ color: colors.textPrimary }}>
                    {error.table}
                  </td>
                  <td className="py-3 px-4 font-mono" style={{ color: colors.textSecondary }}>
                    {error.column}
                  </td>
                  <td className="py-3 px-4" style={{ color: colors.textPrimary }}>
                    {error.rule}
                  </td>
                  <td className="py-3 px-4 text-center">
                    <Badge variant="error">{error.errorCount}</Badge>
                  </td>
                  <td className="py-3 px-4 text-center">
                    <Badge 
                      variant={
                        error.severity === 'high' ? 'error' : 
                        error.severity === 'medium' ? 'warning' : 
                        'info'
                      }
                    >
                      {error.severity === 'high' ? '높음' : error.severity === 'medium' ? '중간' : '낮음'}
                    </Badge>
                  </td>
                  <td className="py-3 px-4" style={{ color: colors.textSecondary }}>
                    {error.date}
                  </td>
                  <td className="py-3 px-4 text-center">
                    <Button variant="ghost" size="sm">
                      상세 보기
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
