import { useState } from 'react';
import { Sparkles, List, Eye, BarChart3 } from 'lucide-react';
import { Card } from '../components/common/Card';
import { Button } from '../components/common/Button';
import { TermCombinationBuilder } from '../components/term/TermCombinationBuilder';
import { TermDetailView } from '../components/term/TermDetailView';
import { DQMDashboard } from '../components/dqm/DQMDashboard';
import { colors } from '../constants/designSystem';

type DemoMode = 'list' | 'create' | 'detail' | 'dqm';

export function DemoShowcasePage() {
  const [demoMode, setDemoMode] = useState<DemoMode>('list');

  const sampleTerm = {
    name: 'Customer_Account_Number',
    englishAbbrev: 'CUST_ACCT_NO',
    domain: 'Customer',
    owner: 'John Doe',
    status: 'Approved',
  };

  return (
    <div className="h-full flex flex-col">
      {/* Demo Mode Selector */}
      <div className="mb-6 p-4 rounded-xl border" style={{ backgroundColor: 'white', borderColor: colors.border }}>
        <div className="mb-4" style={{ color: colors.textPrimary, fontWeight: 600 }}>
          🎨 Interactive Demo - Select a feature to explore:
        </div>
        <div className="flex gap-3">
          <Button
            variant={demoMode === 'list' ? 'primary' : 'secondary'}
            icon={<List className="w-4 h-4" />}
            onClick={() => setDemoMode('list')}
          >
            Standard List View
          </Button>
          <Button
            variant={demoMode === 'create' ? 'primary' : 'secondary'}
            icon={<Sparkles className="w-4 h-4" />}
            onClick={() => setDemoMode('create')}
          >
            ✨ Term Builder (Create)
          </Button>
          <Button
            variant={demoMode === 'detail' ? 'primary' : 'secondary'}
            icon={<Eye className="w-4 h-4" />}
            onClick={() => setDemoMode('detail')}
          >
            Detail View (Read)
          </Button>
          <Button
            variant={demoMode === 'dqm' ? 'primary' : 'secondary'}
            icon={<BarChart3 className="w-4 h-4" />}
            onClick={() => setDemoMode('dqm')}
          >
            📊 DQM Dashboard
          </Button>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-auto">
        {demoMode === 'list' && (
          <div className="animate-fade-in">
            <Card>
              <div className="mb-6">
                <h2 className="text-xl mb-2" style={{ color: colors.textPrimary, fontWeight: 600 }}>
                  Standard Terms Management
                </h2>
                <p style={{ color: colors.textSecondary }}>
                  Click "Term Builder" or "Detail View" buttons above to see innovative UX features!
                </p>
              </div>

              <div className="space-y-3">
                {[
                  { name: 'Customer_Account_Number', abbrev: 'CUST_ACCT_NO', domain: 'Customer' },
                  { name: 'Product_Category_Code', abbrev: 'PROD_CAT_CD', domain: 'Product' },
                  { name: 'Transaction_Date', abbrev: 'TXN_DT', domain: 'Transaction' },
                ].map((term, index) => (
                  <div
                    key={index}
                    className="p-4 rounded-lg border hover:shadow-md transition-all cursor-pointer"
                    style={{
                      backgroundColor: 'white',
                      borderColor: colors.border,
                    }}
                    onClick={() => setDemoMode('detail')}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-1">
                          <span style={{ color: colors.textPrimary, fontWeight: 600 }}>
                            {term.name}
                          </span>
                          <span
                            className="px-2 py-0.5 rounded-full text-xs"
                            style={{
                              backgroundColor: colors.successLight,
                              color: colors.success,
                            }}
                          >
                            Approved
                          </span>
                        </div>
                        <div className="text-sm" style={{ color: colors.textSecondary }}>
                          {term.abbrev} · {term.domain}
                        </div>
                      </div>
                      <Button
                        variant="secondary"
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          setDemoMode('detail');
                        }}
                      >
                        View Details
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </div>
        )}

        {demoMode === 'create' && (
          <div className="animate-slide-in">
            <Card className="p-8">
              <div className="flex items-center gap-3 mb-6 pb-6 border-b" style={{ borderColor: colors.divider }}>
                <div
                  className="p-3 rounded-xl"
                  style={{ backgroundColor: colors.primaryLight }}
                >
                  <Sparkles className="w-6 h-6" style={{ color: colors.primary }} />
                </div>
                <div>
                  <h2 className="text-xl" style={{ color: colors.textPrimary, fontWeight: 600 }}>
                    ✨ Register New Standard Term
                  </h2>
                  <p style={{ color: colors.textSecondary }}>
                    Build terms by combining standard word blocks - No manual typing needed!
                  </p>
                </div>
              </div>

              <TermCombinationBuilder />

              <div className="flex gap-3 mt-8 pt-6 border-t" style={{ borderColor: colors.divider }}>
                <Button variant="primary" fullWidth>
                  Register Term
                </Button>
                <Button variant="secondary" onClick={() => setDemoMode('list')}>
                  Cancel
                </Button>
              </div>
            </Card>
          </div>
        )}

        {demoMode === 'detail' && (
          <div className="animate-fade-in">
            <Card>
              <div className="mb-4">
                <h2 className="text-xl mb-2" style={{ color: colors.textPrimary, fontWeight: 600 }}>
                  Detail View Demo
                </h2>
                <p style={{ color: colors.textSecondary }}>
                  Click the button below to open the detailed view panel with animated tabs and visual graphs!
                </p>
              </div>

              <Button
                variant="primary"
                icon={<Eye className="w-4 h-4" />}
                onClick={() => {
                  // This will show the actual detail view
                  const event = new CustomEvent('showDetailView');
                  window.dispatchEvent(event);
                }}
              >
                Open Detail View Panel
              </Button>

              <div className="mt-6 p-6 rounded-lg" style={{ backgroundColor: colors.primaryLight }}>
                <div className="mb-3" style={{ color: colors.primary, fontWeight: 600 }}>
                  ✨ Features in Detail View:
                </div>
                <ul className="space-y-2" style={{ color: colors.textSecondary }}>
                  <li>• Smooth slide-in animation from right side</li>
                  <li>• Animated tab switching (Basic Info, Where Used, History)</li>
                  <li>• Visual relationship graph with animated connecting lines</li>
                  <li>• Real-time data visualization</li>
                </ul>
              </div>
            </Card>

            <TermDetailView
              term={sampleTerm}
              onClose={() => setDemoMode('list')}
            />
          </div>
        )}

        {demoMode === 'dqm' && (
          <div className="animate-fade-in">
            <DQMDashboard />
          </div>
        )}
      </div>
    </div>
  );
}
