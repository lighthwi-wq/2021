import { Activity, Play, Calendar, BarChart3, Clock, CheckCircle, XCircle } from 'lucide-react';
import { Card } from '../components/common/Card';
import { IconBox } from '../components/common/IconBox';
import { Button } from '../components/common/Button';
import { Badge } from '../components/common/Badge';
import { useState } from 'react';

export function QualityDiagnosisManagementPage() {
  const [isStartingDiagnosis, setIsStartingDiagnosis] = useState(false);

  const handleStartDiagnosis = () => {
    setIsStartingDiagnosis(true);
    setTimeout(() => {
      setIsStartingDiagnosis(false);
      alert('새로운 품질 진단이 시작되었습니다.\\n진단 작업 목록에서 진행 상황을 확인할 수 있습니다.');
    }, 1500);
  };

  const diagnosisJobs = [
    {
      id: 'DJ-001',
      name: '일일 품질 진단',
      description: '전체 테이블 품질 규칙 일괄 실행',
      schedule: '매일 09:00',
      rulesCount: 234,
      tablesCount: 45,
      status: '완료',
      lastRun: '2024-11-20 09:00',
      nextRun: '2024-11-21 09:00',
      duration: '23분 15초',
      passRate: 92.5,
      violations: 18
    },
    {
      id: 'DJ-002',
      name: '고객 테이블 진단',
      description: '고객 관련 테이블 품질 검증',
      schedule: '매시간',
      rulesCount: 45,
      tablesCount: 8,
      status: '실행중',
      lastRun: '2024-11-20 14:00',
      nextRun: '2024-11-20 15:00',
      duration: '5분 30초',
      passRate: 88.2,
      violations: 12
    },
    {
      id: 'DJ-003',
      name: '주문 데이터 검증',
      description: '주문/결제 테이블 품질 점검',
      schedule: '매일 12:00, 18:00',
      rulesCount: 67,
      tablesCount: 12,
      status: '대기',
      lastRun: '2024-11-20 12:00',
      nextRun: '2024-11-20 18:00',
      duration: '8분 45초',
      passRate: 95.1,
      violations: 5
    },
    {
      id: 'DJ-004',
      name: '재고 데이터 진단',
      description: '재고 관리 테이블 품질 체크',
      schedule: '매일 10:00',
      rulesCount: 34,
      tablesCount: 6,
      status: '실패',
      lastRun: '2024-11-20 10:00',
      nextRun: '2024-11-21 10:00',
      duration: '2분 18초',
      passRate: 0,
      violations: 0
    },
  ];

  const recentResults = [
    { time: '09:00', job: '일일 품질 진단', status: 'success', violations: 18, passRate: 92.5 },
    { time: '08:00', job: '고객 테이블 진단', status: 'success', violations: 12, passRate: 88.2 },
    { time: '07:00', job: '일일 품질 진단', status: 'warning', violations: 25, passRate: 87.3 },
    { time: '06:00', job: '주문 데이터 검증', status: 'success', violations: 5, passRate: 95.1 },
  ];

  const qualityTrend = [
    { date: '11/14', score: 85 },
    { date: '11/15', score: 87 },
    { date: '11/16', score: 86 },
    { date: '11/17', score: 89 },
    { date: '11/18', score: 90 },
    { date: '11/19', score: 88 },
    { date: '11/20', score: 92 },
  ];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case '완료': return CheckCircle;
      case '실행중': return Activity;
      case '대기': return Clock;
      case '실패': return XCircle;
      default: return Clock;
    }
  };

  const getStatusVariant = (status: string) => {
    switch (status) {
      case '완료': return 'success';
      case '실행중': return 'info';
      case '대기': return 'warning';
      case '실패': return 'error';
      default: return 'default';
    }
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 mb-6">
        <Card padding="lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="mb-1" style={{ color: '#5F6368' }}>진단 작업</p>
              <h3 className="font-bold" style={{ color: '#202124' }}>24</h3>
            </div>
            <IconBox icon={Activity} color="blue" size="md" />
          </div>
        </Card>
        <Card padding="lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="mb-1" style={{ color: '#5F6368' }}>오늘 완료</p>
              <h3 className="font-bold" style={{ color: '#202124' }}>18</h3>
            </div>
            <IconBox icon={CheckCircle} color="green" size="md" />
          </div>
        </Card>
        <Card padding="lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="mb-1" style={{ color: '#5F6368' }}>실행중</p>
              <h3 className="font-bold" style={{ color: '#202124' }}>3</h3>
            </div>
            <IconBox icon={Activity} color="orange" size="md" />
          </div>
        </Card>
        <Card padding="lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="mb-1" style={{ color: '#5F6368' }}>평균 통과율</p>
              <h3 className="font-bold" style={{ color: '#202124' }}>91.2%</h3>
            </div>
            <IconBox icon={BarChart3} color="indigo" size="md" />
          </div>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 space-y-4">
          <Card padding="lg">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <IconBox icon={Activity} color="blue" size="md" />
                <h3 className="font-bold" style={{ color: '#202124' }}>진단 작업 목록</h3>
              </div>
              <Button 
                variant="primary" 
                icon={<Play className="w-4 h-4" />} 
                size="sm"
                onClick={handleStartDiagnosis}
                disabled={isStartingDiagnosis}
              >
                {isStartingDiagnosis ? '진단 시작 중...' : '새 진단 시작'}
              </Button>
            </div>

            <div className="space-y-3">
              {diagnosisJobs.map((job, idx) => (
                <div 
                  key={idx} 
                  className="p-4 rounded-xl border transition-all"
                  style={{ backgroundColor: '#F9F9F9', borderColor: '#DADCE0' }}
                  onMouseEnter={(e) => e.currentTarget.style.borderColor = '#2B8DFF'}
                  onMouseLeave={(e) => e.currentTarget.style.borderColor = '#DADCE0'}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-start gap-3 flex-1">
                      <IconBox icon={getStatusIcon(job.status)} color={
                        job.status === '완료' ? 'green' :
                        job.status === '실행중' ? 'blue' :
                        job.status === '대기' ? 'orange' : 'red'
                      } size="sm" />
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h4 className="font-bold" style={{ color: '#202124' }}>{job.name}</h4>
                          <Badge variant={getStatusVariant(job.status) as any}>
                            {job.status}
                          </Badge>
                          <span className="text-sm" style={{ color: '#5F6368' }}>#{job.id}</span>
                        </div>
                        <p className="mb-3" style={{ color: '#5F6368' }}>{job.description}</p>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
                          <div>
                            <span style={{ color: '#5F6368' }}>규칙:</span>
                            <span className="ml-2 font-bold" style={{ color: '#202124' }}>{job.rulesCount}</span>
                          </div>
                          <div>
                            <span style={{ color: '#5F6368' }}>테이블:</span>
                            <span className="ml-2 font-bold" style={{ color: '#202124' }}>{job.tablesCount}</span>
                          </div>
                          <div>
                            <span style={{ color: '#5F6368' }}>통과율:</span>
                            <span 
                              className="ml-2 font-bold"
                              style={{
                                color: job.passRate >= 90 ? '#10B981' :
                                       job.passRate >= 80 ? '#2B8DFF' : '#F59E0B'
                              }}
                            >
                              {job.passRate}%
                            </span>
                          </div>
                          <div>
                            <span style={{ color: '#5F6368' }}>위반:</span>
                            <span className="ml-2 font-bold" style={{ color: '#EA4335' }}>{job.violations}</span>
                          </div>
                        </div>
                        <div className="grid grid-cols-3 gap-3 mt-3 text-sm">
                          <div>
                            <span style={{ color: '#5F6368' }}>스케줄:</span>
                            <span className="ml-2" style={{ color: '#202124' }}>{job.schedule}</span>
                          </div>
                          <div>
                            <span style={{ color: '#5F6368' }}>마지막 실행:</span>
                            <span className="ml-2" style={{ color: '#202124' }}>{job.lastRun}</span>
                          </div>
                          <div>
                            <span style={{ color: '#5F6368' }}>소요시간:</span>
                            <span className="ml-2" style={{ color: '#202124' }}>{job.duration}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    {job.status !== '실행중' && (
                      <Button variant="secondary" size="sm" icon={<Play className="w-4 h-4" />}>실행</Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>

        <div className="space-y-4">
          <Card padding="lg">
            <div className="flex items-center gap-3 mb-6">
              <IconBox icon={Clock} color="orange" size="md" />
              <h3 className="font-bold" style={{ color: '#202124' }}>최근 실행 결과</h3>
            </div>
            <div className="space-y-3">
              {recentResults.map((result, idx) => (
                <div key={idx} className="p-3 rounded-xl border" style={{ backgroundColor: '#F9F9F9', borderColor: '#DADCE0' }}>
                  <div className="flex items-center justify-between mb-2">
                    <span style={{ color: '#5F6368' }}>{result.time}</span>
                    <Badge variant={
                      result.status === 'success' ? 'success' : 'warning'
                    }>
                      {result.passRate}%
                    </Badge>
                  </div>
                  <h4 className="font-bold mb-1" style={{ color: '#202124' }}>{result.job}</h4>
                  <p style={{ color: '#5F6368' }}>위반 {result.violations}건</p>
                </div>
              ))}
            </div>
          </Card>

          <Card padding="lg">
            <div className="flex items-center gap-3 mb-6">
              <IconBox icon={BarChart3} color="indigo" size="md" />
              <h3 className="font-bold" style={{ color: '#202124' }}>품질 점수 추이</h3>
            </div>
            <div className="space-y-2">
              {qualityTrend.map((item, idx) => (
                <div key={idx} className="flex items-center gap-3">
                  <span className="text-sm w-12" style={{ color: '#5F6368' }}>{item.date}</span>
                  <div className="flex-1 h-2 rounded-full overflow-hidden" style={{ backgroundColor: '#E8EAED' }}>
                    <div 
                      className={`h-full ${
                        item.score >= 90 ? 'bg-green-500' :
                        item.score >= 85 ? 'bg-blue-500' : 'bg-orange-500'
                      }`}
                      style={{ width: `${item.score}%` }}
                    ></div>
                  </div>
                  <span className="font-bold text-sm w-8" style={{ color: '#202124' }}>{item.score}</span>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
