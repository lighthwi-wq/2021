import { useState } from 'react';
import { Card } from '../components/common/Card';
import { Button } from '../components/common/Button';
import { Badge } from '../components/common/Badge';
import { Play, Database, BarChart3, Plus } from 'lucide-react';
import { colors } from '../constants/designSystem';

interface ProfilingJob {
  id: number;
  tableName: string;
  status: 'completed' | 'running' | 'pending';
  recordCount: number;
  columnCount: number;
  lastRun: string;
  nullRate: number;
  uniqueRate: number;
}

const mockJobs: ProfilingJob[] = [
  { id: 1, tableName: 'TB_CUSTOMER', status: 'completed', recordCount: 125000, columnCount: 15, lastRun: '2024-01-27 09:00', nullRate: 2.3, uniqueRate: 98.5 },
  { id: 2, tableName: 'TB_ORDER', status: 'completed', recordCount: 450000, columnCount: 20, lastRun: '2024-01-27 08:30', nullRate: 5.1, uniqueRate: 100 },
  { id: 3, tableName: 'TB_PRODUCT', status: 'running', recordCount: 15000, columnCount: 12, lastRun: '2024-01-27 10:15', nullRate: 0, uniqueRate: 95.2 },
  { id: 4, tableName: 'TB_PAYMENT', status: 'pending', recordCount: 0, columnCount: 10, lastRun: '-', nullRate: 0, uniqueRate: 0 },
];

export function ProfilingPage() {
  const [jobs] = useState(mockJobs);

  return (
    <div className="space-y-6 animate-fade-in-up">
      {/* Stats Cards */}
      <div className="grid grid-cols-4 gap-4">
        <Card>
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-xl" style={{ backgroundColor: colors.primaryLight }}>
              <Database className="w-6 h-6" style={{ color: colors.primary }} />
            </div>
            <div>
              <p className="text-sm" style={{ color: colors.textSecondary }}>분석 완료</p>
              <p className="text-2xl font-bold" style={{ color: colors.textPrimary }}>24</p>
            </div>
          </div>
        </Card>
        <Card>
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-xl" style={{ backgroundColor: colors.successLight }}>
              <BarChart3 className="w-6 h-6" style={{ color: colors.success }} />
            </div>
            <div>
              <p className="text-sm" style={{ color: colors.textSecondary }}>실행중</p>
              <p className="text-2xl font-bold" style={{ color: colors.textPrimary }}>3</p>
            </div>
          </div>
        </Card>
        <Card>
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-xl" style={{ backgroundColor: colors.warningLight }}>
              <Play className="w-6 h-6" style={{ color: colors.warning }} />
            </div>
            <div>
              <p className="text-sm" style={{ color: colors.textSecondary }}>대기중</p>
              <p className="text-2xl font-bold" style={{ color: colors.textPrimary }}>5</p>
            </div>
          </div>
        </Card>
        <Card>
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-xl" style={{ backgroundColor: colors.infoLight }}>
              <Database className="w-6 h-6" style={{ color: colors.info }} />
            </div>
            <div>
              <p className="text-sm" style={{ color: colors.textSecondary }}>총 레코드</p>
              <p className="text-2xl font-bold" style={{ color: colors.textPrimary }}>2.5M</p>
            </div>
          </div>
        </Card>
      </div>

      {/* Actions */}
      <Card>
        <div className="flex items-center justify-between">
          <h3 className="font-semibold" style={{ color: colors.textPrimary }}>
            프로파일링 작업 목록
          </h3>
          <Button variant="primary" icon={<Plus className="w-4 h-4" />}>
            신규 프로파일링 실행
          </Button>
        </div>
      </Card>

      {/* Job List */}
      <Card>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b" style={{ borderColor: colors.divider }}>
                <th className="text-left py-3 px-4" style={{ color: colors.textSecondary }}>테이블명</th>
                <th className="text-center py-3 px-4" style={{ color: colors.textSecondary }}>상태</th>
                <th className="text-right py-3 px-4" style={{ color: colors.textSecondary }}>레코드 수</th>
                <th className="text-center py-3 px-4" style={{ color: colors.textSecondary }}>컬럼 수</th>
                <th className="text-right py-3 px-4" style={{ color: colors.textSecondary }}>NULL 비율</th>
                <th className="text-right py-3 px-4" style={{ color: colors.textSecondary }}>고유값 비율</th>
                <th className="text-left py-3 px-4" style={{ color: colors.textSecondary }}>마지막 실행</th>
                <th className="text-center py-3 px-4" style={{ color: colors.textSecondary }}>액션</th>
              </tr>
            </thead>
            <tbody>
              {jobs.map((job) => (
                <tr 
                  key={job.id} 
                  className="border-b hover:bg-black/[0.02] transition-colors"
                  style={{ borderColor: colors.divider }}
                >
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-2">
                      <Database className="w-4 h-4" style={{ color: colors.primary }} />
                      <span className="font-mono font-medium" style={{ color: colors.textPrimary }}>
                        {job.tableName}
                      </span>
                    </div>
                  </td>
                  <td className="py-3 px-4 text-center">
                    <Badge 
                      variant={
                        job.status === 'completed' ? 'success' : 
                        job.status === 'running' ? 'warning' : 
                        'info'
                      }
                    >
                      {job.status === 'completed' ? '완료' : job.status === 'running' ? '실행중' : '대기'}
                    </Badge>
                  </td>
                  <td className="py-3 px-4 text-right font-mono" style={{ color: colors.textPrimary }}>
                    {job.recordCount.toLocaleString()}
                  </td>
                  <td className="py-3 px-4 text-center" style={{ color: colors.textSecondary }}>
                    {job.columnCount}
                  </td>
                  <td className="py-3 px-4 text-right font-mono" style={{ color: colors.textSecondary }}>
                    {job.nullRate}%
                  </td>
                  <td className="py-3 px-4 text-right font-mono" style={{ color: colors.textSecondary }}>
                    {job.uniqueRate}%
                  </td>
                  <td className="py-3 px-4 text-sm" style={{ color: colors.textSecondary }}>
                    {job.lastRun}
                  </td>
                  <td className="py-3 px-4 text-center">
                    <div className="flex gap-2 justify-center">
                      {job.status === 'completed' && (
                        <Button variant="ghost" size="sm" icon={<BarChart3 className="w-3 h-3" />}>
                          결과 보기
                        </Button>
                      )}
                      {job.status !== 'running' && (
                        <Button variant="ghost" size="sm" icon={<Play className="w-3 h-3" />}>
                          실행
                        </Button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
