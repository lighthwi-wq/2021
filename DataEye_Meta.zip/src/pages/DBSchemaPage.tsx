import { useState, useEffect } from 'react';
import { Card } from '../components/common/Card';
import { Button } from '../components/common/Button';
import { Badge } from '../components/common/Badge';
import { Plus, Search, Database, RefreshCw, Eye, AlertCircle } from 'lucide-react';
import { colors } from '../constants/designSystem';
import { AnimatePresence, motion } from 'motion/react';
import { X } from 'lucide-react';
import { useModal } from '../contexts/ModalContext';

interface Schema {
  id: number;
  dbName: string;
  schemaName: string;
  tableCount: number;
  columnCount: number;
  lastSync: string;
  status: string;
}

const mockSchemas: Schema[] = [
  { id: 1, dbName: 'PROD_DB', schemaName: 'CUSTOMER', tableCount: 8, columnCount: 156, lastSync: '2024-01-26 14:30', status: 'Synced' },
  { id: 2, dbName: 'PROD_DB', schemaName: 'ORDER', tableCount: 12, columnCount: 234, lastSync: '2024-01-26 14:30', status: 'Synced' },
  { id: 3, dbName: 'PROD_DB', schemaName: 'PRODUCT', tableCount: 5, columnCount: 89, lastSync: '2024-01-25 10:15', status: 'OutOfSync' },
  { id: 4, dbName: 'DW_DB', schemaName: 'ANALYTICS', tableCount: 15, columnCount: 456, lastSync: '2024-01-26 14:30', status: 'Synced' },
];

export function DBSchemaPage() {
  const { setIsModalOpen } = useModal();
  const [showModal, setShowModal] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'name' | 'tableCount' | 'lastSync'>('name');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');

  useEffect(() => {
    setIsModalOpen(showModal);
  }, [showModal, setIsModalOpen]);

  const handleSync = () => {
    setSyncing(true);
    setTimeout(() => setSyncing(false), 2000);
  };

  // 필터링 및 정렬
  const filteredAndSortedSchemas = mockSchemas
    .filter(schema => {
      const matchesSearch = 
        schema.dbName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        schema.schemaName.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesStatus = statusFilter === 'all' || schema.status === statusFilter;
      return matchesSearch && matchesStatus;
    })
    .sort((a, b) => {
      let compareValue = 0;
      if (sortBy === 'name') {
        compareValue = a.dbName.localeCompare(b.dbName);
      } else if (sortBy === 'tableCount') {
        compareValue = a.tableCount - b.tableCount;
      } else if (sortBy === 'lastSync') {
        compareValue = new Date(a.lastSync).getTime() - new Date(b.lastSync).getTime();
      }
      return sortOrder === 'asc' ? compareValue : -compareValue;
    });

  return (
    <div className="space-y-6 animate-fade-in-up">
      {/* Actions Bar */}
      <Card>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3 flex-1">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: colors.textTertiary }} />
              <input
                type="text"
                placeholder="DB명, 스키마명으로 검색..."
                className="w-full pl-10 pr-4 py-2 rounded-lg border"
                style={{
                  borderColor: colors.border,
                  backgroundColor: colors.background,
                }}
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            
            <select
              className="px-4 py-2 rounded-lg border"
              style={{
                borderColor: colors.border,
                backgroundColor: colors.background,
              }}
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
            >
              <option value="all">전체 상태</option>
              <option value="Synced">동기화 완료</option>
              <option value="OutOfSync">동기화 필요</option>
            </select>

            <select
              className="px-4 py-2 rounded-lg border"
              style={{
                borderColor: colors.border,
                backgroundColor: colors.background,
              }}
              value={`${sortBy}-${sortOrder}`}
              onChange={(e) => {
                const [newSortBy, newSortOrder] = e.target.value.split('-') as [typeof sortBy, typeof sortOrder];
                setSortBy(newSortBy);
                setSortOrder(newSortOrder);
              }}
            >
              <option value="name-asc">이름 ↑</option>
              <option value="name-desc">이름 ↓</option>
              <option value="tableCount-asc">테이블 수 ↑</option>
              <option value="tableCount-desc">테이블 수 ↓</option>
              <option value="lastSync-asc">동기화 시간 ↑</option>
              <option value="lastSync-desc">동기화 시간 ↓</option>
            </select>
          </div>
          <div className="flex gap-2">
            <Button 
              variant="secondary" 
              icon={syncing ? <RefreshCw className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
              onClick={handleSync}
              disabled={syncing}
            >
              {syncing ? '동기화 중...' : 'DB 동기화'}
            </Button>
            <Button variant="primary" icon={<Plus className="w-4 h-4" />} onClick={() => setShowModal(true)}>
              DB 연결 추가
            </Button>
          </div>
        </div>
      </Card>

      {/* Schema Grid */}
      <div className="grid grid-cols-2 gap-4">
        {filteredAndSortedSchemas.map((schema) => (
          <Card key={schema.id} hover>
            <div className="flex items-start gap-4">
              <div 
                className="p-3 rounded-xl flex-shrink-0"
                style={{ 
                  backgroundColor: schema.status === 'Synced' ? colors.successLight : colors.warningLight 
                }}
              >
                <Database className="w-6 h-6" style={{ 
                  color: schema.status === 'Synced' ? colors.success : colors.warning 
                }} />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <h3 className="font-bold" style={{ color: colors.textPrimary }}>
                    {schema.dbName}
                  </h3>
                  <span style={{ color: colors.textTertiary }}>/</span>
                  <span className="font-mono" style={{ color: colors.textPrimary }}>
                    {schema.schemaName}
                  </span>
                </div>
                
                <div className="grid grid-cols-2 gap-3 mb-3">
                  <div className="px-3 py-2 rounded-lg" style={{ backgroundColor: colors.backgroundSecondary }}>
                    <div className="text-xs mb-1" style={{ color: colors.textSecondary }}>테이블</div>
                    <div className="text-xl font-bold" style={{ color: colors.primary }}>{schema.tableCount}</div>
                  </div>
                  <div className="px-3 py-2 rounded-lg" style={{ backgroundColor: colors.backgroundSecondary }}>
                    <div className="text-xs mb-1" style={{ color: colors.textSecondary }}>컬럼</div>
                    <div className="text-xl font-bold" style={{ color: colors.accent }}>{schema.columnCount}</div>
                  </div>
                </div>
                
                <div className="flex items-center justify-between pt-3 border-t" style={{ borderColor: colors.divider }}>
                  <div className="flex items-center gap-2">
                    <Badge variant={schema.status === 'Synced' ? 'success' : 'warning'} showDot>
                      {schema.status === 'Synced' ? '동기화됨' : '동기화 필요'}
                    </Badge>
                    <span className="text-xs" style={{ color: colors.textTertiary }}>
                      {schema.lastSync}
                    </span>
                  </div>
                  <Button variant="ghost" size="sm" icon={<Eye className="w-3 h-3" />}>
                    상세
                  </Button>
                </div>
              </div>
            </div>
          </Card>
        ))}
      </div>

      {/* Sync Warning */}
      {mockSchemas.some(s => s.status === 'OutOfSync') && (
        <Card>
          <div className="flex items-center gap-3 p-4 rounded-lg" style={{ backgroundColor: colors.warningLight }}>
            <AlertCircle className="w-5 h-5 flex-shrink-0" style={{ color: colors.warning }} />
            <div className="flex-1">
              <p className="font-medium mb-1" style={{ color: colors.textPrimary }}>
                일부 스키마가 동기화되지 않았습니다
              </p>
              <p className="text-sm" style={{ color: colors.textSecondary }}>
                최신 DB 구조를 반영하려면 동기화를 실행하세요.
              </p>
            </div>
            <Button variant="primary" size="sm" onClick={handleSync}>
              지금 동기화
            </Button>
          </div>
        </Card>
      )}

      {/* Modal */}
      <AnimatePresence>
        {showModal && (
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 30, stiffness: 300 }}
              className="fixed top-0 right-0 bottom-0 z-50 shadow-2xl border-l overflow-hidden flex flex-col"
              style={{
                width: '400px',
                backgroundColor: colors.background,
                borderColor: colors.divider
              }}
            >
              {/* Header */}
              <div className="px-6 py-4 border-b flex items-center justify-between" style={{ borderColor: colors.divider }}>
                <div>
                  <h3 className="text-xl font-bold" style={{ color: colors.textPrimary }}>DB 연결 추가</h3>
                  <p className="text-sm mt-1" style={{ color: colors.textSecondary }}>새로운 데이터베이스 연결을 등록합니다</p>
                </div>
                <button
                  onClick={() => setShowModal(false)}
                  className="p-2 rounded-lg hover:bg-black/5 transition-colors"
                >
                  <X className="w-5 h-5" style={{ color: colors.textSecondary }} />
                </button>
              </div>

              {/* Content */}
              <div className="flex-1 overflow-y-auto p-6 space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium" style={{ color: colors.textSecondary }}>
                    DB 타입 <span style={{ color: colors.error }}>*</span>
                  </label>
                  <select
                    className="w-full px-4 py-2 rounded-lg border focus:outline-none focus:ring-2"
                    style={{
                      borderColor: colors.border,
                      backgroundColor: colors.background
                    }}
                  >
                    <option>Oracle</option>
                    <option>MySQL</option>
                    <option>PostgreSQL</option>
                    <option>MSSQL</option>
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium" style={{ color: colors.textSecondary }}>
                      호스트 <span style={{ color: colors.error }}>*</span>
                    </label>
                    <input
                      type="text"
                      placeholder="예: localhost"
                      className="w-full px-4 py-2 rounded-lg border focus:outline-none focus:ring-2"
                      style={{
                        borderColor: colors.border,
                        backgroundColor: colors.background
                      }}
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium" style={{ color: colors.textSecondary }}>
                      포트 <span style={{ color: colors.error }}>*</span>
                    </label>
                    <input
                      type="text"
                      placeholder="예: 1521"
                      className="w-full px-4 py-2 rounded-lg border focus:outline-none focus:ring-2"
                      style={{
                        borderColor: colors.border,
                        backgroundColor: colors.background
                      }}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium" style={{ color: colors.textSecondary }}>
                    데이터베이스명 <span style={{ color: colors.error }}>*</span>
                  </label>
                  <input
                    type="text"
                    placeholder="예: PROD_DB"
                    className="w-full px-4 py-2 rounded-lg border focus:outline-none focus:ring-2"
                    style={{
                      borderColor: colors.border,
                      backgroundColor: colors.background
                    }}
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium" style={{ color: colors.textSecondary }}>
                    사용자명 <span style={{ color: colors.error }}>*</span>
                  </label>
                  <input
                    type="text"
                    placeholder="예: admin"
                    className="w-full px-4 py-2 rounded-lg border focus:outline-none focus:ring-2"
                    style={{
                      borderColor: colors.border,
                      backgroundColor: colors.background
                    }}
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium" style={{ color: colors.textSecondary }}>
                    비밀번호 <span style={{ color: colors.error }}>*</span>
                  </label>
                  <input
                    type="password"
                    placeholder="••••••••"
                    className="w-full px-4 py-2 rounded-lg border focus:outline-none focus:ring-2"
                    style={{
                      borderColor: colors.border,
                      backgroundColor: colors.background
                    }}
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium" style={{ color: colors.textSecondary }}>
                    스키마명
                  </label>
                  <input
                    type="text"
                    placeholder="예: PUBLIC"
                    className="w-full px-4 py-2 rounded-lg border focus:outline-none focus:ring-2"
                    style={{
                      borderColor: colors.border,
                      backgroundColor: colors.background
                    }}
                  />
                </div>
              </div>

              {/* Footer */}
              <div className="px-6 py-4 border-t flex items-center justify-end gap-3" style={{ borderColor: colors.divider }}>
                <Button variant="ghost" onClick={() => setShowModal(false)}>
                  취소
                </Button>
                <Button variant="secondary">
                  연결 테스트
                </Button>
                <Button variant="primary" glow>
                  저장
                </Button>
              </div>
            </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}