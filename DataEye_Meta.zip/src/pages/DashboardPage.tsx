import { Database, FileCheck2, Briefcase, ShieldCheck, TrendingUp, AlertTriangle, Activity, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { Card } from '../components/common/Card';
import { Badge } from '../components/common/Badge';
import { Modal } from '../components/common/Modal';
import { LineChart, Line, AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, ResponsiveContainer, XAxis, YAxis, Tooltip, CartesianGrid, Legend, ComposedChart } from 'recharts';
import { useState, useCallback } from 'react';
import { colors } from '../constants/designSystem';
import { DndProvider } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import { DraggableSection } from '../components/dashboard/DraggableSection';
import { QualityTrendSection } from '../components/dashboard/sections/QualityTrendSection';
import { CategoryDistributionSection } from '../components/dashboard/sections/CategoryDistributionSection';
import { SystemStandardizationSection } from '../components/dashboard/sections/SystemStandardizationSection';
import { QualityDimensionsSection } from '../components/dashboard/sections/QualityDimensionsSection';
import { StandardizationProgressSection } from '../components/dashboard/sections/StandardizationProgressSection';
import { RecentActivitiesSection } from '../components/dashboard/sections/RecentActivitiesSection';

export function DashboardPage() {
  const [selectedModal, setSelectedModal] = useState<string | null>(null);
  const [selectedItem, setSelectedItem] = useState<any>(null);
  const [sortConfig, setSortConfig] = useState<{ key: string; direction: 'asc' | 'desc' } | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 5;

  // 섹션 순서 관리
  const [sectionOrder, setSectionOrder] = useState([
    'quality-trend',
    'category-distribution',
    'system-standardization',
    'quality-dimensions',
    'standardization-progress',
    'recent-activities'
  ]);

  // 섹션 이동 함수
  const moveSection = useCallback((dragIndex: number, hoverIndex: number) => {
    setSectionOrder((prevOrder) => {
      const newOrder = [...prevOrder];
      const [removed] = newOrder.splice(dragIndex, 1);
      newOrder.splice(hoverIndex, 0, removed);
      return newOrder;
    });
  }, []);

  // 메타데이터 통계
  const metaStats = [
    { 
      label: '총 테이블', 
      value: '1,247', 
      change: '+23',
      changePercent: '+30%',
      isPositive: true,
      color: '#2B8DFF', // 메인 블루
      gradientFrom: '#2B8DFF',
      gradientTo: '#3B82F6',
      bgColor: 'rgba(43, 141, 255, 0.08)',
      icon: Database,
      trendData: [10, 15, 25, 40, 60, 80, 95, 85, 65, 45, 25, 40, 70]
    },
    { 
      label: '표준용어', 
      value: '856', 
      change: '+12',
      changePercent: '+40%',
      isPositive: true,
      color: '#F59E0B', // 골드/앰버 - 표준화 성공
      gradientFrom: '#F59E0B',
      gradientTo: '#FCD34D',
      bgColor: 'rgba(245, 158, 11, 0.08)',
      icon: FileCheck2,
      trendData: [15, 20, 30, 45, 65, 85, 95, 90, 70, 50, 30, 45, 75]
    },
    { 
      label: '업무용어', 
      value: '643', 
      change: '+8',
      changePercent: '+60%',
      isPositive: true,
      color: '#84CC16', // 연두색(라임) - 비즈니스 가치
      gradientFrom: '#84CC16',
      gradientTo: '#A3E635',
      bgColor: 'rgba(132, 204, 22, 0.08)',
      icon: Briefcase,
      trendData: [12, 18, 28, 42, 58, 75, 90, 88, 68, 48, 28, 42, 68]
    },
    { 
      label: '품질점수', 
      value: '92.5', 
      change: '+2.3',
      changePercent: '+15%',
      isPositive: true,
      color: '#4B5563', // 진한 그레이
      gradientFrom: '#4B5563',
      gradientTo: '#6B7280',
      bgColor: 'rgba(75, 85, 99, 0.08)',
      icon: Database,
      trendData: [10, 15, 25, 40, 60, 80, 95, 85, 65, 45, 25, 40, 70]
    },
  ];

  // 품질 추이 데이터 (7일)
  const qualityTrendData = [
    { date: '7월', score: 45, standardization: 12 },
    { date: '8월', score: 50, standardization: 16 },
    { date: '9월', score: 68, standardization: 18 },
    { date: '10월', score: 75, standardization: 22 },
    { date: '11월', score: 90, standardization: 26 },
    { date: '12월', score: 102, standardization: 32 },
  ];

  // 데이터 카테고리 분포 (파이차트용)
  const dataCategoryDistribution = [
    { name: '고객데이터', value: 324, color: '#2B8DFF' }, // 블루
    { name: '거래데이터', value: 287, color: '#F59E0B' }, // 골드/앰버
    { name: '상품데이터', value: 256, color: '#0EA5E9' }, // 스카이
    { name: '운영데이터', value: 218, color: '#D97706' }, // 다크 앰버
    { name: '마케팅데이터', value: 195, color: '#84CC16' }, // 라임/연두색
    { name: '기타', value: 162, color: '#6B7280' }, // 그레이
  ];

  // 시스템별 현황
  const systemData = [
    { name: '고객관리', value: 85, standard: 90, max: 100 },
    { name: '주문관리', value: 96, standard: 90, max: 100 },
    { name: '재고관리', value: 78, standard: 90, max: 100 },
    { name: '배송관리', value: 93, standard: 90, max: 100 },
    { name: '정산관리', value: 82, standard: 90, max: 100 },
    { name: '메타데이터', value: 97, standard: 90, max: 100 },
    { name: '데이터카탈로그', value: 88, standard: 90, max: 100 },
    { name: '품질관리', value: 91, standard: 90, max: 100 },
  ];

  // 품질 차원 레이더 차트용
  const qualityDimensions = [
    { dimension: '완전성', score: 92, fullMark: 100, color: '#2B8DFF' },
    { dimension: '유효성', score: 88, fullMark: 100, color: '#3CC7BA' },
    { dimension: '정확성', score: 85, fullMark: 100, color: '#2B8DFF' }, // 블루
    { dimension: '유일성', score: 90, fullMark: 100, color: '#0EA5E9' }, // 스카이 블루
    { dimension: '일관성', score: 87, fullMark: 100, color: '#FFB037' },
    { dimension: '적시성', score: 93, fullMark: 100, color: '#FF8A70' },
  ];

  // 품질 카테고리별 현황
  const qualityCategories = [
    { category: '완전성', score: 92, color: '#2B8DFF' },
    { category: '유효성', score: 88, color: '#3CC7BA' },
    { category: '정확성', score: 85, color: '#2B8DFF' }, // 블루
    { category: '유일성', score: 90, color: '#FFB037' },
    { category: '일관성', score: 87, color: '#FF8A70' },
  ];

  // 표준화 진행 현황
  const standardizationProgress = [
    { label: '표준용어 적용률', current: 87, target: 90 },
    { label: '명명규칙 준수율', current: 92, target: 95 },
    { label: '데이터타입 일관성', current: 78, target: 85 },
    { label: '메타데이터 완성도', current: 95, target: 90 },
  ];

  // 주간 위반 추이
  const violationTrendData = [
    { date: '14일', count: 45 },
    { date: '15일', count: 42 },
    { date: '16일', count: 46 },
    { date: '17일', count: 38 },
    { date: '18일', count: 35 },
    { date: '19일', count: 40 },
    { date: '20일', count: 32 },
  ];

  // 최근 활동
  const recentActivities = [
    { title: '11월 표준용어 배포 완료', time: '2시간 전', type: 'success', manager: '김데이터', department: '데이터팀', datetime: '2025-11-21 14:30' },
    { title: '일일 품질 진단 실행', time: '3시간 전', type: 'info', manager: '이품질', department: 'DBA팀', datetime: '2025-11-21 13:45' },
    { title: '고객 테이블 위반 발견', time: '4시간 전', type: 'warning', manager: '박관리', department: '데이터팀', datetime: '2025-11-21 12:20' },
    { title: '이메일 형식 오류 조치 완료', time: '5시간 전', type: 'success', manager: '최표준', department: '품질관리팀', datetime: '2025-11-21 11:15' },
  ];

  // 테이블 위반 현황 - 더 많은 데이터 추가
  const allViolations = [
    { table: 'CUSTOMER', violations: 45, trend: -5, status: 'high', lastCheck: '2025-11-21 10:30', manager: '김데이터', actionStatus: '조치중', impact: 'high', deadline: '2025-11-22', totalRecords: 125000, violationRate: 0.036, firstDetected: '2025-11-10' },
    { table: 'ORDER', violations: 32, trend: -3, status: 'medium', lastCheck: '2025-11-21 09:15', manager: '이품질', actionStatus: '완료', impact: 'high', deadline: '2025-11-20', totalRecords: 98500, violationRate: 0.032, firstDetected: '2025-11-12' },
    { table: 'PRODUCT', violations: 28, trend: +2, status: 'medium', lastCheck: '2025-11-21 08:45', manager: '박관리', actionStatus: '대기', impact: 'medium', deadline: '2025-11-23', totalRecords: 45000, violationRate: 0.062, firstDetected: '2025-11-08' },
    { table: 'TRANSACTION', violations: 24, trend: -4, status: 'low', lastCheck: '2025-11-21 11:20', manager: '최표준', actionStatus: '완료', impact: 'high', deadline: '2025-11-19', totalRecords: 250000, violationRate: 0.010, firstDetected: '2025-11-15' },
    { table: 'PAYMENT', violations: 38, trend: +3, status: 'high', lastCheck: '2025-11-21 07:30', manager: '김데이터', actionStatus: '조치중', impact: 'high', deadline: '2025-11-22', totalRecords: 87000, violationRate: 0.044, firstDetected: '2025-11-09' },
    { table: 'SHIPPING', violations: 19, trend: -2, status: 'low', lastCheck: '2025-11-21 10:00', manager: '이품질', actionStatus: '완료', impact: 'low', deadline: '2025-11-25', totalRecords: 67000, violationRate: 0.028, firstDetected: '2025-11-14' },
    { table: 'INVENTORY', violations: 41, trend: +5, status: 'high', lastCheck: '2025-11-21 09:30', manager: '박관리', actionStatus: '대기', impact: 'medium', deadline: '2025-11-24', totalRecords: 52000, violationRate: 0.079, firstDetected: '2025-11-07' },
    { table: 'USER', violations: 15, trend: -1, status: 'low', lastCheck: '2025-11-21 08:15', manager: '최표준', actionStatus: '완료', impact: 'medium', deadline: '2025-11-20', totalRecords: 180000, violationRate: 0.008, firstDetected: '2025-11-16' },
    { table: 'REVIEW', violations: 27, trend: +1, status: 'medium', lastCheck: '2025-11-21 11:00', manager: '김데이터', actionStatus: '조치중', impact: 'low', deadline: '2025-11-26', totalRecords: 75000, violationRate: 0.036, firstDetected: '2025-11-11' },
    { table: 'CATEGORY', violations: 12, trend: -3, status: 'low', lastCheck: '2025-11-21 07:45', manager: '이품질', actionStatus: '완료', impact: 'low', deadline: '2025-11-27', totalRecords: 8500, violationRate: 0.141, firstDetected: '2025-11-13' },
    { table: 'COUPON', violations: 33, trend: +4, status: 'medium', lastCheck: '2025-11-21 10:15', manager: '박관리', actionStatus: '대기', impact: 'medium', deadline: '2025-11-23', totalRecords: 42000, violationRate: 0.079, firstDetected: '2025-11-10' },
    { table: 'REFUND', violations: 22, trend: -2, status: 'medium', lastCheck: '2025-11-21 09:00', manager: '최표준', actionStatus: '완료', impact: 'high', deadline: '2025-11-21', totalRecords: 31000, violationRate: 0.071, firstDetected: '2025-11-12' },
    { table: 'CART', violations: 18, trend: +1, status: 'low', lastCheck: '2025-11-21 08:30', manager: '김데이터', actionStatus: '조치중', impact: 'low', deadline: '2025-11-28', totalRecords: 95000, violationRate: 0.019, firstDetected: '2025-11-15' },
  ];

  // 정렬 함수
  const handleSort = (key: string) => {
    let direction: 'asc' | 'desc' = 'asc';
    if (sortConfig && sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };

  // 정렬된 데이터
  const sortedViolations = [...allViolations].sort((a, b) => {
    if (!sortConfig) return 0;
    
    const { key, direction } = sortConfig;
    const aValue = a[key as keyof typeof a];
    const bValue = b[key as keyof typeof b];
    
    if (typeof aValue === 'number' && typeof bValue === 'number') {
      return direction === 'asc' ? aValue - bValue : bValue - aValue;
    }
    
    if (typeof aValue === 'string' && typeof bValue === 'string') {
      return direction === 'asc' 
        ? aValue.localeCompare(bValue) 
        : bValue.localeCompare(aValue);
    }
    
    return 0;
  });

  // 페이징된 데이터
  const totalPages = Math.ceil(sortedViolations.length / itemsPerPage);
  const paginatedViolations = sortedViolations.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="px-4 py-3 rounded-lg shadow-lg border" style={{ backgroundColor: '#FFFFFF', borderColor: '#DADCE0' }}>
          <p className="font-bold mb-2" style={{ color: '#202124' }}>{label}</p>
          {payload.map((entry: any, index: number) => (
            <p key={index} className="text-sm" style={{ color: entry.color }}>
              {entry.name}: <span className="font-bold">{entry.value}</span>
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  const renderCustomPieLabel = ({ name, percent }: any) => {
    return `${name} ${(percent * 100).toFixed(0)}%`;
  };

  return (
    <div className="space-y-6">
      {/* 상단 통계 카드 - 스파크라인 추가 */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {metaStats.map((stat, idx) => (
          <Card 
            key={idx} 
            padding="md" 
            className="hover:shadow-xl hover:-translate-y-1 transition-all duration-300 cursor-pointer relative overflow-hidden"
            onClick={() => {
              setSelectedItem(stat);
              setSelectedModal('kpi-detail');
            }}
          >
            {/* 왼쪽 컬러 보더 - Kaggle 스타일 */}
            <div 
              className="absolute left-0 top-0 bottom-0 w-1"
              style={{ backgroundColor: stat.color }}
            />
            
            <div className="flex items-start justify-between mb-2">
              <div 
                className="p-2.5 rounded-xl"
                style={{ backgroundColor: stat.bgColor }}
              >
                <stat.icon className="w-5 h-5" style={{ color: stat.color }} />
              </div>
              <div className="flex flex-col items-end gap-1">
                <div className="flex items-center gap-1.5">
                  {stat.isPositive ? (
                    <ArrowUpRight className="w-3.5 h-3.5 text-teal-500" />
                  ) : (
                    <ArrowDownRight className="w-3.5 h-3.5 text-gray-500" />
                  )}
                  <span className={`text-xs font-bold ${stat.isPositive ? 'text-teal-500' : 'text-gray-500'}`}>
                    {stat.changePercent}
                  </span>
                </div>
                <p 
                  className="font-bold text-right" 
                  style={{ 
                    fontSize: '15px',
                    color: '#5F6368'
                  }}
                >
                  {stat.label}
                </p>
              </div>
            </div>
            <h3 
              className="font-bold mb-2" 
              style={{ 
                fontSize: '24px',
                color: '#202124'
              }}
            >
              {stat.value}
            </h3>
            {/* 미니 스파크라인 */}
            {idx === 0 && (
              // 총 테이블 - 그라데이션 Area + 동적 Line
              <ResponsiveContainer width="100%" height={70}>
                <AreaChart data={stat.trendData.map((val, i) => ({ value: val, peak: Math.max(...stat.trendData.slice(0, i + 1)) }))}>
                  <defs>
                    <linearGradient id={`areaGradient-${idx}`} x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor={stat.color} stopOpacity={0.4}/>
                      <stop offset="50%" stopColor={stat.color} stopOpacity={0.2}/>
                      <stop offset="100%" stopColor={stat.color} stopOpacity={0.05}/>
                    </linearGradient>
                    <filter id={`glow-${idx}`}>
                      <feGaussianBlur stdDeviation="2" result="coloredBlur"/>
                      <feMerge>
                        <feMergeNode in="coloredBlur"/>
                        <feMergeNode in="SourceGraphic"/>
                      </feMerge>
                    </filter>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" opacity={0.5} vertical={false} />
                  <YAxis 
                    stroke="#9CA3AF" 
                    style={{ fontSize: '9px' }}
                    tickLine={false}
                    axisLine={false}
                    width={28}
                    domain={[0, 'dataMax + 10']}
                  />
                  <Tooltip 
                    content={({ active, payload }: any) => {
                      if (active && payload && payload.length) {
                        return (
                          <div 
                            className="px-3 py-2 rounded-lg shadow-xl border"
                            style={{
                              backgroundColor: '#FFFFFF',
                              borderColor: stat.color,
                              borderWidth: '2px'
                            }}
                          >
                            <p className="text-xs font-bold" style={{ color: stat.color }}>
                              {payload[0].value}
                            </p>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Area 
                    type="monotone"
                    dataKey="value" 
                    stroke={stat.color}
                    strokeWidth={1}
                    fill={`url(#areaGradient-${idx})`}
                    dot={false}
                    activeDot={{ 
                      r: 6, 
                      fill: stat.color,
                      stroke: '#FFFFFF',
                      strokeWidth: 2,
                      filter: `url(#glow-${idx})`
                    }}
                    animationDuration={1500}
                    animationEasing="ease-in-out"
                  />
                </AreaChart>
              </ResponsiveContainer>
            )}
            {idx === 1 && (
              // 표준용어 - 그라데이션 바 + 트렌드 라인
              <ResponsiveContainer width="100%" height={70}>
                <ComposedChart data={stat.trendData.map((val, i) => ({ value: val, trend: val * 1.1 }))}>
                  <defs>
                    <linearGradient id={`barGradient-${idx}`} x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor={stat.color} stopOpacity={0.9}/>
                      <stop offset="100%" stopColor={stat.color} stopOpacity={0.3}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" opacity={0.4} vertical={false} />
                  <YAxis 
                    stroke="#9CA3AF" 
                    style={{ fontSize: '9px' }}
                    tickLine={false}
                    axisLine={false}
                    width={28}
                  />
                  <Tooltip 
                    content={({ active, payload }: any) => {
                      if (active && payload && payload.length) {
                        return (
                          <div 
                            className="px-3 py-2 rounded-lg shadow-xl border"
                            style={{
                              backgroundColor: '#FFFFFF',
                              borderColor: stat.color,
                              borderWidth: '2px'
                            }}
                          >
                            <p className="text-xs font-bold" style={{ color: stat.color }}>
                              {payload[0].value}
                            </p>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Bar 
                    dataKey="value" 
                    fill={`url(#barGradient-${idx})`}
                    radius={[6, 6, 0, 0]}
                    barSize={12}
                    animationDuration={1200}
                  />
                  <Line 
                    type="natural"
                    dataKey="trend" 
                    stroke={stat.color}
                    strokeWidth={1}
                    strokeDasharray="5 5"
                    dot={false}
                    activeDot={{ r: 5, fill: stat.color, strokeWidth: 2, stroke: '#FFFFFF' }}
                    animationDuration={1500}
                  />
                </ComposedChart>
              </ResponsiveContainer>
            )}
            {idx === 2 && (
              // 업무용어 - 부드러운 곡선 Area + 글로우
              <ResponsiveContainer width="100%" height={70}>
                <AreaChart data={stat.trendData.map((val, i) => ({ value: val }))}>
                  <defs>
                    <linearGradient id={`smoothGradient-${idx}`} x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor={stat.color} stopOpacity={0.6}/>
                      <stop offset="40%" stopColor={stat.color} stopOpacity={0.3}/>
                      <stop offset="100%" stopColor={stat.color} stopOpacity={0}/>
                    </linearGradient>
                    <filter id={`shadow-${idx}`}>
                      <feDropShadow dx="0" dy="2" stdDeviation="3" floodColor={stat.color} floodOpacity="0.4"/>
                    </filter>
                  </defs>
                  <CartesianGrid strokeDasharray="2 4" stroke="#E5E7EB" opacity={0.3} vertical={false} />
                  <YAxis 
                    stroke="#9CA3AF" 
                    style={{ fontSize: '9px' }}
                    tickLine={false}
                    axisLine={false}
                    width={28}
                  />
                  <Tooltip 
                    content={({ active, payload }: any) => {
                      if (active && payload && payload.length) {
                        return (
                          <div 
                            className="px-3 py-2 rounded-lg shadow-xl border"
                            style={{
                              backgroundColor: '#FFFFFF',
                              borderColor: stat.color,
                              borderWidth: '2px'
                            }}
                          >
                            <p className="text-xs font-bold" style={{ color: stat.color }}>
                              {payload[0].value}
                            </p>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Area 
                    type="natural"
                    dataKey="value" 
                    stroke={stat.color}
                    strokeWidth={1}
                    fill={`url(#smoothGradient-${idx})`}
                    dot={{ fill: stat.color, r: 4, strokeWidth: 2, stroke: '#FFFFFF' }}
                    activeDot={{ 
                      r: 7, 
                      fill: stat.color,
                      stroke: '#FFFFFF',
                      strokeWidth: 3,
                      filter: `url(#shadow-${idx})`
                    }}
                    animationDuration={1800}
                    animationEasing="ease-out"
                  />
                </AreaChart>
              </ResponsiveContainer>
            )}
            {idx === 3 && (
              // 품질점수 - 멀티 레이어 Area + 목표선
              <ResponsiveContainer width="100%" height={70}>
                <AreaChart data={stat.trendData.map((val, i) => ({ value: val, target: 85 }))}>
                  <defs>
                    <linearGradient id={`multiGradient-${idx}`} x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor={stat.color} stopOpacity={0.5}/>
                      <stop offset="50%" stopColor={stat.color} stopOpacity={0.25}/>
                      <stop offset="100%" stopColor={stat.color} stopOpacity={0.05}/>
                    </linearGradient>
                    <linearGradient id={`targetGradient-${idx}`} x1="0" y1="0" x2="1" y2="0">
                      <stop offset="0%" stopColor="#10B981" stopOpacity={0.2}/>
                      <stop offset="50%" stopColor="#10B981" stopOpacity={0.5}/>
                      <stop offset="100%" stopColor="#10B981" stopOpacity={0.2}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" opacity={0.5} vertical={false} />
                  <YAxis 
                    stroke="#9CA3AF" 
                    style={{ fontSize: '9px' }}
                    tickLine={false}
                    axisLine={false}
                    width={28}
                  />
                  <Tooltip 
                    content={({ active, payload }: any) => {
                      if (active && payload && payload.length) {
                        return (
                          <div 
                            className="px-3 py-2 rounded-lg shadow-xl border"
                            style={{
                              backgroundColor: '#FFFFFF',
                              borderColor: stat.color,
                              borderWidth: '2px'
                            }}
                          >
                            <p className="text-xs font-bold mb-1" style={{ color: stat.color }}>
                              현재: {payload[0].value}
                            </p>
                            <p className="text-xs" style={{ color: '#10B981' }}>
                              목표: {payload[1]?.value || 85}
                            </p>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Area 
                    type="monotone"
                    dataKey="value" 
                    stroke={stat.color}
                    strokeWidth={1}
                    fill={`url(#multiGradient-${idx})`}
                    dot={false}
                    activeDot={{ 
                      r: 6, 
                      fill: stat.color,
                      stroke: '#FFFFFF',
                      strokeWidth: 2
                    }}
                    animationDuration={1500}
                  />
                  <Line 
                    type="monotone"
                    dataKey="target" 
                    stroke="#10B981"
                    strokeWidth={1}
                    strokeDasharray="8 4"
                    dot={false}
                    animationDuration={1000}
                  />
                </AreaChart>
              </ResponsiveContainer>
            )}
          </Card>
        ))}
      </div>

      {/* 드래그 가능한 섹션들 */}
      <DndProvider backend={HTML5Backend}>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {sectionOrder.map((sectionId, index) => {
            const isEven = index % 2 === 0;
            const isLast = index === sectionOrder.length - 1;
            const gridClass = (isLast && index % 2 === 0) ? "lg:col-span-2" : "";
            
            let sectionContent = null;
            
            switch (sectionId) {
              case 'quality-trend':
                sectionContent = <QualityTrendSection data={qualityTrendData} CustomTooltip={CustomTooltip} />;
                break;
              case 'category-distribution':
                sectionContent = <CategoryDistributionSection data={dataCategoryDistribution} />;
                break;
              case 'system-standardization':
                sectionContent = <SystemStandardizationSection data={systemData} CustomTooltip={CustomTooltip} />;
                break;
              case 'quality-dimensions':
                sectionContent = <QualityDimensionsSection data={qualityDimensions} />;
                break;
              case 'standardization-progress':
                sectionContent = <StandardizationProgressSection data={standardizationProgress} />;
                break;
              case 'recent-activities':
                sectionContent = <RecentActivitiesSection data={recentActivities} />;
                break;
            }
            
            return (
              <div key={sectionId} className={gridClass}>
                <DraggableSection
                  id={sectionId}
                  index={index}
                  moveSection={moveSection}
                >
                  {sectionContent}
                </DraggableSection>
              </div>
            );
          })}
        </div>
      </DndProvider>

      {/* 테이블 위반 현황 */}
      <Card padding="lg" className="hover:shadow-lg transition-shadow duration-300">
        <div className="mb-6">
          <h3 
            className="font-bold mb-1"
            style={{ color: '#111827' }}
          >
            테이블별 위반 현황
          </h3>
          <p 
            className="text-sm"
            style={{ color: '#6b7280' }}
          >
            위반 건수가 많은 테이블
          </p>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead style={{ backgroundColor: '#F7F8FA' }}>
              <tr style={{ borderBottom: '1px solid #DADCE0' }}>
                <th 
                  className="px-4 py-3 text-left text-sm"
                  style={{ color: '#5F6368', width: '60px' }}
                >
                  No.
                </th>
                <th 
                  className="px-4 py-3 text-left text-sm cursor-pointer hover:bg-gray-100 transition-colors"
                  style={{ color: '#5F6368' }}
                  onClick={() => handleSort('table')}
                >
                  <div className="flex items-center gap-2">
                    <span>테이블명</span>
                    {sortConfig?.key === 'table' && (
                      <span className="text-xs">{sortConfig.direction === 'asc' ? '▲' : '▼'}</span>
                    )}
                  </div>
                </th>
                <th 
                  className="px-4 py-3 text-left text-sm cursor-pointer hover:bg-gray-100 transition-colors"
                  style={{ color: '#5F6368' }}
                  onClick={() => handleSort('violations')}
                >
                  <div className="flex items-center gap-2">
                    <span>위반건수</span>
                    {sortConfig?.key === 'violations' && (
                      <span className="text-xs">{sortConfig.direction === 'asc' ? '▲' : '▼'}</span>
                    )}
                  </div>
                </th>
                <th 
                  className="px-4 py-3 text-left text-sm cursor-pointer hover:bg-gray-100 transition-colors"
                  style={{ color: '#5F6368' }}
                  onClick={() => handleSort('status')}
                >
                  <div className="flex items-center gap-2">
                    <span>심각도</span>
                    {sortConfig?.key === 'status' && (
                      <span className="text-xs">{sortConfig.direction === 'asc' ? '▲' : '▼'}</span>
                    )}
                  </div>
                </th>
                <th 
                  className="px-4 py-3 text-left text-sm cursor-pointer hover:bg-gray-100 transition-colors"
                  style={{ color: '#5F6368' }}
                  onClick={() => handleSort('lastCheck')}
                >
                  <div className="flex items-center gap-2">
                    <span>마지막 점검일</span>
                    {sortConfig?.key === 'lastCheck' && (
                      <span className="text-xs">{sortConfig.direction === 'asc' ? '▲' : '▼'}</span>
                    )}
                  </div>
                </th>
                <th 
                  className="px-4 py-3 text-left text-sm cursor-pointer hover:bg-gray-100 transition-colors"
                  style={{ color: '#5F6368' }}
                  onClick={() => handleSort('manager')}
                >
                  <div className="flex items-center gap-2">
                    <span>담당자</span>
                    {sortConfig?.key === 'manager' && (
                      <span className="text-xs">{sortConfig.direction === 'asc' ? '▲' : '▼'}</span>
                    )}
                  </div>
                </th>
                <th 
                  className="px-4 py-3 text-left text-sm cursor-pointer hover:bg-gray-100 transition-colors"
                  style={{ color: '#5F6368' }}
                  onClick={() => handleSort('actionStatus')}
                >
                  <div className="flex items-center gap-2">
                    <span>조치 상태</span>
                    {sortConfig?.key === 'actionStatus' && (
                      <span className="text-xs">{sortConfig.direction === 'asc' ? '▲' : '▼'}</span>
                    )}
                  </div>
                </th>
                <th 
                  className="px-4 py-3 text-left text-sm cursor-pointer hover:bg-gray-100 transition-colors"
                  style={{ color: '#5F6368' }}
                  onClick={() => handleSort('impact')}
                >
                  <div className="flex items-center gap-2">
                    <span>영향도</span>
                    {sortConfig?.key === 'impact' && (
                      <span className="text-xs">{sortConfig.direction === 'asc' ? '▲' : '▼'}</span>
                    )}
                  </div>
                </th>
                <th 
                  className="px-4 py-3 text-left text-sm cursor-pointer hover:bg-gray-100 transition-colors"
                  style={{ color: '#5F6368' }}
                  onClick={() => handleSort('deadline')}
                >
                  <div className="flex items-center gap-2">
                    <span>처리 기한</span>
                    {sortConfig?.key === 'deadline' && (
                      <span className="text-xs">{sortConfig.direction === 'asc' ? '▲' : '▼'}</span>
                    )}
                  </div>
                </th>
                <th 
                  className="px-4 py-3 text-left text-sm cursor-pointer hover:bg-gray-100 transition-colors"
                  style={{ color: '#5F6368' }}
                  onClick={() => handleSort('totalRecords')}
                >
                  <div className="flex items-center gap-2">
                    <span>데이터 건수</span>
                    {sortConfig?.key === 'totalRecords' && (
                      <span className="text-xs">{sortConfig.direction === 'asc' ? '▲' : '▼'}</span>
                    )}
                  </div>
                </th>
                <th 
                  className="px-4 py-3 text-left text-sm cursor-pointer hover:bg-gray-100 transition-colors"
                  style={{ color: '#5F6368' }}
                  onClick={() => handleSort('violationRate')}
                >
                  <div className="flex items-center gap-2">
                    <span>위반율(%)</span>
                    {sortConfig?.key === 'violationRate' && (
                      <span className="text-xs">{sortConfig.direction === 'asc' ? '▲' : '▼'}</span>
                    )}
                  </div>
                </th>
                <th 
                  className="px-4 py-3 text-left text-sm cursor-pointer hover:bg-gray-100 transition-colors"
                  style={{ color: '#5F6368' }}
                  onClick={() => handleSort('firstDetected')}
                >
                  <div className="flex items-center gap-2">
                    <span>최초 발견일</span>
                    {sortConfig?.key === 'firstDetected' && (
                      <span className="text-xs">{sortConfig.direction === 'asc' ? '▲' : '▼'}</span>
                    )}
                  </div>
                </th>
              </tr>
            </thead>
            <tbody>
              {paginatedViolations.map((item, idx) => (
                <tr 
                  key={idx} 
                  className="border-b transition-colors cursor-pointer"
                  style={{ borderColor: '#e5e7eb' }}
                  onClick={() => {
                    setSelectedItem(item);
                    setSelectedModal('violation-detail');
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.backgroundColor = '#f9fafb';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.backgroundColor = 'transparent';
                  }}
                >
                  <td className="px-4 py-4">
                    <span 
                      className="text-sm"
                      style={{ color: '#9CA3AF' }}
                    >
                      {(currentPage - 1) * itemsPerPage + idx + 1}
                    </span>
                  </td>
                  <td className="px-4 py-4">
                    <span 
                      className="font-bold font-mono"
                      style={{ color: '#111827' }}
                    >
                      {item.table}
                    </span>
                  </td>
                  <td className="px-4 py-4">
                    <span 
                      className="font-bold"
                      style={{ color: '#111827' }}
                    >
                      {item.violations}
                    </span>
                  </td>
                  <td className="px-4 py-4">
                    <Badge variant={
                      item.status === 'high' ? 'warning' :
                      item.status === 'medium' ? 'warning' : 'default'
                    }>
                      {item.status === 'high' ? '높음' : item.status === 'medium' ? '중간' : '낮음'}
                    </Badge>
                  </td>
                  <td className="px-4 py-4">
                    <span 
                      className="text-sm"
                      style={{ color: '#5F6368' }}
                    >
                      {item.lastCheck}
                    </span>
                  </td>
                  <td className="px-4 py-4">
                    <span 
                      className="font-bold text-sm"
                      style={{ color: '#111827' }}
                    >
                      {item.manager}
                    </span>
                  </td>
                  <td className="px-4 py-4">
                    <Badge variant={
                      item.actionStatus === '완료' ? 'success' :
                      item.actionStatus === '조치중' ? 'warning' : 'default'
                    }>
                      {item.actionStatus}
                    </Badge>
                  </td>
                  <td className="px-4 py-4">
                    <Badge variant={
                      item.impact === 'high' ? 'warning' :
                      item.impact === 'medium' ? 'default' : 'success'
                    }>
                      {item.impact === 'high' ? '높음' : item.impact === 'medium' ? '중간' : '낮음'}
                    </Badge>
                  </td>
                  <td className="px-4 py-4">
                    <span 
                      className="text-sm"
                      style={{ color: '#5F6368' }}
                    >
                      {item.deadline}
                    </span>
                  </td>
                  <td className="px-4 py-4">
                    <span 
                      className="text-sm"
                      style={{ color: '#5F6368' }}
                    >
                      {item.totalRecords.toLocaleString()}
                    </span>
                  </td>
                  <td className="px-4 py-4">
                    <span 
                      className="text-sm"
                      style={{ color: '#5F6368' }}
                    >
                      {item.violationRate.toFixed(2)}
                    </span>
                  </td>
                  <td className="px-4 py-4">
                    <span 
                      className="text-sm"
                      style={{ color: '#5F6368' }}
                    >
                      {item.firstDetected}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="flex items-center justify-center mt-6 pt-4" style={{ borderTop: '1px solid #DADCE0' }}>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setCurrentPage(1)}
              disabled={currentPage === 1}
              className="px-3 py-2 rounded-lg transition-colors text-sm font-bold"
              style={{
                backgroundColor: currentPage === 1 ? '#F1F3F4' : '#FFFFFF',
                color: currentPage === 1 ? '#9AA0A6' : '#202124',
                border: '1px solid #DADCE0',
                cursor: currentPage === 1 ? 'not-allowed' : 'pointer'
              }}
              onMouseEnter={(e) => {
                if (currentPage !== 1) {
                  e.currentTarget.style.backgroundColor = '#F1F3F4';
                }
              }}
              onMouseLeave={(e) => {
                if (currentPage !== 1) {
                  e.currentTarget.style.backgroundColor = '#FFFFFF';
                }
              }}
            >
              First
            </button>
            <button
              onClick={() => setCurrentPage(currentPage - 1)}
              disabled={currentPage === 1}
              className="px-3 py-2 rounded-lg transition-colors text-sm font-bold"
              style={{
                backgroundColor: currentPage === 1 ? '#F1F3F4' : '#FFFFFF',
                color: currentPage === 1 ? '#9AA0A6' : '#202124',
                border: '1px solid #DADCE0',
                cursor: currentPage === 1 ? 'not-allowed' : 'pointer'
              }}
              onMouseEnter={(e) => {
                if (currentPage !== 1) {
                  e.currentTarget.style.backgroundColor = '#F1F3F4';
                }
              }}
              onMouseLeave={(e) => {
                if (currentPage !== 1) {
                  e.currentTarget.style.backgroundColor = '#FFFFFF';
                }
              }}
            >
              Previous
            </button>
            
            {/* 페이지 번호 */}
            <div className="flex items-center gap-1">
              {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => {
                // 현재 페이지 주변만 표시
                if (
                  page === 1 ||
                  page === totalPages ||
                  (page >= currentPage - 1 && page <= currentPage + 1)
                ) {
                  return (
                    <button
                      key={page}
                      onClick={() => setCurrentPage(page)}
                      className="w-9 h-9 rounded-lg transition-colors text-sm font-bold"
                      style={{
                        backgroundColor: currentPage === page ? '#2B8DFF' : '#FFFFFF',
                        color: currentPage === page ? '#FFFFFF' : '#202124',
                        border: currentPage === page ? 'none' : '1px solid #DADCE0'
                      }}
                      onMouseEnter={(e) => {
                        if (currentPage !== page) {
                          e.currentTarget.style.backgroundColor = '#F1F3F4';
                        }
                      }}
                      onMouseLeave={(e) => {
                        if (currentPage !== page) {
                          e.currentTarget.style.backgroundColor = '#FFFFFF';
                        }
                      }}
                    >
                      {page}
                    </button>
                  );
                } else if (page === currentPage - 2 || page === currentPage + 2) {
                  return <span key={page} style={{ color: '#9AA0A6' }}>...</span>;
                }
                return null;
              })}
            </div>

            <button
              onClick={() => setCurrentPage(currentPage + 1)}
              disabled={currentPage === totalPages}
              className="px-3 py-2 rounded-lg transition-colors text-sm font-bold"
              style={{
                backgroundColor: currentPage === totalPages ? '#F1F3F4' : '#FFFFFF',
                color: currentPage === totalPages ? '#9AA0A6' : '#202124',
                border: '1px solid #DADCE0',
                cursor: currentPage === totalPages ? 'not-allowed' : 'pointer'
              }}
              onMouseEnter={(e) => {
                if (currentPage !== totalPages) {
                  e.currentTarget.style.backgroundColor = '#F1F3F4';
                }
              }}
              onMouseLeave={(e) => {
                if (currentPage !== totalPages) {
                  e.currentTarget.style.backgroundColor = '#FFFFFF';
                }
              }}
            >
              Next
            </button>
            <button
              onClick={() => setCurrentPage(totalPages)}
              disabled={currentPage === totalPages}
              className="px-3 py-2 rounded-lg transition-colors text-sm font-bold"
              style={{
                backgroundColor: currentPage === totalPages ? '#F1F3F4' : '#FFFFFF',
                color: currentPage === totalPages ? '#9AA0A6' : '#202124',
                border: '1px solid #DADCE0',
                cursor: currentPage === totalPages ? 'not-allowed' : 'pointer'
              }}
              onMouseEnter={(e) => {
                if (currentPage !== totalPages) {
                  e.currentTarget.style.backgroundColor = '#F1F3F4';
                }
              }}
              onMouseLeave={(e) => {
                if (currentPage !== totalPages) {
                  e.currentTarget.style.backgroundColor = '#FFFFFF';
                }
              }}
            >
              Last
            </button>
          </div>
        </div>
      </Card>

      {/* KPI 상세 모달 */}
      <Modal
        isOpen={selectedModal === 'kpi-detail'}
        onClose={() => setSelectedModal(null)}
        title={selectedItem?.label + ' 상세 정보'}
        size="lg"
      >
        {selectedItem && (
          <div className="space-y-6">
            <div className="grid grid-cols-3 gap-4">
              <div className="p-4 rounded-lg" style={{ backgroundColor: '#F9F9F9' }}>
                <p className="text-sm mb-1" style={{ color: '#5F6368' }}>현재 값</p>
                <p className="font-bold" style={{ fontSize: '24px', color: '#202124' }}>{selectedItem.value}</p>
              </div>
              <div className="p-4 rounded-lg" style={{ backgroundColor: '#F9F9F9' }}>
                <p className="text-sm mb-1" style={{ color: '#5F6368' }}>증가량</p>
                <p className="text-teal-500 font-bold" style={{ fontSize: '24px' }}>{selectedItem.change}</p>
              </div>
              <div className="p-4 rounded-lg" style={{ backgroundColor: '#F9F9F9' }}>
                <p className="text-sm mb-1" style={{ color: '#5F6368' }}>증가율</p>
                <p className="text-teal-500 font-bold" style={{ fontSize: '24px' }}>{selectedItem.changePercent}</p>
              </div>
            </div>
            
            <div>
              <h4 className="font-bold mb-4" style={{ color: '#202124' }}>7일 추이</h4>
              <ResponsiveContainer width="100%" height={200}>
                <AreaChart data={selectedItem.trendData.map((val: any, i: number) => ({ 
                  day: `${i+1}일`, 
                  value: val 
                }))}>
                  <defs>
                    <linearGradient id="modalGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor={selectedItem.color} stopOpacity={0.3}/>
                      <stop offset="95%" stopColor={selectedItem.color} stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" opacity={0.5} />
                  <XAxis 
                    dataKey="day" 
                    stroke="#6b7280"
                    style={{ fontSize: '12px', fill: '#9ca3af' }}
                  />
                  <YAxis 
                    stroke="#6b7280"
                    style={{ fontSize: '12px', fill: '#9ca3af' }}
                  />
                  <Tooltip />
                  <Area 
                    type="monotone" 
                    dataKey="value" 
                    stroke={selectedItem.color} 
                    strokeWidth={3}
                    fillOpacity={1} 
                    fill="url(#modalGradient)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>

            <div className="p-4 rounded-lg border" style={{ backgroundColor: '#E8F0FE', borderColor: '#C2DBFF' }}>
              <p className="text-sm" style={{ color: '#1967D2' }}>
                <strong>분석:</strong> {selectedItem.label}은(는) 지난 7일간 꾸준한 상승세를 보이고 있습니다. 
                전주 대비 {selectedItem.changePercent} 증가하여 목표 달성에 긍정적인 신호를 보이 있습니다.
              </p>
            </div>
          </div>
        )}
      </Modal>

      {/* 위반 상세 모달 */}
      <Modal
        isOpen={selectedModal === 'violation-detail'}
        onClose={() => setSelectedModal(null)}
        title={`${selectedItem?.table} 테이블 위반 상세`}
        size="xl"
        footer={
          <div className="flex items-center justify-end gap-3">
            <button
              onClick={() => setSelectedModal(null)}
              className="px-4 py-2 rounded-lg transition-colors"
              style={{ backgroundColor: '#F1F3F4', color: '#5F6368' }}
              onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#E8EAED'}
              onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#F1F3F4'}
            >
              닫기
            </button>
            <button
              className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
            >
              조치 계획 작성
            </button>
          </div>
        }
      >
        {selectedItem && (
          <div className="space-y-6">
            <div className="grid grid-cols-4 gap-4">
              <div className="p-4 rounded-lg" style={{ backgroundColor: '#F9F9F9' }}>
                <p className="text-sm mb-1" style={{ color: '#5F6368' }}>총 위반 건수</p>
                <p className="font-bold" style={{ fontSize: '24px', color: '#202124' }}>{selectedItem.violations}</p>
              </div>
              <div className="p-4 rounded-lg" style={{ backgroundColor: '#F9F9F9' }}>
                <p className="text-sm mb-1" style={{ color: '#5F6368' }}>추세</p>
                <p className={`font-bold ${selectedItem.trend < 0 ? 'text-green-500' : 'text-gray-500'}`} style={{ fontSize: '24px' }}>
                  {selectedItem.trend < 0 ? selectedItem.trend : `+${selectedItem.trend}`}
                </p>
              </div>
              <div className="p-4 rounded-lg" style={{ backgroundColor: '#F9F9F9' }}>
                <p className="text-sm mb-1" style={{ color: '#5F6368' }}>심각도</p>
                <Badge variant={selectedItem.status === 'high' ? 'warning' : 'default'}>
                  {selectedItem.status === 'high' ? '높' : selectedItem.status === 'medium' ? '중간' : '낮음'}
                </Badge>
              </div>
              <div className="p-4 rounded-lg" style={{ backgroundColor: '#F9F9F9' }}>
                <p className="text-sm mb-1" style={{ color: '#5F6368' }}>조치율</p>
                <p className="font-bold" style={{ fontSize: '24px', color: '#202124' }}>
                  {Math.floor((selectedItem.violations / 50) * 100)}%
                </p>
              </div>
            </div>

            <div>
              <h4 className="font-bold mb-4" style={{ color: '#202124' }}>위반 유형별 분포</h4>
              <div className="space-y-3">
                {[
                  { type: 'NULL 값 존재', count: Math.floor(selectedItem.violations * 0.4), color: '#FF8A70' },
                  { type: '데이터타입 불일치', count: Math.floor(selectedItem.violations * 0.3), color: '#FFB037' },
                  { type: '명명규칙 위반', count: Math.floor(selectedItem.violations * 0.2), color: '#2B8DFF' },
                  { type: '중복 데이터', count: Math.floor(selectedItem.violations * 0.1), color: '#94A3B8' },
                ].map((item, idx) => (
                  <div key={idx}>
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-bold text-sm" style={{ color: '#202124' }}>{item.type}</span>
                      <span className="text-sm" style={{ color: '#5F6368' }}>{item.count}건</span>
                    </div>
                    <div className="w-full h-2 rounded-full overflow-hidden" style={{ backgroundColor: '#F1F3F4' }}>
                      <div 
                        className="h-full rounded-full transition-all duration-500"
                        style={{ 
                          width: `${(item.count / selectedItem.violations) * 100}%`,
                          backgroundColor: item.color
                        }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <h4 className="font-bold mb-4" style={{ color: '#202124' }}>최근 위반 이력</h4>
              <div className="border rounded-lg overflow-hidden" style={{ borderColor: '#DADCE0' }}>
                <table className="w-full">
                  <thead style={{ backgroundColor: '#F7F8FA' }}>
                    <tr>
                      <th className="px-4 py-3 text-left text-sm" style={{ color: '#5F6368' }}>컬럼명</th>
                      <th className="px-4 py-3 text-left text-sm" style={{ color: '#5F6368' }}>위반 유형</th>
                      <th className="px-4 py-3 text-left text-sm" style={{ color: '#5F6368' }}>발견 시각</th>
                      <th className="px-4 py-3 text-left text-sm" style={{ color: '#5F6368' }}>상태</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      { column: 'EMAIL', type: 'NULL 값', time: '2시간 전', status: '조치중' },
                      { column: 'PHONE_NUMBER', type: '형식 오류', time: '3시간 전', status: '대기' },
                      { column: 'BIRTH_DATE', type: '데이터타', time: '5시간 전', status: '완' },
                      { column: 'ADDRESS', type: '길이 초과', time: '7시간 전', status: '대기' },
                    ].map((row, idx) => (
                      <tr key={idx} className="border-t" style={{ borderColor: '#DADCE0' }}>
                        <td className="px-4 py-3 font-mono text-sm" style={{ color: '#202124' }}>{row.column}</td>
                        <td className="px-4 py-3 text-sm" style={{ color: '#202124' }}>{row.type}</td>
                        <td className="px-4 py-3 text-sm" style={{ color: '#5F6368' }}>{row.time}</td>
                        <td className="px-4 py-3">
                          <Badge variant={row.status === '완료' ? 'success' : row.status === '조치' ? 'warning' : 'default'}>
                            {row.status}
                          </Badge>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}