import { Card } from '../components/common/Card';
import { Construction } from 'lucide-react';
import { colors } from '../constants/designSystem';

interface PlaceholderPageProps {
  title: string;
  description: string;
}

export function PlaceholderPage({ title, description }: PlaceholderPageProps) {
  return (
    <div className="flex items-center justify-center h-full">
      <Card className="max-w-md text-center">
        <div className="py-12 px-8">
          <div 
            className="w-20 h-20 mx-auto mb-6 rounded-full flex items-center justify-center"
            style={{ backgroundColor: colors.primaryLight }}
          >
            <Construction className="w-10 h-10" style={{ color: colors.primary }} />
          </div>
          <h2 className="text-2xl font-bold mb-3" style={{ color: colors.textPrimary }}>
            {title}
          </h2>
          <p style={{ color: colors.textSecondary }}>
            {description}
          </p>
          <div className="mt-6 pt-6 border-t" style={{ borderColor: colors.divider }}>
            <p className="text-sm" style={{ color: colors.textTertiary }}>
              이 페이지는 현재 개발 중입니다.
            </p>
          </div>
        </div>
      </Card>
    </div>
  );
}
