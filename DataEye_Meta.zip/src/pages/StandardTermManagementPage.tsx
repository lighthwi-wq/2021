import { BookOpen, Search, Plus, Download, Upload, ArrowUpDown, ChevronUp, ChevronDown, Filter } from 'lucide-react';
import { Card } from '../components/common/Card';
import { IconBox } from '../components/common/IconBox';
import { Button } from '../components/common/Button';
import { Badge } from '../components/common/Badge';
import { Pagination } from '../components/common/Pagination';
import { StandardTermFormModal } from '../components/modals/StandardTermFormModal';
import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { useModal } from '../contexts/ModalContext';

export function StandardTermManagementPage() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState<'create' | 'edit'>('create');
  const [selectedTerm, setSelectedTerm] = useState<any>(null);
  const [sortField, setSortField] = useState<string>('');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [filters, setFilters] = useState<Record<string, string>>({});
  const [activeFilterColumn, setActiveFilterColumn] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);

  const handleAddClick = () => {
    setModalMode('create');
    setSelectedTerm(null);
    setIsModalOpen(true);
  };

  const handleTermClick = (term: any) => {
    setModalMode('edit');
    setSelectedTerm(term);
    setIsModalOpen(true);
  };

  const standardTerms = [
    { term: '고객명', englishName: 'CUSTOMER_NAME', standard: 'CUST_NM', type: '일반용어', dataType: 'VARCHAR(100)', status: '승인', createdDate: '2024-10-15', usage: 156 },
    { term: '주문번호', englishName: 'ORDER_NUMBER', standard: 'ORD_NO', type: '일반용어', dataType: 'VARCHAR(20)', status: '승인', createdDate: '2024-10-18', usage: 243 },
    { term: '상품코드', englishName: 'PRODUCT_CODE', standard: 'PROD_CD', type: '일반용어', dataType: 'VARCHAR(15)', status: '검토중', createdDate: '2024-11-01', usage: 89 },
    { term: '거래금액', englishName: 'TRANSACTION_AMOUNT', standard: 'TRX_AMT', type: '일반용어', dataType: 'NUMBER(15,2)', status: '승인', createdDate: '2024-10-20', usage: 198 },
    { term: '배송주소', englishName: 'DELIVERY_ADDRESS', standard: 'DLVR_ADDR', type: '일반용어', dataType: 'VARCHAR(200)', status: '승인', createdDate: '2024-10-25', usage: 134 },
    { term: '결제일자', englishName: 'PAYMENT_DATE', standard: 'PAY_DT', type: '일반용어', dataType: 'DATE', status: '검토중', createdDate: '2024-11-05', usage: 167 },
  ];

  const termStats = [
    { label: '전체 표준용어', value: '1,247', color: 'blue' as const },
    { label: '승인 완료', value: '1,089', color: 'green' as const },
    { label: '검토중', value: '158', color: 'orange' as const },
    { label: '미사용', value: '47', color: 'red' as const },
  ];

  const handleSort = (field: string) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const SortIcon = ({ field }: { field: string }) => {
    if (sortField !== field) {
      return <ArrowUpDown className="w-3.5 h-3.5 text-gray-400 ml-1" />;
    }
    return sortDirection === 'asc' ? (
      <ChevronUp className="w-3.5 h-3.5 ml-1" style={{ color: '#2B8DFF' }} />
    ) : (
      <ChevronDown className="w-3.5 h-3.5 ml-1" style={{ color: '#2B8DFF' }} />
    );
  };

  const handleImport = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.csv,.xlsx,.xls';
    input.onchange = (e: any) => {
      const file = e.target.files[0];
      if (file) {
        console.log('파일 가져오기:', file.name);
        alert(`${file.name} 파일을 가져왔습니다.\n실제 구현시 파일 파싱 및 데이터 임포트 로직이 실행됩니다.`);
      }
    };
    input.click();
  };

  const handleExport = () => {
    // CSV 형식으로 내보내기
    const headers = ['한글명', '영문명', '표준명', '유형', '데이터타입', '상태', '등록일', '사용횟수'];
    const csvContent = [
      headers.join(','),
      ...standardTerms.map(term => 
        [term.term, term.englishName, term.standard, term.type, term.dataType, term.status, term.createdDate, term.usage].join(',')
      )
    ].join('\n');

    const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `표준용어목록_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleFilter = (field: string, value: string) => {
    setFilters(prev => {
      const newFilters = { ...prev };
      if (value === '') {
        delete newFilters[field];
      } else {
        newFilters[field] = value;
      }
      return newFilters;
    });
    setActiveFilterColumn(null);
  };

  const getUniqueValues = (field: string) => {
    const values = standardTerms.map(term => String(term[field as keyof typeof term]));
    return Array.from(new Set(values)).sort();
  };

  const FilterDropdown = ({ field }: { field: string }) => {
    if (activeFilterColumn !== field) return null;
    
    const uniqueValues = getUniqueValues(field);
    
    return (
      <div 
        className="absolute top-full left-0 mt-1 bg-white rounded-lg shadow-lg border border-gray-200 z-50 min-w-[200px]"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-2 max-h-[300px] overflow-y-auto">
          <div
            className="px-3 py-2 hover:bg-gray-50 cursor-pointer rounded text-sm"
            onClick={() => handleFilter(field, '')}
            style={{ color: filters[field] === '' || !filters[field] ? '#2B8DFF' : '#5F6368' }}
          >
            전체
          </div>
          {uniqueValues.map((value) => (
            <div
              key={value}
              className="px-3 py-2 hover:bg-gray-50 cursor-pointer rounded text-sm"
              onClick={() => handleFilter(field, value)}
              style={{ color: filters[field] === value ? '#2B8DFF' : '#5F6368' }}
            >
              {value}
            </div>
          ))}
        </div>
      </div>
    );
  };

  const filteredTerms = standardTerms.filter(term => {
    return Object.entries(filters).every(([field, value]) => {
      return String(term[field as keyof typeof term]) === value;
    });
  });

  const sortedTerms = [...filteredTerms].sort((a, b) => {
    if (!sortField) return 0;
    
    let aVal = a[sortField as keyof typeof a];
    let bVal = b[sortField as keyof typeof b];
    
    if (typeof aVal === 'number' && typeof bVal === 'number') {
      return sortDirection === 'asc' ? aVal - bVal : bVal - aVal;
    }
    
    const aStr = String(aVal).toLowerCase();
    const bStr = String(bVal).toLowerCase();
    
    if (sortDirection === 'asc') {
      return aStr < bStr ? -1 : aStr > bStr ? 1 : 0;
    } else {
      return aStr > bStr ? -1 : aStr < bStr ? 1 : 0;
    }
  });

  const totalPages = Math.ceil(sortedTerms.length / itemsPerPage);
  const currentTerms = sortedTerms.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  return (
    <div className="space-y-4 p-0">
      <div className="flex-1 overflow-auto">
        <div className="space-y-4">
          {/* Stats Cards */}
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 mb-6">
            {termStats.map((stat, idx) => (
              <Card key={idx} padding="lg">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-500 mb-1">{stat.label}</p>
                    <h3 className="text-gray-900 font-bold">{stat.value}</h3>
                  </div>
                  <IconBox icon={BookOpen} color={stat.color} size="md" />
                </div>
              </Card>
            ))}
          </div>

          <Card padding="lg">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
              <div className="flex items-center gap-3">
                <IconBox icon={BookOpen} color="blue" size="md" />
                <h3 className="text-gray-900 font-bold">표준용어 목록</h3>
              </div>
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-3 bg-gray-50 rounded-xl px-4 py-2 border border-gray-200">
                  <Search className="w-4 h-4 text-gray-400" />
                  <input 
                    type="text" 
                    placeholder="표준용어 검색..."
                    className="bg-transparent border-none outline-none text-gray-900 placeholder-gray-400 w-48"
                  />
                </div>
                <Button variant="secondary" icon={<Upload className="w-4 h-4" />} size="sm" onClick={handleImport}>가져오기</Button>
                <Button variant="secondary" icon={<Download className="w-4 h-4" />} size="sm" onClick={handleExport}>내보내기</Button>
                <Button variant="primary" icon={<Plus className="w-4 h-4" />} size="sm" onClick={handleAddClick}>용어 추가</Button>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full">
                <thead style={{ backgroundColor: '#F7F8FA' }}>
                  <tr style={{ borderBottom: '1px solid #DADCE0' }}>
                    <th 
                      className="px-4 py-3 text-left text-sm hover:bg-gray-100 transition-colors relative" 
                      style={{ color: '#5F6368' }}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center cursor-pointer" onClick={() => handleSort('term')}>
                          한글명
                          <SortIcon field="term" />
                        </div>
                        <Filter 
                          className="w-3.5 h-3.5 ml-2 cursor-pointer hover:text-blue-600" 
                          style={{ color: filters['term'] ? '#2B8DFF' : '#9CA3AF' }}
                          onClick={(e) => {
                            e.stopPropagation();
                            setActiveFilterColumn(activeFilterColumn === 'term' ? null : 'term');
                          }}
                        />
                        <FilterDropdown field="term" />
                      </div>
                    </th>
                    <th 
                      className="px-4 py-3 text-left text-sm hover:bg-gray-100 transition-colors relative" 
                      style={{ color: '#5F6368' }}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center cursor-pointer" onClick={() => handleSort('englishName')}>
                          영문명
                          <SortIcon field="englishName" />
                        </div>
                        <Filter 
                          className="w-3.5 h-3.5 ml-2 cursor-pointer hover:text-blue-600" 
                          style={{ color: filters['englishName'] ? '#2B8DFF' : '#9CA3AF' }}
                          onClick={(e) => {
                            e.stopPropagation();
                            setActiveFilterColumn(activeFilterColumn === 'englishName' ? null : 'englishName');
                          }}
                        />
                        <FilterDropdown field="englishName" />
                      </div>
                    </th>
                    <th 
                      className="px-4 py-3 text-left text-sm hover:bg-gray-100 transition-colors relative" 
                      style={{ color: '#5F6368' }}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center cursor-pointer" onClick={() => handleSort('standard')}>
                          표준명
                          <SortIcon field="standard" />
                        </div>
                        <Filter 
                          className="w-3.5 h-3.5 ml-2 cursor-pointer hover:text-blue-600" 
                          style={{ color: filters['standard'] ? '#2B8DFF' : '#9CA3AF' }}
                          onClick={(e) => {
                            e.stopPropagation();
                            setActiveFilterColumn(activeFilterColumn === 'standard' ? null : 'standard');
                          }}
                        />
                        <FilterDropdown field="standard" />
                      </div>
                    </th>
                    <th 
                      className="px-4 py-3 text-left text-sm hover:bg-gray-100 transition-colors relative" 
                      style={{ color: '#5F6368' }}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center cursor-pointer" onClick={() => handleSort('type')}>
                          유형
                          <SortIcon field="type" />
                        </div>
                        <Filter 
                          className="w-3.5 h-3.5 ml-2 cursor-pointer hover:text-blue-600" 
                          style={{ color: filters['type'] ? '#2B8DFF' : '#9CA3AF' }}
                          onClick={(e) => {
                            e.stopPropagation();
                            setActiveFilterColumn(activeFilterColumn === 'type' ? null : 'type');
                          }}
                        />
                        <FilterDropdown field="type" />
                      </div>
                    </th>
                    <th 
                      className="px-4 py-3 text-left text-sm hover:bg-gray-100 transition-colors relative" 
                      style={{ color: '#5F6368' }}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center cursor-pointer" onClick={() => handleSort('dataType')}>
                          데이터타입
                          <SortIcon field="dataType" />
                        </div>
                        <Filter 
                          className="w-3.5 h-3.5 ml-2 cursor-pointer hover:text-blue-600" 
                          style={{ color: filters['dataType'] ? '#2B8DFF' : '#9CA3AF' }}
                          onClick={(e) => {
                            e.stopPropagation();
                            setActiveFilterColumn(activeFilterColumn === 'dataType' ? null : 'dataType');
                          }}
                        />
                        <FilterDropdown field="dataType" />
                      </div>
                    </th>
                    <th 
                      className="px-4 py-3 text-left text-sm hover:bg-gray-100 transition-colors relative" 
                      style={{ color: '#5F6368' }}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center cursor-pointer" onClick={() => handleSort('status')}>
                          상태
                          <SortIcon field="status" />
                        </div>
                        <Filter 
                          className="w-3.5 h-3.5 ml-2 cursor-pointer hover:text-blue-600" 
                          style={{ color: filters['status'] ? '#2B8DFF' : '#9CA3AF' }}
                          onClick={(e) => {
                            e.stopPropagation();
                            setActiveFilterColumn(activeFilterColumn === 'status' ? null : 'status');
                          }}
                        />
                        <FilterDropdown field="status" />
                      </div>
                    </th>
                    <th 
                      className="px-4 py-3 text-left text-sm hover:bg-gray-100 transition-colors relative" 
                      style={{ color: '#5F6368' }}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center cursor-pointer" onClick={() => handleSort('createdDate')}>
                          등록일
                          <SortIcon field="createdDate" />
                        </div>
                        <Filter 
                          className="w-3.5 h-3.5 ml-2 cursor-pointer hover:text-blue-600" 
                          style={{ color: filters['createdDate'] ? '#2B8DFF' : '#9CA3AF' }}
                          onClick={(e) => {
                            e.stopPropagation();
                            setActiveFilterColumn(activeFilterColumn === 'createdDate' ? null : 'createdDate');
                          }}
                        />
                        <FilterDropdown field="createdDate" />
                      </div>
                    </th>
                    <th 
                      className="px-4 py-3 text-left text-sm hover:bg-gray-100 transition-colors relative" 
                      style={{ color: '#5F6368' }}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center cursor-pointer" onClick={() => handleSort('usage')}>
                          사용횟수
                          <SortIcon field="usage" />
                        </div>
                        <Filter 
                          className="w-3.5 h-3.5 ml-2 cursor-pointer hover:text-blue-600" 
                          style={{ color: filters['usage'] ? '#2B8DFF' : '#9CA3AF' }}
                          onClick={(e) => {
                            e.stopPropagation();
                            setActiveFilterColumn(activeFilterColumn === 'usage' ? null : 'usage');
                          }}
                        />
                        <FilterDropdown field="usage" />
                      </div>
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {currentTerms.map((term, idx) => (
                    <tr 
                      key={idx} 
                      className="border-b border-gray-200 hover:bg-gray-50 transition-colors cursor-pointer"
                      onClick={() => {
                        setSelectedTerm(term);
                        setModalMode('edit');
                        setIsModalOpen(true);
                      }}
                    >
                      <td className="px-4 py-3 text-gray-900 font-bold">{term.term}</td>
                      <td className="px-4 py-3 text-gray-600">{term.englishName}</td>
                      <td className="px-4 py-3 text-blue-600 font-mono text-sm font-bold">{term.standard}</td>
                      <td className="px-4 py-3 text-gray-600">{term.type}</td>
                      <td className="px-4 py-3 text-gray-600 font-mono text-sm">{term.dataType}</td>
                      <td className="px-4 py-3">
                        <Badge variant={term.status === '승인' ? 'success' : 'warning'}>
                          {term.status}
                        </Badge>
                      </td>
                      <td className="px-4 py-3 text-gray-600">{term.createdDate}</td>
                      <td className="px-4 py-3 text-gray-600 text-center">{term.usage}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <Pagination
              currentPage={currentPage}
              totalPages={Math.ceil(sortedTerms.length / itemsPerPage)}
              totalItems={sortedTerms.length}
              onPageChange={setCurrentPage}
              itemsPerPage={itemsPerPage}
              onItemsPerPageChange={setItemsPerPage}
            />
          </Card>
        </div>
      </div>

      {/* 모달 영역 */}
      <StandardTermFormModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        mode={modalMode}
        initialData={selectedTerm}
      />
    </div>
  );
}