import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  User, Bell, Shield, Globe, Link, Database, Palette,
  Save, Upload, Mail, Phone, MapPin, Lock, CheckCircle2, 
  Key, Eye, EyeOff, Cloud, Server, Code, RefreshCw, Sun
} from 'lucide-react';
import { Modal } from '../components/common/Modal';
import { Card } from '../components/common/Card';
import { Badge } from '../components/common/Badge';
import { useModal } from '../contexts/ModalContext';

export function SettingsPage() {
  const { setIsModalOpen } = useModal();
  const [activeTab, setActiveTab] = useState('profile');
  const [showModal, setShowModal] = useState(false);
  const [modalType, setModalType] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  useEffect(() => {
    setIsModalOpen(showModal);
  }, [showModal, setIsModalOpen]);

  const tabs = [
    { id: 'profile', label: '프로필', icon: User },
    { id: 'notifications', label: '알림', icon: Bell },
    { id: 'security', label: '보안', icon: Shield },
    { id: 'system', label: '시스템', icon: Globe },
    { id: 'integrations', label: '통합', icon: Link },
    { id: 'data', label: '데이터', icon: Database },
    { id: 'appearance', label: '테마', icon: Palette },
  ];

  // 프로필 정보
  const [profileData, setProfileData] = useState({
    name: '홍길동',
    email: 'hong@company.com',
    phone: '010-1234-5678',
    department: '데이터관리팀',
    position: '데이터 아키텍트',
    location: '서울, 대한민국',
    bio: '데이터 품질 및 메타데이터 관리 전문가'
  });

  // 알림 설정
  const [notificationSettings, setNotificationSettings] = useState({
    emailNotifications: true,
    qualityAlerts: true,
    systemUpdates: false,
    weeklyReports: true,
    slackIntegration: true,
    pushNotifications: false
  });

  // 시스템 설정
  const [systemSettings, setSystemSettings] = useState({
    language: 'ko',
    timezone: 'Asia/Seoul',
    dateFormat: 'YYYY-MM-DD',
    timeFormat: '24h',
    numberFormat: '1,234.56'
  });

  // 통합 설정
  const integrations = [
    { name: 'Snowflake', status: 'connected', icon: Cloud, color: '#29B5E8' },
    { name: 'Databricks', status: 'connected', icon: Server, color: '#FF3621' },
    { name: 'AWS S3', status: 'disconnected', icon: Cloud, color: '#FF9900' },
    { name: 'Azure Data Lake', status: 'connected', icon: Cloud, color: '#0078D4' },
    { name: 'Slack', status: 'connected', icon: Link, color: '#4A154B' },
    { name: 'GitHub', status: 'disconnected', icon: Code, color: '#181717' }
  ];

  const handleSave = () => {
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  const renderProfileTab = () => (
    <div className="space-y-6">
      <Card padding="lg" className="hover:shadow-lg transition-shadow duration-300">
        <div className="flex items-start justify-between mb-6">
          <div>
            <h3 className="font-bold mb-2" style={{ color: '#202124' }}>프로필 정보</h3>
            <p className="text-sm" style={{ color: '#5F6368' }}>
              사용자 프로필 정보를 관리합니다
            </p>
          </div>
          <button
            onClick={handleSave}
            className="flex items-center gap-2 px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition-colors"
          >
            <Save className="w-4 h-4" />
            저장
          </button>
        </div>

        <div className="flex items-start gap-8 mb-8">
          <div className="flex-shrink-0">
            <div className="w-24 h-24 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white font-bold text-2xl shadow-lg">
              {profileData.name.substring(0, 2)}
            </div>
            <button className="mt-3 w-full flex items-center justify-center gap-2 px-3 py-2 rounded-lg transition-colors text-sm" style={{ backgroundColor: '#F1F3F4', color: '#5F6368' }} onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#E8EAED'} onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#F1F3F4'}>
              <Upload className="w-4 h-4" />
              변경
            </button>
          </div>
          
          <div className="flex-1 grid grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-bold mb-2" style={{ color: '#5F6368' }}>
                <User className="w-4 h-4 inline mr-2" />
                이름
              </label>
              <input
                type="text"
                value={profileData.name}
                onChange={(e) => setProfileData({...profileData, name: e.target.value})}
                className="w-full px-4 py-2 rounded-lg border focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                style={{ backgroundColor: '#FFFFFF', borderColor: '#DADCE0', color: '#202124' }}
              />
            </div>
            
            <div>
              <label className="block text-sm font-bold mb-2" style={{ color: '#5F6368' }}>
                <Mail className="w-4 h-4 inline mr-2" />
                이메일
              </label>
              <input
                type="email"
                value={profileData.email}
                onChange={(e) => setProfileData({...profileData, email: e.target.value})}
                className="w-full px-4 py-2 rounded-lg border focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                style={{ backgroundColor: '#FFFFFF', borderColor: '#DADCE0', color: '#202124' }}
              />
            </div>

            <div>
              <label className="block text-sm font-bold mb-2" style={{ color: '#5F6368' }}>
                <Phone className="w-4 h-4 inline mr-2" />
                전화번호
              </label>
              <input
                type="tel"
                value={profileData.phone}
                onChange={(e) => setProfileData({...profileData, phone: e.target.value})}
                className="w-full px-4 py-2 rounded-lg border focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                style={{ backgroundColor: '#FFFFFF', borderColor: '#DADCE0', color: '#202124' }}
              />
            </div>

            <div>
              <label className="block text-sm font-bold mb-2" style={{ color: '#5F6368' }}>
                <MapPin className="w-4 h-4 inline mr-2" />
                위치
              </label>
              <input
                type="text"
                value={profileData.location}
                onChange={(e) => setProfileData({...profileData, location: e.target.value})}
                className="w-full px-4 py-2 rounded-lg border focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                style={{ backgroundColor: '#FFFFFF', borderColor: '#DADCE0', color: '#202124' }}
              />
            </div>

            <div>
              <label className="block text-sm font-bold mb-2" style={{ color: '#5F6368' }}>
                부서
              </label>
              <input
                type="text"
                value={profileData.department}
                onChange={(e) => setProfileData({...profileData, department: e.target.value})}
                className="w-full px-4 py-2 rounded-lg border focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                style={{ backgroundColor: '#FFFFFF', borderColor: '#DADCE0', color: '#202124' }}
              />
            </div>

            <div>
              <label className="block text-sm font-bold mb-2" style={{ color: '#5F6368' }}>
                직책
              </label>
              <input
                type="text"
                value={profileData.position}
                onChange={(e) => setProfileData({...profileData, position: e.target.value})}
                className="w-full px-4 py-2 rounded-lg border focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                style={{ backgroundColor: '#FFFFFF', borderColor: '#DADCE0', color: '#202124' }}
              />
            </div>

            <div className="col-span-2">
              <label className="block text-sm font-bold mb-2" style={{ color: '#5F6368' }}>
                소개
              </label>
              <textarea
                value={profileData.bio}
                onChange={(e) => setProfileData({...profileData, bio: e.target.value})}
                rows={3}
                className="w-full px-4 py-2 rounded-lg border focus:ring-2 focus:ring-blue-500 outline-none transition-all resize-none"
                style={{ backgroundColor: '#FFFFFF', borderColor: '#DADCE0', color: '#202124' }}
              />
            </div>
          </div>
        </div>
      </Card>
    </div>
  );

  const renderNotificationsTab = () => (
    <div className="space-y-6">
      <Card padding="lg" className="hover:shadow-lg transition-shadow duration-300">
        <div className="flex items-start justify-between mb-6">
          <div>
            <h3 className="font-bold mb-2" style={{ color: '#202124' }}>알림 설정</h3>
            <p className="text-sm" style={{ color: '#5F6368' }}>
              알림 수신 방법을 설정합니다
            </p>
          </div>
          <button
            onClick={handleSave}
            className="flex items-center gap-2 px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition-colors"
          >
            <Save className="w-4 h-4" />
            저장
          </button>
        </div>

        <div className="space-y-4">
          {[
            { key: 'emailNotifications', label: '이메일 알림', description: '중요한 알림을 이메일로 받습니다' },
            { key: 'qualityAlerts', label: '품질 경고', description: '데이터 품질 이슈 발생 시 알림' },
            { key: 'systemUpdates', label: '시스템 업데이트', description: '시스템 업데이트 및 유지보수 알림' },
            { key: 'weeklyReports', label: '주간 리포트', description: '매주 데이터 품질 리포트 수신' },
            { key: 'slackIntegration', label: 'Slack 통합', description: 'Slack으로 실시간 알림 수신' },
            { key: 'pushNotifications', label: '푸시 알림', description: '브라우저 푸시 알림 수신' }
          ].map((setting) => (
            <div
              key={setting.key}
              className="flex items-center justify-between p-4 rounded-lg transition-colors"
              style={{ backgroundColor: '#F9F9F9' }}
              onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#F1F3F4'}
              onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#F9F9F9'}
            >
              <div className="flex-1">
                <p className="font-bold mb-1" style={{ color: '#202124' }}>{setting.label}</p>
                <p className="text-sm" style={{ color: '#5F6368' }}>{setting.description}</p>
              </div>
              <button
                onClick={() => setNotificationSettings({
                  ...notificationSettings,
                  [setting.key]: !notificationSettings[setting.key as keyof typeof notificationSettings]
                })}
                className={`relative w-14 h-7 rounded-full transition-colors ${
                  notificationSettings[setting.key as keyof typeof notificationSettings]
                    ? 'bg-blue-500'
                    : 'bg-gray-300'
                }`}
              >
                <div
                  className={`absolute top-1 left-1 w-5 h-5 bg-white rounded-full transition-transform ${
                    notificationSettings[setting.key as keyof typeof notificationSettings]
                      ? 'translate-x-7'
                      : 'translate-x-0'
                  }`}
                />
              </button>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );

  const renderSecurityTab = () => (
    <div className="space-y-6">
      <Card padding="lg" className="hover:shadow-lg transition-shadow duration-300">
        <div className="mb-6">
          <h3 className="font-bold mb-2" style={{ color: '#202124' }}>비밀번호 변경</h3>
          <p className="text-sm" style={{ color: '#5F6368' }}>
            보안을 위해 주기적으로 비밀번호를 변경하세요
          </p>
        </div>

        <div className="space-y-4 max-w-xl">
          <div>
            <label className="block text-sm font-bold mb-2" style={{ color: '#5F6368' }}>
              현재 비밀번호
            </label>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                className="w-full px-4 py-2 rounded-lg border focus:ring-2 focus:ring-blue-500 outline-none transition-all pr-10"
                style={{ backgroundColor: '#FFFFFF', borderColor: '#DADCE0', color: '#202124' }}
                placeholder="현재 비밀번호 입력"
              />
              <button
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
              >
                {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
              </button>
            </div>
          </div>

          <div>
            <label className="block text-sm font-bold mb-2" style={{ color: '#5F6368' }}>
              새 비밀번호
            </label>
            <input
              type={showPassword ? 'text' : 'password'}
              className="w-full px-4 py-2 rounded-lg border focus:ring-2 focus:ring-blue-500 outline-none transition-all"
              style={{ backgroundColor: '#FFFFFF', borderColor: '#DADCE0', color: '#202124' }}
              placeholder="새 비밀번호 입력"
            />
          </div>

          <div>
            <label className="block text-sm font-bold mb-2" style={{ color: '#5F6368' }}>
              비밀번호 확인
            </label>
            <input
              type={showPassword ? 'text' : 'password'}
              className="w-full px-4 py-2 rounded-lg border focus:ring-2 focus:ring-blue-500 outline-none transition-all"
              style={{ backgroundColor: '#FFFFFF', borderColor: '#DADCE0', color: '#202124' }}
              placeholder="비밀번호 재입력"
            />
          </div>

          <button
            onClick={handleSave}
            className="flex items-center gap-2 px-6 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition-colors"
          >
            <Lock className="w-4 h-4" />
            비밀번호 변경
          </button>
        </div>
      </Card>

      <Card padding="lg" className="hover:shadow-lg transition-shadow duration-300">
        <div className="mb-6">
          <h3 className="font-bold mb-2" style={{ color: '#202124' }}>2단계 인증 (2FA)</h3>
          <p className="text-sm" style={{ color: '#5F6368' }}>
            계정 보안을 강화하세요
          </p>
        </div>

        <div className="flex items-center justify-between p-4 rounded-lg border" style={{ backgroundColor: '#F0FDF4', borderColor: '#BBF7D0' }}>
          <div className="flex items-center gap-3">
            <CheckCircle2 className="w-5 h-5" style={{ color: '#16A34A' }} />
            <div>
              <p className="font-bold" style={{ color: '#202124' }}>2단계 인증 활성화됨</p>
              <p className="text-sm" style={{ color: '#5F6368' }}>Google Authenticator 앱 사용 중</p>
            </div>
          </div>
          <button className="px-4 py-2 rounded-lg border transition-colors" style={{ backgroundColor: '#FFFFFF', color: '#5F6368', borderColor: '#DADCE0' }} onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#F9F9F9'} onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#FFFFFF'}>
            비활성화
          </button>
        </div>
      </Card>

      <Card padding="lg" className="hover:shadow-lg transition-shadow duration-300">
        <div className="mb-6">
          <h3 className="font-bold mb-2" style={{ color: '#202124' }}>API 키 관리</h3>
          <p className="text-sm" style={{ color: '#5F6368' }}>
            API 접근을 위한 키를 관리합니다
          </p>
        </div>

        <div className="space-y-3">
          {[
            { name: 'Production API Key', created: '2024-01-15', lastUsed: '2시간 전' },
            { name: 'Development API Key', created: '2024-02-01', lastUsed: '5일 전' }
          ].map((key, idx) => (
            <div
              key={idx}
              className="flex items-center justify-between p-4 rounded-lg transition-colors"
              style={{ backgroundColor: '#F9F9F9' }}
              onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#F1F3F4'}
              onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#F9F9F9'}
            >
              <div>
                <p className="font-bold mb-1" style={{ color: '#202124' }}>{key.name}</p>
                <p className="text-sm" style={{ color: '#5F6368' }}>
                  생성: {key.created} • 마지막 사용: {key.lastUsed}
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button className="px-3 py-1.5 rounded-lg transition-colors text-sm" style={{ backgroundColor: '#E8EAED', color: '#5F6368' }} onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#DADCE0'} onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#E8EAED'}>
                  복사
                </button>
                <button className="px-3 py-1.5 rounded-lg transition-colors text-sm" style={{ backgroundColor: '#FEE2E2', color: '#DC2626' }} onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#FECACA'} onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#FEE2E2'}>
                  삭제
                </button>
              </div>
            </div>
          ))}
        </div>

        <button className="mt-4 flex items-center gap-2 px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition-colors">
          <Key className="w-4 h-4" />
          새 API 키 생성
        </button>
      </Card>
    </div>
  );

  const renderSystemTab = () => (
    <div className="space-y-6">
      <Card padding="lg" className="hover:shadow-lg transition-shadow duration-300">
        <div className="flex items-start justify-between mb-6">
          <div>
            <h3 className="font-bold mb-2" style={{ color: '#202124' }}>시스템 설정</h3>
            <p className="text-sm" style={{ color: '#5F6368' }}>
              언어, 시간대 및 형식을 설정합니다
            </p>
          </div>
          <button
            onClick={handleSave}
            className="flex items-center gap-2 px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition-colors"
          >
            <Save className="w-4 h-4" />
            저장
          </button>
        </div>

        <div className="grid grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-bold mb-2" style={{ color: '#5F6368' }}>
              <Globe className="w-4 h-4 inline mr-2" />
              언어
            </label>
            <select
              value={systemSettings.language}
              onChange={(e) => setSystemSettings({...systemSettings, language: e.target.value})}
              className="w-full px-4 py-2 rounded-lg border focus:ring-2 focus:ring-blue-500 outline-none transition-all"
              style={{ backgroundColor: '#FFFFFF', borderColor: '#DADCE0', color: '#202124' }}
            >
              <option value="ko">한국어</option>
              <option value="en">English</option>
              <option value="ja">日本語</option>
              <option value="zh">中文</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-bold mb-2" style={{ color: '#5F6368' }}>
              시간대
            </label>
            <select
              value={systemSettings.timezone}
              onChange={(e) => setSystemSettings({...systemSettings, timezone: e.target.value})}
              className="w-full px-4 py-2 rounded-lg border focus:ring-2 focus:ring-blue-500 outline-none transition-all"
              style={{ backgroundColor: '#FFFFFF', borderColor: '#DADCE0', color: '#202124' }}
            >
              <option value="Asia/Seoul">서울 (UTC+9)</option>
              <option value="America/New_York">뉴욕 (UTC-5)</option>
              <option value="Europe/London">런던 (UTC+0)</option>
              <option value="Asia/Tokyo">도쿄 (UTC+9)</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-bold mb-2" style={{ color: '#5F6368' }}>
              날짜 형식
            </label>
            <select
              value={systemSettings.dateFormat}
              onChange={(e) => setSystemSettings({...systemSettings, dateFormat: e.target.value})}
              className="w-full px-4 py-2 rounded-lg border focus:ring-2 focus:ring-blue-500 outline-none transition-all"
              style={{ backgroundColor: '#FFFFFF', borderColor: '#DADCE0', color: '#202124' }}
            >
              <option value="YYYY-MM-DD">YYYY-MM-DD</option>
              <option value="MM/DD/YYYY">MM/DD/YYYY</option>
              <option value="DD/MM/YYYY">DD/MM/YYYY</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-bold mb-2" style={{ color: '#5F6368' }}>
              시간 형식
            </label>
            <select
              value={systemSettings.timeFormat}
              onChange={(e) => setSystemSettings({...systemSettings, timeFormat: e.target.value})}
              className="w-full px-4 py-2 rounded-lg border focus:ring-2 focus:ring-blue-500 outline-none transition-all"
              style={{ backgroundColor: '#FFFFFF', borderColor: '#DADCE0', color: '#202124' }}
            >
              <option value="24h">24시간 (23:00)</option>
              <option value="12h">12시간 (11:00 PM)</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-bold mb-2" style={{ color: '#5F6368' }}>
              숫자 형식
            </label>
            <select
              value={systemSettings.numberFormat}
              onChange={(e) => setSystemSettings({...systemSettings, numberFormat: e.target.value})}
              className="w-full px-4 py-2 rounded-lg border focus:ring-2 focus:ring-blue-500 outline-none transition-all"
              style={{ backgroundColor: '#FFFFFF', borderColor: '#DADCE0', color: '#202124' }}
            >
              <option value="1,234.56">1,234.56</option>
              <option value="1.234,56">1.234,56</option>
              <option value="1 234.56">1 234.56</option>
            </select>
          </div>
        </div>
      </Card>
    </div>
  );

  const renderIntegrationsTab = () => (
    <div className="space-y-6">
      <Card padding="lg" className="hover:shadow-lg transition-shadow duration-300">
        <div className="mb-6">
          <h3 className="font-bold mb-2" style={{ color: '#202124' }}>통합 서비스</h3>
          <p className="text-sm" style={{ color: '#5F6368' }}>
            외부 서비스와의 연동을 관리합니다
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {integrations.map((integration, idx) => (
            <div
              key={idx}
              className="p-4 rounded-lg border transition-all"
              style={{ borderColor: '#DADCE0' }}
              onMouseEnter={(e) => e.currentTarget.style.borderColor = '#2B8DFF'}
              onMouseLeave={(e) => e.currentTarget.style.borderColor = '#DADCE0'}
            >
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div
                    className="w-10 h-10 rounded-lg flex items-center justify-center"
                    style={{ backgroundColor: `${integration.color}20` }}
                  >
                    <integration.icon 
                      className="w-5 h-5" 
                      style={{ color: integration.color }}
                    />
                  </div>
                  <div>
                    <p className="font-bold" style={{ color: '#202124' }}>{integration.name}</p>
                    <Badge variant={integration.status === 'connected' ? 'success' : 'default'}>
                      {integration.status === 'connected' ? '연결됨' : '연결 안 됨'}
                    </Badge>
                  </div>
                </div>
              </div>
              <button
                className={`w-full px-4 py-2 rounded-lg transition-colors ${
                  integration.status === 'connected'
                    ? 'text-white'
                    : 'bg-blue-500 text-white hover:bg-blue-600'
                }`}
                style={integration.status === 'connected' ? { backgroundColor: '#E8EAED', color: '#5F6368' } : {}}
                onMouseEnter={(e) => {
                  if (integration.status === 'connected') {
                    e.currentTarget.style.backgroundColor = '#DADCE0';
                  }
                }}
                onMouseLeave={(e) => {
                  if (integration.status === 'connected') {
                    e.currentTarget.style.backgroundColor = '#E8EAED';
                  }
                }}
              >
                {integration.status === 'connected' ? '연결 해제' : '연결하기'}
              </button>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );

  const renderDataTab = () => (
    <div className="space-y-6">
      <Card padding="lg" className="hover:shadow-lg transition-shadow duration-300">
        <div className="flex items-start justify-between mb-6">
          <div>
            <h3 className="font-bold mb-2" style={{ color: '#202124' }}>데이터 동기화</h3>
            <p className="text-sm" style={{ color: '#5F6368' }}>
              자동 동기화 및 백업 설정
            </p>
          </div>
          <button
            onClick={handleSave}
            className="flex items-center gap-2 px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition-colors"
          >
            <Save className="w-4 h-4" />
            저장
          </button>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 rounded-lg" style={{ backgroundColor: '#F9F9F9' }}>
            <div>
              <p className="font-bold mb-1" style={{ color: '#202124' }}>자동 동기화</p>
              <p className="text-sm" style={{ color: '#5F6368' }}>데이터를 자동으로 동기화합니다</p>
            </div>
            <button className="relative w-14 h-7 bg-blue-500 rounded-full">
              <div className="absolute top-1 right-1 w-5 h-5 bg-white rounded-full" />
            </button>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-bold mb-2" style={{ color: '#5F6368' }}>
                동기화 주기
              </label>
              <select className="w-full px-4 py-2 rounded-lg border focus:ring-2 focus:ring-blue-500 outline-none transition-all" style={{ backgroundColor: '#FFFFFF', borderColor: '#DADCE0', color: '#202124' }}>
                <option value="5">5분마다</option>
                <option value="15">15분마다</option>
                <option value="30">30분마다</option>
                <option value="60">1시간마다</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-bold mb-2" style={{ color: '#5F6368' }}>
                데이터 보관 기간
              </label>
              <select className="w-full px-4 py-2 rounded-lg border focus:ring-2 focus:ring-blue-500 outline-none transition-all" style={{ backgroundColor: '#FFFFFF', borderColor: '#DADCE0', color: '#202124' }}>
                <option value="30">30일</option>
                <option value="60">60일</option>
                <option value="90">90일</option>
                <option value="180">180일</option>
                <option value="365">1년</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-bold mb-2" style={{ color: '#5F6368' }}>
                백업 빈도
              </label>
              <select className="w-full px-4 py-2 rounded-lg border focus:ring-2 focus:ring-blue-500 outline-none transition-all" style={{ backgroundColor: '#FFFFFF', borderColor: '#DADCE0', color: '#202124' }}>
                <option value="daily">매일</option>
                <option value="weekly">매주</option>
                <option value="monthly">매월</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-bold mb-2" style={{ color: '#5F6368' }}>
                백업 보관 기간
              </label>
              <select className="w-full px-4 py-2 rounded-lg border focus:ring-2 focus:ring-blue-500 outline-none transition-all" style={{ backgroundColor: '#FFFFFF', borderColor: '#DADCE0', color: '#202124' }}>
                <option value="7">7일</option>
                <option value="14">14일</option>
                <option value="30">30일</option>
                <option value="90">90일</option>
              </select>
            </div>
          </div>
        </div>
      </Card>

      <Card padding="lg" className="hover:shadow-lg transition-shadow duration-300">
        <div className="mb-6">
          <h3 className="font-bold mb-2" style={{ color: '#202124' }}>최근 백업</h3>
          <p className="text-sm" style={{ color: '#5F6368' }}>
            최근 백업 이력
          </p>
        </div>

        <div className="space-y-3">
          {[
            { date: '2024-11-20', time: '02:00', size: '2.3 GB', status: 'success' },
            { date: '2024-11-19', time: '02:00', size: '2.2 GB', status: 'success' },
            { date: '2024-11-18', time: '02:00', size: '2.1 GB', status: 'success' }
          ].map((backup, idx) => (
            <div
              key={idx}
              className="flex items-center justify-between p-4 rounded-lg transition-colors"
              style={{ backgroundColor: '#F9F9F9' }}
              onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#F1F3F4'}
              onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#F9F9F9'}
            >
              <div className="flex items-center gap-3">
                <CheckCircle2 className="w-5 h-5 text-green-500" />
                <div>
                  <p className="font-bold" style={{ color: '#202124' }}>
                    {backup.date} {backup.time}
                  </p>
                  <p className="text-sm" style={{ color: '#5F6368' }}>크기: {backup.size}</p>
                </div>
              </div>
              <button className="px-3 py-1.5 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors text-sm">
                복원
              </button>
            </div>
          ))}
        </div>

        <button className="mt-4 w-full flex items-center justify-center gap-2 px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition-colors">
          <RefreshCw className="w-4 h-4" />
          지금 백업 실행
        </button>
      </Card>
    </div>
  );

  const renderAppearanceTab = () => (
    <div className="space-y-6">
      <Card padding="lg" className="hover:shadow-lg transition-shadow duration-300">
        <div className="mb-6">
          <h3 className="font-bold mb-2" style={{ color: '#202124' }}>테마 설정</h3>
          <p className="text-sm" style={{ color: '#5F6368' }}>
            애플리케이션의 외관을 설정합니다
          </p>
        </div>

        <div className="space-y-6">
          <div className="flex items-center justify-between p-4 rounded-lg" style={{ backgroundColor: '#F9F9F9' }}>
            <div className="flex items-center gap-3">
              <Sun className="w-5 h-5 text-orange-500" />
              <div>
                <p className="font-bold mb-1" style={{ color: '#202124' }}>라이트 모드</p>
                <p className="text-sm" style={{ color: '#5F6368' }}>
                  라이트 모드가 활성화되어 있습니다 (고정)
                </p>
              </div>
            </div>
            <button
              className="relative w-14 h-7 rounded-full transition-colors bg-gray-300 opacity-50 cursor-not-allowed"
              disabled
            >
              <div className="absolute top-1 left-1 w-5 h-5 bg-white rounded-full" />
            </button>
          </div>

          <div>
            <label className="block text-sm font-bold mb-4" style={{ color: '#5F6368' }}>
              색상 테마
            </label>
            <div className="grid grid-cols-4 gap-3">
              {[
                { name: '블루', color: '#2B8DFF' },
                { name: '틸', color: '#3CC7BA' },
                { name: '인디고', color: '#4F46E5' },
                { name: '스카이', color: '#0EA5E9' },
              ].map((theme, idx) => (
                <button
                  key={idx}
                  className="flex flex-col items-center gap-2 p-4 rounded-lg border-2 transition-all"
                  style={{ borderColor: '#DADCE0' }}
                  onMouseEnter={(e) => e.currentTarget.style.borderColor = '#2B8DFF'}
                  onMouseLeave={(e) => e.currentTarget.style.borderColor = '#DADCE0'}
                >
                  <div
                    className="w-12 h-12 rounded-full"
                    style={{ backgroundColor: theme.color }}
                  />
                  <span className="text-sm font-bold" style={{ color: '#202124' }}>
                    {theme.name}
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </Card>
    </div>
  );

  return (
    <div className="space-y-6">
      {/* 성공 메시지 */}
      {saveSuccess && (
        <div className="fixed top-20 right-6 z-50 p-4 bg-green-500 text-white rounded-lg shadow-lg flex items-center gap-3 animate-slide-in">
          <CheckCircle2 className="w-5 h-5" />
          <span className="font-bold">설정이 저장되었습니다!</span>
        </div>
      )}

      {/* 헤더 */}
      <div className="flex items-center justify-between">
      </div>

      {/* 탭 메뉴 */}
      <div className="flex items-center gap-2 border-b overflow-x-auto" style={{ borderColor: '#DADCE0' }}>
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-2 px-4 py-3 border-b-2 transition-colors whitespace-nowrap ${
              activeTab === tab.id
                ? 'border-blue-500 text-blue-500'
                : 'border-transparent hover:text-gray-700'
            }`}
            style={activeTab !== tab.id ? { color: '#5F6368' } : {}}
          >
            <tab.icon className="w-5 h-5" />
            <span className="font-bold">{tab.label}</span>
          </button>
        ))}
      </div>

      {/* 탭 컨텐츠 */}
      <AnimatePresence mode="wait">
        {activeTab === 'profile' && (
          <motion.div
            key="profile"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3, ease: "easeInOut" }}
          >
            {renderProfileTab()}
          </motion.div>
        )}
        {activeTab === 'notifications' && (
          <motion.div
            key="notifications"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3, ease: "easeInOut" }}
          >
            {renderNotificationsTab()}
          </motion.div>
        )}
        {activeTab === 'security' && (
          <motion.div
            key="security"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3, ease: "easeInOut" }}
          >
            {renderSecurityTab()}
          </motion.div>
        )}
        {activeTab === 'system' && (
          <motion.div
            key="system"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3, ease: "easeInOut" }}
          >
            {renderSystemTab()}
          </motion.div>
        )}
        {activeTab === 'integrations' && (
          <motion.div
            key="integrations"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3, ease: "easeInOut" }}
          >
            {renderIntegrationsTab()}
          </motion.div>
        )}
        {activeTab === 'data' && (
          <motion.div
            key="data"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3, ease: "easeInOut" }}
          >
            {renderDataTab()}
          </motion.div>
        )}
        {activeTab === 'appearance' && (
          <motion.div
            key="appearance"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3, ease: "easeInOut" }}
          >
            {renderAppearanceTab()}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
