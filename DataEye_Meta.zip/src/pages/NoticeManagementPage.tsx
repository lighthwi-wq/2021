import { Bell, Search, Plus, Download, ArrowUpDown, ChevronUp, ChevronDown, Filter, Pin, Eye } from 'lucide-react';
import { Card } from '../components/common/Card';
import { IconBox } from '../components/common/IconBox';
import { Button } from '../components/common/Button';
import { Badge } from '../components/common/Badge';
import { Pagination } from '../components/common/Pagination';
import { NoticeFormModal } from '../components/modals/NoticeFormModal';
import { useState } from 'react';
import { motion } from 'motion/react';

export function NoticeManagementPage() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState<'create' | 'edit'>('create');
  const [selectedNotice, setSelectedNotice] = useState<any>(null);
  const [sortField, setSortField] = useState<string>('');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);

  const handleAddClick = () => {
    setModalMode('create');
    setSelectedNotice(null);
    setIsModalOpen(true);
  };

  const handleNoticeClick = (notice: any) => {
    setModalMode('edit');
    setSelectedNotice(notice);
    setIsModalOpen(true);
  };

  const notices = [
    { 
      id: 1,
      title: '2024년 12월 DataEye Meta 정기 점검 안내', 
      category: '시스템',
      content: '2024년 12월 5일(목) 02:00 ~ 06:00 정기 시스템 점검이 진행됩니다.',
      isPinned: true,
      isImportant: true,
      author: '시스템관리자',
      views: 1247,
      status: '게시중',
      createdDate: '2024-11-20',
      startDate: '2024-11-20',
      endDate: '2024-12-31'
    },
    { 
      id: 2,
      title: '데이터 품질 관리 프로세스 개선 안내', 
      category: '업무',
      content: '데이터 품질 관리 프로세스가 개선되어 안내드립니다.',
      isPinned: true,
      isImportant: false,
      author: '데이터관리팀',
      views: 856,
      status: '게시중',
      createdDate: '2024-11-18',
      startDate: '2024-11-18',
      endDate: '2024-12-31'
    },
    { 
      id: 3,
      title: '표준용어 승인 절차 변경 공지', 
      category: '업무',
      content: '표준용어 승인 절차가 변경되어 공지합니다.',
      isPinned: false,
      isImportant: true,
      author: '데이터관리팀',
      views: 623,
      status: '게시중',
      createdDate: '2024-11-15',
      startDate: '2024-11-15',
      endDate: '2024-12-15'
    },
    { 
      id: 4,
      title: 'DataEye Meta 신규 기능 업데이트 안내', 
      category: '시스템',
      content: '신규 데이터 프로파일링 기능이 추가되었습니다.',
      isPinned: false,
      isImportant: false,
      author: '시스템관리자',
      views: 1089,
      status: '게시중',
      createdDate: '2024-11-10',
      startDate: '2024-11-10',
      endDate: '2024-12-10'
    },
    { 
      id: 5,
      title: '데이터 거버넌스 교육 안내', 
      category: '교육',
      content: '12월 데이터 거버넌스 교육 일정을 안내드립니다.',
      isPinned: false,
      isImportant: false,
      author: '교육담당',
      views: 445,
      status: '게시중',
      createdDate: '2024-11-08',
      startDate: '2024-11-08',
      endDate: '2024-12-08'
    },
    { 
      id: 6,
      title: '메타데이터 등록 가이드 배포', 
      category: '문서',
      content: '메타데이터 등록 가이드 문서를 배포합니다.',
      isPinned: false,
      isImportant: false,
      author: '데이터관리팀',
      views: 734,
      status: '게시중',
      createdDate: '2024-11-05',
      startDate: '2024-11-05',
      endDate: '2024-12-05'
    },
    { 
      id: 7,
      title: '11월 데이터 품질 평가 결과 공유', 
      category: '품질',
      content: '11월 데이터 품질 평가 결과를 공유합니다.',
      isPinned: false,
      isImportant: false,
      author: '품질관리팀',
      views: 892,
      status: '게시중',
      createdDate: '2024-11-01',
      startDate: '2024-11-01',
      endDate: '2024-11-30'
    },
    { 
      id: 8,
      title: '시스템 접근 권한 관리 정책 개정', 
      category: '보안',
      content: '시스템 접근 권한 관리 정책이 개정되었습니다.',
      isPinned: false,
      isImportant: true,
      author: '보안팀',
      views: 567,
      status: '게시중',
      createdDate: '2024-10-28',
      startDate: '2024-10-28',
      endDate: '2024-12-28'
    },
  ];

  const noticeStats = [
    { label: '전체 공지', value: '156', color: 'blue' as const },
    { label: '게시중', value: '89', color: 'green' as const },
    { label: '예약', value: '12', color: 'orange' as const },
    { label: '종료', value: '55', color: 'default' as const },
  ];

  const handleSort = (field: string) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const SortIcon = ({ field }: { field: string }) => {
    if (sortField !== field) {
      return <ArrowUpDown className="w-3.5 h-3.5 text-gray-400 ml-1" />;
    }
    return sortDirection === 'asc' ? (
      <ChevronUp className="w-3.5 h-3.5 ml-1" style={{ color: '#2B8DFF' }} />
    ) : (
      <ChevronDown className="w-3.5 h-3.5 ml-1" style={{ color: '#2B8DFF' }} />
    );
  };

  const handleExport = () => {
    const headers = ['제목', '카테고리', '작성자', '조회수', '상태', '등록일', '시작일', '종료일'];
    const csvContent = [
      headers.join(','),
      ...notices.map(notice => 
        [notice.title, notice.category, notice.author, notice.views, notice.status, notice.createdDate, notice.startDate, notice.endDate].join(',')
      )
    ].join('\n');

    const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `공지사항목록_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const totalPages = Math.ceil(notices.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const currentItems = notices.slice(startIndex, endIndex);

  return (
    <>
      <div className="p-6 space-y-6">
        {/* 헤더 영역 */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <IconBox icon={Bell} variant="blue" />
            <div>
              <h1 className="font-bold mb-1" style={{ color: '#202124' }}>공지사항 관리</h1>
              <p className="text-sm" style={{ color: '#5F6368' }}>시스템 공지사항을 관리합니다</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="secondary" size="md" onClick={handleExport}>
              <Download className="w-4 h-4" />
              내보내기
            </Button>
            <Button variant="primary" size="md" onClick={handleAddClick}>
              <Plus className="w-4 h-4" />
              공지 작성
            </Button>
          </div>
        </div>

        {/* 통계 카드 */}
        <div className="grid grid-cols-4 gap-4">
          {noticeStats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: index * 0.1 }}
            >
              <Card padding="lg" hover>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm mb-2" style={{ color: '#5F6368' }}>{stat.label}</p>
                    <p className="font-bold" style={{ fontSize: '24px', color: '#202124' }}>{stat.value}</p>
                  </div>
                  <div 
                    className="w-12 h-12 rounded-xl flex items-center justify-center"
                    style={{ 
                      backgroundColor: stat.color === 'blue' ? '#E8F0FE' :
                                     stat.color === 'green' ? '#E6F4EA' :
                                     stat.color === 'orange' ? '#FEF7E0' : '#F1F3F4'
                    }}
                  >
                    <Bell 
                      className="w-6 h-6"
                      style={{ 
                        color: stat.color === 'blue' ? '#1967D2' :
                               stat.color === 'green' ? '#137333' :
                               stat.color === 'orange' ? '#E37400' : '#5F6368'
                      }}
                    />
                  </div>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* 검색 및 필터 */}
        <Card padding="lg">
          <div className="flex items-center gap-4">
            <div className="flex-1 relative">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2" style={{ color: '#5F6368' }} />
              <input
                type="text"
                placeholder="제목, 내용, 작성자로 검색..."
                className="w-full pl-10 pr-4 py-2.5 rounded-lg border text-sm"
                style={{ 
                  borderColor: '#DADCE0',
                  backgroundColor: '#FFFFFF'
                }}
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Button variant="secondary" size="md">
              <Filter className="w-4 h-4" />
              필터
            </Button>
          </div>
        </Card>

        {/* 테이블 */}
        <Card padding="none">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr style={{ borderBottom: '2px solid #E8EAED' }}>
                  <th className="text-left px-6 py-4 text-sm font-medium" style={{ color: '#5F6368', backgroundColor: '#F8F9FA', width: '50px' }}>
                    <Pin className="w-4 h-4" />
                  </th>
                  <th className="text-left px-6 py-4 text-sm font-medium" style={{ color: '#5F6368', backgroundColor: '#F8F9FA' }}>
                    <button onClick={() => handleSort('title')} className="flex items-center hover:text-blue-600">
                      제목 <SortIcon field="title" />
                    </button>
                  </th>
                  <th className="text-left px-6 py-4 text-sm font-medium" style={{ color: '#5F6368', backgroundColor: '#F8F9FA' }}>
                    카테고리
                  </th>
                  <th className="text-left px-6 py-4 text-sm font-medium" style={{ color: '#5F6368', backgroundColor: '#F8F9FA' }}>
                    작성자
                  </th>
                  <th className="text-left px-6 py-4 text-sm font-medium" style={{ color: '#5F6368', backgroundColor: '#F8F9FA' }}>
                    <button onClick={() => handleSort('views')} className="flex items-center hover:text-blue-600">
                      조회수 <SortIcon field="views" />
                    </button>
                  </th>
                  <th className="text-left px-6 py-4 text-sm font-medium" style={{ color: '#5F6368', backgroundColor: '#F8F9FA' }}>
                    상태
                  </th>
                  <th className="text-left px-6 py-4 text-sm font-medium" style={{ color: '#5F6368', backgroundColor: '#F8F9FA' }}>
                    <button onClick={() => handleSort('createdDate')} className="flex items-center hover:text-blue-600">
                      등록일 <SortIcon field="createdDate" />
                    </button>
                  </th>
                </tr>
              </thead>
              <tbody>
                {currentItems.map((notice, index) => (
                  <motion.tr
                    key={notice.id}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ duration: 0.3, delay: index * 0.05 }}
                    onClick={() => handleNoticeClick(notice)}
                    className="cursor-pointer transition-colors"
                    style={{ borderBottom: '1px solid #E8EAED' }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.backgroundColor = '#F8F9FA';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.backgroundColor = 'transparent';
                    }}
                  >
                    <td className="px-6 py-4">
                      {notice.isPinned && (
                        <Pin className="w-4 h-4" style={{ color: '#E37400' }} fill="#E37400" />
                      )}
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-medium" style={{ color: '#202124' }}>
                          {notice.title}
                        </span>
                        {notice.isImportant && (
                          <Badge variant="error">중요</Badge>
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <Badge variant="default">{notice.category}</Badge>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-sm" style={{ color: '#5F6368' }}>{notice.author}</span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-1.5">
                        <Eye className="w-3.5 h-3.5" style={{ color: '#5F6368' }} />
                        <span className="text-sm" style={{ color: '#5F6368' }}>{notice.views.toLocaleString()}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <Badge variant={notice.status === '게시중' ? 'success' : 'default'}>
                        {notice.status}
                      </Badge>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-sm" style={{ color: '#5F6368' }}>{notice.createdDate}</span>
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>

        {/* Pagination */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-sm" style={{ color: '#5F6368' }}>페이지당 표시:</span>
            <select
              value={itemsPerPage}
              onChange={(e) => {
                setItemsPerPage(Number(e.target.value));
                setCurrentPage(1);
              }}
              className="px-3 py-1.5 rounded-lg border text-sm"
              style={{ borderColor: '#DADCE0', backgroundColor: '#FFFFFF' }}
            >
              <option value={10}>10개</option>
              <option value={20}>20개</option>
              <option value={50}>50개</option>
            </select>
          </div>
          <Pagination
            currentPage={currentPage}
            totalPages={totalPages}
            onPageChange={setCurrentPage}
          />
        </div>
      </div>

      <NoticeFormModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        mode={modalMode}
        initialData={selectedNotice}
      />
    </>
  );
}
