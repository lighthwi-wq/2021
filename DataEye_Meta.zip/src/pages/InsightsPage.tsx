import { TrendingUp } from 'lucide-react';
import { Card } from '../components/common/Card';
import { IconBox } from '../components/common/IconBox';

export function InsightsPage() {
  const insights = [
    { title: '사용자 참여도 피크', desc: '오후 2-4시 사이 사용자 활동이 45% 증가합니다', color: 'blue' },
    { title: '데이터 품질 경고', desc: '고객 데이터베이스에서 누락된 값 2.3% 감지되었습니다', color: 'red' },
    { title: '성능 개선', desc: '이번 주 API 응답 시간이 30% 개선되었습니다', color: 'green' },
    { title: '이상 징후 감지', desc: '금요일 저녁 트랜잭션이 비정상적으로 급증했습니다', color: 'orange' },
  ];

  return (
    <div className="space-y-4">
      <Card padding="lg">
        <div className="flex items-center gap-4 mb-6">
          <IconBox icon={TrendingUp} color="orange" size="lg" />
          <div>
            <h3 className="font-bold mb-1" style={{ color: '#202124' }}>AI 기반 인사이트</h3>
            <p style={{ color: '#5F6368' }}>데이터에서 트렌드와 패턴을 발견합니다</p>
          </div>
        </div>
        <div className="space-y-4">
          {insights.map((insight, idx) => (
            <div key={idx} className="p-4 rounded-xl border" style={{ backgroundColor: '#F9F9F9', borderColor: '#DADCE0' }}>
              <h4 className="font-bold mb-2" style={{ color: '#202124' }}>{insight.title}</h4>
              <p style={{ color: '#5F6368' }}>{insight.desc}</p>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
