import { createContext, useContext, ReactNode } from 'react';
import { MenuId } from '../types';

interface NavigationContextValue {
  activeMenu: MenuId;
  setActiveMenu: (menu: MenuId) => void;
  navigate: (menu: MenuId) => void;
}

const NavigationContext = createContext<NavigationContextValue | undefined>(undefined);

export function useNavigation() {
  const context = useContext(NavigationContext);
  if (!context) {
    throw new Error('useNavigation must be used within NavigationProvider');
  }
  return context;
}

interface NavigationProviderProps {
  children: ReactNode;
  value: NavigationContextValue;
}

export function NavigationProvider({ children, value }: NavigationProviderProps) {
  return (
    <NavigationContext.Provider value={value}>
      {children}
    </NavigationContext.Provider>
  );
}
