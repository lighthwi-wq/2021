# DataEye Meta - 프로젝트 구조

## 📁 디렉토리 구조

```
src/
├── config/                  # 애플리케이션 설정
│   ├── app.config.ts       # 앱 전역 설정
│   └── theme.config.ts     # 테마 설정
│
├── contexts/               # React Context API
│   ├── ThemeContext.tsx    # 다크모드 전역 상태
│   └── NavigationContext.tsx # 네비게이션 상태
│
├── hooks/                  # 커스텀 훅
│   ├── useDarkMode.ts      # 다크모드 관리
│   ├── useActiveMenu.ts    # 활성 메뉴 관리
│   ├── useLocalStorage.ts  # 로컬스토리지 연동
│   ├── useFilters.ts       # 필터링 로직
│   ├── useSearch.ts        # 검색 로직
│   ├── usePagination.ts    # 페이지네이션
│   └── useMediaQuery.ts    # 반응형 처리
│
├── types/                  # TypeScript 타입 정의
│   ├── index.ts           # 기본 타입
│   ├── components.ts      # 컴포넌트 타입
│   └── api.ts            # API 관련 타입
│
├── constants/             # 상수 데이터
│   ├── menuItems.ts      # 메뉴 항목
│   ├── statsData.ts      # 통계 데이터
│   ├── chartData.ts      # 차트 데이터
│   ├── activityData.ts   # 활동 로그
│   └── tableData.ts      # 테이블 데이터
│
├── utils/                # 유틸리티 함수
│   ├── cn.ts            # 클래스명 병합
│   ├── formatters.ts    # 포맷팅 유틸
│   └── validators.ts    # 유효성 검증
│
├── components/
│   ├── common/          # 재사용 가능한 공통 컴포넌트
│   │   ├── Button.tsx
│   │   ├── Card.tsx
│   │   ├── Badge.tsx
│   │   ├── IconBox.tsx
│   │   ├── Table/
│   │   ├── Input/
│   │   ├── Select/
│   │   ├── Spinner/
│   │   ├── Modal/
│   │   ├── Dropdown/
│   │   ├── Empty/
│   │   └── ErrorBoundary/
│   │
│   ├── layout/          # 레이아웃 컴포넌트
│   │   ├── Header.tsx
│   │   ├── Sidebar.tsx
│   │   ├── PageHeader.tsx
│   │   └── MainContent.tsx
│   │
│   ├── dashboard/       # 대시보드 전용 컴포넌트
│   │   ├── StatCard.tsx
│   │   ├── StatsGrid.tsx
│   │   ├── TrendChart.tsx
│   │   ├── ApiChart.tsx
│   │   ├── ActivityFeed.tsx
│   │   └── DataSourceTable.tsx
│   │
│   └── features/        # 기능별 컴포넌트
│       ├── FilterPanel/
│       ├── SearchBar/
│       └── Pagination/
│
├── pages/               # 페이지 컴포넌트
│   ├── DashboardPage.tsx
│   ├── AnalyticsPage.tsx
│   ├── DataSourcesPage.tsx
│   ├── InsightsPage.tsx
│   ├── ReportsPage.tsx
│   ├── MetadataPage.tsx
│   ├── UsersPage.tsx
│   └── SettingsPage.tsx
│
└── App.tsx             # 루트 컴포넌트
```

## 🎯 핵심 아키텍처 패턴

### 1. **Context API 패턴**
전역 상태 관리를 위해 Context API 사용:
- `ThemeContext`: 다크모드 상태
- `NavigationContext`: 현재 활성 메뉴

```tsx
// 사용 예시
const { isDarkMode, toggleDarkMode } = useTheme();
const { activeMenu, navigate } = useNavigation();
```

### 2. **Compound Components 패턴**
복잡한 컴포넌트를 작은 서브 컴포넌트로 분리:

```tsx
<Table>
  <Table.Header>
    <Table.HeadCell>이름</Table.HeadCell>
  </Table.Header>
  <Table.Body>
    <Table.Row>
      <Table.Cell>데이터</Table.Cell>
    </Table.Row>
  </Table.Body>
</Table>
```

### 3. **Custom Hooks 패턴**
재사용 가능한 로직을 훅으로 분리:

```tsx
// 필터링
const { filteredData, toggleFilter } = useFilters(data, filterFn);

// 검색
const { searchedData, handleSearch } = useSearch(data, searchFn);

// 페이지네이션
const { paginatedData, goToPage } = usePagination(data);
```

### 4. **Config 패턴**
설정을 중앙에서 관리:

```tsx
// app.config.ts
export const appConfig = {
  app: { name: 'DataEye Meta' },
  features: { darkMode: true },
  storage: { darkModeKey: 'dataeye-dark-mode' },
};
```

## 🔧 주요 기능

### 컴포넌트 재사용성
- ✅ Props 기반 커스터마이징
- ✅ 일관된 디자인 시스템
- ✅ TypeScript 타입 안정성

### 상태 관리
- ✅ Context API로 전역 상태
- ✅ Custom Hooks로 로컬 상태
- ✅ LocalStorage 동기화

### 유틸리티
- ✅ `cn()`: 클래스명 조합 헬퍼
- ✅ `formatters`: 숫자, 날짜, 통화 포맷팅
- ✅ `validators`: 입력값 검증

### 에러 처리
- ✅ ErrorBoundary로 컴포넌트 에러 캐치
- ✅ 사용자 친화적인 에러 UI

## 🎨 디자인 시스템

### 색상 체계
```tsx
primary: blue (파란색)
secondary: gray (회색)
success: green (초록색)
error: red (빨간색)
warning: orange (주황색)
```

### 사이즈 체계
```tsx
xs, sm, md, lg, xl
```

### 컴포넌트 변형
```tsx
Button: primary | secondary | ghost | outline | danger
Badge: success | error | warning | info | default
```

## 📝 사용 방법

### 새로운 페이지 추가

1. `/pages`에 페이지 컴포넌트 생성
2. `/types/index.ts`에 MenuId 추가
3. `/constants/menuItems.ts`에 메뉴 항목 추가
4. `/utils/pageConfig.ts`에 페이지 정보 추가
5. `/components/layout/MainContent.tsx`에 라우트 추가

### 새로운 공통 컴포넌트 추가

1. `/components/common`에 컴포넌트 생성
2. `/types/components.ts`에 타입 추가
3. Props 인터페이스 정의
4. 재사용 가능하게 구현

### 새로운 커스텀 훅 추가

1. `/hooks`에 훅 파일 생성
2. 로직을 캡슐화
3. 필요한 반환값 정의
4. 타입 안정성 보장

## 🚀 확장성

이 구조는 다음과 같은 확장이 용이합니다:

- ✅ 새로운 페이지 추가
- ✅ API 통합
- ✅ 상태 관리 라이브러리 교체
- ✅ 라우팅 라이브러리 추가
- ✅ 테스트 추가
- ✅ 스토리북 통합

## 🛠️ 개발 가이드

### 컴포넌트 작성 규칙

1. **단일 책임 원칙**: 하나의 컴포넌트는 하나의 역할만
2. **Props 타입 정의**: 모든 Props는 TypeScript로 타입 정의
3. **재사용성**: 가능한 한 재사용 가능하게 작성
4. **일관성**: 기존 컴포넌트의 패턴 따르기

### 스타일링 규칙

1. **Tailwind CSS 사용**: 인라인 유틸리티 클래스
2. **다크모드 지원**: 모든 스타일에 dark: 접두사
3. **반응형**: 모바일 우선 접근
4. **일관성**: 디자인 시스템의 색상/크기 사용

### 상태 관리 규칙

1. **로컬 우선**: 가능하면 로컬 상태 사용
2. **Context 최소화**: 꼭 필요한 경우만 Context
3. **Custom Hooks**: 복잡한 로직은 훅으로 분리
4. **불변성**: 상태 업데이트 시 불변성 유지

## 📚 참고 자료

- React Context API
- Custom Hooks Best Practices
- Compound Components Pattern
- TypeScript with React
- Tailwind CSS v4
