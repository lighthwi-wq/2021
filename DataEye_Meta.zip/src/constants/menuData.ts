import { MenuId } from '../types';

export type { MenuId };

export const pageTitles: Record<MenuId, string> = {
  'demo': '🎨 Interactive Demo Showcase',
  'dashboard': '대시보드',
  'biz-meta': '비즈메타',
  'business-area': '업무 영역 관리',
  'business-process': '업무 프로세스 관리',
  'business-term': '업무 용어 관리',
  'data-linkage': '데이터 연계 관리',
  'data-standard': '데이터 표준 관리',
  'standard-word': '표준 단어 관리',
  'standard-domain': '표준 도메인 관리',
  'standard-term': '표준 용어 관리',
  'standard-code': '표준 코드 관리',
  'business-glossary': '비즈니스 용어 사전',
  'data-model': '데이터 모델 관리',
  'subject-area': '주제 영역 관리',
  'logical-model': '논리 모델 관리',
  'physical-model': '물리 모델 관리',
  'db-schema': 'DB 스키마 관리',
  'data-lineage': '데이터 흐름(Lineage)',
  'impact-analysis': '영향도 분석',
  'data-quality': '데이터 품질 관리',
  'quality-rule': '품질 지표(Rule) 관리',
  'profiling': '프로파일링',
  'quality-evaluation': '정기 품질 평가',
  'error-data': '오류 데이터 로그',
  'improvement': '개선 활동 관리',
  'workflow': '데이터 요청/승인',
  'new-request': '신규 신청',
  'change-management': '변경 관리',
  'admin': '관리자',
  'user-management': '사용자/권한 관리',
  'menu-management': '메뉴 관리',
  'system-code': '시스템 코드 관리',
  'notice': '공지사항 관리',
};

export const pageDescriptions: Record<MenuId, string> = {
  'demo': 'Explore innovative UX features: Term Builder, Detail View, and DQM Dashboard',
  'dashboard': '시스템의 전체 현황과 핵심 지표를 확인하세요',
  'biz-meta': '비즈니스 메타데이터를 체계적으로 관리하세요',
  'business-area': '조직의 업무 영역을 정의하고 관리합니다',
  'business-process': '업무 프로세스를 등록하고 흐름을 설계합니다',
  'business-term': '업무 용어를 추가하고 중복/유사 용어를 관리합니다',
  'data-linkage': '업무용어와 데이터를 연계 매핑합니다',
  'data-standard': '데이터 표준화 체계를 관리하세요',
  'standard-word': '업무에서 사용하는 최소 단위 단어를 관리하세요',
  'standard-domain': '데이터 타입과 길이를 정의하세요',
  'standard-term': '표준 단어 조합으로 구성된 용어를 관리하세요',
  'standard-code': '공통 코드 및 코드값을 정의하세요',
  'business-glossary': '현업이 이해하기 쉬운 업무 용어 설명서',
  'data-model': '실제 DB 스키마와 데이터 흐름을 관리하세요',
  'subject-area': '업무별 폴더 구조를 관리하세요',
  'logical-model': 'ERD 기준의 엔터티/속성 정보를 관리하세요',
  'physical-model': 'ERD 기준의 테이블/컬럼 정보를 관리하세요',
  'db-schema': '실제 적재된 DB 정보를 동기화하세요',
  'data-lineage': '데이터의 생성부터 소멸까지의 흐름을 시각화하세요',
  'impact-analysis': '특정 컬럼 변경 시 영향을 받는 항목을 추적하세요',
  'data-quality': '정의된 표준과 모델대로 데이터가 관리되는지 감시하세요',
  'quality-rule': '체크할 품질 규칙을 정의하세요',
  'profiling': '실제 데이터 분포를 자동 분석하세요',
  'quality-evaluation': '월/분기별 품질 측정 스케줄을 관리하세요',
  'error-data': '품질 규칙을 위반한 데이터 목록을 조회하세요',
  'improvement': '오류 데이터 담당자 지정 및 조치 결과를 등록하세요',
  'workflow': '표준/모델 신규 신청 및 변경 관리',
  'new-request': '새로운 테이블이나 용어를 신청하세요',
  'change-management': '기존 구조 변경 이력을 관리하세요',
  'admin': '시스템 관리자 기능',
  'user-management': '사용자별 권한(R/W)을 설정하세요',
  'menu-management': '메뉴 구조를 변경하세요',
  'system-code': '시스템 코드를 관리하세요',
  'notice': '공지사항을 등록하고 관리하세요',
};

export const pageBreadcrumbs: Record<MenuId, { label: string; active?: boolean }[]> = {
  'demo': [
    { label: 'Home' },
    { label: 'Interactive Demo', active: true }
  ],
  'dashboard': [
    { label: 'Home' },
    { label: '대시보드', active: true }
  ],
  'biz-meta': [
    { label: 'Home' },
    { label: '비즈메타', active: true }
  ],
  'business-area': [
    { label: 'Home' },
    { label: '비즈메타' },
    { label: '업무 영역 관리', active: true }
  ],
  'business-process': [
    { label: 'Home' },
    { label: '비즈메타' },
    { label: '업무 프로세스 관리', active: true }
  ],
  'business-term': [
    { label: 'Home' },
    { label: '비즈메타' },
    { label: '업무 용어 관리', active: true }
  ],
  'data-linkage': [
    { label: 'Home' },
    { label: '비즈메타' },
    { label: '데이터 연계 관리', active: true }
  ],
  'data-standard': [
    { label: 'Home' },
    { label: '데이터 표준 관리', active: true }
  ],
  'standard-word': [
    { label: 'Home' },
    { label: '데이터 표준 관리' },
    { label: '표준 단어 관리', active: true }
  ],
  'standard-domain': [
    { label: 'Home' },
    { label: '데이터 표준 관리' },
    { label: '표준 도메인 관리', active: true }
  ],
  'standard-term': [
    { label: 'Home' },
    { label: '데이터 표준 관리' },
    { label: '표준 용어 관리', active: true }
  ],
  'standard-code': [
    { label: 'Home' },
    { label: '데이터 표준 관리' },
    { label: '표준 코드 관리', active: true }
  ],
  'business-glossary': [
    { label: 'Home' },
    { label: '데이터 표준 관리' },
    { label: '비즈니스 용어 사전', active: true }
  ],
  'data-model': [
    { label: 'Home' },
    { label: '데이터 모델 관리', active: true }
  ],
  'subject-area': [
    { label: 'Home' },
    { label: '데이터 모델 관리' },
    { label: '주제 영역 관리', active: true }
  ],
  'logical-model': [
    { label: 'Home' },
    { label: '데이터 모델 관리' },
    { label: '논리 모델 관리', active: true }
  ],
  'physical-model': [
    { label: 'Home' },
    { label: '데이터 모델 관리' },
    { label: '물리 모델 관리', active: true }
  ],
  'db-schema': [
    { label: 'Home' },
    { label: '데이터 모델 관리' },
    { label: 'DB 스키마 관리', active: true }
  ],
  'data-lineage': [
    { label: 'Home' },
    { label: '데이터 모델 관리' },
    { label: '데이터 흐름(Lineage)', active: true }
  ],
  'impact-analysis': [
    { label: 'Home' },
    { label: '데이터 모델 관리' },
    { label: '영향도 분석', active: true }
  ],
  'data-quality': [
    { label: 'Home' },
    { label: '데이터 품질 관리', active: true }
  ],
  'quality-rule': [
    { label: 'Home' },
    { label: '데이터 품질 관리' },
    { label: '품질 지표(Rule) 관리', active: true }
  ],
  'profiling': [
    { label: 'Home' },
    { label: '데이터 품질 관리' },
    { label: '프로파일링', active: true }
  ],
  'quality-evaluation': [
    { label: 'Home' },
    { label: '데이터 품질 관리' },
    { label: '정기 품질 평가', active: true }
  ],
  'error-data': [
    { label: 'Home' },
    { label: '데이터 품질 관리' },
    { label: '오류 데이터 로그', active: true }
  ],
  'improvement': [
    { label: 'Home' },
    { label: '데이터 품질 관리' },
    { label: '개선 활동 관리', active: true }
  ],
  'workflow': [
    { label: 'Home' },
    { label: '데이터 요청/승인', active: true }
  ],
  'new-request': [
    { label: 'Home' },
    { label: '데이터 요청/승인' },
    { label: '신규 신청', active: true }
  ],
  'change-management': [
    { label: 'Home' },
    { label: '데이터 요청/승인' },
    { label: '변경 관리', active: true }
  ],
  'admin': [
    { label: 'Home' },
    { label: '관리자', active: true }
  ],
  'user-management': [
    { label: 'Home' },
    { label: '관리자' },
    { label: '사용자/권한 관리', active: true }
  ],
  'menu-management': [
    { label: 'Home' },
    { label: '관리자' },
    { label: '메뉴 관리', active: true }
  ],
  'system-code': [
    { label: 'Home' },
    { label: '관리자' },
    { label: '시스템 코드 관리', active: true }
  ],
  'notice': [
    { label: 'Home' },
    { label: '관리자' },
    { label: '공지사항 관리', active: true }
  ],
};