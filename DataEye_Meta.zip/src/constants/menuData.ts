import { MenuId } from '../types';

export type { MenuId };

export const pageTitles: Record<MenuId, string> = {
  'dashboard': '대시보드',
  'data-standardization': '데이터 표준화',
  'standard-term-management': '표준용어 관리',
  'menu-management': '메뉴 관리',
  'deployment-management': '배포 관리',
  'standard-adequacy-management': '표준 적정성 관리',
  'biz-meta': '업무 메타데이터',
  'business-area-management': '업무 영역 관리',
  'business-process-management': '업무 프로세스 관리',
  'business-term-management': '업무용어 관리',
  'data-linkage-management': '데이터 연계 관리',
  'data-quality': '데이터 품질',
  'quality-rule-management': '품질 규칙 관리',
  'quality-diagnosis-management': '품질 진단 관리',
  'quality-violation-management': '품질 위반 관리',
  'action-management': '조치 관리',
  'common-management': '공통 관리',
  'settings': '설정',
};

export const pageDescriptions: Record<MenuId, string> = {
  'dashboard': '전체 시스템 현황 및 주요 지표를 확인하세요',
  'data-standardization': '데이터 표준화 현황을 관리하세요',
  'standard-term-management': '표준용어를 등록하고 관리하세요',
  'menu-management': '시스템 메뉴를 관리하세요',
  'deployment-management': '배포 ��력을 관리하세요',
  'standard-adequacy-management': '표준 적정성을 관리하세요',
  'biz-meta': '업무 메타데이터를 관리하세요',
  'business-area-management': '업무 영역을 등록하고 관리하세요',
  'business-process-management': '업무 프로세스를 관리하세요',
  'business-term-management': '업무용어를 등록하고 관리하세요',
  'data-linkage-management': '데이터 연계 현황을 관리하세요',
  'data-quality': '데이터 품질 현황을 확인하세요',
  'quality-rule-management': '품질 규칙을 등록하고 관리하세요',
  'quality-diagnosis-management': '품질 진단 결과를 확인하세요',
  'quality-violation-management': '품질 위반 사항을 관리하세요',
  'action-management': '품질 위반 조치 사항을 관리하세요',
  'common-management': '공통 코드 및 설정을 관리하세요',
  'settings': '시스템 설정을 관리하세요',
};

export const pageBreadcrumbs: Record<MenuId, { label: string; active?: boolean }[]> = {
  'dashboard': [
    { label: 'Home' },
    { label: '대시보드', active: true }
  ],
  'data-standardization': [
    { label: 'Home' },
    { label: '데이터 표준화', active: true }
  ],
  'standard-term-management': [
    { label: 'Home' },
    { label: '데이터 표준화' },
    { label: '표준용어 관리', active: true }
  ],
  'menu-management': [
    { label: 'Home' },
    { label: '데이터 표준화' },
    { label: '메뉴 관리', active: true }
  ],
  'deployment-management': [
    { label: 'Home' },
    { label: '데이터 표준화' },
    { label: '배포 관리', active: true }
  ],
  'standard-adequacy-management': [
    { label: 'Home' },
    { label: '데이터 표준화' },
    { label: '표준 적정성 관리', active: true }
  ],
  'biz-meta': [
    { label: 'Home' },
    { label: '업무 메타데이터', active: true }
  ],
  'business-area-management': [
    { label: 'Home' },
    { label: '업무 메타데이터' },
    { label: '업무 영역 관리', active: true }
  ],
  'business-process-management': [
    { label: 'Home' },
    { label: '업무 메타데이터' },
    { label: '업무 프로세스 관리', active: true }
  ],
  'business-term-management': [
    { label: 'Home' },
    { label: '업무 메타데이터' },
    { label: '업무용어 관리', active: true }
  ],
  'data-linkage-management': [
    { label: 'Home' },
    { label: '업무 메타데이터' },
    { label: '데이터 연계 관리', active: true }
  ],
  'data-quality': [
    { label: 'Home' },
    { label: '데이터 품질', active: true }
  ],
  'quality-rule-management': [
    { label: 'Home' },
    { label: '데이터 품질' },
    { label: '품질 규칙 관리', active: true }
  ],
  'quality-diagnosis-management': [
    { label: 'Home' },
    { label: '데이터 품질' },
    { label: '품질 진단 관리', active: true }
  ],
  'quality-violation-management': [
    { label: 'Home' },
    { label: '데이터 품질' },
    { label: '품질 위반 관리', active: true }
  ],
  'action-management': [
    { label: 'Home' },
    { label: '데이터 품질' },
    { label: '조치 관리', active: true }
  ],
  'common-management': [
    { label: 'Home' },
    { label: '공통 관리', active: true }
  ],
  'settings': [
    { label: 'Home' },
    { label: '설정', active: true }
  ],
};