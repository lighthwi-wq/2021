import { Database, TrendingUp, Users, Activity } from 'lucide-react';
import { StatCard } from '../types';

export const stats: StatCard[] = [
  {
    label: '총 데이터 소스',
    value: '24',
    change: '+12.5%',
    trend: 'up',
    icon: Database,
    color: 'blue',
  },
  {
    label: 'API 요청',
    value: '1.2M',
    change: '+8.2%',
    trend: 'up',
    icon: TrendingUp,
    color: 'green',
  },
  {
    label: '활성 사용자',
    value: '8,549',
    change: '-2.4%',
    trend: 'down',
    icon: Users,
    color: 'purple',
  },
  {
    label: '평균 응답 시간',
    value: '124ms',
    change: '+5.1%',
    trend: 'up',
    icon: Activity,
    color: 'orange',
  },
];
