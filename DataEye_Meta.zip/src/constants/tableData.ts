import { DataRow } from '../types';

export const tableData: DataRow[] = [
  { 
    id: 'DS-001', 
    name: '고객 데이터베이스', 
    source: 'PostgreSQL', 
    status: 'active', 
    records: '125,483', 
    lastSync: '2분 전' 
  },
  { 
    id: 'DS-002', 
    name: '제품 카탈로그', 
    source: 'MongoDB', 
    status: 'syncing', 
    records: '8,392', 
    lastSync: '진행 중' 
  },
  { 
    id: 'DS-003', 
    name: '주문 기록', 
    source: 'MySQL', 
    status: 'active', 
    records: '45,892', 
    lastSync: '5분 전' 
  },
  { 
    id: 'DS-004', 
    name: '사용자 행동 로그', 
    source: 'BigQuery', 
    status: 'error', 
    records: '2,456,789', 
    lastSync: '30분 전' 
  },
  { 
    id: 'DS-005', 
    name: '재고 관리', 
    source: 'Redis', 
    status: 'active', 
    records: '3,245', 
    lastSync: '1분 전' 
  },
];
