import { 
  LayoutDashboard, 
  FileCheck2,
  Briefcase,
  ShieldCheck,
  FolderCog,
  Settings,
  BookOpen,
  Menu,
  Send,
  CheckCircle,
  Building2,
  Workflow,
  BookText,
  GitBranch,
  ShieldAlert,
  Activity,
  AlertTriangle,
  ClipboardCheck
} from 'lucide-react';
import { MenuItem } from '../types';

export const menuItems: MenuItem[] = [
  { id: 'dashboard', label: '대시보드', icon: LayoutDashboard },
  { 
    id: 'data-standardization', 
    label: '데이터 표준화', 
    icon: FileCheck2,
    children: [
      { id: 'standard-term-management', label: '표준용어관리', icon: BookOpen },
      { id: 'menu-management', label: '메뉴관리', icon: Menu },
      { id: 'deployment-management', label: '배포관리', icon: Send },
      { id: 'standard-adequacy-management', label: '표준 적정성 관리', icon: CheckCircle },
    ]
  },
  { 
    id: 'biz-meta', 
    label: '비즈메타', 
    icon: Briefcase,
    children: [
      { id: 'business-area-management', label: '업무 영역 관리', icon: Building2 },
      { id: 'business-process-management', label: '업무 프로세스 관리', icon: Workflow },
      { id: 'business-term-management', label: '업무 용어 관리', icon: BookText },
      { id: 'data-linkage-management', label: '데이터 연계 관리', icon: GitBranch },
    ]
  },
  { 
    id: 'data-quality', 
    label: '데이터 품질(DQM)', 
    icon: ShieldCheck,
    children: [
      { id: 'quality-rule-management', label: '품질 규칙 관리', icon: ShieldAlert },
      { id: 'quality-diagnosis-management', label: '품질 진단 관리', icon: Activity },
      { id: 'quality-violation-management', label: '품질 위반 관리', icon: AlertTriangle },
      { id: 'action-management', label: '조치관리', icon: ClipboardCheck },
    ]
  },
  { id: 'common-management', label: '공통관리', icon: FolderCog },
  { id: 'settings', label: '설정', icon: Settings },
];