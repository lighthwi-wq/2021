import { 
  LayoutDashboard, 
  FileText,
  Database,
  ShieldCheck,
  GitPullRequest,
  Settings,
  BookOpen,
  Box,
  Tag,
  BookText,
  Users,
  FolderTree,
  Table2,
  Server,
  GitBranch,
  TrendingUp,
  ShieldAlert,
  ScanSearch,
  Calendar,
  AlertTriangle,
  ClipboardCheck,
  FilePlus,
  History,
  UserCog,
  Layout,
  Bell,
  Briefcase,
  Workflow
} from 'lucide-react';
import { MenuItem } from '../types';

export const menuItems: MenuItem[] = [
  { 
    id: 'dashboard', 
    label: '대시보드', 
    icon: LayoutDashboard 
  },
  { 
    id: 'data-standard', 
    label: '데이터 표준 관리', 
    icon: FileText,
    children: [
      { id: 'standard-word', label: '표준 단어 관리', icon: BookOpen },
      { id: 'standard-domain', label: '표준 도메인 관리', icon: Box },
      { id: 'standard-term', label: '표준 용어 관리', icon: Tag },
      { id: 'standard-code', label: '표준 코드 관리', icon: Tag },
      { id: 'business-glossary', label: '비즈니스 용어 사전', icon: BookText },
    ]
  },
  { 
    id: 'biz-meta', 
    label: '비즈메타', 
    icon: Briefcase,
    children: [
      { id: 'business-area', label: '업무 영역 관리', icon: Briefcase },
      { id: 'business-process', label: '업무 프로세스 관리', icon: Workflow },
      { id: 'business-term', label: '업무 용어 관리', icon: BookText },
      { id: 'data-linkage', label: '데이터 연계 관리', icon: GitBranch },
    ]
  },
  { 
    id: 'data-model', 
    label: '데이터 모델 관리', 
    icon: Database,
    children: [
      { id: 'subject-area', label: '주제 영역 관리', icon: FolderTree },
      { id: 'logical-model', label: '논리 모델 관리', icon: Table2 },
      { id: 'physical-model', label: '물리 모델 관리', icon: Table2 },
      { id: 'db-schema', label: 'DB 스키마 관리', icon: Server },
      { id: 'data-lineage', label: '데이터 흐름(Lineage)', icon: GitBranch },
      { id: 'impact-analysis', label: '영향도 분석', icon: TrendingUp },
    ]
  },
  { 
    id: 'data-quality', 
    label: '데이터 품질 관리', 
    icon: ShieldCheck,
    children: [
      { id: 'quality-rule', label: '품질 지표(Rule) 관리', icon: ShieldAlert },
      { id: 'profiling', label: '프로파일링', icon: ScanSearch },
      { id: 'quality-evaluation', label: '정기 품질 평가', icon: Calendar },
      { id: 'error-data', label: '오류 데이터 로그', icon: AlertTriangle },
      { id: 'improvement', label: '개선 활동 관리', icon: ClipboardCheck },
    ]
  },
  { 
    id: 'workflow', 
    label: '데이터 요청/승인', 
    icon: GitPullRequest,
    children: [
      { id: 'new-request', label: '신규 신청', icon: FilePlus },
      { id: 'change-management', label: '변경 관리', icon: History },
    ]
  },
  { 
    id: 'admin', 
    label: '관리자', 
    icon: Settings,
    children: [
      { id: 'user-management', label: '사용자/권한 관리', icon: UserCog },
      { id: 'menu-management', label: '메뉴 관리', icon: Layout },
      { id: 'system-code', label: '시스템 코드 관리', icon: Tag },
      { id: 'notice', label: '공지사항 관리', icon: Bell },
    ]
  },
];