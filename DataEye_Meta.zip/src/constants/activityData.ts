import { Upload, RefreshCw, AlertCircle, CheckCircle } from 'lucide-react';
import { Activity } from '../types';

export const activities: Activity[] = [
  {
    title: '데이터 업로드 완료',
    description: 'customer_data.csv 파일이 성공적으로 처리되었습니다',
    time: '2분 전',
    type: 'upload',
    icon: Upload,
  },
  {
    title: '자동 동기화 실행',
    description: 'PostgreSQL 데이터베이스와 동기화가 완료되었습니다',
    time: '15분 전',
    type: 'sync',
    icon: RefreshCw,
  },
  {
    title: '연결 오류 감지',
    description: 'MongoDB 연결 재시도 중입니다',
    time: '1시간 전',
    type: 'error',
    icon: AlertCircle,
  },
  {
    title: '스키마 업데이트',
    description: 'orders 테이블 스키마가 업데이트되었습니다',
    time: '2시간 전',
    type: 'update',
    icon: CheckCircle,
  },
];
