// 데이터 거버넌스 전문가를 위한 모던 디자인 시스템
// 신뢰성, 정확성, 전문성을 나타내는 인디고/슬레이트 블루 기반 팔레트

export const colors = {
  // Primary Colors - 메뉴 활성 블루 (전문성과 신뢰성)
  primary: '#2B8DFF',
  primaryHover: '#1E7FEF',
  primaryLight: 'rgba(43, 141, 255, 0.08)',
  
  // Status Colors
  success: '#F59E0B', // 골드/앰버 - 성공과 성장
  successLight: 'rgba(245, 158, 11, 0.08)',
  warning: '#D97706', // 앰버 - 주의와 중요도
  warningLight: 'rgba(217, 119, 6, 0.08)',
  error: '#DC2626', // 레드 - 오류와 위험
  errorLight: 'rgba(220, 38, 38, 0.08)',
  info: '#0284C7', // 사파이어 블루 - 통찰력
  infoLight: 'rgba(2, 132, 199, 0.08)',
  
  // Secondary - 스카이 블루 (혁신과 명료성)
  secondary: '#0EA5E9',
  secondaryLight: 'rgba(14, 165, 233, 0.08)',
  
  // Neutral Colors
  background: '#F9FAFB',
  surface: '#FFFFFF',
  hover: '#F3F4F6',
  inputBg: '#F9FAFB',
  bgPrimary: '#FFFFFF',
  bgSecondary: '#F8FAFC',
  contentBackground: '#F9FAFB',
  
  // Border Colors
  border: '#E5E7EB',
  borderHover: '#2B8DFF',
  divider: '#E5E7EB',
  
  // Text Colors
  textPrimary: '#111827',
  textSecondary: '#6B7280',
  textDisabled: '#9CA3AF',
  textOnPrimary: '#FFFFFF',
  
  // Chart Colors - 데이터 거버넌스 전문 팔레트
  chart1: '#2B8DFF', // 메뉴 활성 블루
  chart2: '#F59E0B', // 골드/앰버 (노란색 계열)
  chart3: '#0EA5E9', // 스카이
  chart4: '#D97706', // 다크 앰버
  chart5: '#F97316', // 오렌지
  chart6: '#EC4899', // 핑크
};

export const shadows = {
  card: '0 1px 3px rgba(0, 0, 0, 0.05), 0 1px 2px rgba(0, 0, 0, 0.05)',
  cardHover: '0 4px 12px rgba(0, 0, 0, 0.08), 0 2px 6px rgba(0, 0, 0, 0.04)',
  dropdown: '0 8px 16px rgba(0, 0, 0, 0.12), 0 2px 8px rgba(0, 0, 0, 0.08)',
  modal: '0 16px 32px rgba(0, 0, 0, 0.16), 0 4px 12px rgba(0, 0, 0, 0.08)',
};

export const spacing = {
  xs: '4px',
  sm: '8px',
  md: '16px',
  lg: '24px',
  xl: '32px',
  xxl: '48px',
};

export const borderRadius = {
  sm: '6px',
  md: '8px',
  lg: '12px',
  xl: '16px',
  full: '9999px',
};

export const transitions = {
  fast: '0.15s ease-in-out',
  normal: '0.2s ease-in-out',
  slow: '0.3s ease-in-out',
};