// DataEye Meta - Light Mode Design System
// Award-winning futuristic Enterprise Data Governance Platform

export const colors = {
  // Core Background - Clean Light
  background: '#FFFFFF',
  backgroundSecondary: '#F8F9FA',
  backgroundTertiary: '#F1F3F5',
  
  // Primary Action - Professional Blue
  primary: '#0066FF',
  primaryHover: '#0052CC',
  primaryLight: 'rgba(0, 102, 255, 0.08)',
  primaryGlow: 'rgba(0, 102, 255, 0.2)',
  
  // Highlight/Active - Purple
  accent: '#7C3AED',
  accentHover: '#6D28D9',
  accentLight: 'rgba(124, 58, 237, 0.08)',
  accentGlow: 'rgba(124, 58, 237, 0.2)',
  
  // Success/Positive - Green
  success: '#10B981',
  successHover: '#059669',
  successLight: 'rgba(16, 185, 129, 0.08)',
  successGlow: 'rgba(16, 185, 129, 0.2)',
  
  // Critical/Error - Red
  error: '#EF4444',
  errorHover: '#DC2626',
  errorLight: 'rgba(239, 68, 68, 0.08)',
  errorGlow: 'rgba(239, 68, 68, 0.2)',
  
  // Warning - Orange
  warning: '#F59E0B',
  warningHover: '#D97706',
  warningLight: 'rgba(245, 158, 11, 0.08)',
  warningGlow: 'rgba(245, 158, 11, 0.2)',
  
  // Info - Cyan
  info: '#06B6D4',
  infoLight: 'rgba(6, 182, 212, 0.08)',
  
  // Surface & Glass
  surface: 'rgba(255, 255, 255, 0.8)',
  surfaceHover: 'rgba(248, 249, 250, 0.9)',
  glass: 'rgba(255, 255, 255, 0.7)',
  glassBorder: 'rgba(0, 0, 0, 0.08)',
  glassHover: 'rgba(255, 255, 255, 0.9)',
  
  // Border
  border: 'rgba(0, 0, 0, 0.08)',
  borderHover: 'rgba(0, 102, 255, 0.3)',
  divider: 'rgba(0, 0, 0, 0.06)',
  
  // Text
  textPrimary: '#1F2937',
  textSecondary: '#6B7280',
  textTertiary: '#9CA3AF',
  textDisabled: '#D1D5DB',
  textOnPrimary: '#FFFFFF',
  
  // Input
  inputBg: '#FFFFFF',
  hover: '#F3F4F6',
  
  // Chart Colors - Professional Palette
  chart1: '#0066FF',
  chart2: '#10B981',
  chart3: '#7C3AED',
  chart4: '#EF4444',
  chart5: '#F59E0B',
  chart6: '#06B6D4',
  
  // Block Colors - For Term Builder
  blockBlue: '#0066FF',
  blockGreen: '#10B981',
  blockPurple: '#7C3AED',
  blockOrange: '#F59E0B',
  blockPink: '#EC4899',
  blockCyan: '#06B6D4',
};

// Advanced Glassmorphism Effects - Light Mode
export const glassmorphism = {
  card: {
    background: 'rgba(255, 255, 255, 0.8)',
    backdropFilter: 'blur(24px) saturate(180%)',
    border: '1px solid rgba(0, 0, 0, 0.08)',
    boxShadow: '0 4px 20px rgba(0, 0, 0, 0.08)',
  },
  cardHover: {
    background: 'rgba(255, 255, 255, 0.95)',
    backdropFilter: 'blur(28px) saturate(200%)',
    border: '1px solid rgba(0, 102, 255, 0.2)',
    boxShadow: '0 8px 30px rgba(0, 102, 255, 0.12)',
  },
  sidebar: {
    background: 'rgba(255, 255, 255, 0.9)',
    backdropFilter: 'blur(40px) saturate(180%)',
    border: '1px solid rgba(0, 0, 0, 0.08)',
    boxShadow: '4px 0 20px rgba(0, 0, 0, 0.05)',
  },
  modal: {
    background: 'rgba(255, 255, 255, 0.98)',
    backdropFilter: 'blur(60px) saturate(200%)',
    border: '1px solid rgba(0, 0, 0, 0.1)',
    boxShadow: '0 20px 60px rgba(0, 0, 0, 0.15)',
  },
  drawer: {
    background: 'rgba(255, 255, 255, 0.95)',
    backdropFilter: 'blur(50px) saturate(180%)',
    border: '1px solid rgba(0, 0, 0, 0.08)',
    boxShadow: '-8px 0 40px rgba(0, 0, 0, 0.1)',
  },
};

// Soft Glow Effects - Light Mode
export const glows = {
  primary: '0 4px 20px rgba(0, 102, 255, 0.15)',
  accent: '0 4px 20px rgba(124, 58, 237, 0.15)',
  success: '0 4px 20px rgba(16, 185, 129, 0.15)',
  error: '0 4px 20px rgba(239, 68, 68, 0.15)',
  soft: '0 2px 10px rgba(0, 102, 255, 0.1)',
};

// Shadows for depth
export const shadows = {
  card: '0 2px 8px rgba(0, 0, 0, 0.08)',
  cardHover: '0 8px 24px rgba(0, 0, 0, 0.12)',
  dropdown: '0 12px 32px rgba(0, 0, 0, 0.15)',
  modal: '0 24px 60px rgba(0, 0, 0, 0.2)',
};

export const spacing = {
  xs: '4px',
  sm: '8px',
  md: '16px',
  lg: '24px',
  xl: '32px',
  xxl: '48px',
};

export const borderRadius = {
  sm: '8px',
  md: '12px',
  lg: '16px',
  xl: '20px',
  xxl: '24px',
  full: '9999px',
};

export const transitions = {
  fast: '0.15s cubic-bezier(0.4, 0, 0.2, 1)',
  normal: '0.25s cubic-bezier(0.4, 0, 0.2, 1)',
  slow: '0.4s cubic-bezier(0.4, 0, 0.2, 1)',
  bounce: '0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55)',
  smooth: '0.3s cubic-bezier(0.4, 0, 0.2, 1)',
};
