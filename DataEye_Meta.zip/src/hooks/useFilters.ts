import { useState, useCallback, useMemo } from 'react';

export interface FilterState {
  [key: string]: string[];
}

export function useFilters<T>(
  data: T[],
  filterFn: (item: T, filters: FilterState) => boolean
) {
  const [filters, setFilters] = useState<FilterState>({});
  const [isOpen, setIsOpen] = useState(false);

  const toggleFilter = useCallback((type: string, value: string) => {
    setFilters(prev => ({
      ...prev,
      [type]: prev[type]?.includes(value)
        ? prev[type].filter(v => v !== value)
        : [...(prev[type] || []), value]
    }));
  }, []);

  const clearFilters = useCallback(() => {
    setFilters({});
  }, []);

  const activeFilterCount = useMemo(() => {
    return Object.values(filters).reduce((acc, arr) => acc + arr.length, 0);
  }, [filters]);

  const filteredData = useMemo(() => {
    if (activeFilterCount === 0) return data;
    return data.filter(item => filterFn(item, filters));
  }, [data, filters, filterFn, activeFilterCount]);

  return {
    filters,
    isOpen,
    setIsOpen,
    toggleFilter,
    clearFilters,
    activeFilterCount,
    filteredData,
  };
}
