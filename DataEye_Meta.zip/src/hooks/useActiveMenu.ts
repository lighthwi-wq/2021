import { useState } from 'react';
import { MenuId } from '../types';

export function useActiveMenu(initialMenu: MenuId = 'dashboard') {
  const [activeMenu, setActiveMenu] = useState<MenuId>(initialMenu);

  return { activeMenu, setActiveMenu };
}
