import { useState, useMemo } from 'react';

interface UsePaginationProps<T> {
  data: T[];
  initialPage?: number;
  initialItemsPerPage?: number;
}

/**
 * usePagination - 페이지네이션 로직을 관리하는 커스텀 훅
 * 
 * @example
 * const { paginatedData, currentPage, itemsPerPage, totalPages, setCurrentPage, setItemsPerPage } = usePagination({
 *   data: users,
 *   initialPage: 1,
 *   initialItemsPerPage: 10,
 * });
 */
export function usePagination<T>({
  data,
  initialPage = 1,
  initialItemsPerPage = 10,
}: UsePaginationProps<T>) {
  const [currentPage, setCurrentPage] = useState(initialPage);
  const [itemsPerPage, setItemsPerPage] = useState(initialItemsPerPage);

  const totalPages = Math.ceil(data.length / itemsPerPage);

  const paginatedData = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    return data.slice(startIndex, endIndex);
  }, [data, currentPage, itemsPerPage]);

  // 데이터가 변경되면 첫 페이지로 리셋
  useMemo(() => {
    if (currentPage > totalPages && totalPages > 0) {
      setCurrentPage(1);
    }
  }, [data.length, totalPages, currentPage]);

  return {
    paginatedData,
    currentPage,
    itemsPerPage,
    totalPages,
    totalItems: data.length,
    setCurrentPage,
    setItemsPerPage,
  };
}
