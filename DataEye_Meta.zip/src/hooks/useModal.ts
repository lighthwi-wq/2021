import { useState, useCallback } from 'react';

interface UseModalProps<T> {
  initialMode?: 'create' | 'edit';
}

/**
 * useModal - 모달 상태 관리를 위한 커스텀 훅
 * 
 * @example
 * const { isOpen, mode, selectedItem, openModal, closeModal, openCreateModal, openEditModal } = useModal<User>();
 * 
 * // 생성 모달 열기
 * openCreateModal();
 * 
 * // 수정 모달 열기
 * openEditModal(user);
 */
export function useModal<T = any>({ initialMode = 'create' }: UseModalProps<T> = {}) {
  const [isOpen, setIsOpen] = useState(false);
  const [mode, setMode] = useState<'create' | 'edit'>(initialMode);
  const [selectedItem, setSelectedItem] = useState<T | null>(null);

  const openModal = useCallback((newMode: 'create' | 'edit', item?: T) => {
    setMode(newMode);
    setSelectedItem(item || null);
    setIsOpen(true);
  }, []);

  const closeModal = useCallback(() => {
    setIsOpen(false);
    // 모달이 닫힌 후 상태 초기화 (애니메이션 완료 후)
    setTimeout(() => {
      setSelectedItem(null);
      setMode(initialMode);
    }, 300);
  }, [initialMode]);

  const openCreateModal = useCallback(() => {
    openModal('create');
  }, [openModal]);

  const openEditModal = useCallback((item: T) => {
    openModal('edit', item);
  }, [openModal]);

  return {
    isOpen,
    mode,
    selectedItem,
    openModal,
    closeModal,
    openCreateModal,
    openEditModal,
    setIsOpen,
    setMode,
    setSelectedItem,
  };
}
