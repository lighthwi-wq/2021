import { useState, useMemo } from 'react';

interface UseTableSortProps<T> {
  data: T[];
  initialSortField?: string;
  initialSortDirection?: 'asc' | 'desc';
}

/**
 * useTableSort - 테이블 정렬 로직을 관리하는 커스텀 훅
 * 
 * @example
 * const { sortedData, sortField, sortDirection, handleSort, SortIcon } = useTableSort({
 *   data: users,
 *   initialSortField: 'name',
 * });
 */
export function useTableSort<T extends Record<string, any>>({
  data,
  initialSortField = '',
  initialSortDirection = 'asc',
}: UseTableSortProps<T>) {
  const [sortField, setSortField] = useState<string>(initialSortField);
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>(initialSortDirection);

  const handleSort = (field: string) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const sortedData = useMemo(() => {
    if (!sortField) return data;

    return [...data].sort((a, b) => {
      const aVal = a[sortField];
      const bVal = b[sortField];

      // 숫자 비교
      if (typeof aVal === 'number' && typeof bVal === 'number') {
        return sortDirection === 'asc' ? aVal - bVal : bVal - aVal;
      }

      // 문자열 비교
      const aStr = String(aVal).toLowerCase();
      const bStr = String(bVal).toLowerCase();

      if (sortDirection === 'asc') {
        return aStr < bStr ? -1 : aStr > bStr ? 1 : 0;
      } else {
        return aStr > bStr ? -1 : aStr < bStr ? 1 : 0;
      }
    });
  }, [data, sortField, sortDirection]);

  return {
    sortedData,
    sortField,
    sortDirection,
    handleSort,
  };
}
