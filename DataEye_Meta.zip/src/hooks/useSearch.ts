import { useState, useMemo, useCallback } from 'react';

export function useSearch<T>(
  data: T[],
  searchFn: (item: T, query: string) => boolean
) {
  const [searchQuery, setSearchQuery] = useState('');

  const searchedData = useMemo(() => {
    if (!searchQuery.trim()) return data;
    return data.filter(item => searchFn(item, searchQuery.toLowerCase()));
  }, [data, searchQuery, searchFn]);

  const handleSearch = useCallback((query: string) => {
    setSearchQuery(query);
  }, []);

  const clearSearch = useCallback(() => {
    setSearchQuery('');
  }, []);

  return {
    searchQuery,
    searchedData,
    handleSearch,
    clearSearch,
    hasSearch: searchQuery.trim().length > 0,
  };
}
