import { useState, useEffect } from 'react';

// 초기값을 즉시 읽고 HTML에 적용
const getInitialDarkMode = () => {
  if (typeof window !== 'undefined') {
    const saved = localStorage.getItem('darkMode');
    // 명시적으로 'true'인 경우만 다크모드, 그 외에는 모두 라이트모드
    const isDark = saved === 'true';
    
    console.log('🔍 초기 다크모드 로드:', isDark);
    console.log('📦 localStorage 값:', saved);
    
    // 즉시 HTML에 클래스 적용
    if (isDark) {
      document.documentElement.classList.add('dark');
      console.log('✅ HTML에 dark 클래스 추가됨');
    } else {
      document.documentElement.classList.remove('dark');
      console.log('✅ HTML에서 dark 클래스 제거됨 (라이트모드)');
    }
    
    console.log('🔍 현재 HTML 클래스:', document.documentElement.className);
    
    return isDark;
  }
  // 서버 사이드에서는 기본값 false (라이트모드)
  return false;
};

export function useDarkMode() {
  const [isDarkMode, setIsDarkMode] = useState(getInitialDarkMode);

  // 다크모드 상태 변경 시 HTML에 반영
  useEffect(() => {
    console.log('🔄 다크모드 상태 변경:', isDarkMode);
    
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('darkMode', 'true');
      console.log('✅ HTML에 dark 클래스 추가됨');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('darkMode', 'false');
      console.log('✅ HTML에서 dark 클래스 제거됨 (라이트모드)');
    }
    
    console.log('🔍 현재 HTML 클래스:', document.documentElement.className);
    console.log('🔍 localStorage에 저장된 값:', localStorage.getItem('darkMode'));
  }, [isDarkMode]);

  const toggleDarkMode = () => {
    console.log('🎬 toggleDarkMode 호출, 현재:', isDarkMode, '→ 변경 후:', !isDarkMode);
    setIsDarkMode(!isDarkMode);
  };

  return { isDarkMode, setIsDarkMode, toggleDarkMode };
}