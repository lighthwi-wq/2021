import { useState, useMemo } from 'react';

interface UseTableFilterProps<T> {
  data: T[];
}

/**
 * useTableFilter - 테이블 필터 로직을 관리하는 커스텀 훅
 * 
 * @example
 * const { filteredData, filters, activeFilterColumn, handleFilter, setActiveFilterColumn } = useTableFilter({
 *   data: users,
 * });
 */
export function useTableFilter<T extends Record<string, any>>({
  data,
}: UseTableFilterProps<T>) {
  const [filters, setFilters] = useState<Record<string, string>>({});
  const [activeFilterColumn, setActiveFilterColumn] = useState<string | null>(null);

  const handleFilter = (field: string, value: string) => {
    setFilters((prev) => {
      const newFilters = { ...prev };
      if (value === '') {
        delete newFilters[field];
      } else {
        newFilters[field] = value;
      }
      return newFilters;
    });
    setActiveFilterColumn(null);
  };

  const filteredData = useMemo(() => {
    return data.filter((item) => {
      return Object.entries(filters).every(([field, value]) => {
        const itemValue = String(item[field]);
        return itemValue === value;
      });
    });
  }, [data, filters]);

  const getUniqueValues = (field: string): string[] => {
    const values = data.map((item) => String(item[field]));
    return Array.from(new Set(values)).sort();
  };

  return {
    filteredData,
    filters,
    activeFilterColumn,
    handleFilter,
    setActiveFilterColumn,
    getUniqueValues,
  };
}
