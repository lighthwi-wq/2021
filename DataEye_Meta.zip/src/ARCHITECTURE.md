# DataEye Meta - 아키텍처 가이드

## 📋 목차
- [프로젝트 개요](#프로젝트-개요)
- [기술 스택](#기술-스택)
- [폴더 구조](#폴더-구조)
- [디자인 시스템](#디자인-시스템)
- [컴포넌트 아키텍처](#컴포넌트-아키텍처)
- [상태 관리](#상태-관리)
- [모달 시스템](#모달-시스템)
- [커스텀 훅](#커스텀-훅)
- [코딩 컨벤션](#코딩-컨벤션)

## 🎯 프로젝트 개요

DataEye Meta는 엔터프라이즈급 데이터 메타데이터 관리 시스템입니다.
- 화면 해상도: 1920px × 1080px
- 반응형 레이아웃 지원
- 라이트 모드 전용 디자인

## 🛠 기술 스택

- **React 18+** - UI 라이브러리
- **TypeScript** - 타입 안정성
- **Tailwind CSS v4** - 스타일링
- **Motion (Framer Motion)** - 애니메이션
- **Lucide React** - 아이콘
- **Context API** - 전역 상태 관리

## 📁 폴더 구조

```
src/
├── components/           # 재사용 가능한 컴포넌트
│   ├── common/          # 공통 UI 컴포넌트 (Button, Card, Badge 등)
│   ├── modals/          # 모달 컴포넌트
│   ├── form/            # 폼 관련 컴포넌트
│   ├── table/           # 테이블 컴포넌트
│   └── stats/           # 통계 카드 컴포넌트
├── pages/               # 페이지 컴포넌트
├── hooks/               # 커스텀 훅
├── contexts/            # Context API
├── constants/           # 상수 및 디자인 시스템
├── types/               # TypeScript 타입 정의
└── utils/               # 유틸리티 함수
```

## 🎨 디자인 시스템

### 색상 팔레트

```typescript
// constants/designSystem.ts
export const colors = {
  // 배경색
  bgPrimary: '#F9F9F9',    // 거의 순백에 가까운 메인 배경
  bgSecondary: '#FFFFFF',   // 순백색 카드 배경
  surface: '#FFFFFF',       // 인풋 배경
  
  // 텍스트
  textPrimary: '#202124',   // 검은색에 가까운 메인 텍스트
  textSecondary: '#5F6368', // 보조 텍스트
  
  // 보더
  border: '#DADCE0',        // 매우 연한 보더
  
  // 액센트
  primary: '#2B8DFF',       // 파란색 액센트
  success: '#10B981',       // 성공
  warning: '#F59E0B',       // 경고
  error: '#EF4444',         // 에러
};
```

### 타이포그래피

- 폰트: **Inter**
- 기본 폰트 사이즈: 14px
- 헤딩 폰트 사이즈는 `globals.css`에서 정의

## 🧩 컴포넌트 아키텍처

### 1. Atomic Design 패턴

#### Atoms (원자)
가장 작은 단위의 컴포넌트
```typescript
// components/common/Button.tsx
<Button variant="primary" size="sm">
  저장
</Button>
```

#### Molecules (분자)
Atoms를 조합한 컴포넌트
```typescript
// components/form/FormField.tsx
<FormField label="이름" required>
  <Input type="text" />
</FormField>
```

#### Organisms (유기체)
비즈니스 로직을 포함한 복잡한 컴포넌트
```typescript
// components/modals/SlideModal.tsx
<SlideModal title="제목">
  <FormSection title="기본 정보">
    ...
  </FormSection>
</SlideModal>
```

### 2. Compound Components 패턴

관련 컴포넌트들을 그룹화하여 제공

```typescript
// 사용 예시
<DataTable
  columns={columns}
  data={data}
  sortField={sortField}
  onSort={handleSort}
/>
```

## 🔄 상태 관리

### Context API

전역 상태는 Context API를 사용합니다.

```typescript
// contexts/ThemeContext.tsx
const { isDarkMode, toggleDarkMode } = useTheme();
```

### Local State

페이지 레벨의 상태는 useState로 관리합니다.

```typescript
const [isModalOpen, setIsModalOpen] = useState(false);
const [selectedItem, setSelectedItem] = useState(null);
```

## 🪟 모달 시스템

### SlideModal 컴포넌트

모든 모달은 `SlideModal` 컴포넌트를 기반으로 합니다.

**특징:**
- 오른쪽에서 슬라이드되는 애니메이션
- 메인 컨텐츠가 왼쪽으로 밀리는 방식 (`marginRight` 사용)
- 일관된 600px 너비
- Spring 애니메이션 (damping: 30, stiffness: 300)

**구조:**
```typescript
<SlideModal
  isOpen={isOpen}
  onClose={onClose}
  title="제목"
  description="설명"
  icon={<Icon />}
  footer={<Button>저장</Button>}
>
  {/* 콘텐츠 */}
</SlideModal>
```

**페이지 구조:**
```typescript
return (
  <div className="flex gap-0 h-full relative">
    {/* 메인 콘텐츠 */}
    <motion.div
      className="flex-1 overflow-auto"
      animate={{
        marginRight: isModalOpen ? '600px' : '0px'
      }}
      transition={{
        type: 'spring',
        damping: 30,
        stiffness: 300
      }}
    >
      {/* 콘텐츠 */}
    </motion.div>

    {/* 모달 */}
    <SlideModal isOpen={isModalOpen} ... />
  </div>
);
```

## 🪝 커스텀 훅

### useModal

모달 상태 관리를 단순화합니다.

```typescript
const { isOpen, mode, selectedItem, openCreateModal, openEditModal, closeModal } = useModal<User>();

// 생성 모달
<Button onClick={openCreateModal}>추가</Button>

// 수정 모달
<Button onClick={() => openEditModal(user)}>수정</Button>
```

### useTableSort

테이블 정렬 로직을 관리합니다.

```typescript
const { sortedData, sortField, sortDirection, handleSort } = useTableSort({
  data: users,
  initialSortField: 'name',
});
```

### useTableFilter

테이블 필터링 로직을 관리합니다.

```typescript
const { filteredData, filters, handleFilter, getUniqueValues } = useTableFilter({
  data: users,
});
```

### usePagination

페이지네이션 로직을 관리합니다.

```typescript
const { paginatedData, currentPage, totalPages, setCurrentPage } = usePagination({
  data: users,
  initialPage: 1,
  initialItemsPerPage: 10,
});
```

## 📝 코딩 컨벤션

### 1. 파일명
- 컴포넌트: PascalCase (예: `Button.tsx`, `DataTable.tsx`)
- 유틸리티/훅: camelCase (예: `useModal.ts`, `formatDate.ts`)
- 상수: SCREAMING_SNAKE_CASE (예: `API_URL`)

### 2. 컴포넌트 작성

```typescript
/**
 * 컴포넌트 설명
 * 
 * @example
 * <Button variant="primary">클릭</Button>
 */
export function Button({ variant = 'primary', children }: ButtonProps) {
  return (
    <button className={`btn btn-${variant}`}>
      {children}
    </button>
  );
}
```

### 3. Props 타입

```typescript
interface ButtonProps {
  variant?: 'primary' | 'secondary';
  size?: 'sm' | 'md' | 'lg';
  children: ReactNode;
  onClick?: () => void;
}
```

### 4. 스타일링

- Tailwind CSS 클래스 우선 사용
- 인라인 스타일은 동적 색상에만 사용
- 폰트 관련 클래스는 사용 금지 (globals.css에서 관리)

```typescript
// ✅ 좋은 예
<div className="rounded-xl p-6 border" style={{ borderColor: colors.border }}>

// ❌ 나쁜 예
<div className="text-2xl font-bold leading-tight">
```

### 5. 이벤트 핸들러

```typescript
// ✅ handle로 시작
const handleClick = () => { ... };
const handleSubmit = (e: FormEvent) => { ... };

// ❌ 일관성 없는 네이밍
const onClick = () => { ... };
const submitForm = () => { ... };
```

### 6. State 관리

```typescript
// ✅ 명확한 네이밍
const [isModalOpen, setIsModalOpen] = useState(false);
const [selectedUser, setSelectedUser] = useState<User | null>(null);

// ❌ 불명확한 네이밍
const [open, setOpen] = useState(false);
const [user, setUser] = useState(null);
```

## 🚀 최적화 팁

### 1. useMemo 활용
```typescript
const filteredData = useMemo(() => {
  return data.filter(item => item.status === 'active');
}, [data]);
```

### 2. useCallback 활용
```typescript
const handleSort = useCallback((field: string) => {
  setSortField(field);
}, []);
```

### 3. 컴포넌트 분리
- 재사용 가능한 로직은 커스텀 훅으로 분리
- 복잡한 UI는 작은 컴포넌트로 분리
- 비즈니스 로직과 UI 로직 분리

## 📚 추가 리소스

- [React 공식 문서](https://react.dev)
- [TypeScript 공식 문서](https://www.typescriptlang.org)
- [Tailwind CSS 공식 문서](https://tailwindcss.com)
- [Motion 공식 문서](https://motion.dev)

---

**버전:** 1.0.0  
**최종 수정일:** 2024-11-26
