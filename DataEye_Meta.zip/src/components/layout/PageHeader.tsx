import { colors } from '../../constants/designSystem';
import { ChevronRight, Home } from 'lucide-react';

interface PageHeaderProps {
  title: string;
  description?: string;
  breadcrumbs?: { label: string; active?: boolean }[];
}

export function PageHeader({
  title,
  description,
  breadcrumbs
}: PageHeaderProps) {
  return (
    <div className="mb-6" style={{ backgroundColor: '#fff' }}>
      <div className="flex items-start justify-between">
        {/* 왼쪽: 기존 타이틀 및 설명 */}
        <div>
          <h1 
            className="mt-5 mb-2"
            style={{ color: colors.textPrimary, paddingLeft: '25px', fontSize: '18px' }}
          >
            {title}
          </h1>
          {description && (
            <p style={{ 
              color: colors.textSecondary, 
              marginLeft: '25px', 
              fontSize: '13px',
              fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", "Noto Sans KR", "Malgun Gothic", sans-serif'
            }}>
              안녕하세요 DataEye AI Meta 입니다.
            </p>
          )}
        </div>

        {/* 우측: Breadcrumb */}
        {breadcrumbs && breadcrumbs.length > 0 && (
          <div 
            className="mt-5 flex items-center gap-2"
            style={{ paddingRight: '25px' }}
          >
            {breadcrumbs.map((crumb, index) => (
              <div key={index} className="flex items-center gap-2">
                <span 
                  className="text-sm"
                  style={{ 
                    color: crumb.active ? colors.textPrimary : colors.textSecondary,
                    fontWeight: crumb.active ? 600 : 400
                  }}
                >
                  {crumb.label === 'Home' ? (
                    <Home size={16} style={{ color: colors.textSecondary }} />
                  ) : (
                    crumb.label
                  )}
                </span>
                {index < breadcrumbs.length - 1 && (
                  <ChevronRight 
                    size={14} 
                    style={{ color: colors.textSecondary }} 
                  />
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}