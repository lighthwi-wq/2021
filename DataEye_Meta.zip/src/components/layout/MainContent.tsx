import { type MenuId, pageTitles, pageDescriptions, pageBreadcrumbs } from '../../constants/menuData';
import { PageHeader } from './PageHeader';
import { colors } from '../../constants/designSystem';
import { useModal } from '../../contexts/ModalContext';
import { NewDashboardPage } from '../../pages/NewDashboardPage';
import { BizMetaPage } from '../../pages/BizMetaPage';
import { BusinessAreaManagementPage } from '../../pages/BusinessAreaManagementPage';
import { BusinessProcessManagementPage } from '../../pages/BusinessProcessManagementPage';
import { BusinessTermManagementPage } from '../../pages/BusinessTermManagementPage';
import { DataLinkageManagementPage } from '../../pages/DataLinkageManagementPage';
import { StandardWordPage } from '../../pages/StandardWordPage';
import { StandardTermPage } from '../../pages/StandardTermPage';
import { StandardDomainPage } from '../../pages/StandardDomainPage';
import { StandardCodePage } from '../../pages/StandardCodePage';
import { BusinessGlossaryPage } from '../../pages/BusinessGlossaryPage';
import { SubjectAreaPage } from '../../pages/SubjectAreaPage';
import { LogicalModelPage } from '../../pages/LogicalModelPage';
import { PhysicalModelPage } from '../../pages/PhysicalModelPage';
import { DBSchemaPage } from '../../pages/DBSchemaPage';
import { DataLineagePage } from '../../pages/DataLineagePage';
import { ImpactAnalysisPage } from '../../pages/ImpactAnalysisPage';
import { NewQualityRulePage } from '../../pages/NewQualityRulePage';
import { WorkflowRequestPage } from '../../pages/WorkflowRequestPage';
import { MenuManagementPage } from '../../pages/MenuManagementPage';
import { SearchResultsPage } from '../../pages/SearchResultsPage';
import { DemoShowcasePage } from '../../pages/DemoShowcasePage';
import { FuturisticDQMDashboard } from '../../pages/FuturisticDQMDashboard';
import { ProfilingPage } from '../../pages/ProfilingPage';
import { QualityEvaluationPage } from '../../pages/QualityEvaluationPage';
import { ErrorDataPage } from '../../pages/ErrorDataPage';
import { ImprovementPage } from '../../pages/ImprovementPage';
import { ChangeManagementPage } from '../../pages/ChangeManagementPage';
import { UserManagementPage } from '../../pages/UserManagementPage';
import { PlaceholderPage } from '../../pages/PlaceholderPage';
import { useNavigation } from '../../contexts/NavigationContext';

interface MainContentProps {
  activeMenu: MenuId;
}

export function MainContent({
  activeMenu
}: MainContentProps) {
  const { navigate } = useNavigation();
  const { isModalOpen } = useModal();

  const renderPage = () => {
    switch (activeMenu) {
      // Demo
      case 'demo':
        return <DemoShowcasePage />;
      
      // Dashboard
      case 'dashboard':
        return <NewDashboardPage />;
      
      // 비즈메타
      case 'biz-meta':
        return <BizMetaPage />;
      case 'business-area':
        return <BusinessAreaManagementPage />;
      case 'business-process':
        return <BusinessProcessManagementPage />;
      case 'business-term':
        return <BusinessTermManagementPage />;
      case 'data-linkage':
        return <DataLinkageManagementPage />;
      
      // 데이터 표준 관리
      case 'data-standard':
        return <PlaceholderPage title="데이터 표준 관리" description="데이터 표준화 체계를 관리하세요" />;
      case 'standard-word':
        return <StandardWordPage />;
      case 'standard-domain':
        return <StandardDomainPage />;
      case 'standard-term':
        return <StandardTermPage />;
      case 'standard-code':
        return <StandardCodePage />;
      case 'business-glossary':
        return <BusinessGlossaryPage />;
      
      // 데이터 모델 관리
      case 'data-model':
        return <PlaceholderPage title="데이터 모델 관리" description="실제 DB 스키마와 데이터 흐름을 관리하세요" />;
      case 'subject-area':
        return <SubjectAreaPage />;
      case 'logical-model':
        return <LogicalModelPage />;
      case 'physical-model':
        return <PhysicalModelPage />;
      case 'db-schema':
        return <DBSchemaPage />;
      case 'data-lineage':
        return <DataLineagePage />;
      case 'impact-analysis':
        return <ImpactAnalysisPage />;
      
      // 데이터 품질 관리
      case 'data-quality':
        return <FuturisticDQMDashboard />;
      case 'quality-rule':
        return <NewQualityRulePage />;
      case 'profiling':
        return <ProfilingPage />;
      case 'quality-evaluation':
        return <QualityEvaluationPage />;
      case 'error-data':
        return <ErrorDataPage />;
      case 'improvement':
        return <ImprovementPage />;
      
      // 데이터 요청/승인
      case 'workflow':
        return <PlaceholderPage title="데이터 요청/승인" description="표준/모델 신규 신청 및 변경 관리" />;
      case 'new-request':
        return <WorkflowRequestPage />;
      case 'change-management':
        return <ChangeManagementPage />;
      
      // 관리자
      case 'admin':
        return <PlaceholderPage title="관리자" description="시스템 관리자 기능" />;
      case 'user-management':
        return <UserManagementPage />;
      case 'menu-management':
        return <MenuManagementPage />;
      case 'system-code':
        return <PlaceholderPage title="시스템 코드 관리" description="시스템 코드를 관리하세요" />;
      case 'notice':
        return <PlaceholderPage title="공지사항 관리" description="공지사항을 등록하고 관리하세요" />;
      
      // Search Results
      case 'search-results':
        return <SearchResultsPage searchQuery="" onNavigate={navigate} />;
      
      default:
        return <NewDashboardPage />;
    }
  };

  return (
    <main 
      className="flex-1 flex flex-col overflow-hidden rounded-xl border shadow-sm transition-all duration-300"
      style={{
        backgroundColor: colors.background,
        borderColor: colors.border,
        marginRight: isModalOpen ? '400px' : '0',
      }}
    >
      <PageHeader 
        title={pageTitles[activeMenu] || '검색 결과'} 
        description={pageDescriptions[activeMenu] || '검색된 결과를 확인하세요'} 
        breadcrumbs={pageBreadcrumbs[activeMenu] || [{ label: '검색 결과' }]}
      />
      <div 
        className="flex-1 overflow-hidden relative"
        style={{
          backgroundColor: colors.backgroundSecondary,
        }}
      >
        <div className="absolute inset-0 overflow-auto p-6">
          {renderPage()}
        </div>
      </div>
    </main>
  );
}