import { MetadataPage } from '../../pages/MetadataPage';
import { type MenuId, pageTitles, pageDescriptions, pageBreadcrumbs } from '../../constants/menuData';
import { PageHeader } from './PageHeader';
import { colors } from '../../constants/designSystem';
import { DashboardPage } from '../../pages/DashboardPage';
import { DataStandardizationPage } from '../../pages/DataStandardizationPage';
import { StandardTermManagementPage } from '../../pages/StandardTermManagementPage';
import { MenuManagementPage } from '../../pages/MenuManagementPage';
import { DeploymentManagementPage } from '../../pages/DeploymentManagementPage';
import { StandardAdequacyManagementPage } from '../../pages/StandardAdequacyManagementPage';
import { BizMetaPage } from '../../pages/BizMetaPage';
import { BusinessAreaManagementPage } from '../../pages/BusinessAreaManagementPage';
import { BusinessProcessManagementPage } from '../../pages/BusinessProcessManagementPage';
import { BusinessTermManagementPage } from '../../pages/BusinessTermManagementPage';
import { DataLinkageManagementPage } from '../../pages/DataLinkageManagementPage';
import { DataQualityPage } from '../../pages/DataQualityPage';
import { QualityRuleManagementPage } from '../../pages/QualityRuleManagementPage';
import { QualityDiagnosisManagementPage } from '../../pages/QualityDiagnosisManagementPage';
import { QualityViolationManagementPage } from '../../pages/QualityViolationManagementPage';
import { ActionManagementPage } from '../../pages/ActionManagementPage';
import { CommonManagementPage } from '../../pages/CommonManagementPage';
import { SettingsPage } from '../../pages/SettingsPage';
import { SearchResultsPage } from '../../pages/SearchResultsPage';
import { useNavigation } from '../../contexts/NavigationContext';

interface MainContentProps {
  activeMenu: MenuId;
}

export function MainContent({
  activeMenu
}: MainContentProps) {
  const { navigate } = useNavigation();

  const renderPage = () => {
    switch (activeMenu) {
      case 'dashboard':
        return <DashboardPage />;
      case 'search-results':
        return <SearchResultsPage searchQuery="" onNavigate={navigate} />;
      case 'data-standardization':
        return <DataStandardizationPage />;
      case 'standard-term-management':
        return <StandardTermManagementPage />;
      case 'menu-management':
        return <MenuManagementPage />;
      case 'deployment-management':
        return <DeploymentManagementPage />;
      case 'standard-adequacy-management':
        return <StandardAdequacyManagementPage />;
      case 'biz-meta':
        return <BizMetaPage />;
      case 'business-area-management':
        return <BusinessAreaManagementPage />;
      case 'business-process-management':
        return <BusinessProcessManagementPage />;
      case 'business-term-management':
        return <BusinessTermManagementPage />;
      case 'data-linkage-management':
        return <DataLinkageManagementPage />;
      case 'data-quality':
        return <DataQualityPage />;
      case 'quality-rule-management':
        return <QualityRuleManagementPage />;
      case 'quality-diagnosis-management':
        return <QualityDiagnosisManagementPage />;
      case 'quality-violation-management':
        return <QualityViolationManagementPage />;
      case 'action-management':
        return <ActionManagementPage />;
      case 'common-management':
        return <CommonManagementPage />;
      case 'settings':
        return <SettingsPage />;
      default:
        return <DashboardPage />;
    }
  };

  return (
    <main 
      className="flex-1 flex flex-col overflow-hidden rounded-xl border shadow-sm transition-colors duration-300"
      style={{
        backgroundColor: '#fff',
        borderColor: colors.border
      }}
    >
      <PageHeader 
        title={pageTitles[activeMenu] || '검색 결과'} 
        description={pageDescriptions[activeMenu] || '검색된 결과를 확인하세요'} 
        breadcrumbs={pageBreadcrumbs[activeMenu] || [{ label: '검색 결과' }]}
      />
      <div 
        className="flex-1 overflow-auto p-6"
        style={{
          backgroundColor: colors.contentBackground,
          borderTop: '1px solid #dee3eb'
        }}
      >
        {renderPage()}
      </div>
    </main>
  );
}