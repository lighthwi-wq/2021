import { Bell, Settings, PanelLeftClose, PanelLeftOpen, UserCog, LogOut, FileCheck } from 'lucide-react';
import { SearchBar } from '../common/SearchBar';
import { MenuId } from '../../types';
import logoLight from 'figma:asset/1bbf2e3946f645f8509820f2f9de933f45359ffc.png';
import emblemLight from 'figma:asset/a72aa4248ef3334b9fa3e90659cfb3a3ac02b725.png';
import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Tooltip } from '../common/Tooltip';

interface HeaderProps {
  isSidebarCollapsed: boolean;
  toggleSidebar: () => void;
  onNavigate: (menuId: MenuId) => void;
  onLogout?: () => void;
}

export function Header({ isSidebarCollapsed, toggleSidebar, onNavigate, onLogout }: HeaderProps) {
  const [showNotifications, setShowNotifications] = useState(false);

  const notifications = [
    { id: 1, type: 'warning', title: '품질 점수 하락', message: 'CUSTOMER 테이블의 품질 점수가 85점으로 하락했습니다.', time: '5분 전' },
    { id: 2, type: 'info', title: '신규 위반 발견', message: '필수값 검증 규칙에서 3건의 위반이 발견되었습니다.', time: '1시간 전' },
    { id: 3, type: 'success', title: '조치 완료', message: '이메일 형식 오류 데이터 수정이 완료되었습니다.', time: '2시간 전' },
  ];

  return (
    <header 
      className="h-14 border-b sticky top-0 z-50"
      style={{
        backgroundColor: '#FFFFFF',
        borderColor: '#DADCE0',
        boxShadow: '0 1px 3px rgba(0, 0, 0, 0.05)'
      }}
    >
      <div className="h-full flex items-center justify-between">
        {/* 좌측 영역: 로고 + 햄버거 메뉴 + 검색창 */}
        <div className="flex items-center gap-1 flex-1">
          <button 
            onClick={() => onNavigate('dashboard')}
            className="flex items-center justify-center transition-opacity duration-300 hover:opacity-80 cursor-pointer"
            style={{ width: isSidebarCollapsed ? '64px' : '256px' }}
            title="대시보드로 이동"
          >
            {!isSidebarCollapsed ? (
              <img 
                src={logoLight} 
                alt="DataEye Meta" 
                className="h-5 object-contain transition-opacity duration-300"
              />
            ) : (
              <img 
                src={emblemLight} 
                alt="DataEye Meta Emblem" 
                className="h-5 object-contain transition-opacity duration-300"
              />
            )}
          </button>
          
          <button
            onClick={toggleSidebar}
            className="p-2 rounded-lg transition-all duration-200 hover:scale-105 active:scale-95"
            title={isSidebarCollapsed ? '메뉴 펼치기' : '메뉴 접기'}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = '#F1F3F4';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = 'transparent';
            }}
          >
            {isSidebarCollapsed ? (
              <PanelLeftOpen 
                className="w-5 h-5 transition-transform duration-200" 
                style={{ color: '#5F6368' }}
              />
            ) : (
              <PanelLeftClose 
                className="w-5 h-5 transition-transform duration-200" 
                style={{ color: '#5F6368' }}
              />
            )}
          </button>
          
          <div className="flex-1 max-w-2xl ml-2">
            <SearchBar onNavigate={onNavigate} />
          </div>
        </div>

        {/* 우측 영역: 알림 & 설정 버튼들 */}
        <div className="flex items-center gap-2 pr-6">
          <Tooltip content="관리자">
            <button 
              className="p-2 rounded-lg transition-all duration-200 hover:scale-105 active:scale-95"
              style={{ backgroundColor: 'transparent' }}
              onMouseEnter={(e) => {
                e.currentTarget.style.backgroundColor = '#F1F3F4';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.backgroundColor = 'transparent';
              }}
            >
              <UserCog 
                className="w-4 h-4" 
                style={{ color: '#5F6368' }}
              />
            </button>
          </Tooltip>
          <Tooltip content="로그아웃">
            <button 
              className="p-2 rounded-lg transition-all duration-200 hover:scale-105 active:scale-95"
              style={{ backgroundColor: 'transparent' }}
              onMouseEnter={(e) => {
                e.currentTarget.style.backgroundColor = '#F1F3F4';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.backgroundColor = 'transparent';
              }}
              onClick={onLogout}
            >
              <LogOut 
                className="w-4 h-4" 
                style={{ color: '#5F6368' }}
              />
            </button>
          </Tooltip>
          <Tooltip content="결재">
            <button 
              className="p-2 rounded-lg transition-all duration-200 hover:scale-105 active:scale-95"
              style={{ backgroundColor: 'transparent' }}
              onMouseEnter={(e) => {
                e.currentTarget.style.backgroundColor = '#F1F3F4';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.backgroundColor = 'transparent';
              }}
            >
              <FileCheck 
                className="w-4 h-4" 
                style={{ color: '#5F6368' }}
              />
            </button>
          </Tooltip>
          <Tooltip content="알림">
            <button 
              className="p-2 rounded-lg transition-all duration-200 hover:scale-105 active:scale-95"
              style={{ backgroundColor: 'transparent' }}
              onMouseEnter={(e) => {
                e.currentTarget.style.backgroundColor = '#F1F3F4';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.backgroundColor = 'transparent';
              }}
              onClick={() => setShowNotifications(!showNotifications)}
            >
              <Bell 
                className="w-4 h-4" 
                style={{ color: '#5F6368' }}
              />
            </button>
          </Tooltip>
          <Tooltip content="설정">
            <button 
              className="p-2 rounded-lg transition-all duration-200 hover:scale-105 active:scale-95"
              style={{ backgroundColor: 'transparent' }}
              onMouseEnter={(e) => {
                e.currentTarget.style.backgroundColor = '#F1F3F4';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.backgroundColor = 'transparent';
              }}
            >
              <Settings 
                className="w-4 h-4" 
                style={{ color: '#5F6368' }}
              />
            </button>
          </Tooltip>
        </div>
      </div>

      {/* 알림 팝업 */}
      <AnimatePresence>
        {showNotifications && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
            className="absolute right-10 top-16 rounded-lg w-80 z-50"
            style={{
              backgroundColor: '#FFFFFF',
              border: '1px solid #DADCE0',
              boxShadow: '0 4px 12px rgba(0, 0, 0, 0.15)'
            }}
          >
            <div 
              className="p-4"
              style={{ borderBottom: '1px solid #DADCE0' }}
            >
              <h3 
                className="font-bold"
                style={{ 
                  fontSize: '14px',
                  color: '#202124'
                }}
              >
                알림
              </h3>
            </div>
            <div className="max-h-96 overflow-y-auto">
              {notifications.map((notification) => (
                <div 
                  key={notification.id} 
                  className="p-4 hover:bg-gray-50 transition-colors cursor-pointer"
                  style={{ borderBottom: '1px solid #F1F3F4' }}
                >
                  <div className="flex items-start gap-3">
                    <div
                      className="w-2 h-2 rounded-full mt-1.5 flex-shrink-0"
                      style={{
                        backgroundColor:
                          notification.type === 'warning'
                            ? '#F59E0B'
                            : notification.type === 'info'
                            ? '#2B8DFF'
                            : '#84CC16',
                      }}
                    />
                    <div className="flex-1 min-w-0">
                      <p 
                        className="font-bold mb-1"
                        style={{ 
                          fontSize: '13px',
                          color: '#202124'
                        }}
                      >
                        {notification.title}
                      </p>
                      <p 
                        className="mb-1"
                        style={{ 
                          fontSize: '12px',
                          color: '#5F6368',
                          lineHeight: '1.4'
                        }}
                      >
                        {notification.message}
                      </p>
                      <p 
                        style={{ 
                          fontSize: '11px',
                          color: '#80868B'
                        }}
                      >
                        {notification.time}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <div 
              className="p-3 text-center"
              style={{ borderTop: '1px solid #DADCE0' }}
            >
              <button
                className="text-sm font-medium hover:underline"
                style={{ color: '#2B8DFF' }}
                onClick={() => setShowNotifications(false)}
              >
                모두 읽음으로 표시
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}