import { useState } from 'react';
import { ChevronDown, User } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { menuItems } from '../../constants/menuItems';
import { MenuId } from '../../types';
import { colors } from '../../constants/designSystem';

interface SidebarProps {
  activeMenu: MenuId;
  setActiveMenu: (menu: MenuId) => void;
  isCollapsed: boolean;
  userType: 'admin' | 'user';
}

export function Sidebar({ activeMenu, setActiveMenu, isCollapsed, userType }: SidebarProps) {
  const [expandedMenus, setExpandedMenus] = useState<string[]>(['biz-meta', 'data-standard', 'data-model', 'data-quality']);

  const toggleMenu = (menuId: string) => {
    if (isCollapsed) return;
    setExpandedMenus(prev => 
      prev.includes(menuId) 
        ? prev.filter(id => id !== menuId)
        : [...prev, menuId]
    );
  };

  const isMenuExpanded = (menuId: string) => expandedMenus.includes(menuId);

  const isParentActive = (menuId: string, children?: any[]) => {
    if (activeMenu === menuId) return true;
    if (children) {
      return children.some(child => activeMenu === child.id);
    }
    return false;
  };

  return (
    <aside 
      className={`border-r rounded-xl transition-all duration-300 flex-shrink-0 overflow-auto flex flex-col ${ 
        isCollapsed ? 'w-16' : 'w-64'
      }`}
      style={{
        backgroundColor: '#FFFFFF',
        borderColor: '#DADCE0',
        boxShadow: '0 1px 3px rgba(0, 0, 0, 0.05)'
      }}
    >
      <nav 
        className={`${isCollapsed ? 'p-2' : 'p-4 pl-3'} flex-1 rounded-xl`}
        style={{
          backgroundColor: '#FFFFFF',
          margin: '8px'
        }}
      >
        <div className="space-y-1">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeMenu === item.id;
            const hasChildren = item.children && item.children.length > 0;
            const isExpanded = isMenuExpanded(item.id);
            const isThisOrChildActive = isParentActive(item.id, item.children);
            
            return (
              <div key={item.id}>
                <motion.button
                  onClick={() => {
                    if (hasChildren) {
                      toggleMenu(item.id);
                    } else {
                      setActiveMenu(item.id as MenuId);
                    }
                  }}
                  className={`w-full flex items-center ${isCollapsed ? 'justify-center' : 'gap-3'} px-3 py-2.5 rounded-lg transition-all duration-200 text-sm font-medium`}
                  style={{
                    backgroundColor: isThisOrChildActive 
                      ? '#2B8DFF'
                      : 'transparent',
                    color: isThisOrChildActive
                      ? '#FFFFFF'
                      : '#333333'
                  }}
                  onMouseEnter={(e) => {
                    if (!isThisOrChildActive) {
                      e.currentTarget.style.backgroundColor = '#F1F3F4';
                    }
                  }}
                  onMouseLeave={(e) => {
                    if (!isThisOrChildActive) {
                      e.currentTarget.style.backgroundColor = 'transparent';
                    }
                  }}
                  whileHover={{ 
                    scale: 1.02,
                    x: isCollapsed ? 0 : 4,
                    transition: { duration: 0.2 }
                  }}
                  whileTap={{ scale: 0.98 }}
                >
                  <motion.div
                    whileHover={{ scale: 1.1, rotate: isThisOrChildActive ? 0 : 5 }}
                    transition={{ duration: 0.2 }}
                  >
                    <Icon 
                      className="w-4 h-4 flex-shrink-0"
                      style={{
                        color: isThisOrChildActive
                          ? '#FFFFFF'
                          : '#333333'
                      }}
                    />
                  </motion.div>
                  {!isCollapsed && (
                    <>
                      <span 
                        className="flex-1 text-left"
                        style={{
                          color: isThisOrChildActive ? '#FFFFFF' : '#333333'
                        }}
                      >
                        {item.label}
                      </span>
                      {hasChildren && (
                        <motion.div
                          animate={{ rotate: isExpanded ? 0 : -90 }}
                          transition={{ duration: 0.2 }}
                        >
                          <ChevronDown 
                            className="w-4 h-4 flex-shrink-0"
                            style={{
                              color: isThisOrChildActive
                                ? '#FFFFFF'
                                : '#333333'
                            }}
                          />
                        </motion.div>
                      )}
                    </>
                  )}
                </motion.button>
                
                {hasChildren && !isCollapsed && (
                  <AnimatePresence>
                    {isExpanded && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.2 }}
                        className="overflow-hidden"
                      >
                        <div className="ml-3 mt-1 space-y-1 border-l pl-3 pr-2 overflow-visible" style={{ borderColor: '#E8EAED' }}>
                          {item.children?.map((child, idx) => {
                            const ChildIcon = child.icon;
                            const isChildActive = activeMenu === child.id;
                            
                            return (
                              <motion.button
                                key={child.id}
                                onClick={() => setActiveMenu(child.id as MenuId)}
                                className="w-full flex items-center gap-2 px-3 py-2 rounded-lg transition-all duration-200 text-sm"
                                style={{
                                  backgroundColor: isChildActive 
                                    ? '#E8EAED'
                                    : 'transparent',
                                  color: isChildActive
                                    ? '#333333'
                                    : '#5F6368'
                                }}
                                onMouseEnter={(e) => {
                                  if (!isChildActive) {
                                    e.currentTarget.style.backgroundColor = '#F1F3F4';
                                  }
                                }}
                                onMouseLeave={(e) => {
                                  if (!isChildActive) {
                                    e.currentTarget.style.backgroundColor = 'transparent';
                                  }
                                }}
                                initial={{ opacity: 0, x: -10 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ 
                                  duration: 0.2,
                                  delay: idx * 0.05
                                }}
                                whileHover={{ 
                                  scale: 1.02,
                                  x: 4,
                                  transition: { duration: 0.15 }
                                }}
                                whileTap={{ scale: 0.98 }}
                              >
                                <motion.div
                                  whileHover={{ scale: 1.15 }}
                                  transition={{ duration: 0.15 }}
                                >
                                  <ChildIcon 
                                    className="w-3.5 h-3.5 flex-shrink-0"
                                    style={{
                                      color: isChildActive
                                        ? '#333333'
                                        : '#5F6368'
                                    }}
                                  />
                                </motion.div>
                                <span 
                                  className="text-left"
                                  style={{
                                    color: isChildActive ? '#333333' : '#5F6368'
                                  }}
                                >
                                  {child.label}
                                </span>
                              </motion.button>
                            );
                          })}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                )}
              </div>
            );
          })}
        </div>
      </nav>
      
      {/* 하단 프로필 영역 */}
      <motion.div 
        className={`border-t ${isCollapsed ? 'p-2' : 'p-4'}`}
        style={{ borderColor: '#DADCE0' }}
        whileHover={{ 
          backgroundColor: '#F9FAFB',
          transition: { duration: 0.2 }
        }}
      >
        {isCollapsed ? (
          <div className="flex items-center justify-center">
            <motion.div 
              className="w-10 h-10 rounded-full flex items-center justify-center border cursor-pointer"
              style={{ 
                backgroundColor: 'transparent',
                borderColor: '#DADCE0',
                color: '#5F6368'
              }}
              whileHover={{ 
                scale: 1.1,
                borderColor: '#2B8DFF',
                transition: { duration: 0.2 }
              }}
              whileTap={{ scale: 0.95 }}
            >
              <span className="font-bold text-sm">오</span>
            </motion.div>
          </div>
        ) : (
          <motion.div 
            className="flex items-center gap-3 cursor-pointer"
            whileHover={{ x: 4 }}
            whileTap={{ scale: 0.98 }}
          >
            <motion.div 
              className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 border"
              style={{ 
                backgroundColor: 'transparent',
                borderColor: '#DADCE0',
                color: '#5F6368'
              }}
              whileHover={{ 
                scale: 1.05,
                borderColor: '#2B8DFF',
                transition: { duration: 0.2 }
              }}
            >
              <span className="font-bold text-sm">오</span>
            </motion.div>
            <div className="flex-1 min-w-0">
              <div 
                className="font-bold text-sm"
                style={{ color: '#202124' }}
              >
                {userType === 'admin' ? '관리자' : '사용자'}
              </div>
              <div className="flex items-center gap-1.5 mt-0.5">
                <motion.div 
                  className="w-2 h-2 rounded-full"
                  style={{ backgroundColor: '#10B981' }}
                  animate={{ 
                    scale: [1, 1.2, 1],
                    opacity: [1, 0.8, 1]
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                />
                <span 
                  className="text-xs"
                  style={{ color: '#5F6368' }}
                >
                  로그인하셨습니다
                </span>
              </div>
            </div>
          </motion.div>
        )}
      </motion.div>
    </aside>
  );
}