import { ReactNode } from 'react';
import { ArrowUpDown, ChevronUp, ChevronDown, Filter } from 'lucide-react';

interface Column<T> {
  key: string;
  label: string;
  sortable?: boolean;
  filterable?: boolean;
  render?: (value: any, row: T) => ReactNode;
  width?: string;
}

interface DataTableProps<T> {
  columns: Column<T>[];
  data: T[];
  onRowClick?: (row: T) => void;
  sortField?: string;
  sortDirection?: 'asc' | 'desc';
  onSort?: (field: string) => void;
  filters?: Record<string, string>;
  onFilter?: (field: string) => void;
  activeFilterColumn?: string | null;
  getRowKey?: (row: T, index: number) => string | number;
}

/**
 * DataTable - 데이터 테이블 컴포넌트
 * 
 * 정렬, 필터링, 행 클릭 등의 기능을 제공하는 재사용 가능한 테이블 컴포넌트입니다.
 * 
 * @example
 * <DataTable
 *   columns={[
 *     { key: 'name', label: '이름', sortable: true },
 *     { key: 'age', label: '나이', sortable: true },
 *   ]}
 *   data={users}
 *   onRowClick={handleRowClick}
 *   sortField={sortField}
 *   sortDirection={sortDirection}
 *   onSort={handleSort}
 * />
 */
export function DataTable<T extends Record<string, any>>({
  columns,
  data,
  onRowClick,
  sortField,
  sortDirection = 'asc',
  onSort,
  filters = {},
  onFilter,
  activeFilterColumn,
  getRowKey = (_, index) => index,
}: DataTableProps<T>) {
  
  const SortIcon = ({ field }: { field: string }) => {
    if (sortField !== field) {
      return <ArrowUpDown className="w-3.5 h-3.5 text-gray-400 ml-1" />;
    }
    return sortDirection === 'asc' ? (
      <ChevronUp className="w-3.5 h-3.5 ml-1" style={{ color: '#2B8DFF' }} />
    ) : (
      <ChevronDown className="w-3.5 h-3.5 ml-1" style={{ color: '#2B8DFF' }} />
    );
  };

  return (
    <div className="overflow-x-auto">
      <table className="w-full">
        <thead style={{ backgroundColor: '#F7F8FA' }}>
          <tr style={{ borderBottom: '1px solid #DADCE0' }}>
            {columns.map((column) => (
              <th
                key={column.key}
                className={`px-4 py-3 text-left text-sm relative ${
                  column.sortable ? 'cursor-pointer hover:bg-gray-100 transition-colors' : ''
                }`}
                style={{
                  color: sortField === column.key ? '#2B8DFF' : '#5F6368',
                  width: column.width,
                }}
                onClick={() => column.sortable && onSort && onSort(column.key)}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    {column.label}
                    {column.sortable && <SortIcon field={column.key} />}
                  </div>
                  {column.filterable && onFilter && (
                    <Filter
                      className="w-3.5 h-3.5 ml-2 cursor-pointer hover:text-blue-600"
                      style={{ color: filters[column.key] ? '#2B8DFF' : '#9CA3AF' }}
                      onClick={(e) => {
                        e.stopPropagation();
                        onFilter(column.key);
                      }}
                    />
                  )}
                </div>
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {data.map((row, idx) => (
            <tr
              key={getRowKey(row, idx)}
              className={`border-b transition-colors ${onRowClick ? 'cursor-pointer' : ''}`}
              style={{
                borderColor: '#DADCE0',
                backgroundColor: 'transparent',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.backgroundColor = '#F9F9F9';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.backgroundColor = 'transparent';
              }}
              onClick={() => onRowClick && onRowClick(row)}
            >
              {columns.map((column) => (
                <td
                  key={column.key}
                  className="px-4 py-3"
                  style={{ color: '#5F6368' }}
                >
                  {column.render
                    ? column.render(row[column.key], row)
                    : row[column.key]}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
