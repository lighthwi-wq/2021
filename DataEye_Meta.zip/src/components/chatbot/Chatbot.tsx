import { useState, useRef, useEffect } from 'react';
import { MessageCircle, X, Send, Bot, User, Minimize2 } from 'lucide-react';
import { colors } from '../../constants/designSystem';

interface Message {
  id: string;
  type: 'user' | 'bot';
  content: string;
  timestamp: Date;
}

export function Chatbot() {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      type: 'bot',
      content: '안녕하세요! DataEye Meta AI 어시스턴트입니다. 🤖✨\n메타데이터 관리, 데이터 품질, 표준화에 대해 무엇이든 물어보세요!',
      timestamp: new Date()
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    if (isOpen && !isMinimized && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isOpen, isMinimized]);

  const quickReplies = [
    '데이터 품질 점수 뭔가요?',
    '표준화율은 어��� 계산하나요?',
    '위반 사항을 어떻게 조치하나요?',
    '메타데이터 등록 방법',
  ];

  const getBotResponse = (userMessage: string): string => {
    const lowerMessage = userMessage.toLowerCase();
    
    if (lowerMessage.includes('품질') || lowerMessage.includes('점수')) {
      return '데이터 품질 점수는 완전성, 유효성, 정확성, 유일성, 일관성, 적시성 6가지 품질 차원을 종합하여 산출됩니다. 현재 시스템 전체 평균은 92.5점입니다. 📊\n\n각 차원별 점수는 대시보드의 "품질 차원 분석" 차트에서 확인하실 수 있습니다.';
    }
    
    if (lowerMessage.includes('표준화') || lowerMessage.includes('계산')) {
      return '표준화율은 (표준용어 적용 컬럼 수 / 전체 컬럼 수) x 100으로 계산됩니다. 📐\n\n현재 전체 표준화율은 87%이며, 목표치 90% 달성을 위해 노력하고 있습니다. 시스템별 표준화율은 대시보드에서 확인 가능합니다.';
    }
    
    if (lowerMessage.includes('위반') || lowerMessage.includes('조치')) {
      return '데이터 품질 위반 조치 절차는 다음과 같습니다:\n\n1️⃣ 위반 건 확인 (대시보드 > 테이블별 위반 현황)\n2️⃣ 위반 상세 내역 분석\n3️⃣ 조치 계획 작성\n4️⃣ 담당자 배정 및 처리\n5️⃣ 처리 완료 확인\n\n"품질 관리 > 위반 사항 관리" 메뉴에서 상세한 조치 관리가 가능합니다.';
    }
    
    if (lowerMessage.includes('메타데이터') || lowerMessage.includes('등록')) {
      return '메타데이터 등록은 다음 메뉴에서 가능합니다:\n\n📌 기술 메타데이터: "메타데이터 > 데이터 소스"\n📌 업무 메타데이터: "메타데이터 > 업무 메타"\n📌 표준용어: "메타데이터 > 표준용어 관리"\n📌 업무용어: "메타데이터 > 업무용어 관리"\n\n각 메뉴의 "등록" 버튼을 클릭하여 신규 등록이 가능합니다.';
    }

    if (lowerMessage.includes('도움') || lowerMessage.includes('help')) {
      return '제가 도와드릴 수 있는 주요 기능입니다:\n\n✅ 데이터 품질 지표 설명\n✅ 표준화 절차 안내\n✅ 위반 사항 조치 방법\n✅ 메타데이터 등록 가이드\n✅ 대시보드 활용 방법\n✅ 시스템 사용 팁\n\n궁금하신 내용을 자유롭게 질문해주세요!';
    }

    if (lowerMessage.includes('대시보드')) {
      return '대시보드에서는 다음 정보를 한눈에 확인할 수 있습니다:\n\n📊 총 테이블, 표준용어, 업무용어 통계\n📈 품질 점수 및 표준화율 추이\n🎯 시스템별 표준화 현황\n⚠️ 테이블별 위반 현황\n📌 최근 활동 이력\n\nKPI 카드나 차트를 클릭하면 더 상세한 정보를 확인하실 수 있습니다!';
    }
    
    return '죄송합니다. 질문을 이해하지 못했습니다. 😅\n\n다음과 같은 주제로 질문해주세요:\n• 데이터 품질 관리\n• 표준화 절차\n• 메타데이터 등록\n• 위반 사항 조치\n• 시스템 사용법';
  };

  const handleSend = () => {
    if (!inputValue.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: inputValue,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsTyping(true);

    // 봇 응답 시뮬레이션
    setTimeout(() => {
      const botResponse: Message = {
        id: (Date.now() + 1).toString(),
        type: 'bot',
        content: getBotResponse(inputValue),
        timestamp: new Date()
      };
      setMessages(prev => [...prev, botResponse]);
      setIsTyping(false);
    }, 1000 + Math.random() * 1000);
  };

  const handleQuickReply = (reply: string) => {
    setInputValue(reply);
    setTimeout(() => handleSend(), 100);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <>
      {/* 챗봇 버튼 */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="chatbot-button fixed right-6 w-16 h-16 text-white rounded-full shadow-xl hover:shadow-2xl flex items-center justify-center transition-all duration-300 hover:scale-105 z-[9999] group"
          style={{
            background: '#2B8DFF',
            bottom: '124px'
          }}
        >
          <div className="relative">
            <Bot className="w-8 h-8 text-white transition-transform duration-300 group-hover:scale-110" strokeWidth={2} />
            {/* Pulse effect */}
            <div className="absolute inset-0 rounded-full bg-white/20 animate-ping"></div>
          </div>
        </button>
      )}

      {/* 챗봇 창 */}
      {isOpen && (
        <div 
          className={`fixed right-6 w-96 rounded-2xl shadow-2xl flex flex-col overflow-hidden transition-all duration-300 z-[9999] ${
            isMinimized ? 'h-16' : 'h-[600px]'
          }`}
          style={{
            backgroundColor: colors.background,
            border: `1px solid ${colors.border}`,
            bottom: '124px'
          }}
        >
          {/* 헤더 */}
          <div 
            className="px-5 py-4 flex items-center justify-between"
            style={{
              background: '#2B8DFF'
            }}
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm">
                <Bot className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="text-white font-bold flex items-center gap-2">
                  AI Assistant
                  <span className="text-xs bg-white/20 px-2 py-0.5 rounded-full text-[rgb(255,255,255)]">Beta</span>
                </h3>
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></span>
                  <span className="text-white text-xs opacity-90">온라인</span>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setIsMinimized(!isMinimized)}
                className="p-2 hover:bg-white/10 rounded-lg transition-colors"
              >
                <Minimize2 className="w-4 h-4 text-white" />
              </button>
              <button
                onClick={() => setIsOpen(false)}
                className="p-2 hover:bg-white/10 rounded-lg transition-colors"
              >
                <X className="w-4 h-4 text-white" />
              </button>
            </div>
          </div>

          {!isMinimized && (
            <>
              {/* 메시 영역 */}
              <div 
                className="flex-1 overflow-y-auto p-4 space-y-4"
                style={{ backgroundColor: colors.background }}
              >
                {messages.map((message) => (
                  <div
                    key={message.id}
                    className={`flex gap-3 ${message.type === 'user' ? 'flex-row-reverse' : 'flex-row'}`}
                  >
                    {/* 아바타 */}
                    <div 
                      className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0`}
                      style={{
                        backgroundColor: message.type === 'bot' 
                          ? colors.primaryLight 
                          : colors.hover
                      }}
                    >
                      {message.type === 'bot' ? (
                        <Bot className="w-4 h-4" style={{ color: colors.primary }} />
                      ) : (
                        <User className="w-5 h-5" style={{ color: colors.textSecondary }} />
                      )}
                    </div>

                    {/* 메시지 버블 */}
                    <div className={`max-w-[75%] ${message.type === 'user' ? 'items-end' : 'items-start'}`}>
                      <div 
                        className={`px-4 py-3 rounded-2xl whitespace-pre-wrap`}
                        style={{
                          backgroundColor: message.type === 'bot' ? colors.surface : colors.primary,
                          color: message.type === 'bot' ? colors.textPrimary : colors.textOnPrimary,
                          boxShadow: '0 1px 2px rgba(0, 0, 0, 0.05)'
                        }}
                      >
                        <p className="text-sm leading-relaxed">{message.content}</p>
                      </div>
                      <p 
                        className={`text-xs mt-1 px-1 ${
                          message.type === 'user' ? 'text-right' : 'text-left'
                        }`}
                        style={{ color: colors.textDisabled }}
                      >
                        {message.timestamp.toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' })}
                      </p>
                    </div>
                  </div>
                ))}

                {/* 타이핑 인디케이터 */}
                {isTyping && (
                  <div className="flex gap-3">
                    <div 
                      className="w-8 h-8 rounded-full flex items-center justify-center"
                      style={{ backgroundColor: colors.primaryLight }}
                    >
                      <Bot className="w-4 h-4 animate-pulse" style={{ color: colors.primary }} />
                    </div>
                    <div 
                      className="px-4 py-3 rounded-2xl"
                      style={{ backgroundColor: colors.surface, boxShadow: '0 1px 2px rgba(0, 0, 0, 0.05)' }}
                    >
                      <div className="flex gap-1">
                        <span 
                          className="w-2 h-2 rounded-full animate-bounce" 
                          style={{ backgroundColor: colors.textDisabled, animationDelay: '0ms' }}
                        ></span>
                        <span 
                          className="w-2 h-2 rounded-full animate-bounce" 
                          style={{ backgroundColor: colors.textDisabled, animationDelay: '150ms' }}
                        ></span>
                        <span 
                          className="w-2 h-2 rounded-full animate-bounce" 
                          style={{ backgroundColor: colors.textDisabled, animationDelay: '300ms' }}
                        ></span>
                      </div>
                    </div>
                  </div>
                )}

                <div ref={messagesEndRef} />
              </div>

              {/* 빠른 답장 */}
              {messages.length === 1 && (
                <div 
                  className="px-4 py-3 border-t"
                  style={{
                    backgroundColor: colors.surface,
                    borderColor: colors.border
                  }}
                >
                  <p className="text-xs mb-2" style={{ color: colors.textDisabled }}>자주 묻는 질문</p>
                  <div className="flex flex-wrap gap-2">
                    {quickReplies.map((reply, idx) => (
                      <button
                        key={idx}
                        onClick={() => handleQuickReply(reply)}
                        className="px-3 py-1.5 rounded-full text-xs transition-colors"
                        style={{
                          backgroundColor: colors.hover,
                          color: colors.textSecondary
                        }}
                        onMouseEnter={(e) => {
                          e.currentTarget.style.backgroundColor = colors.primaryLight;
                          e.currentTarget.style.color = colors.primary;
                        }}
                        onMouseLeave={(e) => {
                          e.currentTarget.style.backgroundColor = colors.hover;
                          e.currentTarget.style.color = colors.textSecondary;
                        }}
                      >
                        {reply}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* 입력 영역 */}
              <div 
                className="p-4 border-t"
                style={{
                  backgroundColor: colors.surface,
                  borderColor: colors.border
                }}
              >
                <div className="flex gap-2">
                  <input
                    ref={inputRef}
                    type="text"
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    onKeyPress={handleKeyPress}
                    placeholder="메시지를 입력하세요..."
                    className="flex-1 px-4 py-3 rounded-xl focus:outline-none transition-all text-sm"
                    style={{
                      backgroundColor: colors.inputBg,
                      color: colors.textPrimary,
                      border: `1px solid ${colors.border}`
                    }}
                    onFocus={(e) => {
                      e.currentTarget.style.borderColor = colors.primary;
                      e.currentTarget.style.boxShadow = `0 0 0 3px ${colors.primaryLight}`;
                    }}
                    onBlur={(e) => {
                      e.currentTarget.style.borderColor = colors.border;
                      e.currentTarget.style.boxShadow = 'none';
                    }}
                  />
                  <button
                    onClick={handleSend}
                    disabled={!inputValue.trim()}
                    className="px-4 py-3 rounded-xl transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                    style={{
                      backgroundColor: inputValue.trim() ? colors.primary : colors.textDisabled,
                      color: colors.textOnPrimary
                    }}
                    onMouseEnter={(e) => {
                      if (inputValue.trim()) {
                        e.currentTarget.style.backgroundColor = colors.primaryHover;
                      }
                    }}
                    onMouseLeave={(e) => {
                      if (inputValue.trim()) {
                        e.currentTarget.style.backgroundColor = colors.primary;
                      }
                    }}
                  >
                    <Send className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </>
          )}
        </div>
      )}
    </>
  );
}