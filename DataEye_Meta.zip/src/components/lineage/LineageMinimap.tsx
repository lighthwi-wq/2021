import { NodeData } from './DataLineageNode';

interface LineageMinimapProps {
  nodes: NodeData[];
  viewBox: { x: number; y: number; width: number; height: number };
  scale: number;
  onNavigate: (x: number, y: number) => void;
}

export function LineageMinimap({ nodes, viewBox, scale, onNavigate }: LineageMinimapProps) {
  const minimapWidth = 200;
  const minimapHeight = 120;
  const totalWidth = 2400;
  const totalHeight = 1000;

  const scaleX = minimapWidth / totalWidth;
  const scaleY = minimapHeight / totalHeight;

  const viewportWidth = viewBox.width * scaleX;
  const viewportHeight = viewBox.height * scaleY;
  const viewportX = viewBox.x * scaleX;
  const viewportY = viewBox.y * scaleY;

  const handleMinimapClick = (e: React.MouseEvent<SVGSVGElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = (e.clientX - rect.left) / scaleX - viewBox.width / 2;
    const y = (e.clientY - rect.top) / scaleY - viewBox.height / 2;
    onNavigate(x, y);
  };

  return (
    <div 
      className="absolute bottom-20 right-6 rounded-xl border overflow-hidden"
      style={{
        backgroundColor: 'rgba(255, 255, 255, 0.95)',
        borderColor: 'rgba(0, 0, 0, 0.1)',
        backdropFilter: 'blur(10px)',
        boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)'
      }}
    >
      <div className="px-3 py-2 border-b" style={{ borderColor: 'rgba(0, 0, 0, 0.1)' }}>
        <p className="text-xs font-semibold" style={{ color: '#5F6368' }}>MINIMAP</p>
      </div>
      <svg
        width={minimapWidth}
        height={minimapHeight}
        style={{ cursor: 'pointer', display: 'block' }}
        onClick={handleMinimapClick}
      >
        {/* Background */}
        <rect width={minimapWidth} height={minimapHeight} fill="#F8F9FA" />

        {/* Grid pattern */}
        <defs>
          <pattern id="minimapGrid" width="20" height="20" patternUnits="userSpaceOnUse">
            <path d="M 20 0 L 0 0 0 20" fill="none" stroke="rgba(0,0,0,0.05)" strokeWidth="0.5"/>
          </pattern>
        </defs>
        <rect width={minimapWidth} height={minimapHeight} fill="url(#minimapGrid)" />

        {/* Nodes */}
        {nodes.map(node => (
          <rect
            key={node.id}
            x={node.x * scaleX}
            y={node.y * scaleY}
            width={200 * scaleX}
            height={180 * scaleY}
            fill={
              node.type === 'source' ? '#3B82F6' :
              node.type === 'warehouse' ? '#8B5CF6' :
              '#10B981'
            }
            opacity={0.6}
            rx={2}
          />
        ))}

        {/* Viewport indicator */}
        <rect
          x={viewportX}
          y={viewportY}
          width={viewportWidth}
          height={viewportHeight}
          fill="none"
          stroke="#3B82F6"
          strokeWidth={2}
          opacity={0.8}
        />
      </svg>
    </div>
  );
}