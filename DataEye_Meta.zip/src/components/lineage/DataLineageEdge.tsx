import { motion } from 'motion/react';

interface EdgeData {
  id: string;
  source: string;
  target: string;
  sourceX: number;
  sourceY: number;
  targetX: number;
  targetY: number;
}

interface DataLineageEdgeProps {
  edge: EdgeData;
  isActive: boolean;
  isDimmed: boolean;
}

export function DataLineageEdge({ edge, isActive, isDimmed }: DataLineageEdgeProps) {
  // Calculate Bezier curve control points
  const deltaX = edge.targetX - edge.sourceX;
  const controlPointOffset = deltaX * 0.5;

  const sourceX = edge.sourceX + 200; // Right edge of source node
  const sourceY = edge.sourceY + 90; // Middle of source node
  const targetX = edge.targetX; // Left edge of target node
  const targetY = edge.targetY + 90; // Middle of target node

  const cp1X = sourceX + controlPointOffset;
  const cp1Y = sourceY;
  const cp2X = targetX - controlPointOffset;
  const cp2Y = targetY;

  const pathD = `M ${sourceX} ${sourceY} C ${cp1X} ${cp1Y}, ${cp2X} ${cp2Y}, ${targetX} ${targetY}`;

  return (
    <g>
      {/* Glow layer for active edges */}
      {isActive && (
        <>
          <motion.path
            d={pathD}
            fill="none"
            stroke="#3B82F6"
            strokeWidth={8}
            opacity={0.2}
            filter="url(#edgeGlow)"
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 1, ease: "easeInOut" }}
          />
          <motion.path
            d={pathD}
            fill="none"
            stroke="#3B82F6"
            strokeWidth={4}
            opacity={0.4}
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 1, ease: "easeInOut" }}
          />
        </>
      )}

      {/* Main edge line */}
      <motion.path
        d={pathD}
        fill="none"
        stroke={isActive ? '#3B82F6' : isDimmed ? '#DADCE0' : '#9CA3AF'}
        strokeWidth={2}
        strokeDasharray={isActive ? '0' : '5,5'}
        opacity={isDimmed ? 0.3 : 1}
        initial={{ pathLength: 0, opacity: 0 }}
        animate={{ 
          pathLength: 1, 
          opacity: isDimmed ? 0.3 : 1 
        }}
        transition={{ duration: 0.8, delay: 0.2 }}
      />

      {/* Animated flow particles for active edges */}
      {isActive && (
        <>
          <motion.circle
            r={3}
            fill="#3B82F6"
            filter="url(#glow)"
          >
            <animateMotion
              dur="2s"
              repeatCount="indefinite"
              path={pathD}
            />
          </motion.circle>
          <motion.circle
            r={2}
            fill="#1E40AF"
          >
            <animateMotion
              dur="2s"
              repeatCount="indefinite"
              path={pathD}
              begin="0.5s"
            />
          </motion.circle>
        </>
      )}

      {/* Arrow head */}
      <motion.path
        d={`M ${targetX - 10} ${targetY - 6} L ${targetX} ${targetY} L ${targetX - 10} ${targetY + 6}`}
        fill="none"
        stroke={isActive ? '#3B82F6' : isDimmed ? '#DADCE0' : '#9CA3AF'}
        strokeWidth={2}
        strokeLinecap="round"
        strokeLinejoin="round"
        opacity={isDimmed ? 0.3 : 1}
        initial={{ opacity: 0 }}
        animate={{ opacity: isDimmed ? 0.3 : 1 }}
        transition={{ delay: 0.5 }}
      />
    </g>
  );
}