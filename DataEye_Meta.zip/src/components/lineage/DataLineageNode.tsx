import { Database, Table2, FileText, BarChart3, Zap } from 'lucide-react';
import { motion } from 'motion/react';
import { Badge } from '../common/Badge';

export interface NodeData {
  id: string;
  label: string;
  tableName: string;
  columns: string[];
  dqScore: number;
  type: 'source' | 'warehouse' | 'consumption';
  x: number;
  y: number;
  zone: string;
}

interface DataLineageNodeProps {
  node: NodeData;
  isActive: boolean;
  isDimmed: boolean;
  onClick: (nodeId: string) => void;
}

export function DataLineageNode({ node, isActive, isDimmed, onClick }: DataLineageNodeProps) {
  const getIcon = () => {
    switch (node.type) {
      case 'source':
        return Database;
      case 'warehouse':
        return Table2;
      case 'consumption':
        return BarChart3;
      default:
        return Database;
    }
  };

  const Icon = getIcon();

  const getTypeColor = () => {
    switch (node.type) {
      case 'source':
        return '#3B82F6'; // Blue
      case 'warehouse':
        return '#8B5CF6'; // Purple
      case 'consumption':
        return '#10B981'; // Green
      default:
        return '#6B7280';
    }
  };

  const typeColor = getTypeColor();

  return (
    <motion.g
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ 
        opacity: isDimmed ? 0.3 : 1,
        scale: isActive ? 1.05 : 1
      }}
      transition={{ duration: 0.3 }}
      style={{ cursor: 'pointer' }}
      onClick={() => onClick(node.id)}
    >
      {/* Glow effect for active nodes */}
      {isActive && (
        <rect
          x={node.x - 5}
          y={node.y - 5}
          width={210}
          height={190}
          rx={16}
          fill="none"
          stroke="#00F0FF"
          strokeWidth={2}
          opacity={0.5}
          filter="url(#glow)"
        />
      )}

      {/* Main card */}
      <rect
        x={node.x}
        y={node.y}
        width={200}
        height={180}
        rx={12}
        fill="rgba(255, 255, 255, 0.95)"
        stroke={isActive ? '#3B82F6' : 'rgba(0, 0, 0, 0.1)'}
        strokeWidth={isActive ? 2 : 1}
      />

      {/* Glass effect overlay */}
      <rect
        x={node.x}
        y={node.y}
        width={200}
        height={60}
        rx={12}
        fill="url(#glassGradient)"
        opacity={0.05}
      />

      {/* Header section */}
      <rect
        x={node.x}
        y={node.y}
        width={200}
        height={50}
        rx={12}
        fill={`${typeColor}22`}
      />

      {/* Icon */}
      <circle
        cx={node.x + 25}
        cy={node.y + 25}
        r={16}
        fill={`${typeColor}33`}
      />
      <foreignObject x={node.x + 17} y={node.y + 17} width={16} height={16}>
        <Icon className="w-4 h-4" style={{ color: typeColor }} />
      </foreignObject>

      {/* Zone label */}
      <text
        x={node.x + 50}
        y={node.y + 20}
        fill="#5F6368"
        fontSize={10}
        fontWeight={500}
      >
        {node.zone}
      </text>

      {/* Table name */}
      <text
        x={node.x + 50}
        y={node.y + 35}
        fill="#202124"
        fontSize={13}
        fontWeight={700}
      >
        {node.tableName}
      </text>

      {/* DQ Score badge */}
      <rect
        x={node.x + 120}
        y={node.y + 12}
        width={70}
        height={22}
        rx={11}
        fill={node.dqScore >= 95 ? '#10B98144' : node.dqScore >= 80 ? '#F59E0B44' : '#EF444444'}
        stroke={node.dqScore >= 95 ? '#10B981' : node.dqScore >= 80 ? '#F59E0B' : '#EF4444'}
        strokeWidth={1}
      />
      <text
        x={node.x + 155}
        y={node.y + 27}
        fill={node.dqScore >= 95 ? '#10B981' : node.dqScore >= 80 ? '#F59E0B' : '#EF4444'}
        fontSize={10}
        fontWeight={600}
        textAnchor="middle"
      >
        DQ {node.dqScore}%
      </text>

      {/* Columns list */}
      <text
        x={node.x + 15}
        y={node.y + 70}
        fill="#5F6368"
        fontSize={10}
        fontWeight={600}
      >
        KEY COLUMNS
      </text>

      {node.columns.slice(0, 4).map((column, idx) => (
        <g key={idx}>
          <circle
            cx={node.x + 20}
            cy={node.y + 90 + idx * 20}
            r={2}
            fill="#3B82F6"
          />
          <text
            x={node.x + 28}
            y={node.y + 93 + idx * 20}
            fill="#202124"
            fontSize={11}
            fontFamily="monospace"
          >
            {column}
          </text>
        </g>
      ))}

      {/* Label below */}
      <text
        x={node.x + 100}
        y={node.y + 195}
        fill="#5F6368"
        fontSize={11}
        textAnchor="middle"
      >
        {node.label}
      </text>
    </motion.g>
  );
}