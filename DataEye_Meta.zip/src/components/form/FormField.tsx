import { ReactNode } from 'react';
import { colors } from '../../constants/designSystem';

interface FormFieldProps {
  label: string;
  required?: boolean;
  children: ReactNode;
  description?: string;
}

/**
 * FormField - 일관된 폼 필드 레이아웃을 제공하는 컴포넌트
 * 
 * @example
 * <FormField label="이름" required>
 *   <input type="text" />
 * </FormField>
 */
export function FormField({ label, required, children, description }: FormFieldProps) {
  return (
    <div>
      <label className="block text-sm font-medium mb-2" style={{ color: colors.textPrimary }}>
        {label}
        {required && <span className="text-red-500 ml-1">*</span>}
      </label>
      {children}
      {description && (
        <p className="text-xs mt-1" style={{ color: colors.textSecondary }}>
          {description}
        </p>
      )}
    </div>
  );
}

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  fullWidth?: boolean;
}

/**
 * Input - 스타일이 적용된 인풋 컴포넌트
 */
export function Input({ fullWidth = true, className = '', ...props }: InputProps) {
  return (
    <input
      className={`px-4 py-2 rounded-lg border transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-blue-500 ${fullWidth ? 'w-full' : ''} ${className}`}
      style={{
        backgroundColor: colors.surface,
        borderColor: colors.border,
        color: colors.textPrimary,
      }}
      {...props}
    />
  );
}

interface TextAreaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  fullWidth?: boolean;
}

/**
 * TextArea - 스타일이 적용된 텍스트영역 컴포넌트
 */
export function TextArea({ fullWidth = true, className = '', ...props }: TextAreaProps) {
  return (
    <textarea
      className={`px-4 py-2 rounded-lg border transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none ${fullWidth ? 'w-full' : ''} ${className}`}
      style={{
        backgroundColor: colors.surface,
        borderColor: colors.border,
        color: colors.textPrimary,
      }}
      {...props}
    />
  );
}

interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  fullWidth?: boolean;
  options: Array<{ value: string | number; label: string }>;
}

/**
 * Select - 스타일이 적용된 셀렉트 컴포넌트
 */
export function Select({ fullWidth = true, className = '', options, ...props }: SelectProps) {
  return (
    <select
      className={`px-4 py-2 rounded-lg border transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-blue-500 ${fullWidth ? 'w-full' : ''} ${className}`}
      style={{
        backgroundColor: colors.surface,
        borderColor: colors.border,
        color: colors.textPrimary,
      }}
      {...props}
    >
      {options.map((option) => (
        <option key={option.value} value={option.value}>
          {option.label}
        </option>
      ))}
    </select>
  );
}

interface FormSectionProps {
  title: string;
  children: ReactNode;
  accent?: string;
}

/**
 * FormSection - 폼 내의 섹션을 구분하는 컴포넌트
 */
export function FormSection({ title, children, accent = '#2B8DFF' }: FormSectionProps) {
  return (
    <div
      className="rounded-xl p-6 border space-y-5"
      style={{
        backgroundColor: colors.bgSecondary,
        borderColor: colors.border,
      }}
    >
      <h4
        className="font-bold mb-4 flex items-center gap-2"
        style={{ color: colors.textPrimary }}
      >
        <div className="w-1.5 h-5 rounded-full" style={{ backgroundColor: accent }}></div>
        {title}
      </h4>
      {children}
    </div>
  );
}
