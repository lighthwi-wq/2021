import { Download, Filter, MoreVertical, X } from 'lucide-react';
import { useState } from 'react';

const tableData = [
  { id: 'DS-001', name: '고객 데이터베이스', source: 'PostgreSQL', status: 'active', records: '1.2M', lastSync: '2분 전' },
  { id: 'DS-002', name: '분석 이벤트', source: 'MongoDB', status: 'syncing', records: '3.4M', lastSync: '5분 전' },
  { id: 'DS-003', name: '사용자 프로필', source: 'MySQL', status: 'active', records: '856K', lastSync: '1분 전' },
  { id: 'DS-004', name: '트랜잭션 로그', source: 'BigQuery', status: 'error', records: '2.1M', lastSync: '10분 전' },
  { id: 'DS-005', name: '상품 카탈로그', source: 'PostgreSQL', status: 'active', records: '45K', lastSync: '3분 전' },
];

export function DataTable() {
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [filters, setFilters] = useState({
    status: [] as string[],
    source: [] as string[],
  });

  const toggleFilter = (category: 'status' | 'source', value: string) => {
    setFilters(prev => ({
      ...prev,
      [category]: prev[category].includes(value)
        ? prev[category].filter(v => v !== value)
        : [...prev[category], value]
    }));
  };

  const clearFilters = () => {
    setFilters({ status: [], source: [] });
  };

  const filteredData = tableData.filter(row => {
    const statusMatch = filters.status.length === 0 || filters.status.includes(row.status);
    const sourceMatch = filters.source.length === 0 || filters.source.includes(row.source);
    return statusMatch && sourceMatch;
  });

  const activeFilterCount = filters.status.length + filters.source.length;

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 transition-all duration-300 shadow-sm">
      <div className="p-3 border-b border-gray-200 dark:border-gray-700">
        <div className="flex items-center justify-between">
          <h3 className="text-gray-900 dark:text-white font-bold text-sm">데이터 소스</h3>
          <div className="flex items-center gap-2">
            <div className="relative">
              <button 
                onClick={() => setIsFilterOpen(!isFilterOpen)}
                className={`px-3 py-1.5 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-all duration-200 flex items-center gap-2 shadow-sm border text-sm ${
                  activeFilterCount > 0 
                    ? 'bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400 border-blue-200 dark:border-blue-700' 
                    : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 border-gray-200 dark:border-gray-600'
                }`}
              >
                <Filter className="w-3.5 h-3.5" />
                필터
                {activeFilterCount > 0 && (
                  <span className="ml-1 px-1.5 py-0.5 bg-blue-600 dark:bg-blue-500 text-white rounded-full text-xs">
                    {activeFilterCount}
                  </span>
                )}
              </button>

              {isFilterOpen && (
                <div className="absolute right-0 mt-2 w-72 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl shadow-lg z-10 p-4">
                  <div className="flex items-center justify-between mb-5">
                    <h4 className="font-bold text-gray-900 dark:text-white">필터</h4>
                    <button 
                      onClick={() => setIsFilterOpen(false)}
                      className="p-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
                    >
                      <X className="w-4 h-4 text-gray-500 dark:text-gray-400" />
                    </button>
                  </div>

                  <div className="space-y-5">
                    <div>
                      <h5 className="text-gray-700 dark:text-gray-300 mb-3 font-bold">Status</h5>
                      <div className="space-y-2">
                        {['active', 'syncing', 'error'].map(status => (
                          <label key={status} className="flex items-center gap-3 cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700/50 p-2 rounded-lg transition-colors">
                            <input
                              type="checkbox"
                              checked={filters.status.includes(status)}
                              onChange={() => toggleFilter('status', status)}
                              className="w-4 h-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                            />
                            <span className="text-gray-700 dark:text-gray-300 capitalize">{status}</span>
                          </label>
                        ))}
                      </div>
                    </div>

                    <div>
                      <h5 className="text-gray-700 dark:text-gray-300 mb-3 font-bold">Source</h5>
                      <div className="space-y-2">
                        {['PostgreSQL', 'MongoDB', 'MySQL', 'BigQuery'].map(source => (
                          <label key={source} className="flex items-center gap-3 cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700/50 p-2 rounded-lg transition-colors">
                            <input
                              type="checkbox"
                              checked={filters.source.includes(source)}
                              onChange={() => toggleFilter('source', source)}
                              className="w-4 h-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                            />
                            <span className="text-gray-700 dark:text-gray-300">{source}</span>
                          </label>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="flex gap-3 mt-6 pt-6 border-t border-gray-200 dark:border-gray-700">
                    <button
                      onClick={clearFilters}
                      className="flex-1 px-4 py-2 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
                    >
                      Clear
                    </button>
                    <button
                      onClick={() => setIsFilterOpen(false)}
                      className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                    >
                      Apply
                    </button>
                  </div>
                </div>
              )}
            </div>

            <button className="px-4 py-2 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-all duration-200 flex items-center gap-2 shadow-lg shadow-blue-500/20">
              <Download className="w-4 h-4" />
              내보내기
            </button>
          </div>
        </div>
      </div>
      
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900/50">
              <th className="px-3 py-2 text-left text-gray-600 dark:text-gray-400 text-xs">ID</th>
              <th className="px-3 py-2 text-left text-gray-600 dark:text-gray-400 text-xs">이름</th>
              <th className="px-3 py-2 text-left text-gray-600 dark:text-gray-400 text-xs">소스</th>
              <th className="px-3 py-2 text-left text-gray-600 dark:text-gray-400 text-xs">상태</th>
              <th className="px-3 py-2 text-left text-gray-600 dark:text-gray-400 text-xs">레코드</th>
              <th className="px-3 py-2 text-left text-gray-600 dark:text-gray-400 text-xs">마지막 동기화</th>
              <th className="px-3 py-2 text-left text-gray-600 dark:text-gray-400 text-xs">작업</th>
            </tr>
          </thead>
          <tbody>
            {filteredData.length > 0 ? (
              filteredData.map((row) => (
                <tr key={row.id} className="border-b border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700/30 transition-colors">
                  <td className="px-3 py-2 text-gray-900 dark:text-gray-100 text-sm">{row.id}</td>
                  <td className="px-3 py-2 text-gray-900 dark:text-gray-100 text-sm">{row.name}</td>
                  <td className="px-3 py-2 text-gray-600 dark:text-gray-400 text-sm">{row.source}</td>
                  <td className="px-3 py-2">
                    <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${
                      row.status === 'active'
                        ? 'bg-green-50 dark:bg-green-900/20 text-green-700 dark:text-green-400'
                        : row.status === 'syncing'
                        ? 'bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-400'
                        : 'bg-orange-50 dark:bg-orange-900/20 text-orange-700 dark:text-orange-400'
                    }`}>
                      <span className={`w-1.5 h-1.5 rounded-full ${
                        row.status === 'active'
                          ? 'bg-green-500'
                          : row.status === 'syncing'
                          ? 'bg-blue-500'
                          : 'bg-orange-500'
                      }`}></span>
                      {row.status === 'active' ? '활성' : row.status === 'syncing' ? '동기화 중' : '오류'}
                    </span>
                  </td>
                  <td className="px-3 py-2 text-gray-900 dark:text-gray-100 text-sm">{row.records}</td>
                  <td className="px-3 py-2 text-gray-600 dark:text-gray-400 text-sm">{row.lastSync}</td>
                  <td className="px-3 py-2">
                    <button className="p-1.5 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors border border-transparent hover:border-gray-200 dark:hover:border-gray-600">
                      <MoreVertical className="w-3.5 h-3.5 text-gray-600 dark:text-gray-400" />
                    </button>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={7} className="px-3 py-6 text-center text-gray-500 dark:text-gray-400 text-sm">
                  선택한 필터와 일치하는 데이터 소스가 없습니다.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}