import { LucideIcon } from 'lucide-react';
import { Card } from '../common/Card';
import { IconBox } from '../common/IconBox';

interface StatsCardProps {
  label: string;
  value: string | number;
  icon: LucideIcon;
  color: 'blue' | 'green' | 'orange' | 'red' | 'indigo' | 'purple';
  trend?: {
    value: number;
    isPositive: boolean;
  };
  progressBar?: {
    current: number;
    max: number;
  };
}

/**
 * StatsCard - 통계 정보를 표시하는 카드 컴포넌트
 * 
 * @example
 * <StatsCard
 *   label="전체 사용자"
 *   value="1,247"
 *   icon={Users}
 *   color="blue"
 *   trend={{ value: 12, isPositive: true }}
 * />
 */
export function StatsCard({ label, value, icon, color, trend, progressBar }: StatsCardProps) {
  return (
    <Card padding="lg">
      <div className="flex items-center justify-between mb-3">
        <IconBox icon={icon} color={color} size="md" />
        <div className="text-right">
          <h3 className="text-2xl font-bold" style={{ color: '#202124' }}>
            {value}
          </h3>
          {trend && (
            <p
              className="text-xs mt-1"
              style={{ color: trend.isPositive ? '#10B981' : '#EF4444' }}
            >
              {trend.isPositive ? '+' : ''}{trend.value}%
            </p>
          )}
        </div>
      </div>
      <p className="text-sm mb-2" style={{ color: '#5F6368' }}>
        {label}
      </p>
      {progressBar && (
        <div className="w-full h-1 rounded-full overflow-hidden" style={{ backgroundColor: '#F7F8FA' }}>
          <div
            className="h-full rounded-full transition-all duration-500"
            style={{
              width: `${Math.min((progressBar.current / progressBar.max) * 100, 100)}%`,
              backgroundColor: getColorValue(color),
            }}
          />
        </div>
      )}
    </Card>
  );
}

function getColorValue(color: string): string {
  const colorMap: Record<string, string> = {
    blue: '#0066FF',
    green: '#10B981',
    orange: '#F59E0B',
    red: '#EF4444',
    indigo: '#6366F1',
    purple: '#A855F7',
  };
  return colorMap[color] || colorMap.blue;
}

interface StatsGridProps {
  stats: Array<{
    label: string;
    value: string | number;
    icon: LucideIcon;
    color: 'blue' | 'green' | 'orange' | 'red' | 'indigo' | 'purple';
    trend?: {
      value: number;
      isPositive: boolean;
    };
    progressBar?: {
      current: number;
      max: number;
    };
  }>;
  columns?: 2 | 3 | 4;
}

/**
 * StatsGrid - 여러 통계 카드를 그리드 레이아웃으로 표시
 * 
 * @example
 * <StatsGrid
 *   stats={[
 *     { label: "전체", value: "100", icon: Users, color: "blue" },
 *     { label: "활성", value: "80", icon: Check, color: "green" },
 *   ]}
 *   columns={4}
 * />
 */
export function StatsGrid({ stats, columns = 4 }: StatsGridProps) {
  const gridCols = `grid-cols-1 md:grid-cols-${columns}`;
  
  return (
    <div className={`grid ${gridCols} gap-4 mb-6`}>
      {stats.map((stat, idx) => (
        <StatsCard key={idx} {...stat} />
      ))}
    </div>
  );
}
