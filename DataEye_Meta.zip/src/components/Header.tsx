import { Moon, Sun, Bell, Search, Settings } from 'lucide-react';

interface HeaderProps {
  isDarkMode: boolean;
  setIsDarkMode: (value: boolean) => void;
}

export function Header({ isDarkMode, setIsDarkMode }: HeaderProps) {
  return (
    <header className="h-14 bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 sticky top-0 z-50 transition-colors duration-300">
      <div className="h-full px-6 flex items-center justify-between">
        <div className="flex items-center gap-12">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center shadow-lg shadow-blue-500/20">
              <span className="text-white text-sm">DE</span>
            </div>
            <h1 className="text-gray-900 dark:text-white">
              DataEye Meta
            </h1>
          </div>
          
          <div className="hidden md:flex items-center gap-3 bg-gray-50 dark:bg-gray-700 rounded-xl px-4 py-2 w-96 border border-gray-200 dark:border-gray-600 transition-colors duration-300">
            <Search className="w-4 h-4 text-gray-400 dark:text-gray-500" />
            <input 
              type="text" 
              placeholder="데이터, 리포트, 인사이트 검색..."
              className="bg-transparent border-none outline-none text-gray-900 dark:text-gray-100 placeholder-gray-400 dark:placeholder-gray-500 w-full text-sm"
            />
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button className="p-2 hover:bg-gray-50 dark:hover:bg-gray-700 rounded-xl transition-all duration-200 border border-transparent hover:border-gray-200 dark:hover:border-gray-600">
            <Bell className="w-4 h-4 text-gray-600 dark:text-gray-300" />
          </button>
          <button className="p-2 hover:bg-gray-50 dark:hover:bg-gray-700 rounded-xl transition-all duration-200 border border-transparent hover:border-gray-200 dark:hover:border-gray-600">
            <Settings className="w-4 h-4 text-gray-600 dark:text-gray-300" />
          </button>
          <button
            onClick={() => {
              console.log('Toggle clicked, current mode:', isDarkMode);
              setIsDarkMode(!isDarkMode);
            }}
            className="p-2 hover:bg-gray-50 dark:hover:bg-gray-700 rounded-xl transition-all duration-200 border border-transparent hover:border-gray-200 dark:hover:border-gray-600"
          >
            {isDarkMode ? (
              <Sun className="w-4 h-4 text-yellow-400" />
            ) : (
              <Moon className="w-4 h-4 text-gray-600" />
            )}
          </button>
          <div className="w-9 h-9 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center ml-2 shadow-lg shadow-blue-500/20">
            <span className="text-white text-sm">U</span>
          </div>
        </div>
      </div>
    </header>
  );
}