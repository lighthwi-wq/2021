import { ReactNode } from 'react';

interface CardProps {
  children: ReactNode;
  className?: string;
  padding?: 'sm' | 'md' | 'lg';
}

export function Card({ children, className = '', padding = 'md' }: CardProps) {
  const paddingClasses = {
    sm: 'p-2.5',
    md: 'p-4',
    lg: 'p-5',
  };

  return (
    <div 
      className={`rounded-xl border ${paddingClasses[padding]} ${className}`}
      style={{
        backgroundColor: '#FFFFFF',
        borderColor: '#DADCE0',
        boxShadow: '0 1px 3px rgba(0, 0, 0, 0.05), 0 1px 2px rgba(0, 0, 0, 0.05)'
      }}
    >
      {children}
    </div>
  );
}