import { ReactNode } from 'react';
import { glassmorphism } from '../../constants/designSystem';

interface CardProps {
  children: ReactNode;
  className?: string;
  padding?: 'sm' | 'md' | 'lg' | 'none';
  glow?: boolean;
  hover?: boolean;
}

export function Card({ 
  children, 
  className = '', 
  padding = 'md',
  glow = false,
  hover = true,
}: CardProps) {
  const paddingClasses = {
    none: '',
    sm: 'p-3',
    md: 'p-5',
    lg: 'p-6',
  };

  return (
    <div 
      className={`rounded-xl ${paddingClasses[padding]} ${hover ? 'card-hover' : ''} ${className}`}
      style={{
        background: '#FFFFFF',
        backdropFilter: 'none',
        border: '1px solid #DADCE0',
        boxShadow: glow 
          ? '0 4px 12px rgba(0, 0, 0, 0.1), 0 0 20px rgba(59, 130, 246, 0.15)'
          : '0 1px 3px rgba(0, 0, 0, 0.05)',
      }}
    >
      {children}
    </div>
  );
}