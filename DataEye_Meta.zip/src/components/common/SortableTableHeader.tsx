import { ArrowUpDown, ChevronUp, ChevronDown } from 'lucide-react';

interface SortableTableHeaderProps {
  columns: {
    key: string;
    label: string;
    sortable?: boolean;
  }[];
  sortField: string;
  sortDirection: 'asc' | 'desc';
  onSort: (field: string) => void;
}

export function SortableTableHeader({ columns, sortField, sortDirection, onSort }: SortableTableHeaderProps) {
  const SortIcon = ({ field }: { field: string }) => {
    if (sortField !== field) {
      return <ArrowUpDown className="w-3.5 h-3.5 text-gray-400 ml-1" />;
    }
    return sortDirection === 'asc' ? (
      <ChevronUp className="w-3.5 h-3.5 ml-1" style={{ color: '#2B8DFF' }} />
    ) : (
      <ChevronDown className="w-3.5 h-3.5 ml-1" style={{ color: '#2B8DFF' }} />
    );
  };

  return (
    <thead style={{ backgroundColor: '#F7F8FA' }}>
      <tr style={{ borderBottom: '1px solid #DADCE0' }}>
        {columns.map((column) => (
          <th
            key={column.key}
            className={`px-4 py-3 text-left text-sm ${column.sortable !== false ? 'cursor-pointer hover:bg-gray-100 transition-colors' : ''}`}
            style={{ color: '#5F6368' }}
            onClick={() => column.sortable !== false && onSort(column.key)}
          >
            {column.sortable !== false ? (
              <div className="flex items-center">
                {column.label}
                <SortIcon field={column.key} />
              </div>
            ) : (
              column.label
            )}
          </th>
        ))}
      </tr>
    </thead>
  );
}
