import { ReactNode } from 'react';
import { cn } from '../../../utils/cn';
import { colors } from '../../../constants/designSystem';

interface TableProps {
  children: ReactNode;
  className?: string;
}

interface TableHeaderProps {
  children: ReactNode;
}

interface TableBodyProps {
  children: ReactNode;
}

interface TableRowProps {
  children: ReactNode;
  onClick?: () => void;
  className?: string;
}

interface TableHeadCellProps {
  children: ReactNode;
  className?: string;
}

interface TableCellProps {
  children: ReactNode;
  className?: string;
}

interface TableEmptyProps {
  message?: string;
  colSpan?: number;
}

export function Table({ children, className }: TableProps) {
  return (
    <div className="overflow-x-auto">
      <table className={cn('w-full', className)}>
        {children}
      </table>
    </div>
  );
}

Table.Header = function TableHeader({ children }: TableHeaderProps) {
  
  return (
    <thead>
      <tr 
        className="border-b"
        style={{ borderColor: colors.border }}
      >
        {children}
      </tr>
    </thead>
  );
};

Table.Body = function TableBody({ children }: TableBodyProps) {
  return <tbody>{children}</tbody>;
};

Table.HeadCell = function TableHeadCell({ children, className }: TableHeadCellProps) {
  
  return (
    <th 
      className={cn(
        'text-left px-4 py-3 font-medium text-xs',
        className
      )}
      style={{ 
        color: colors.textSecondary,
        backgroundColor: colors.background
      }}
    >
      {children}
    </th>
  );
};

Table.Row = function TableRow({ children, onClick, className }: TableRowProps) {
  
  return (
    <tr 
      onClick={onClick}
      className={cn(
        'border-b transition-colors',
        onClick && 'cursor-pointer',
        className
      )}
      style={{ 
        borderColor: colors.border
      }}
      onMouseEnter={(e) => {
        if (onClick) {
          e.currentTarget.style.backgroundColor = colors.hover;
        }
      }}
      onMouseLeave={(e) => {
        if (onClick) {
          e.currentTarget.style.backgroundColor = 'transparent';
        }
      }}
    >
      {children}
    </tr>
  );
};

Table.Cell = function TableCell({ children, className }: TableCellProps) {
  
  return (
    <td 
      className={cn('px-4 py-3 text-sm', className)}
      style={{ color: colors.textPrimary }}
    >
      {children}
    </td>
  );
};

Table.Empty = function TableEmpty({ message = '데이터가 없습니다', colSpan }: TableEmptyProps) {
  
  return (
    <tr>
      <td 
        colSpan={colSpan} 
        className="text-center py-12"
        style={{ color: colors.textDisabled }}
      >
        {message}
      </td>
    </tr>
  );
};
