import { ReactNode } from 'react';
import { colors } from '../../constants/designSystem';

interface BadgeProps {
  children: ReactNode;
  variant?: 'success' | 'warning' | 'info' | 'error' | 'danger' | 'primary' | 'default';
  size?: 'sm' | 'md' | 'lg';
  showDot?: boolean;
  glow?: boolean;
}

export function Badge({ 
  children, 
  variant = 'default',
  size = 'md',
  showDot = false,
  glow = false 
}: BadgeProps) {
  
  const getVariantStyles = () => {
    const variants = {
      primary: {
        bg: colors.primaryLight,
        text: colors.primary,
        dot: colors.primary,
        border: `1px solid ${colors.primary}40`,
      },
      success: {
        bg: colors.successLight,
        text: colors.success,
        dot: colors.success,
        border: `1px solid ${colors.success}40`,
      },
      warning: {
        bg: colors.warningLight,
        text: colors.warning,
        dot: colors.warning,
        border: `1px solid ${colors.warning}40`,
      },
      info: {
        bg: colors.infoLight,
        text: colors.info,
        dot: colors.info,
        border: `1px solid ${colors.info}40`,
      },
      error: {
        bg: colors.errorLight,
        text: colors.error,
        dot: colors.error,
        border: `1px solid ${colors.error}40`,
      },
      danger: {
        bg: '#FEE2E2',
        text: '#DC2626',
        dot: '#DC2626',
        border: '1px solid #DC262640',
      },
      default: {
        bg: 'rgba(255, 255, 255, 0.05)',
        text: colors.textSecondary,
        dot: colors.textSecondary,
        border: '1px solid rgba(255, 255, 255, 0.1)',
      }
    };
    
    return variants[variant];
  };

  const getSizeStyles = () => {
    const sizes = {
      sm: 'px-2 py-0.5 text-xs',
      md: 'px-2.5 py-1 text-xs',
      lg: 'px-3 py-1.5 text-sm'
    };
    return sizes[size];
  };

  const styles = getVariantStyles();
  const sizeClass = getSizeStyles();

  return (
    <span 
      className={`${sizeClass} rounded-full inline-flex items-center gap-1.5 font-medium ${glow ? 'animate-pulse-glow' : ''}`}
      style={{
        backgroundColor: styles.bg,
        color: styles.text,
        border: styles.border,
      }}
    >
      {showDot && (
        <span 
          className="w-1.5 h-1.5 rounded-full animate-pulse"
          style={{ backgroundColor: styles.dot }}
        ></span>
      )}
      {children}
    </span>
  );
}