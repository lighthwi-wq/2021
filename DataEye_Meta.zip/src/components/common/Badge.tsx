import { ReactNode } from 'react';
import { colors } from '../../constants/designSystem';

interface BadgeProps {
  children: React.ReactNode;
  variant?: 'success' | 'warning' | 'info' | 'error' | 'default';
  showDot?: boolean;
}

export function Badge({ children, variant = 'default', showDot = false }: BadgeProps) {
  
  const getVariantStyles = () => {
    const variants = {
      success: {
        bg: colors.successLight,
        text: colors.success,
        dot: colors.success
      },
      warning: {
        bg: colors.warningLight,
        text: colors.warning,
        dot: colors.warning
      },
      info: {
        bg: colors.infoLight,
        text: colors.info,
        dot: colors.info
      },
      error: {
        bg: colors.errorLight,
        text: colors.error,
        dot: colors.error
      },
      default: {
        bg: colors.hover,
        text: colors.textSecondary,
        dot: colors.textSecondary
      }
    };
    
    return variants[variant];
  };

  const styles = getVariantStyles();

  return (
    <span 
      className="px-2 py-0.5 rounded-full inline-flex items-center gap-1 text-xs"
      style={{
        backgroundColor: styles.bg,
        color: styles.text
      }}
    >
      {showDot && (
        <span 
          className="w-1.5 h-1.5 rounded-full"
          style={{ backgroundColor: styles.dot }}
        ></span>
      )}
      {children}
    </span>
  );
}
