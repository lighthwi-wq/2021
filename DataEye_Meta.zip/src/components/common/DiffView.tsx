import { motion } from 'motion/react';
import { Card } from './Card';

interface DiffViewProps {
  before: Record<string, any>;
  after: Record<string, any>;
  title?: string;
}

export function DiffView({ before, after, title = "변경 내역" }: DiffViewProps) {
  const allKeys = Array.from(new Set([...Object.keys(before), ...Object.keys(after)]));

  const getChangeType = (key: string) => {
    if (!(key in before)) return 'added';
    if (!(key in after)) return 'removed';
    if (before[key] !== after[key]) return 'modified';
    return 'unchanged';
  };

  const getLabel = (key: string) => {
    const labels: Record<string, string> = {
      termName: '용어명',
      englishName: '영문명',
      description: '설명',
      domain: '도메인',
      dataType: '데이터 타입',
      length: '길이',
      status: '상태',
      owner: '담당자',
      department: '부서',
      tableName: '테이블명',
      columnName: '컬럼명',
    };
    return labels[key] || key;
  };

  return (
    <div className="space-y-4">
      <h4 className="font-bold" style={{ color: '#202124' }}>{title}</h4>
      <div className="grid grid-cols-2 gap-4">
        {/* Before */}
        <Card padding="md">
          <div className="mb-3 pb-3 border-b" style={{ borderColor: '#DADCE0' }}>
            <h5 className="text-sm font-bold" style={{ color: '#5F6368' }}>변경 전 (Before)</h5>
          </div>
          <div className="space-y-2">
            {allKeys.map((key) => {
              const changeType = getChangeType(key);
              const isRemoved = changeType === 'removed';
              const isModified = changeType === 'modified';
              
              return (
                <div 
                  key={`before-${key}`}
                  className="flex justify-between p-2 rounded"
                  style={{
                    backgroundColor: isRemoved ? '#FEE2E2' : isModified ? '#FEF3C7' : 'transparent'
                  }}
                >
                  <span className="text-sm font-medium" style={{ color: '#5F6368' }}>
                    {getLabel(key)}
                  </span>
                  <span 
                    className="text-sm"
                    style={{ 
                      color: '#202124',
                      textDecoration: isRemoved || isModified ? 'line-through' : 'none'
                    }}
                  >
                    {before[key] || '-'}
                  </span>
                </div>
              );
            })}
          </div>
        </Card>

        {/* After */}
        <Card padding="md">
          <div className="mb-3 pb-3 border-b" style={{ borderColor: '#DADCE0' }}>
            <h5 className="text-sm font-bold" style={{ color: '#5F6368' }}>변경 후 (After)</h5>
          </div>
          <div className="space-y-2">
            {allKeys.map((key) => {
              const changeType = getChangeType(key);
              const isAdded = changeType === 'added';
              const isModified = changeType === 'modified';
              
              return (
                <div 
                  key={`after-${key}`}
                  className="flex justify-between p-2 rounded"
                  style={{
                    backgroundColor: isAdded ? '#D1FAE5' : isModified ? '#FEF3C7' : 'transparent'
                  }}
                >
                  <span className="text-sm font-medium" style={{ color: '#5F6368' }}>
                    {getLabel(key)}
                  </span>
                  <span 
                    className="text-sm font-bold"
                    style={{ 
                      color: isAdded || isModified ? '#10B981' : '#202124'
                    }}
                  >
                    {after[key] || '-'}
                  </span>
                </div>
              );
            })}
          </div>
        </Card>
      </div>

      {/* Legend */}
      <div className="flex items-center gap-4 text-xs" style={{ color: '#5F6368' }}>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 rounded" style={{ backgroundColor: '#D1FAE5' }} />
          <span>추가됨</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 rounded" style={{ backgroundColor: '#FEF3C7' }} />
          <span>수정됨</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 rounded" style={{ backgroundColor: '#FEE2E2' }} />
          <span>삭제됨</span>
        </div>
      </div>
    </div>
  );
}
