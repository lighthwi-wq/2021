import { X } from 'lucide-react';
import { ReactNode, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { colors } from '../../constants/designSystem';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  children: ReactNode;
  size?: 'sm' | 'md' | 'lg' | 'xl' | 'full';
  footer?: ReactNode;
}

export function Modal({ isOpen, onClose, title, children, size = 'md', footer }: ModalProps) {
  
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };

    document.addEventListener('keydown', handleEscape);
    return () => document.removeEventListener('keydown', handleEscape);
  }, [isOpen, onClose]);

  const sizeClasses = {
    sm: 'max-w-md',
    md: 'max-w-2xl',
    lg: 'max-w-4xl',
    xl: 'max-w-6xl',
    full: 'max-w-7xl'
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Overlay */}
          <motion.div
            className="fixed inset-0 z-40"
            style={{
              backgroundColor: 'rgba(0, 0, 0, 0.5)'
            }}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
          />

          {/* Modal Content */}
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              className={`w-full ${sizeClasses[size]} shadow-2xl overflow-hidden flex flex-col max-h-[90vh] rounded-xl`}
              style={{
                backgroundColor: colors.bgPrimary,
              }}
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              transition={{ 
                type: 'spring',
                damping: 30,
                stiffness: 300
              }}
              onClick={(e) => e.stopPropagation()}
            >
              {/* Header - Only show if title is provided */}
              {title && (
                <div 
                  className="flex items-center justify-between p-6 border-b flex-shrink-0"
                  style={{ 
                    borderColor: colors.border,
                    backgroundColor: colors.bgPrimary
                  }}
                >
                  <h2 
                    className="font-bold"
                    style={{ color: colors.textPrimary }}
                  >
                    {title}
                  </h2>
                  <button
                    onClick={onClose}
                    className="p-2 rounded-lg transition-colors"
                    style={{
                      backgroundColor: 'transparent'
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.backgroundColor = colors.hover;
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.backgroundColor = 'transparent';
                    }}
                  >
                    <X 
                      className="w-5 h-5" 
                      style={{ color: colors.textSecondary }}
                    />
                  </button>
                </div>
              )}
              
              {/* Content */}
              <div className={`flex-1 overflow-y-auto ${title ? 'p-6' : 'p-0'}`}>
                {children}
              </div>
              
              {/* Footer */}
              {footer && (
                <div 
                  className="p-6 border-t flex-shrink-0"
                  style={{ 
                    borderColor: colors.border,
                    backgroundColor: colors.bgPrimary
                  }}
                >
                  {footer}
                </div>
              )}
            </motion.div>
          </div>
        </>
      )}
    </AnimatePresence>
  );
}
