import { ReactNode, ButtonHTMLAttributes } from 'react';
import { colors } from '../../constants/designSystem';

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  children: ReactNode;
  variant?: 'primary' | 'secondary' | 'success' | 'warning' | 'error';
  size?: 'sm' | 'md' | 'lg';
  icon?: ReactNode;
  fullWidth?: boolean;
}

export function Button({ 
  children, 
  variant = 'primary', 
  size = 'md', 
  icon,
  fullWidth = false,
  className = '',
  disabled = false,
  ...props 
}: ButtonProps) {
  
  const sizeStyles = {
    sm: 'px-3 py-1.5 text-xs',
    md: 'px-4 py-2 text-sm',
    lg: 'px-6 py-3 text-base',
  };

  const getVariantStyles = () => {
    switch (variant) {
      case 'primary':
        return {
          backgroundColor: disabled ? '#CBD5E1' : '#2B8DFF',
          color: '#FFFFFF',
          border: 'none',
        };
      case 'secondary':
        return {
          backgroundColor: colors.surface,
          color: colors.textSecondary,
          border: `1px solid ${colors.border}`,
        };
      case 'success':
        return {
          backgroundColor: disabled ? '#CBD5E1' : colors.success,
          color: colors.textOnPrimary,
          border: 'none',
        };
      case 'warning':
        return {
          backgroundColor: disabled ? '#CBD5E1' : colors.warning,
          color: colors.textOnPrimary,
          border: 'none',
        };
      case 'error':
        return {
          backgroundColor: disabled ? '#CBD5E1' : colors.error,
          color: colors.textOnPrimary,
          border: 'none',
        };
      default:
        return {
          backgroundColor: '#2B8DFF',
          color: '#FFFFFF',
          border: 'none',
        };
    }
  };

  return (
    <button
      className={`
        ${sizeStyles[size]}
        ${fullWidth ? 'w-full' : ''}
        inline-flex items-center justify-center gap-2
        ${variant === 'primary' ? 'rounded-full' : 'rounded-lg'} font-medium
        transition-all duration-200
        ${disabled ? 'cursor-not-allowed opacity-60' : 'hover:shadow-md active:scale-[0.98]'}
        ${className}
      `}
      style={getVariantStyles()}
      disabled={disabled}
      onMouseEnter={(e) => {
        if (!disabled && variant === 'primary') {
          e.currentTarget.style.backgroundColor = '#1570EF';
        }
      }}
      onMouseLeave={(e) => {
        if (!disabled && variant === 'primary') {
          e.currentTarget.style.backgroundColor = '#2B8DFF';
        }
      }}
      {...props}
    >
      {icon && <span className="flex-shrink-0" style={{ color: variant === 'primary' || variant === 'success' || variant === 'warning' || variant === 'error' ? '#FFFFFF' : 'inherit' }}>{icon}</span>}
      {children}
    </button>
  );
}