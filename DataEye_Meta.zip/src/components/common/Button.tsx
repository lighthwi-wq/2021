import { ReactNode, ButtonHTMLAttributes } from 'react';
import { colors, glows } from '../../constants/designSystem';

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  children: ReactNode;
  variant?: 'primary' | 'secondary' | 'success' | 'error' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
  icon?: ReactNode;
  fullWidth?: boolean;
  glow?: boolean;
}

export function Button({ 
  children, 
  variant = 'primary', 
  size = 'md', 
  icon,
  fullWidth = false,
  glow = false,
  className = '',
  disabled = false,
  ...props 
}: ButtonProps) {
  
  const sizeStyles = {
    sm: 'px-3 py-1.5 text-xs',
    md: 'px-5 py-2.5 text-sm',
    lg: 'px-7 py-3.5 text-base',
  };

  const getVariantStyles = () => {
    if (disabled) {
      return {
        backgroundColor: 'rgba(255, 255, 255, 0.05)',
        color: 'rgba(255, 255, 255, 0.3)',
        border: '1px solid rgba(255, 255, 255, 0.1)',
        cursor: 'not-allowed',
      };
    }

    switch (variant) {
      case 'primary':
        return {
          backgroundColor: colors.primary,
          color: '#FFFFFF',
          border: 'none',
          boxShadow: glow ? glows.primary : 'none',
          fontWeight: '600',
        };
      case 'secondary':
        return {
          backgroundColor: 'rgba(255, 255, 255, 0.8)',
          color: colors.textPrimary,
          border: `1px solid ${colors.border}`,
        };
      case 'success':
        return {
          backgroundColor: colors.success,
          color: '#FFFFFF',
          border: 'none',
          boxShadow: glow ? glows.success : 'none',
          fontWeight: '600',
        };
      case 'error':
        return {
          backgroundColor: colors.error,
          color: '#FFFFFF',
          border: 'none',
          boxShadow: glow ? glows.error : 'none',
          fontWeight: '600',
        };
      case 'ghost':
        return {
          backgroundColor: 'transparent',
          color: colors.textSecondary,
          border: `1px solid transparent`,
        };
      default:
        return {
          backgroundColor: colors.primary,
          color: '#0A0A0A',
          border: 'none',
        };
    }
  };

  const variantStyles = getVariantStyles();

  return (
    <button
      className={`
        ${sizeStyles[size]}
        ${fullWidth ? 'w-full' : ''}
        inline-flex items-center justify-center gap-2
        rounded-lg font-medium
        transition-all duration-300
        ${disabled ? '' : 'hover:shadow-xl active:scale-[0.98]'}
        ${className}
      `}
      style={variantStyles}
      disabled={disabled}
      onMouseEnter={(e) => {
        if (disabled) return;
        if (variant === 'primary') {
          e.currentTarget.style.backgroundColor = colors.primaryHover;
          if (glow) {
            e.currentTarget.style.boxShadow = '0 4px 30px rgba(0, 102, 255, 0.3)';
          }
        } else if (variant === 'ghost') {
          e.currentTarget.style.backgroundColor = 'rgba(0, 0, 0, 0.03)';
          e.currentTarget.style.borderColor = colors.border;
        } else if (variant === 'secondary') {
          e.currentTarget.style.borderColor = colors.primary;
        }
      }}
      onMouseLeave={(e) => {
        if (disabled) return;
        if (variant === 'primary') {
          e.currentTarget.style.backgroundColor = colors.primary;
          if (glow) {
            e.currentTarget.style.boxShadow = glows.primary;
          }
        } else if (variant === 'ghost') {
          e.currentTarget.style.backgroundColor = 'transparent';
          e.currentTarget.style.borderColor = 'transparent';
        } else if (variant === 'secondary') {
          e.currentTarget.style.borderColor = colors.border;
        }
      }}
      {...props}
    >
      {icon && (
        <span 
          className="flex-shrink-0 flex items-center justify-center"
          style={{ 
            color: variant === 'primary' || variant === 'success' || variant === 'error' ? '#FFFFFF' : 'inherit'
          }}
        >
          {icon}
        </span>
      )}
      {children}
    </button>
  );
}