import { useState, useRef, useEffect } from 'react';
import { Search, Database, Table2, FileText, Shield, AlertCircle, Settings2, BarChart3, Book, ArrowRight } from 'lucide-react';
import { MenuId } from '../../types';

interface SearchItem {
  id: string;
  title: string;
  description: string;
  category: string;
  icon: any;
  menuId?: MenuId;
  type: 'menu' | 'data' | 'quality' | 'feature';
}

interface SearchBarProps {
  onNavigate: (menuId: MenuId) => void;
}

export function SearchBar({ onNavigate }: SearchBarProps) {
  const [query, setQuery] = useState('');
  const [isOpen, setIsOpen] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(0);
  const searchRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // 검색 가능한 항목들
  const searchItems: SearchItem[] = [
    // 메뉴 항목
    { id: 'dashboard', title: '대시보드', description: '전체 시스템 현황 및 주요 지표', category: '메뉴', icon: BarChart3, menuId: 'dashboard', type: 'menu' },
    { id: 'table-mgmt', title: '테이블 관리', description: '데이터베이스 테이블 메타데이터 관리', category: '메뉴', icon: Table2, menuId: 'table-mgmt', type: 'menu' },
    { id: 'column-mgmt', title: '컬럼 관리', description: '테이블 컬럼 메타데이터 관리', category: '메뉴', icon: Database, menuId: 'column-mgmt', type: 'menu' },
    { id: 'standard-word', title: '표준단어 사전', description: '표준화된 단어 및 용어 관리', category: '메뉴', icon: Book, menuId: 'standard-word', type: 'menu' },
    { id: 'standard-domain', title: '표준도메인 사전', description: '데이터 도메인 표준 관리', category: '메뉴', icon: Book, menuId: 'standard-domain', type: 'menu' },
    { id: 'standard-code', title: '표준코드', description: '표준 코드 체계 관리', category: '메뉴', icon: FileText, menuId: 'standard-code', type: 'menu' },
    { id: 'standard-term', title: '표준용어 사전', description: '비즈니스 표준용어 관리', category: '메뉴', icon: Book, menuId: 'standard-term', type: 'menu' },
    { id: 'biz-term', title: '업무용어 사전', description: '업무 도메인 용어 관리', category: '메뉴', icon: Book, menuId: 'biz-term', type: 'menu' },
    { id: 'biz-glossary', title: '용어집', description: '전사 용어 통합 관리', category: '메뉴', icon: Book, menuId: 'biz-glossary', type: 'menu' },
    { id: 'quality-rule', title: '품질 규칙관리', description: '데이터 품질 규칙 정의 및 관리', category: '메뉴', icon: Shield, menuId: 'quality-rule', type: 'menu' },
    { id: 'quality-diagnosis', title: '품질 진단관리', description: '품질 진단 실행 및 모니터링', category: '메뉴', icon: AlertCircle, menuId: 'quality-diagnosis', type: 'menu' },
    { id: 'quality-violation', title: '품질 위반관리', description: '품질 위반 사항 추적 및 관리', category: '메뉴', icon: AlertCircle, menuId: 'quality-violation', type: 'menu' },
    { id: 'quality-action', title: '조치관리', description: '품질 개선 조치 사항 관리', category: '메뉴', icon: Settings2, menuId: 'quality-action', type: 'menu' },
    
    // 데이터 관련
    { id: 'data-catalog', title: '데이터 카탈로그', description: '전사 데이터 자산 카탈로그', category: '데이터', icon: Database, type: 'data' },
    { id: 'data-lineage', title: '데이터 계보', description: '데이터 흐름 및 의존성 추적', category: '데이터', icon: BarChart3, type: 'data' },
    { id: 'metadata-repository', title: '메타데이터 저장소', description: '메타데이터 통합 저장소', category: '데이터', icon: Database, type: 'data' },
    
    // 품질 관련
    { id: 'quality-score', title: '품질 점수', description: '전체 데이터 품질 점수 현황', category: '품질', icon: BarChart3, menuId: 'dashboard', type: 'quality' },
    { id: 'quality-completeness', title: '완전성 검증', description: 'NULL 값 및 필수값 검증', category: '품질', icon: Shield, type: 'quality' },
    { id: 'quality-validity', title: '유효성 검증', description: '데이터 형식 및 범위 검증', category: '품질', icon: Shield, type: 'quality' },
    { id: 'quality-accuracy', title: '정확성 검증', description: '데이터 정확도 검증', category: '품질', icon: Shield, type: 'quality' },
    
    // 기능
    { id: 'export-excel', title: '엑셀 내보내기', description: '데이터를 엑셀 형식으로 내보내기', category: '기능', icon: FileText, type: 'feature' },
    { id: 'import-metadata', title: '메타데이터 가져오기', description: '외부 메타데이터 임포트', category: '기능', icon: Database, type: 'feature' },
    { id: 'schedule-diagnosis', title: '진단 스케줄링', description: '품질 진단 일정 설정', category: '기능', icon: Settings2, type: 'feature' },
  ];

  // 검색 필터링
  const filteredItems = query.trim() === '' 
    ? [] 
    : searchItems.filter(item => 
        item.title.toLowerCase().includes(query.toLowerCase()) ||
        item.description.toLowerCase().includes(query.toLowerCase()) ||
        item.category.toLowerCase().includes(query.toLowerCase())
      ).slice(0, 8); // 최대 8개 결과

  // 외부 클릭 감지
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setIsOpen(false);
        setQuery('');
      }
    }

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // 키보드 네비게이션
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex(prev => Math.min(prev + 1, filteredItems.length - 1));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex(prev => Math.max(prev - 1, 0));
    } else if (e.key === 'Enter' && filteredItems[selectedIndex]) {
      e.preventDefault();
      handleItemClick(filteredItems[selectedIndex]);
    } else if (e.key === 'Escape') {
      setIsOpen(false);
      setQuery('');
      inputRef.current?.blur();
    }
  };

  // 항목 클릭 처리
  const handleItemClick = (item: SearchItem) => {
    if (item.menuId) {
      onNavigate(item.menuId);
    }
    setIsOpen(false);
    setQuery('');
    inputRef.current?.blur();
  };

  // 모든 결과 보기
  const handleViewAllResults = () => {
    onNavigate('search-results' as MenuId);
    setIsOpen(false);
  };

  // 검색어 변경 처리
  const handleQueryChange = (value: string) => {
    setQuery(value);
    setIsOpen(value.trim() !== '');
    setSelectedIndex(0);
  };

  // 카테고리별 색상
  const getCategoryStyles = (category: string) => {
    switch (category) {
      case '메뉴': return 'text-blue-600 bg-blue-50';
      case '데이터': return 'text-teal-600 bg-teal-50';
      case '품질': return 'text-orange-600 bg-orange-50';
      case '기능': return 'text-indigo-600 bg-indigo-50';
      default: return 'text-gray-600 bg-gray-50';
    }
  };

  return (
    <div ref={searchRef} className="relative flex-1 flex items-center justify-center px-12">
      <div className="w-full max-w-2xl">
        <div 
          className="flex items-center gap-3 rounded-xl px-4 py-2 border transition-colors duration-300"
          style={{
            backgroundColor: '#F9FAFB',
            borderColor: '#DADCE0',
            marginLeft: '-30px'
          }}
        >
          <Search 
            className="w-4 h-4 flex-shrink-0"
            style={{ color: '#5F6368' }}
          />
          <input 
            ref={inputRef}
            type="text" 
            placeholder="데이터, 리포트, 인사이트 검색..."
            value={query}
            onChange={(e) => handleQueryChange(e.target.value)}
            onKeyDown={handleKeyDown}
            onFocus={() => query.trim() !== '' && setIsOpen(true)}
            className="bg-transparent border-none outline-none w-full text-sm"
            style={{
              color: '#202124',
              caretColor: '#202124'
            }}
          />
          {query && (
            <span 
              className="text-xs"
              style={{ color: '#5F6368' }}
            >
              {filteredItems.length}개 결과
            </span>
          )}
        </div>

        {/* 검색 결과 드롭다운 */}
        {isOpen && filteredItems.length > 0 && (
          <div 
            className="absolute top-full mt-2 left-12 right-12 border rounded-xl shadow-2xl max-h-96 overflow-y-auto z-50"
            style={{
              backgroundColor: '#FFFFFF',
              borderColor: '#DADCE0'
            }}
          >
            <div className="p-2">
              {filteredItems.map((item, index) => {
                const Icon = item.icon;
                const isSelected = index === selectedIndex;
                
                return (
                  <button
                    key={item.id}
                    onClick={() => handleItemClick(item)}
                    onMouseEnter={() => setSelectedIndex(index)}
                    className={`w-full flex items-start gap-3 p-3 rounded-lg transition-all duration-200 text-left ${
                      isSelected
                        ? 'bg-sky-50 border border-sky-200'
                        : 'hover:bg-gray-50 border border-transparent'
                    }`}
                  >
                    <div className={`p-2 rounded-lg ${getCategoryStyles(item.category)}`}>
                      <Icon className="w-4 h-4" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <h4 className="text-sm font-bold text-gray-900">
                          {item.title}
                        </h4>
                        <span className={`text-xs px-2 py-0.5 rounded-full ${getCategoryStyles(item.category)}`}>
                          {item.category}
                        </span>
                      </div>
                      <p className="text-xs text-gray-500 mt-0.5">
                        {item.description}
                      </p>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* 검색 팁 */}
            <div className="border-t border-gray-200 p-3 bg-gray-50 flex items-center justify-between">
              <p className="text-xs text-gray-500">
                <kbd className="px-1.5 py-0.5 bg-white border border-gray-300 rounded text-xs">↑</kbd>
                {' '}
                <kbd className="px-1.5 py-0.5 bg-white border border-gray-300 rounded text-xs">↓</kbd>
                {' '}이동 · {' '}
                <kbd className="px-1.5 py-0.5 bg-white border border-gray-300 rounded text-xs">Enter</kbd>
                {' '}선택 · {' '}
                <kbd className="px-1.5 py-0.5 bg-white border border-gray-300 rounded text-xs">Esc</kbd>
                {' '}닫기
              </p>
              <button
                onClick={handleViewAllResults}
                className="text-xs text-blue-600 hover:text-blue-800 font-medium flex items-center gap-1 transition-colors duration-200"
              >
                모든 결과 보기
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}

        {/* 검색 결과 없음 */}
        {isOpen && query.trim() !== '' && filteredItems.length === 0 && (
          <div className="absolute top-full mt-2 left-12 right-12 bg-white border border-gray-200 rounded-xl shadow-2xl p-8 z-50">
            <div className="text-center">
              <Search className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <h4 className="text-sm font-bold text-gray-900 mb-1">
                검색 결과가 없습니다
              </h4>
              <p className="text-xs text-gray-500">
                '{query}'에 대한 결과를 찾을 수 없습니다
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}