import { LucideIcon } from 'lucide-react';
import { colors } from '../../constants/designSystem';

interface IconBoxProps {
  icon: LucideIcon;
  color?: 'blue' | 'green' | 'indigo' | 'gray' | 'orange' | 'red' | 'purple';
  size?: 'sm' | 'md' | 'lg';
}

export function IconBox({ icon: Icon, color = 'blue', size = 'md' }: IconBoxProps) {
  
  const getColorStyles = () => {
    const colorMap = {
      blue: {
        bg: 'rgba(43, 141, 255, 0.08)',
        text: '#2B8DFF',
      },
      green: {
        bg: 'rgba(16, 185, 129, 0.08)',
        text: '#10B981',
      },
      indigo: {
        bg: 'rgba(99, 102, 241, 0.08)',
        text: '#6366F1',
      },
      gray: {
        bg: '#F3F4F6',
        text: '#6B7280',
      },
      orange: {
        bg: 'rgba(245, 158, 11, 0.08)',
        text: '#F59E0B',
      },
      red: {
        bg: 'rgba(239, 68, 68, 0.08)',
        text: '#EF4444',
      },
      purple: {
        bg: 'rgba(139, 92, 246, 0.08)',
        text: '#8B5CF6',
      }
    };
    
    return colorMap[color] || colorMap.blue;
  };

  const sizeClasses = {
    sm: 'p-2 w-8 h-8',
    md: 'p-2.5 w-10 h-10',
    lg: 'p-3 w-14 h-14',
  };

  const iconSizeClasses = {
    sm: 'w-4 h-4',
    md: 'w-5 h-5',
    lg: 'w-8 h-8',
  };

  const colorStyles = getColorStyles();

  return (
    <div 
      className={`rounded-xl flex items-center justify-center flex-shrink-0 ${sizeClasses[size]}`}
      style={{
        backgroundColor: colorStyles.bg,
        color: colorStyles.text,
      }}
    >
      <Icon className={iconSizeClasses[size]} />
    </div>
  );
}
