import { LucideIcon } from 'lucide-react';
import { colors } from '../../constants/designSystem';

interface IconBoxProps {
  icon: LucideIcon;
  color?: 'blue' | 'green' | 'indigo' | 'gray' | 'orange' | 'red';
  size?: 'sm' | 'md' | 'lg';
}

export function IconBox({ icon: Icon, color = 'blue', size = 'md' }: IconBoxProps) {
  
  const getColorStyles = () => {
    const colorMap = {
      blue: {
        bg: colors.primaryLight,
        text: colors.primary
      },
      green: {
        bg: colors.successLight,
        text: colors.success
      },
      indigo: {
        bg: 'rgba(43, 141, 255, 0.08)',
        text: '#2B8DFF'
      },
      gray: {
        bg: colors.hover,
        text: colors.textSecondary
      },
      orange: {
        bg: colors.warningLight,
        text: colors.warning
      },
      red: {
        bg: colors.errorLight,
        text: colors.error
      }
    };
    
    return colorMap[color];
  };

  const sizeClasses = {
    sm: 'p-1.5 w-7 h-7',
    md: 'p-2 w-9 h-9',
    lg: 'p-3 w-12 h-12',
  };

  const iconSizeClasses = {
    sm: 'w-3.5 h-3.5',
    md: 'w-4 h-4',
    lg: 'w-6 h-6',
  };

  const colorStyles = getColorStyles();

  return (
    <div 
      className={`rounded-lg shadow-sm flex items-center justify-center flex-shrink-0 ${sizeClasses[size]}`}
      style={{
        backgroundColor: colorStyles.bg,
        color: colorStyles.text
      }}
    >
      <Icon className={iconSizeClasses[size]} />
    </div>
  );
}