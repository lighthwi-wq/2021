import { ChevronLeft, ChevronRight } from 'lucide-react';

interface PaginationProps {
  currentPage: number;
  totalPages: number;
  itemsPerPage: number;
  totalItems: number;
  onPageChange: (page: number) => void;
  onItemsPerPageChange: (itemsPerPage: number) => void;
}

export function Pagination({
  currentPage,
  totalPages,
  itemsPerPage,
  totalItems,
  onPageChange,
  onItemsPerPageChange,
}: PaginationProps) {
  const startItem = (currentPage - 1) * itemsPerPage + 1;
  const endItem = Math.min(currentPage * itemsPerPage, totalItems);

  const renderPageNumbers = () => {
    const pages = [];
    const maxPagesToShow = 5;
    let startPage = Math.max(1, currentPage - Math.floor(maxPagesToShow / 2));
    let endPage = Math.min(totalPages, startPage + maxPagesToShow - 1);

    if (endPage - startPage < maxPagesToShow - 1) {
      startPage = Math.max(1, endPage - maxPagesToShow + 1);
    }

    // 첫 페이지
    if (startPage > 1) {
      pages.push(
        <button
          key={1}
          onClick={() => onPageChange(1)}
          className="px-3 py-1 rounded transition-colors"
          style={{
            backgroundColor: '#F9F9F9',
            borderWidth: '1px',
            borderStyle: 'solid',
            borderColor: '#DADCE0',
            color: '#5F6368',
          }}
        >
          1
        </button>
      );
      if (startPage > 2) {
        pages.push(<span key="ellipsis1" style={{ color: '#5F6368' }}>...</span>);
      }
    }

    // 페이지 번호들
    for (let i = startPage; i <= endPage; i++) {
      pages.push(
        <button
          key={i}
          onClick={() => onPageChange(i)}
          className="px-3 py-1 rounded transition-colors"
          style={{
            backgroundColor: i === currentPage ? '#2B8DFF' : '#F9F9F9',
            borderWidth: '1px',
            borderStyle: 'solid',
            borderColor: i === currentPage ? '#2B8DFF' : '#DADCE0',
            color: i === currentPage ? '#FFFFFF' : '#5F6368',
            fontWeight: i === currentPage ? 'bold' : 'normal',
          }}
        >
          {i}
        </button>
      );
    }

    // 마지막 페이지
    if (endPage < totalPages) {
      if (endPage < totalPages - 1) {
        pages.push(<span key="ellipsis2" style={{ color: '#5F6368' }}>...</span>);
      }
      pages.push(
        <button
          key={totalPages}
          onClick={() => onPageChange(totalPages)}
          className="px-3 py-1 rounded transition-colors"
          style={{
            backgroundColor: '#F9F9F9',
            borderWidth: '1px',
            borderStyle: 'solid',
            borderColor: '#DADCE0',
            color: '#5F6368',
          }}
        >
          {totalPages}
        </button>
      );
    }

    return pages;
  };

  return (
    <div 
      className="flex justify-between items-center mt-4 pt-4"
      style={{ borderTop: '1px solid #DADCE0' }}
    >
      <div className="flex items-center gap-2">
        <span className="text-sm" style={{ color: '#5F6368' }}>페이지당 항목 수:</span>
        <select
          value={itemsPerPage}
          onChange={(e) => onItemsPerPageChange(Number(e.target.value))}
          className="px-3 py-1 rounded border text-sm"
          style={{
            backgroundColor: '#F9F9F9',
            borderColor: '#DADCE0',
            color: '#202124',
          }}
        >
          <option value={10}>10</option>
          <option value={20}>20</option>
          <option value={50}>50</option>
          <option value={100}>100</option>
        </select>
        <span className="text-sm ml-4" style={{ color: '#5F6368' }}>
          {startItem}-{endItem} / {totalItems}개 항목
        </span>
      </div>

      <div className="flex items-center gap-2">
        <button
          onClick={() => onPageChange(currentPage - 1)}
          disabled={currentPage === 1}
          className="px-3 py-1 rounded transition-colors disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-1"
          style={{
            backgroundColor: '#F9F9F9',
            borderWidth: '1px',
            borderStyle: 'solid',
            borderColor: '#DADCE0',
            color: '#5F6368',
          }}
        >
          <ChevronLeft className="w-4 h-4" />
          <span className="text-sm">이전</span>
        </button>

        <div className="flex items-center gap-1">
          {renderPageNumbers()}
        </div>

        <button
          onClick={() => onPageChange(currentPage + 1)}
          disabled={currentPage === totalPages}
          className="px-3 py-1 rounded transition-colors disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-1"
          style={{
            backgroundColor: '#F9F9F9',
            borderWidth: '1px',
            borderStyle: 'solid',
            borderColor: '#DADCE0',
            color: '#5F6368',
          }}
        >
          <span className="text-sm">다음</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
