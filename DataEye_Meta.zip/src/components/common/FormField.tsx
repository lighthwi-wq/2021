import { colors } from '../../constants/designSystem';

interface FormFieldProps {
  label: string;
  required?: boolean;
  children: React.ReactNode;
}

export function FormField({ label, required, children }: FormFieldProps) {
  return (
    <div>
      <label 
        className="block mb-2 text-sm"
        style={{ 
          fontWeight: '600',
          color: colors.textPrimary
        }}
      >
        {label} {required && <span style={{ color: colors.error }}>*</span>}
      </label>
      {children}
    </div>
  );
}

interface InputFieldProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label: string;
  required?: boolean;
}

export function InputField({ label, required, className = '', ...props }: InputFieldProps) {
  return (
    <FormField label={label} required={required}>
      <input
        {...props}
        className={`w-full px-4 py-3 rounded-lg border focus:outline-none transition-all ${className}`}
        style={{
          backgroundColor: colors.inputBg,
          borderColor: colors.border,
          color: colors.textPrimary,
          ...props.style
        }}
        onFocus={(e) => {
          e.currentTarget.style.borderColor = colors.primary;
          e.currentTarget.style.boxShadow = `0 0 0 3px ${colors.primaryLight}`;
        }}
        onBlur={(e) => {
          e.currentTarget.style.borderColor = colors.border;
          e.currentTarget.style.boxShadow = 'none';
        }}
      />
    </FormField>
  );
}

interface SelectFieldProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  label: string;
  required?: boolean;
  options: { value: string; label: string }[];
}

export function SelectField({ label, required, options, className = '', ...props }: SelectFieldProps) {
  return (
    <FormField label={label} required={required}>
      <select
        {...props}
        className={`w-full px-4 py-3 rounded-lg border focus:outline-none transition-all ${className}`}
        style={{
          backgroundColor: colors.inputBg,
          borderColor: colors.border,
          color: colors.textPrimary,
          ...props.style
        }}
        onFocus={(e) => {
          e.currentTarget.style.borderColor = colors.primary;
          e.currentTarget.style.boxShadow = `0 0 0 3px ${colors.primaryLight}`;
        }}
        onBlur={(e) => {
          e.currentTarget.style.borderColor = colors.border;
          e.currentTarget.style.boxShadow = 'none';
        }}
      >
        {options.map(opt => (
          <option key={opt.value} value={opt.value}>{opt.label}</option>
        ))}
      </select>
    </FormField>
  );
}

interface TextAreaFieldProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  label: string;
  required?: boolean;
}

export function TextAreaField({ label, required, className = '', ...props }: TextAreaFieldProps) {
  return (
    <FormField label={label} required={required}>
      <textarea
        {...props}
        className={`w-full px-4 py-3 rounded-lg border focus:outline-none resize-none transition-all ${className}`}
        style={{
          backgroundColor: colors.inputBg,
          borderColor: colors.border,
          color: colors.textPrimary,
          ...props.style
        }}
        onFocus={(e) => {
          e.currentTarget.style.borderColor = colors.primary;
          e.currentTarget.style.boxShadow = `0 0 0 3px ${colors.primaryLight}`;
        }}
        onBlur={(e) => {
          e.currentTarget.style.borderColor = colors.border;
          e.currentTarget.style.boxShadow = 'none';
        }}
      />
    </FormField>
  );
}
