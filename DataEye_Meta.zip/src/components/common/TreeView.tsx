import { ChevronRight, ChevronDown, Folder, FolderOpen } from 'lucide-react';
import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';

interface TreeNode {
  id: string;
  label: string;
  children?: TreeNode[];
  icon?: any;
}

interface TreeViewProps {
  data: TreeNode[];
  onSelect: (node: TreeNode) => void;
  selectedId?: string;
}

export function TreeView({ data, onSelect, selectedId }: TreeViewProps) {
  const [expandedIds, setExpandedIds] = useState<Set<string>>(new Set(['1']));

  const toggleExpand = (id: string) => {
    const newExpanded = new Set(expandedIds);
    if (newExpanded.has(id)) {
      newExpanded.delete(id);
    } else {
      newExpanded.add(id);
    }
    setExpandedIds(newExpanded);
  };

  const renderNode = (node: TreeNode, level: number = 0) => {
    const hasChildren = node.children && node.children.length > 0;
    const isExpanded = expandedIds.has(node.id);
    const isSelected = selectedId === node.id;
    const Icon = node.icon || (isExpanded ? FolderOpen : Folder);

    return (
      <div key={node.id}>
        <motion.div
          className="flex items-center gap-2 px-3 py-2 rounded-lg cursor-pointer transition-colors"
          style={{
            backgroundColor: isSelected ? '#E8F4FF' : 'transparent',
            marginLeft: `${level * 16}px`,
          }}
          onClick={() => {
            if (hasChildren) {
              toggleExpand(node.id);
            }
            onSelect(node);
          }}
          onMouseEnter={(e) => {
            if (!isSelected) {
              e.currentTarget.style.backgroundColor = '#F7F8FA';
            }
          }}
          onMouseLeave={(e) => {
            if (!isSelected) {
              e.currentTarget.style.backgroundColor = 'transparent';
            }
          }}
          whileHover={{ x: 4 }}
          whileTap={{ scale: 0.98 }}
        >
          {hasChildren && (
            <motion.div
              animate={{ rotate: isExpanded ? 90 : 0 }}
              transition={{ duration: 0.2 }}
            >
              <ChevronRight className="w-4 h-4" style={{ color: '#5F6368' }} />
            </motion.div>
          )}
          {!hasChildren && <div className="w-4" />}
          <Icon 
            className="w-4 h-4" 
            style={{ color: isSelected ? '#2B8DFF' : '#5F6368' }} 
          />
          <span 
            className="text-sm"
            style={{ 
              color: isSelected ? '#2B8DFF' : '#202124',
              fontWeight: isSelected ? 600 : 400
            }}
          >
            {node.label}
          </span>
        </motion.div>

        {hasChildren && (
          <AnimatePresence>
            {isExpanded && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.2 }}
                className="overflow-hidden"
              >
                {node.children!.map((child) => renderNode(child, level + 1))}
              </motion.div>
            )}
          </AnimatePresence>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-1">
      {data.map((node) => renderNode(node))}
    </div>
  );
}
