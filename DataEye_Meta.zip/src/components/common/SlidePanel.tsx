import { X } from 'lucide-react';
import { useEffect } from 'react';
import { colors } from '../../constants/designSystem';

interface SlidePanelProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
  size?: 'sm' | 'md' | 'lg' | 'xl' | 'full';
  footer?: React.ReactNode;
}

export function SlidePanel({ 
  isOpen, 
  onClose, 
  title, 
  children, 
  size = 'lg',
  footer 
}: SlidePanelProps) {

  // ESC 키로 닫기
  useEffect(() => {
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleEsc);
    return () => window.removeEventListener('keydown', handleEsc);
  }, [isOpen, onClose]);

  // 바디 스크롤 방지
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const sizeClasses = {
    sm: 'max-w-md',
    md: 'max-w-2xl',
    lg: 'max-w-3xl',
    xl: 'max-w-5xl',
    full: 'max-w-7xl'
  };

  return (
    <>
      {/* 오버레이 */}
      <div 
        className="fixed inset-0 z-50 transition-opacity duration-300"
        style={{ 
          backgroundColor: 'rgba(0, 0, 0, 0.4)',
          backdropFilter: 'blur(4px)'
        }}
        onClick={onClose}
      />

      {/* 슬라이드 패널 */}
      <div 
        className={`fixed top-0 right-0 bottom-0 z-50 ${sizeClasses[size]} w-full shadow-2xl animate-slide-in`}
        style={{
          backgroundColor: colors.surface,
          animation: 'slideIn 0.3s ease-out'
        }}
      >
        {/* 헤더 */}
        <div 
          className="h-16 px-6 flex items-center justify-between border-b sticky top-0 z-10"
          style={{
            backgroundColor: colors.surface,
            borderColor: colors.border
          }}
        >
          <h2 
            className="font-bold"
            style={{ 
              fontSize: '18px',
              color: colors.textPrimary
            }}
          >
            {title}
          </h2>
          <button
            onClick={onClose}
            className="p-2 rounded-lg transition-all duration-200 hover:scale-110 active:scale-95"
            style={{
              backgroundColor: colors.hover,
              color: colors.textSecondary
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = colors.border;
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = colors.hover;
            }}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 바디 */}
        <div 
          className="overflow-y-auto"
          style={{ 
            height: footer ? 'calc(100vh - 64px - 72px)' : 'calc(100vh - 64px)',
            backgroundColor: colors.background
          }}
        >
          <div className="p-6">
            {children}
          </div>
        </div>

        {/* 푸터 */}
        {footer && (
          <div 
            className="h-[72px] px-6 flex items-center justify-end gap-3 border-t sticky bottom-0"
            style={{
              backgroundColor: colors.surface,
              borderColor: colors.border
            }}
          >
            {footer}
          </div>
        )}
      </div>

      <style>{`
        @keyframes slideIn {
          from {
            transform: translateX(100%);
          }
          to {
            transform: translateX(0);
          }
        }
      `}</style>
    </>
  );
}
