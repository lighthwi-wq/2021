import { Database, RefreshCw, TrendingUp, AlertCircle, Info } from 'lucide-react';

const activities = [
  {
    title: '새로운 데이터 소스 추가됨',
    description: 'PostgreSQL 데이터베이스가 성공적으로 연결되었습니다',
    time: '5분 전',
    type: 'success',
    icon: Database
  },
  {
    title: '데이터 동기화 완료',
    description: 'Customer Database의 1.2M 레코드가 업데이트되었습니다',
    time: '15분 전',
    type: 'info',
    icon: RefreshCw
  },
  {
    title: '성능 알림',
    description: 'API 응답 시간이 평균 30% 개선되었습니다',
    time: '1시간 전',
    type: 'success',
    icon: TrendingUp
  },
  {
    title: '데이터 품질 경고',
    description: 'Product Catalog에서 누락된 필드가 감지되었습니다',
    time: '2시간 전',
    type: 'warning',
    icon: AlertCircle
  },
  {
    title: '백업 완료',
    description: '일일 자동 백업이 성공적으로 완료되었습니다',
    time: '3시간 전',
    type: 'info',
    icon: Database
  }
];

type ActivityType = 'success' | 'info' | 'warning' | 'error';

const activityTypeStyles: Record<ActivityType, string> = {
  success: 'text-green-600 dark:text-green-400 bg-green-50 dark:bg-green-900/20',
  info: 'text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-900/20',
  warning: 'text-yellow-600 dark:text-yellow-400 bg-yellow-50 dark:bg-yellow-900/20',
  error: 'text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-900/20',
};

export function ActivityFeed() {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl p-3 border border-gray-200 dark:border-gray-700 transition-all duration-300 h-full shadow-sm">
      <h3 className="text-gray-900 dark:text-white mb-3 font-bold text-sm">최근 활동</h3>
      <div className="space-y-2.5">
        {activities.map((activity, index) => {
          const Icon = activity.icon;
          return (
            <div key={index} className="flex gap-2.5 pb-2.5 border-b border-gray-200 dark:border-gray-700 last:border-0 last:pb-0">
              <div className={`p-1.5 rounded-lg flex-shrink-0 shadow-sm ${activityTypeStyles[activity.type as ActivityType]}`}>
                <Icon className="w-3.5 h-3.5" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-gray-900 dark:text-white mb-0.5 text-sm">
                  {activity.title}
                </p>
                <p className="text-gray-500 dark:text-gray-400 truncate mb-0.5 text-xs">
                  {activity.description}
                </p>
                <p className="text-gray-400 dark:text-gray-500 text-xs">
                  {activity.time}
                </p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}