import { AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';

const areaData = [
  { name: 'Jan', value: 4000, users: 2400 },
  { name: 'Feb', value: 3000, users: 1398 },
  { name: 'Mar', value: 2000, users: 9800 },
  { name: 'Apr', value: 2780, users: 3908 },
  { name: 'May', value: 1890, users: 4800 },
  { name: 'Jun', value: 2390, users: 3800 },
  { name: 'Jul', value: 3490, users: 4300 },
];

const barData = [
  { name: 'Mon', value: 4000 },
  { name: 'Tue', value: 3000 },
  { name: 'Wed', value: 2000 },
  { name: 'Thu', value: 2780 },
  { name: 'Fri', value: 1890 },
  { name: 'Sat', value: 2390 },
  { name: 'Sun', value: 3490 },
];

export function ChartsSection() {
  return (
    <div className="space-y-2.5">
      <div className="rounded-xl p-3 border shadow-sm" style={{ backgroundColor: '#FFFFFF', borderColor: '#DADCE0' }}>
        <h3 className="mb-3 font-bold text-sm" style={{ color: '#202124' }}>데이터 트렌드</h3>
        <ResponsiveContainer width="100%" height={180}>
          <AreaChart data={areaData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#374151" opacity={0.1} />
            <XAxis dataKey="name" stroke="#9CA3AF" />
            <YAxis stroke="#9CA3AF" />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: '#FFFFFF', 
                border: '1px solid #DADCE0',
                borderRadius: '8px',
                color: '#202124'
              }}
            />
            <Legend />
            <Area 
              type="monotone" 
              dataKey="value" 
              stackId="1" 
              stroke="#3B82F6" 
              fill="#3B82F6" 
              fillOpacity={0.6}
            />
            <Area 
              type="monotone" 
              dataKey="users" 
              stackId="2" 
              stroke="#2B8DFF" 
              fill="#2B8DFF" 
              fillOpacity={0.6}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      <div className="rounded-xl p-3 border shadow-sm" style={{ backgroundColor: '#FFFFFF', borderColor: '#DADCE0' }}>
        <h3 className="mb-3 font-bold text-sm" style={{ color: '#202124' }}>주간 API 요청</h3>
        <ResponsiveContainer width="100%" height={160}>
          <BarChart data={barData.map(item => ({ ...item, max: 5000 }))}>
            <CartesianGrid strokeDasharray="3 3" stroke="#9ca3af" opacity={0.8} />
            <XAxis dataKey="name" stroke="#9CA3AF" />
            <YAxis stroke="#9CA3AF" />
            <Tooltip 
              cursor={{ fill: 'rgba(0, 0, 0, 0.15)' }}
              contentStyle={{ 
                backgroundColor: '#FFFFFF', 
                border: '1px solid #DADCE0',
                borderRadius: '8px',
                color: '#202124'
              }} 
            />
            <Bar 
              dataKey="max" 
              fill="#E5E7EB" 
              radius={[0, 0, 0, 0]}
            />
            <Bar 
              dataKey="value" 
              fill="#3B82F6" 
              radius={[0, 0, 0, 0]}
            />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}