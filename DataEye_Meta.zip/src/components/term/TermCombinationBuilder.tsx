import { useState } from 'react';
import { Plus, X, AlertCircle, CheckCircle } from 'lucide-react';
import { colors } from '../../constants/designSystem';

interface WordBlock {
  id: string;
  text: string;
  color: string;
}

const AVAILABLE_WORDS: WordBlock[] = [
  { id: '1', text: 'Customer', color: colors.blockBlue },
  { id: '2', text: 'Account', color: colors.blockGreen },
  { id: '3', text: 'Number', color: colors.blockOrange },
  { id: '4', text: 'Date', color: colors.blockPurple },
  { id: '5', text: 'Name', color: colors.blockPink },
  { id: '6', text: 'Code', color: colors.blockCyan },
  { id: '7', text: 'Amount', color: colors.chart1 },
  { id: '8', text: 'Type', color: colors.chart4 },
];

export function TermCombinationBuilder() {
  const [selectedBlocks, setSelectedBlocks] = useState<WordBlock[]>([]);
  const [isDragging, setIsDragging] = useState(false);

  const addBlock = (block: WordBlock) => {
    setSelectedBlocks([...selectedBlocks, { ...block, id: `${block.id}-${Date.now()}` }]);
  };

  const removeBlock = (id: string) => {
    setSelectedBlocks(selectedBlocks.filter(b => b.id !== id));
  };

  const generatedTermName = selectedBlocks.map(b => b.text).join('_');
  const isValid = selectedBlocks.length >= 2;

  return (
    <div className="space-y-6">
      {/* Available Words */}
      <div>
        <label className="block mb-3" style={{ color: colors.textPrimary, fontWeight: 600 }}>
          Available Standard Words
        </label>
        <div className="flex flex-wrap gap-2">
          {AVAILABLE_WORDS.map(word => (
            <button
              key={word.id}
              onClick={() => addBlock(word)}
              className="px-4 py-2.5 rounded-lg font-medium transition-all duration-200 hover:transform hover:scale-105 hover:shadow-md"
              style={{
                backgroundColor: `${word.color}15`,
                color: word.color,
                border: `2px solid ${word.color}30`,
              }}
            >
              <Plus className="w-4 h-4 inline mr-1" />
              {word.text}
            </button>
          ))}
        </div>
      </div>

      {/* Combination Area */}
      <div>
        <label className="block mb-3" style={{ color: colors.textPrimary, fontWeight: 600 }}>
          Term Combination Builder ✨
        </label>
        <div
          className="min-h-[120px] p-6 rounded-xl border-2 border-dashed transition-all duration-300"
          style={{
            backgroundColor: isDragging ? colors.primaryLight : '#F9FAFB',
            borderColor: isDragging ? colors.primary : '#E5E7EB',
          }}
          onDragOver={(e) => {
            e.preventDefault();
            setIsDragging(true);
          }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={() => setIsDragging(false)}
        >
          {selectedBlocks.length === 0 ? (
            <div className="text-center py-8" style={{ color: colors.textSecondary }}>
              <div className="mb-2">👆 Click blocks above to build your term</div>
              <div className="text-xs">Combine 2 or more words to create a standard term</div>
            </div>
          ) : (
            <div className="flex flex-wrap gap-3">
              {selectedBlocks.map((block, index) => (
                <div key={block.id} className="flex items-center gap-2 animate-slide-down">
                  <div
                    className="px-5 py-3 rounded-lg font-semibold shadow-md transition-all duration-200 hover:shadow-lg"
                    style={{
                      backgroundColor: block.color,
                      color: '#FFFFFF',
                    }}
                  >
                    {block.text}
                  </div>
                  {index < selectedBlocks.length - 1 && (
                    <span style={{ color: colors.textSecondary, fontWeight: 600 }}>+</span>
                  )}
                  <button
                    onClick={() => removeBlock(block.id)}
                    className="p-1 rounded hover:bg-gray-200 transition-colors"
                  >
                    <X className="w-4 h-4" style={{ color: colors.textSecondary }} />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Real-time Preview */}
      <div
        className="p-5 rounded-xl border-2 transition-all duration-300"
        style={{
          backgroundColor: isValid ? colors.successLight : colors.errorLight,
          borderColor: isValid ? colors.success : colors.error,
        }}
      >
        <div className="flex items-start gap-3">
          {isValid ? (
            <CheckCircle className="w-5 h-5 flex-shrink-0 mt-0.5" style={{ color: colors.success }} />
          ) : (
            <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" style={{ color: colors.error }} />
          )}
          <div className="flex-1">
            <div className="mb-2" style={{ color: colors.textPrimary, fontWeight: 600 }}>
              Generated Term Name
            </div>
            <div 
              className="text-lg font-mono p-3 rounded-lg bg-white border"
              style={{ 
                color: isValid ? colors.primary : colors.textSecondary,
                borderColor: '#E5E7EB',
              }}
            >
              {generatedTermName || '(empty)'}
            </div>
            <div className="mt-2 text-xs" style={{ color: colors.textSecondary }}>
              {isValid 
                ? '✓ Valid term name - ready to register' 
                : '⚠ Please add at least 2 words to create a valid term'}
            </div>
          </div>
        </div>
      </div>

      {/* Additional Fields */}
      <div className="space-y-4 pt-4 border-t" style={{ borderColor: colors.divider }}>
        <div>
          <label className="block mb-2" style={{ color: colors.textPrimary, fontWeight: 600 }}>
            English Abbreviation
          </label>
          <input
            type="text"
            placeholder="e.g., CUST_ACCT_NO"
            className="w-full px-4 py-2.5 rounded-lg border"
            style={{
              backgroundColor: '#FFFFFF',
              borderColor: '#DADCE0',
            }}
            value={selectedBlocks.map(b => b.text.substring(0, 4).toUpperCase()).join('_')}
            readOnly
          />
        </div>

        <div>
          <label className="block mb-2" style={{ color: colors.textPrimary, fontWeight: 600 }}>
            Domain
          </label>
          <select
            className="w-full px-4 py-2.5 rounded-lg border"
            style={{
              backgroundColor: '#FFFFFF',
              borderColor: '#DADCE0',
            }}
          >
            <option>Customer</option>
            <option>Product</option>
            <option>Transaction</option>
            <option>Finance</option>
          </select>
        </div>

        <div>
          <label className="block mb-2" style={{ color: colors.textPrimary, fontWeight: 600 }}>
            Description
          </label>
          <textarea
            rows={3}
            placeholder="Describe the purpose and usage of this term..."
            className="w-full px-4 py-2.5 rounded-lg border resize-none"
            style={{
              backgroundColor: '#FFFFFF',
              borderColor: '#DADCE0',
            }}
          />
        </div>
      </div>
    </div>
  );
}
