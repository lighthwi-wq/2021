import { useState } from 'react';
import { X, FileText, GitBranch, History, Database, Table2 } from 'lucide-react';
import { colors } from '../../constants/designSystem';
import { Card } from '../common/Card';

interface TermDetailViewProps {
  onClose: () => void;
  term: {
    name: string;
    englishAbbrev: string;
    domain: string;
    owner: string;
    status: string;
  };
}

export function TermDetailView({ onClose, term }: TermDetailViewProps) {
  const [activeTab, setActiveTab] = useState<'basic' | 'whereUsed' | 'history'>('basic');

  const tabs = [
    { id: 'basic' as const, label: 'Basic Info', icon: FileText },
    { id: 'whereUsed' as const, label: 'Where Used', icon: GitBranch },
    { id: 'history' as const, label: 'History', icon: History },
  ];

  const relatedTables = [
    { name: 'TB_CUSTOMER', columns: ['CUST_ID', 'CUST_NAME'] },
    { name: 'TB_ORDER', columns: ['ORDER_ID', 'CUST_ID'] },
    { name: 'TB_ACCOUNT', columns: ['ACCT_NO', 'CUST_ID'] },
  ];

  return (
    <div className="fixed inset-0 bg-black bg-opacity-30 z-50 animate-fade-in" onClick={onClose}>
      <div 
        className="absolute right-0 top-0 h-full w-[800px] bg-white shadow-2xl animate-slide-in overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="sticky top-0 z-10 bg-white border-b px-8 py-6" style={{ borderColor: colors.divider }}>
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-2">
                <h2 className="text-2xl" style={{ color: colors.textPrimary, fontWeight: 700 }}>
                  {term.name}
                </h2>
                <span 
                  className="px-3 py-1 rounded-full text-xs"
                  style={{
                    backgroundColor: colors.successLight,
                    color: colors.success,
                    fontWeight: 600,
                  }}
                >
                  {term.status}
                </span>
              </div>
              <div style={{ color: colors.textSecondary }}>
                {term.englishAbbrev} · {term.domain} · Owned by {term.owner}
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
            >
              <X className="w-5 h-5" style={{ color: colors.textSecondary }} />
            </button>
          </div>

          {/* Tabs */}
          <div className="flex gap-2 mt-6 border-b" style={{ borderColor: colors.divider }}>
            {tabs.map(tab => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className="px-4 py-3 flex items-center gap-2 font-medium transition-all duration-300 relative"
                  style={{
                    color: isActive ? colors.primary : colors.textSecondary,
                  }}
                >
                  <Icon className="w-4 h-4" />
                  {tab.label}
                  {isActive && (
                    <div 
                      className="absolute bottom-0 left-0 right-0 h-0.5 animate-slide-down"
                      style={{ backgroundColor: colors.primary }}
                    />
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Content */}
        <div className="p-8">
          {activeTab === 'basic' && (
            <div className="space-y-6 animate-fade-in">
              <Card>
                <div className="space-y-4">
                  <div>
                    <div className="text-xs mb-1" style={{ color: colors.textSecondary, fontWeight: 600 }}>
                      TERM NAME
                    </div>
                    <div style={{ color: colors.textPrimary, fontWeight: 600 }}>
                      {term.name}
                    </div>
                  </div>
                  <div>
                    <div className="text-xs mb-1" style={{ color: colors.textSecondary, fontWeight: 600 }}>
                      ENGLISH ABBREVIATION
                    </div>
                    <div style={{ color: colors.textPrimary, fontWeight: 600 }}>
                      {term.englishAbbrev}
                    </div>
                  </div>
                  <div>
                    <div className="text-xs mb-1" style={{ color: colors.textSecondary, fontWeight: 600 }}>
                      DOMAIN
                    </div>
                    <div style={{ color: colors.textPrimary, fontWeight: 600 }}>
                      {term.domain}
                    </div>
                  </div>
                  <div>
                    <div className="text-xs mb-1" style={{ color: colors.textSecondary, fontWeight: 600 }}>
                      DESCRIPTION
                    </div>
                    <div style={{ color: colors.textPrimary }}>
                      Standard term representing customer account number in the system
                    </div>
                  </div>
                </div>
              </Card>
            </div>
          )}

          {activeTab === 'whereUsed' && (
            <div className="animate-fade-in">
              {/* Visual Graph */}
              <div className="mb-6">
                <div className="mb-4" style={{ color: colors.textPrimary, fontWeight: 600 }}>
                  Relationship Diagram
                </div>
                <Card className="p-8">
                  <svg width="100%" height="400" className="overflow-visible">
                    {/* Central Node - Term */}
                    <g>
                      <rect
                        x="250"
                        y="180"
                        width="200"
                        height="60"
                        rx="12"
                        fill={colors.primaryLight}
                        stroke={colors.primary}
                        strokeWidth="2"
                      />
                      <text
                        x="350"
                        y="210"
                        textAnchor="middle"
                        style={{ fill: colors.primary, fontSize: '16px', fontWeight: 600 }}
                      >
                        {term.name}
                      </text>
                      <text
                        x="350"
                        y="225"
                        textAnchor="middle"
                        style={{ fill: colors.textSecondary, fontSize: '12px' }}
                      >
                        Standard Term
                      </text>
                    </g>

                    {/* Connected Tables */}
                    {relatedTables.map((table, index) => {
                      const angle = (index / relatedTables.length) * 2 * Math.PI - Math.PI / 2;
                      const x = 350 + Math.cos(angle) * 220;
                      const y = 210 + Math.sin(angle) * 180;

                      return (
                        <g key={table.name} className="animate-float" style={{ animationDelay: `${index * 0.2}s` }}>
                          {/* Connection Line */}
                          <line
                            x1="350"
                            y1="210"
                            x2={x}
                            y2={y}
                            stroke={colors.border}
                            strokeWidth="2"
                            strokeDasharray="1000"
                            className="animate-draw-line"
                            style={{ animationDelay: `${index * 0.3}s` }}
                          />
                          
                          {/* Table Node */}
                          <rect
                            x={x - 80}
                            y={y - 25}
                            width="160"
                            height="50"
                            rx="8"
                            fill="white"
                            stroke={colors.border}
                            strokeWidth="2"
                          />
                          <Database
                            x={x - 70}
                            y={y - 15}
                            width="16"
                            height="16"
                            style={{ color: colors.chart1 }}
                          />
                          <text
                            x={x}
                            y={y - 5}
                            textAnchor="middle"
                            style={{ fill: colors.textPrimary, fontSize: '13px', fontWeight: 600 }}
                          >
                            {table.name}
                          </text>
                          <text
                            x={x}
                            y={y + 10}
                            textAnchor="middle"
                            style={{ fill: colors.textSecondary, fontSize: '10px' }}
                          >
                            {table.columns.join(', ')}
                          </text>
                        </g>
                      );
                    })}
                  </svg>
                </Card>
              </div>

              {/* Table List */}
              <div>
                <div className="mb-4" style={{ color: colors.textPrimary, fontWeight: 600 }}>
                  Used in {relatedTables.length} Tables
                </div>
                <div className="space-y-3">
                  {relatedTables.map(table => (
                    <Card key={table.name} className="hover:shadow-md transition-shadow cursor-pointer">
                      <div className="flex items-center gap-3">
                        <div 
                          className="p-2 rounded-lg"
                          style={{ backgroundColor: colors.primaryLight }}
                        >
                          <Table2 className="w-5 h-5" style={{ color: colors.primary }} />
                        </div>
                        <div className="flex-1">
                          <div style={{ color: colors.textPrimary, fontWeight: 600 }}>
                            {table.name}
                          </div>
                          <div className="text-xs" style={{ color: colors.textSecondary }}>
                            Columns: {table.columns.join(', ')}
                          </div>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'history' && (
            <div className="space-y-4 animate-fade-in">
              {[
                { action: 'Updated', user: 'John Doe', date: '2024-01-15 14:30', changes: 'Modified description' },
                { action: 'Approved', user: 'Jane Smith', date: '2024-01-10 09:15', changes: 'Status changed to Approved' },
                { action: 'Created', user: 'John Doe', date: '2024-01-05 16:45', changes: 'Initial creation' },
              ].map((item, index) => (
                <Card key={index} className="relative pl-12">
                  <div 
                    className="absolute left-4 top-6 w-6 h-6 rounded-full flex items-center justify-center"
                    style={{ backgroundColor: colors.primaryLight }}
                  >
                    <div className="w-2 h-2 rounded-full" style={{ backgroundColor: colors.primary }} />
                  </div>
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span style={{ color: colors.textPrimary, fontWeight: 600 }}>
                        {item.action}
                      </span>
                      <span style={{ color: colors.textSecondary }}>by {item.user}</span>
                    </div>
                    <div className="text-xs mb-2" style={{ color: colors.textSecondary }}>
                      {item.date}
                    </div>
                    <div className="text-sm" style={{ color: colors.textPrimary }}>
                      {item.changes}
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
