import { useState, useEffect } from 'react';
import { Bell, X, Trash2, Calendar } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Button } from '../common/Button';
import { Badge } from '../common/Badge';
import { colors } from '../../constants/designSystem';
import { useModal } from '../../contexts/ModalContext';

interface NoticeFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  mode: 'create' | 'edit';
  initialData?: {
    id?: number;
    title: string;
    category: string;
    content: string;
    isPinned: boolean;
    isImportant: boolean;
    author: string;
    status: string;
    startDate: string;
    endDate: string;
  };
}

export function NoticeFormModal({ isOpen, onClose, mode, initialData }: NoticeFormModalProps) {
  const { setIsModalOpen } = useModal();
  const [formData, setFormData] = useState({
    title: initialData?.title || '',
    category: initialData?.category || '시스템',
    content: initialData?.content || '',
    isPinned: initialData?.isPinned || false,
    isImportant: initialData?.isImportant || false,
    status: initialData?.status || '게시중',
    startDate: initialData?.startDate || new Date().toISOString().split('T')[0],
    endDate: initialData?.endDate || '',
  });

  useEffect(() => {
    if (initialData) {
      setFormData({
        title: initialData.title,
        category: initialData.category,
        content: initialData.content,
        isPinned: initialData.isPinned,
        isImportant: initialData.isImportant,
        status: initialData.status,
        startDate: initialData.startDate,
        endDate: initialData.endDate,
      });
    }
  }, [initialData]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('공지사항 저장:', formData);
    onClose();
  };

  const handleChange = (field: string, value: string | boolean) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleDelete = () => {
    if (confirm('정말로 이 공지사항을 삭제하시겠습니까?')) {
      console.log('공지사항 삭제:', initialData);
      onClose();
    }
  };

  useEffect(() => {
    setIsModalOpen(isOpen);
  }, [isOpen, setIsModalOpen]);

  const categories = ['시스템', '업무', '교육', '문서', '품질', '보안'];
  const statuses = ['게시중', '예약', '종료'];

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          className="fixed right-0 top-[72px] h-[calc(100vh-72px)] w-[400px] z-50 shadow-2xl overflow-hidden flex flex-col border-l"
          style={{
            backgroundColor: colors.bgPrimary,
            borderColor: colors.border,
          }}
          initial={{ x: '100%' }}
          animate={{ x: 0 }}
          exit={{ x: '100%' }}
          transition={{ 
            type: 'spring',
            damping: 30,
            stiffness: 300
          }}
        >
          {/* Header */}
          <div
            className="px-8 py-6 border-b flex items-center justify-between flex-shrink-0"
            style={{
              backgroundColor: colors.bgPrimary,
              borderColor: colors.border,
            }}
          >
            <div>
              <h2 className="text-xl font-bold" style={{ color: colors.textPrimary }}>
                {mode === 'create' ? '공지사항 작성' : '공지사항 수정'}
              </h2>
              <p className="text-sm mt-1" style={{ color: colors.textSecondary }}>
                {mode === 'create'
                  ? '새로운 공지사항을 작성합니다'
                  : '기존 공지사항을 수정합니다'}
              </p>
            </div>
            <button
              onClick={onClose}
              className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
              style={{ color: colors.textSecondary }}
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto px-8 py-6">
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* 제목 */}
              <div>
                <label className="block text-sm font-medium mb-2" style={{ color: colors.textPrimary }}>
                  제목 <span style={{ color: '#EF4444' }}>*</span>
                </label>
                <input
                  type="text"
                  value={formData.title}
                  onChange={(e) => handleChange('title', e.target.value)}
                  className="w-full px-4 py-2.5 rounded-lg border"
                  style={{ 
                    borderColor: colors.border,
                    backgroundColor: colors.bgPrimary
                  }}
                  placeholder="공지사항 제목을 입력하세요"
                  required
                />
              </div>

              {/* 카테고리 */}
              <div>
                <label className="block text-sm font-medium mb-2" style={{ color: colors.textPrimary }}>
                  카테고리 <span style={{ color: '#EF4444' }}>*</span>
                </label>
                <select
                  value={formData.category}
                  onChange={(e) => handleChange('category', e.target.value)}
                  className="w-full px-4 py-2.5 rounded-lg border"
                  style={{ 
                    borderColor: colors.border,
                    backgroundColor: colors.bgPrimary
                  }}
                  required
                >
                  {categories.map(cat => (
                    <option key={cat} value={cat}>{cat}</option>
                  ))}
                </select>
              </div>

              {/* 내용 */}
              <div>
                <label className="block text-sm font-medium mb-2" style={{ color: colors.textPrimary }}>
                  내용 <span style={{ color: '#EF4444' }}>*</span>
                </label>
                <textarea
                  value={formData.content}
                  onChange={(e) => handleChange('content', e.target.value)}
                  rows={8}
                  className="w-full px-4 py-2.5 rounded-lg border resize-none"
                  style={{ 
                    borderColor: colors.border,
                    backgroundColor: colors.bgPrimary
                  }}
                  placeholder="공지사항 내용을 입력하세요"
                  required
                />
              </div>

              {/* 옵션 */}
              <div className="space-y-3">
                <label className="block text-sm font-medium" style={{ color: colors.textPrimary }}>
                  옵션
                </label>
                <label className="flex items-center gap-3 cursor-pointer p-3 rounded-lg hover:bg-gray-50 transition-colors">
                  <input
                    type="checkbox"
                    checked={formData.isPinned}
                    onChange={(e) => handleChange('isPinned', e.target.checked)}
                    className="w-4 h-4"
                  />
                  <div>
                    <div className="text-sm font-medium" style={{ color: colors.textPrimary }}>
                      상단 고정
                    </div>
                    <div className="text-xs" style={{ color: colors.textTertiary }}>
                      이 공지사항을 목록 상단에 고정합니다
                    </div>
                  </div>
                </label>
                <label className="flex items-center gap-3 cursor-pointer p-3 rounded-lg hover:bg-gray-50 transition-colors">
                  <input
                    type="checkbox"
                    checked={formData.isImportant}
                    onChange={(e) => handleChange('isImportant', e.target.checked)}
                    className="w-4 h-4"
                  />
                  <div>
                    <div className="text-sm font-medium" style={{ color: colors.textPrimary }}>
                      중요 공지
                    </div>
                    <div className="text-xs" style={{ color: colors.textTertiary }}>
                      중요 배지를 표시합니다
                    </div>
                  </div>
                </label>
              </div>

              {/* 구분선 */}
              <div className="border-t pt-6" style={{ borderColor: colors.border }} />

              {/* 게시 기간 */}
              <div>
                <label className="block text-sm font-medium mb-3" style={{ color: colors.textPrimary }}>
                  게시 기간
                </label>
                <div className="space-y-3">
                  <div>
                    <label className="block text-xs mb-1.5" style={{ color: colors.textSecondary }}>
                      시작일 <span style={{ color: '#EF4444' }}>*</span>
                    </label>
                    <div className="relative">
                      <Calendar className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2" style={{ color: colors.textTertiary }} />
                      <input
                        type="date"
                        value={formData.startDate}
                        onChange={(e) => handleChange('startDate', e.target.value)}
                        className="w-full pl-10 pr-4 py-2.5 rounded-lg border"
                        style={{ 
                          borderColor: colors.border,
                          backgroundColor: colors.bgPrimary
                        }}
                        required
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs mb-1.5" style={{ color: colors.textSecondary }}>
                      종료일
                    </label>
                    <div className="relative">
                      <Calendar className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2" style={{ color: colors.textTertiary }} />
                      <input
                        type="date"
                        value={formData.endDate}
                        onChange={(e) => handleChange('endDate', e.target.value)}
                        className="w-full pl-10 pr-4 py-2.5 rounded-lg border"
                        style={{ 
                          borderColor: colors.border,
                          backgroundColor: colors.bgPrimary
                        }}
                      />
                    </div>
                    <p className="text-xs mt-1" style={{ color: colors.textTertiary }}>
                      종료일을 설정하지 않으면 무기한 게시됩니다
                    </p>
                  </div>
                </div>
              </div>

              {/* 상태 */}
              <div>
                <label className="block text-sm font-medium mb-2" style={{ color: colors.textPrimary }}>
                  상태 <span style={{ color: '#EF4444' }}>*</span>
                </label>
                <select
                  value={formData.status}
                  onChange={(e) => handleChange('status', e.target.value)}
                  className="w-full px-4 py-2.5 rounded-lg border"
                  style={{ 
                    borderColor: colors.border,
                    backgroundColor: colors.bgPrimary
                  }}
                  required
                >
                  {statuses.map(status => (
                    <option key={status} value={status}>{status}</option>
                  ))}
                </select>
              </div>
            </form>
          </div>

          {/* Footer */}
          <div
            className="px-8 py-4 border-t flex items-center justify-between flex-shrink-0"
            style={{
              backgroundColor: colors.bgPrimary,
              borderColor: colors.border,
            }}
          >
            <div>
              {mode === 'edit' && (
                <Button variant="error" size="md" onClick={handleDelete}>
                  <Trash2 className="w-4 h-4" />
                  삭제
                </Button>
              )}
            </div>
            <div className="flex gap-2">
              <Button variant="secondary" size="md" onClick={onClose}>
                취소
              </Button>
              <Button variant="primary" size="md" onClick={handleSubmit}>
                {mode === 'create' ? '등록' : '수정'}
              </Button>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
