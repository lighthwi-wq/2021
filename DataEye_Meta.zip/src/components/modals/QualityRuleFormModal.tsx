import { X, ShieldAlert, AlertCircle, Code } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Button } from '../common/Button';
import { Badge } from '../common/Badge';
import { InputField, SelectField, TextAreaField } from '../common/FormField';
import { useState, useEffect } from 'react';
import { colors } from '../../constants/designSystem';

interface QualityRuleFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  mode: 'create' | 'edit';
  initialData?: any;
}

export function QualityRuleFormModal({ isOpen, onClose, mode, initialData }: QualityRuleFormModalProps) {
  const [formData, setFormData] = useState({
    ruleName: initialData?.ruleName || '',
    category: initialData?.category || '완전성',
    dimension: initialData?.dimension || '필수값 검증',
    severity: initialData?.severity || 'high',
    condition: initialData?.condition || '',
    description: initialData?.description || '',
    status: initialData?.status || '활성',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('품질 규칙 저장:', formData);
    onClose();
  };

  const handleChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          className="fixed right-0 top-0 h-screen w-[600px] z-50 shadow-2xl overflow-hidden flex flex-col border-l"
          style={{
            backgroundColor: colors.bgPrimary,
            borderColor: colors.border,
          }}
          initial={{ x: '100%' }}
          animate={{ x: 0 }}
          exit={{ x: '100%' }}
          transition={{ 
            type: 'spring',
            damping: 30,
            stiffness: 300
          }}
        >
          {/* Header */}
          <div
            className="px-8 py-6 border-b flex items-center justify-between flex-shrink-0"
            style={{
              backgroundColor: colors.bgPrimary,
              borderColor: colors.border,
            }}
          >
            <div>
              <h2 className="text-xl font-bold" style={{ color: colors.textPrimary }}>
                {mode === 'create' ? '품질 규칙 추가' : '품질 규칙 수정'}
              </h2>
              <p className="text-sm mt-1" style={{ color: colors.textSecondary }}>
                {mode === 'create'
                  ? '데이터 품질 검증을 위한 새로운 규칙을 정의합니다'
                  : '기존 품질 규칙의 정보를 수정하고 업데이트합니다'}
              </p>
            </div>
            <button
              onClick={onClose}
              className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
              style={{ color: colors.textSecondary }}
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto px-8 py-6">
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* 헤더 정보 */}
              <div 
                className="flex items-start gap-4 p-6 rounded-xl border"
                style={{
                  backgroundColor: colors.bgSecondary,
                  borderColor: colors.border
                }}
              >
                <div 
                  className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0"
                  style={{
                    backgroundColor: colors.hover
                  }}
                >
                  <ShieldAlert className="w-6 h-6" style={{ color: colors.textSecondary }} />
                </div>
                <div className="flex-1">
                  <h3 
                    className="font-bold mb-1"
                    style={{ color: colors.textPrimary }}
                  >
                    {mode === 'create' ? '새로운 품질 규칙 등록' : '품질 규칙 정보 수정'}
                  </h3>
                  <p 
                    className="text-sm"
                    style={{ color: colors.textSecondary }}
                  >
                    {mode === 'create' 
                      ? '데이터 품질 검증을 위한 새로운 규칙을 정의합니다' 
                      : '기존 품질 규칙의 정보를 수정하고 업데이트합니다'}
                  </p>
                </div>
              </div>

              {/* 기본 정보 섹션 */}
              <div 
                className="rounded-xl p-6 border space-y-5"
                style={{
                  backgroundColor: colors.bgSecondary,
                  borderColor: colors.border
                }}
              >
                <h4 
                  className="font-bold mb-4 flex items-center gap-2"
                  style={{ color: colors.textPrimary }}
                >
                  <div className="w-1.5 h-5 rounded-full" style={{ backgroundColor: colors.textSecondary }}></div>
                  기본 정보
                </h4>

                <InputField
                  label="규칙명"
                  required
                  type="text"
                  value={formData.ruleName}
                  onChange={(e) => handleChange('ruleName', e.target.value)}
                  placeholder="예: 고객명 필수값 검증"
                />

                <div className="grid grid-cols-2 gap-4">
                  <SelectField
                    label="품질 차원"
                    required
                    value={formData.category}
                    onChange={(e) => handleChange('category', e.target.value)}
                    options={[
                      { value: '완전성', label: '완전성 (Completeness)' },
                      { value: '유효성', label: '유효성 (Validity)' },
                      { value: '정확성', label: '정확성 (Accuracy)' },
                      { value: '일관성', label: '일관성 (Consistency)' },
                      { value: '유일성', label: '유일성 (Uniqueness)' },
                      { value: '적시성', label: '적시성 (Timeliness)' }
                    ]}
                  />

                  <SelectField
                    label="규칙 유형"
                    required
                    value={formData.dimension}
                    onChange={(e) => handleChange('dimension', e.target.value)}
                    options={[
                      { value: '필수값 검증', label: '필수값 검증' },
                      { value: '형식 검증', label: '형식 검증' },
                      { value: '범위 검증', label: '범위 검증' },
                      { value: '중복 검증', label: '중복 검증' },
                      { value: '참조 무결성', label: '참조 무결성' },
                      { value: '도메인 검증', label: '도메인 검증' }
                    ]}
                  />
                </div>

                {/* 중요도 */}
                <div>
                  <label 
                    className="block mb-3 font-bold"
                    style={{ color: colors.textSecondary }}
                  >
                    중요도 <span className="text-red-500">*</span>
                  </label>
                  <div className="flex gap-3">
                    {[
                      { value: 'high', variant: 'error' as const, label: '높음', color: '#EF4444' },
                      { value: 'medium', variant: 'warning' as const, label: '보통', color: '#F97316' },
                      { value: 'low', variant: 'default' as const, label: '낮음', color: '#3B82F6' }
                    ].map(({ value, variant, label, color }) => (
                      <label 
                        key={value}
                        className="flex items-center gap-2 cursor-pointer px-4 py-2.5 rounded-lg border-2 transition-all"
                        style={{
                          borderColor: formData.severity === value ? colors.border : colors.border,
                          backgroundColor: formData.severity === value ? colors.hover : 'transparent'
                        }}
                        onMouseEnter={(e) => {
                          if (formData.severity !== value) {
                            e.currentTarget.style.backgroundColor = colors.bgSecondary;
                          }
                        }}
                        onMouseLeave={(e) => {
                          if (formData.severity !== value) {
                            e.currentTarget.style.backgroundColor = 'transparent';
                          }
                        }}
                      >
                        <input
                          type="radio"
                          name="severity"
                          value={value}
                          checked={formData.severity === value}
                          onChange={(e) => handleChange('severity', e.target.value)}
                          className="w-4 h-4"
                        />
                        <span style={{ color: colors.textPrimary }}>{label}</span>
                      </label>
                    ))}
                  </div>
                </div>
              </div>

              {/* 검증 조건 섹션 */}
              <div 
                className="rounded-xl p-6 border space-y-5"
                style={{
                  backgroundColor: colors.bgSecondary,
                  borderColor: colors.border
                }}
              >
                <h4 
                  className="font-bold mb-4 flex items-center gap-2"
                  style={{ color: colors.textPrimary }}
                >
                  <div className="w-1.5 h-5 rounded-full" style={{ backgroundColor: colors.textSecondary }}></div>
                  검증 조건
                </h4>

                <div>
                  <label 
                    className="block mb-2 font-bold flex items-center gap-2"
                    style={{ color: colors.textSecondary }}
                  >
                    <Code className="w-4 h-4" />
                    SQL 조건식 <span className="text-red-500">*</span>
                  </label>
                  <textarea
                    value={formData.condition}
                    onChange={(e) => handleChange('condition', e.target.value)}
                    className="w-full px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-400 focus:border-transparent font-mono text-sm resize-none transition-all"
                    style={{
                      backgroundColor: colors.bgPrimary,
                      borderWidth: '1px',
                      borderStyle: 'solid',
                      borderColor: colors.border,
                      color: colors.textPrimary
                    }}
                    rows={6}
                    placeholder={`예: WHERE column_name IS NULL\n    OR LENGTH(column_name) = 0`}
                    required
                  />
                  <p className="text-xs mt-2" style={{ color: colors.textSecondary }}>
                    SQL WHERE 절에 사용될 조건식을 입력하세요
                  </p>
                </div>

                <TextAreaField
                  label="설명"
                  value={formData.description}
                  onChange={(e) => handleChange('description', e.target.value)}
                  rows={4}
                  placeholder="품질 규칙에 대한 상세 설명을 입력하세요"
                />

                {/* 상태 */}
                <div>
                  <label 
                    className="block mb-3 font-bold"
                    style={{ color: colors.textSecondary }}
                  >
                    상태
                  </label>
                  <div className="flex gap-3">
                    {[
                      { value: '활성', variant: 'success' as const, color: '#10B981' },
                      { value: '비활성', variant: 'default' as const, color: '#9CA3AF' }
                    ].map(({ value, variant, color }) => (
                      <label 
                        key={value}
                        className="flex items-center gap-2 cursor-pointer px-4 py-2.5 rounded-lg border-2 transition-all"
                        style={{
                          borderColor: formData.status === value ? colors.border : colors.border,
                          backgroundColor: formData.status === value ? colors.hover : 'transparent'
                        }}
                        onMouseEnter={(e) => {
                          if (formData.status !== value) {
                            e.currentTarget.style.backgroundColor = colors.bgSecondary;
                          }
                        }}
                        onMouseLeave={(e) => {
                          if (formData.status !== value) {
                            e.currentTarget.style.backgroundColor = 'transparent';
                          }
                        }}
                      >
                        <input
                          type="radio"
                          name="status"
                          value={value}
                          checked={formData.status === value}
                          onChange={(e) => handleChange('status', e.target.value)}
                          className="w-4 h-4"
                        />
                        <span style={{ color: colors.textPrimary }}>{value}</span>
                      </label>
                    ))}
                  </div>
                </div>
              </div>

              {/* 안내 메시지 */}
              <div 
                className="border rounded-xl p-5"
                style={{
                  backgroundColor: colors.hover,
                  borderColor: colors.border
                }}
              >
                <div className="flex gap-3">
                  <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" style={{ color: colors.textSecondary }} />
                  <div className="text-sm">
                    <p className="font-bold mb-2" style={{ color: colors.textPrimary }}>
                      품질 규칙 등록 가이드
                    </p>
                    <ul className="list-disc list-inside space-y-1.5" style={{ color: colors.textSecondary }}>
                      <li>SQL WHERE 절에 사용 가능한 조건식을 작성합니다</li>
                      <li>중요도가 높을수록 위반 시 더 강력한 알림이 발생합니다</li>
                      <li>활성 상태의 규칙만 품질 진단에 적용됩니다</li>
                    </ul>
                  </div>
                </div>
              </div>
            </form>
          </div>

          {/* Footer */}
          <div
            className="px-8 py-4 border-t flex items-center justify-end gap-3 flex-shrink-0"
            style={{
              backgroundColor: colors.bgPrimary,
              borderColor: colors.border,
            }}
          >
            <Button type="button" variant="secondary" onClick={onClose}>
              취소
            </Button>
            <Button type="submit" variant="primary" onClick={handleSubmit}>
              {mode === 'create' ? '등록' : '저장'}
            </Button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}