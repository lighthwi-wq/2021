import { useState, useEffect } from 'react';
import { BookOpen, AlertCircle, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Button } from '../common/Button';
import { Badge } from '../common/Badge';
import { colors } from '../../constants/designSystem';

interface StandardTermFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  mode: 'create' | 'edit';
  initialData?: {
    term: string;
    englishName: string;
    standard: string;
    type: string;
    dataType: string;
    status: string;
    description?: string;
  };
}

export function StandardTermFormModal({ isOpen, onClose, mode, initialData }: StandardTermFormModalProps) {
  const [formData, setFormData] = useState({
    term: initialData?.term || '',
    englishName: initialData?.englishName || '',
    standard: initialData?.standard || '',
    type: initialData?.type || '일반용어',
    dataType: initialData?.dataType || 'VARCHAR(100)',
    status: initialData?.status || '검토중',
    description: initialData?.description || '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('표준용어 저장:', formData);
    // 실제 저장 로직 구현
    onClose();
  };

  const handleChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          className="fixed right-0 top-0 h-screen w-[600px] z-50 shadow-2xl overflow-hidden flex flex-col border-l"
          style={{
            backgroundColor: colors.bgPrimary,
            borderColor: colors.border,
          }}
          initial={{ x: '100%' }}
          animate={{ x: 0 }}
          exit={{ x: '100%' }}
          transition={{ 
            type: 'spring',
            damping: 30,
            stiffness: 300
          }}
        >
          {/* Header */}
          <div
            className="px-8 py-6 border-b flex items-center justify-between flex-shrink-0"
            style={{
              backgroundColor: colors.bgPrimary,
              borderColor: colors.border,
            }}
          >
            <div>
              <h2 className="text-xl font-bold" style={{ color: colors.textPrimary }}>
                {mode === 'create' ? '표준용어 추가' : '표준용어 수정'}
              </h2>
              <p className="text-sm mt-1" style={{ color: colors.textSecondary }}>
                {mode === 'create'
                  ? '메타데이터 표준화를 위한 새로운 표준용어를 정의합니다'
                  : '기존 표준용어의 정보를 수정하고 업데이트합니다'}
              </p>
            </div>
            <button
              onClick={onClose}
              className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
              style={{ color: colors.textSecondary }}
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto px-8 py-6">
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* 헤더 정보 */}
              <div
                className="flex items-start gap-4 p-6 rounded-xl border"
                style={{
                  backgroundColor: colors.bgSecondary,
                  borderColor: colors.border
                }}
              >
                <div
                  className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0"
                  style={{
                    backgroundColor: colors.hover
                  }}
                >
                  <BookOpen className="w-6 h-6" style={{ color: colors.textSecondary }} />
                </div>
                <div className="flex-1">
                  <h3
                    className="font-bold mb-1"
                    style={{ color: colors.textPrimary }}
                  >
                    {mode === 'create' ? '새로운 표준용어 등록' : '표준용어 정보 수정'}
                  </h3>
                  <p
                    className="text-sm"
                    style={{ color: colors.textSecondary }}
                  >
                    {mode === 'create'
                      ? '메타데이터 표준화를 위한 새로운 표준용어를 정의합니다'
                      : '기존 표준용어의 정보를 수정하고 업데이트합니다'}
                  </p>
                </div>
              </div>

              {/* 기본 정보 섹션 */}
              <div
                className="rounded-xl p-6 border space-y-5"
                style={{
                  backgroundColor: colors.bgSecondary,
                  borderColor: colors.border
                }}
              >
                <h4
                  className="font-bold mb-4 flex items-center gap-2"
                  style={{ color: colors.textPrimary }}
                >
                  <div className="w-1.5 h-5 rounded-full" style={{ backgroundColor: colors.textSecondary }}></div>
                  기본 정보
                </h4>

                {/* 한글명 */}
                <div>
                  <label
                    className="block mb-2 font-bold"
                    style={{ color: colors.textSecondary }}
                  >
                    한글명 <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={formData.term}
                    onChange={(e) => handleChange('term', e.target.value)}
                    className="w-full px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-400 focus:border-transparent transition-all"
                    style={{
                      backgroundColor: colors.bgPrimary,
                      borderWidth: '1px',
                      borderStyle: 'solid',
                      borderColor: colors.border,
                      color: colors.textPrimary
                    }}
                    placeholder="예: 고객명"
                    required
                  />
                </div>

                {/* 영문명 */}
                <div>
                  <label
                    className="block mb-2 font-bold"
                    style={{ color: colors.textSecondary }}
                  >
                    영문명 <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={formData.englishName}
                    onChange={(e) => handleChange('englishName', e.target.value)}
                    className="w-full px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-400 focus:border-transparent transition-all"
                    style={{
                      backgroundColor: colors.bgPrimary,
                      borderWidth: '1px',
                      borderStyle: 'solid',
                      borderColor: colors.border,
                      color: colors.textPrimary
                    }}
                    placeholder="예: CUSTOMER_NAME"
                    required
                  />
                </div>

                {/* 표준명 */}
                <div>
                  <label
                    className="block mb-2 font-bold"
                    style={{ color: colors.textSecondary }}
                  >
                    표준명 <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={formData.standard}
                    onChange={(e) => handleChange('standard', e.target.value)}
                    className="w-full px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-400 focus:border-transparent font-mono transition-all"
                    style={{
                      backgroundColor: colors.bgPrimary,
                      borderWidth: '1px',
                      borderStyle: 'solid',
                      borderColor: colors.border,
                      color: colors.textPrimary
                    }}
                    placeholder="예: CUST_NM"
                    required
                  />
                </div>
              </div>

              {/* 상세 정보 섹션 */}
              <div
                className="rounded-xl p-6 border space-y-5"
                style={{
                  backgroundColor: colors.bgSecondary,
                  borderColor: colors.border
                }}
              >
                <h4
                  className="font-bold mb-4 flex items-center gap-2"
                  style={{ color: colors.textPrimary }}
                >
                  <div className="w-1.5 h-5 rounded-full" style={{ backgroundColor: colors.textSecondary }}></div>
                  상세 정보
                </h4>

                <div className="grid grid-cols-2 gap-4">
                  {/* 유형 */}
                  <div>
                    <label
                      className="block mb-2 font-bold"
                      style={{ color: colors.textSecondary }}
                    >
                      유형 <span className="text-red-500">*</span>
                    </label>
                    <select
                      value={formData.type}
                      onChange={(e) => handleChange('type', e.target.value)}
                      className="w-full px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-400 focus:border-transparent transition-all"
                      style={{
                        backgroundColor: colors.bgPrimary,
                        borderWidth: '1px',
                        borderStyle: 'solid',
                        borderColor: colors.border,
                        color: colors.textPrimary
                      }}
                      required
                    >
                      <option value="일반용어">일반용어</option>
                      <option value="코드용어">코드용어</option>
                      <option value="계산용어">계산용어</option>
                      <option value="복합용어">복합용어</option>
                    </select>
                  </div>

                  {/* 데이터타입 */}
                  <div>
                    <label
                      className="block mb-2 font-bold"
                      style={{ color: colors.textSecondary }}
                    >
                      데이터타입 <span className="text-red-500">*</span>
                    </label>
                    <select
                      value={formData.dataType}
                      onChange={(e) => handleChange('dataType', e.target.value)}
                      className="w-full px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-400 focus:border-transparent font-mono text-sm transition-all"
                      style={{
                        backgroundColor: colors.bgPrimary,
                        borderWidth: '1px',
                        borderStyle: 'solid',
                        borderColor: colors.border,
                        color: colors.textPrimary
                      }}
                      required
                    >
                      <option value="VARCHAR(100)">VARCHAR(100)</option>
                      <option value="VARCHAR(200)">VARCHAR(200)</option>
                      <option value="VARCHAR(20)">VARCHAR(20)</option>
                      <option value="NUMBER(15,2)">NUMBER(15,2)</option>
                      <option value="NUMBER(10)">NUMBER(10)</option>
                      <option value="DATE">DATE</option>
                      <option value="TIMESTAMP">TIMESTAMP</option>
                    </select>
                  </div>
                </div>

                {/* 상태 */}
                <div>
                  <label
                    className="block mb-3 font-bold"
                    style={{ color: colors.textSecondary }}
                  >
                    상태
                  </label>
                  <div className="flex gap-3">
                    <label
                      className="flex items-center gap-2 cursor-pointer px-4 py-2.5 rounded-lg border-2 transition-all"
                      style={{
                        borderColor: formData.status === '검토중' ? colors.border : colors.border,
                        backgroundColor: formData.status === '검토중' ? colors.hover : 'transparent'
                      }}
                      onMouseEnter={(e) => {
                        if (formData.status !== '검토중') {
                          e.currentTarget.style.backgroundColor = colors.bgSecondary;
                        }
                      }}
                      onMouseLeave={(e) => {
                        if (formData.status !== '검토중') {
                          e.currentTarget.style.backgroundColor = 'transparent';
                        }
                      }}
                    >
                      <input
                        type="radio"
                        name="status"
                        value="검토중"
                        checked={formData.status === '검토중'}
                        onChange={(e) => handleChange('status', e.target.value)}
                        className="w-4 h-4 text-blue-600"
                      />
                      <span style={{ color: colors.textPrimary }}>검토중</span>
                    </label>
                    <label
                      className="flex items-center gap-2 cursor-pointer px-4 py-2.5 rounded-lg border-2 transition-all"
                      style={{
                        borderColor: formData.status === '승인' ? colors.border : colors.border,
                        backgroundColor: formData.status === '승인' ? colors.hover : 'transparent'
                      }}
                      onMouseEnter={(e) => {
                        if (formData.status !== '승인') {
                          e.currentTarget.style.backgroundColor = colors.bgSecondary;
                        }
                      }}
                      onMouseLeave={(e) => {
                        if (formData.status !== '승인') {
                          e.currentTarget.style.backgroundColor = 'transparent';
                        }
                      }}
                    >
                      <input
                        type="radio"
                        name="status"
                        value="승인"
                        checked={formData.status === '승인'}
                        onChange={(e) => handleChange('status', e.target.value)}
                        className="w-4 h-4 text-blue-600"
                      />
                      <span style={{ color: colors.textPrimary }}>승인</span>
                    </label>
                    <label
                      className="flex items-center gap-2 cursor-pointer px-4 py-2.5 rounded-lg border-2 transition-all"
                      style={{
                        borderColor: formData.status === '반려' ? colors.border : colors.border,
                        backgroundColor: formData.status === '반려' ? colors.hover : 'transparent'
                      }}
                      onMouseEnter={(e) => {
                        if (formData.status !== '반려') {
                          e.currentTarget.style.backgroundColor = colors.bgSecondary;
                        }
                      }}
                      onMouseLeave={(e) => {
                        if (formData.status !== '반려') {
                          e.currentTarget.style.backgroundColor = 'transparent';
                        }
                      }}
                    >
                      <input
                        type="radio"
                        name="status"
                        value="반려"
                        checked={formData.status === '반려'}
                        onChange={(e) => handleChange('status', e.target.value)}
                        className="w-4 h-4 text-blue-600"
                      />
                      <span style={{ color: colors.textPrimary }}>반려</span>
                    </label>
                  </div>
                </div>

                {/* 설명 */}
                <div>
                  <label
                    className="block mb-2 font-bold"
                    style={{ color: colors.textSecondary }}
                  >
                    설명
                  </label>
                  <textarea
                    value={formData.description}
                    onChange={(e) => handleChange('description', e.target.value)}
                    className="w-full px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-400 focus:border-transparent resize-none transition-all"
                    style={{
                      backgroundColor: colors.bgPrimary,
                      borderWidth: '1px',
                      borderStyle: 'solid',
                      borderColor: colors.border,
                      color: colors.textPrimary
                    }}
                    rows={4}
                    placeholder="표준용어에 대한 상세 설명을 입력하세요"
                  />
                </div>
              </div>

              {/* 안내 메시지 */}
              <div
                className="border rounded-xl p-5"
                style={{
                  backgroundColor: colors.hover,
                  borderColor: colors.border
                }}
              >
                <div className="flex gap-3">
                  <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" style={{ color: colors.textSecondary }} />
                  <div className="text-sm">
                    <p className="font-bold mb-2" style={{ color: colors.textPrimary }}>
                      표준용어 등록 가이드
                    </p>
                    <ul className="list-disc list-inside space-y-1.5" style={{ color: colors.textSecondary }}>
                      <li>표준명은 언더스코어(_)로 단어를 구분합니다</li>
                      <li>영문 대문자를 사용하며, 약어를 적극 활용합니다</li>
                      <li>데이터타입은 실제 사용될 타입으로 정확히 지정합니다</li>
                    </ul>
                  </div>
                </div>
              </div>
            </form>
          </div>

          {/* Footer */}
          <div
            className="px-8 py-4 border-t flex items-center justify-end gap-3 flex-shrink-0"
            style={{
              backgroundColor: colors.bgPrimary,
              borderColor: colors.border,
            }}
          >
            <Button type="button" variant="secondary" onClick={onClose}>
              취소
            </Button>
            <Button type="submit" variant="primary" onClick={handleSubmit}>
              {mode === 'create' ? '등록' : '저장'}
            </Button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}