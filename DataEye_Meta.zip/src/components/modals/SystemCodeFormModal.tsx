import { useState, useEffect } from 'react';
import { Code2, X, Trash2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Button } from '../common/Button';
import { Badge } from '../common/Badge';
import { colors } from '../../constants/designSystem';
import { useModal } from '../../contexts/ModalContext';

interface SystemCodeFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  mode: 'create' | 'edit';
  initialData?: {
    codeGroup: string;
    codeGroupName: string;
    code: string;
    codeName: string;
    orderNo: number;
    useYn: string;
    description: string;
  };
}

export function SystemCodeFormModal({ isOpen, onClose, mode, initialData }: SystemCodeFormModalProps) {
  const { setIsModalOpen } = useModal();
  const [formData, setFormData] = useState({
    codeGroup: initialData?.codeGroup || '',
    codeGroupName: initialData?.codeGroupName || '',
    code: initialData?.code || '',
    codeName: initialData?.codeName || '',
    orderNo: initialData?.orderNo || 1,
    useYn: initialData?.useYn || 'Y',
    description: initialData?.description || '',
  });

  useEffect(() => {
    if (initialData) {
      setFormData({
        codeGroup: initialData.codeGroup,
        codeGroupName: initialData.codeGroupName,
        code: initialData.code,
        codeName: initialData.codeName,
        orderNo: initialData.orderNo,
        useYn: initialData.useYn,
        description: initialData.description,
      });
    }
  }, [initialData]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('시스템코드 저장:', formData);
    onClose();
  };

  const handleChange = (field: string, value: string | number) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleDelete = () => {
    if (confirm('정말로 이 코드를 삭제하시겠습니까?')) {
      console.log('코드 삭제:', initialData);
      onClose();
    }
  };

  useEffect(() => {
    setIsModalOpen(isOpen);
  }, [isOpen, setIsModalOpen]);

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          className="fixed right-0 top-[72px] h-[calc(100vh-72px)] w-[400px] z-50 shadow-2xl overflow-hidden flex flex-col border-l"
          style={{
            backgroundColor: colors.bgPrimary,
            borderColor: colors.border,
          }}
          initial={{ x: '100%' }}
          animate={{ x: 0 }}
          exit={{ x: '100%' }}
          transition={{ 
            type: 'spring',
            damping: 30,
            stiffness: 300
          }}
        >
          {/* Header */}
          <div
            className="px-8 py-6 border-b flex items-center justify-between flex-shrink-0"
            style={{
              backgroundColor: colors.bgPrimary,
              borderColor: colors.border,
            }}
          >
            <div>
              <h2 className="text-xl font-bold" style={{ color: colors.textPrimary }}>
                {mode === 'create' ? '시스템코드 추가' : '시스템코드 수정'}
              </h2>
              <p className="text-sm mt-1" style={{ color: colors.textSecondary }}>
                {mode === 'create'
                  ? '새로운 시스템 코드를 등록합니다'
                  : '기존 시스템 코드를 수정합니다'}
              </p>
            </div>
            <button
              onClick={onClose}
              className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
              style={{ color: colors.textSecondary }}
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto px-8 py-6">
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* 코드그룹 정보 */}
              <div>
                <label className="block text-sm font-medium mb-2" style={{ color: colors.textPrimary }}>
                  코드그룹 <span style={{ color: '#EF4444' }}>*</span>
                </label>
                <input
                  type="text"
                  value={formData.codeGroup}
                  onChange={(e) => handleChange('codeGroup', e.target.value.toUpperCase())}
                  className="w-full px-4 py-2.5 rounded-lg border font-mono"
                  style={{ 
                    borderColor: colors.border,
                    backgroundColor: colors.bgPrimary
                  }}
                  placeholder="예: APPR_STAT"
                  required
                  disabled={mode === 'edit'}
                />
                <p className="text-xs mt-1" style={{ color: colors.textTertiary }}>
                  영문 대문자와 언더스코어(_)만 사용
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2" style={{ color: colors.textPrimary }}>
                  그룹명 <span style={{ color: '#EF4444' }}>*</span>
                </label>
                <input
                  type="text"
                  value={formData.codeGroupName}
                  onChange={(e) => handleChange('codeGroupName', e.target.value)}
                  className="w-full px-4 py-2.5 rounded-lg border"
                  style={{ 
                    borderColor: colors.border,
                    backgroundColor: colors.bgPrimary
                  }}
                  placeholder="예: 승인상태"
                  required
                />
              </div>

              {/* 구분선 */}
              <div className="border-t pt-6" style={{ borderColor: colors.border }} />

              {/* 코드 정보 */}
              <div>
                <label className="block text-sm font-medium mb-2" style={{ color: colors.textPrimary }}>
                  코드 <span style={{ color: '#EF4444' }}>*</span>
                </label>
                <input
                  type="text"
                  value={formData.code}
                  onChange={(e) => handleChange('code', e.target.value.toUpperCase())}
                  className="w-full px-4 py-2.5 rounded-lg border font-mono"
                  style={{ 
                    borderColor: colors.border,
                    backgroundColor: colors.bgPrimary
                  }}
                  placeholder="예: APPR"
                  required
                  disabled={mode === 'edit'}
                />
                <p className="text-xs mt-1" style={{ color: colors.textTertiary }}>
                  영문 대문자와 숫자, 언더스코어(_)만 사용
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2" style={{ color: colors.textPrimary }}>
                  코드명 <span style={{ color: '#EF4444' }}>*</span>
                </label>
                <input
                  type="text"
                  value={formData.codeName}
                  onChange={(e) => handleChange('codeName', e.target.value)}
                  className="w-full px-4 py-2.5 rounded-lg border"
                  style={{ 
                    borderColor: colors.border,
                    backgroundColor: colors.bgPrimary
                  }}
                  placeholder="예: 승인완료"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2" style={{ color: colors.textPrimary }}>
                  순서
                </label>
                <input
                  type="number"
                  value={formData.orderNo}
                  onChange={(e) => handleChange('orderNo', parseInt(e.target.value))}
                  className="w-full px-4 py-2.5 rounded-lg border"
                  style={{ 
                    borderColor: colors.border,
                    backgroundColor: colors.bgPrimary
                  }}
                  min={1}
                />
                <p className="text-xs mt-1" style={{ color: colors.textTertiary }}>
                  화면에 표시될 순서 (숫자가 작을수록 먼저 표시)
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2" style={{ color: colors.textPrimary }}>
                  사용여부 <span style={{ color: '#EF4444' }}>*</span>
                </label>
                <div className="flex gap-4">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      name="useYn"
                      value="Y"
                      checked={formData.useYn === 'Y'}
                      onChange={(e) => handleChange('useYn', e.target.value)}
                      className="w-4 h-4"
                    />
                    <span style={{ color: colors.textPrimary }}>사용</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      name="useYn"
                      value="N"
                      checked={formData.useYn === 'N'}
                      onChange={(e) => handleChange('useYn', e.target.value)}
                      className="w-4 h-4"
                    />
                    <span style={{ color: colors.textPrimary }}>미사용</span>
                  </label>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2" style={{ color: colors.textPrimary }}>
                  설명
                </label>
                <textarea
                  value={formData.description}
                  onChange={(e) => handleChange('description', e.target.value)}
                  rows={4}
                  className="w-full px-4 py-2.5 rounded-lg border resize-none"
                  style={{ 
                    borderColor: colors.border,
                    backgroundColor: colors.bgPrimary
                  }}
                  placeholder="코드에 대한 상세 설명을 입력하세요"
                />
              </div>
            </form>
          </div>

          {/* Footer */}
          <div
            className="px-8 py-4 border-t flex items-center justify-between flex-shrink-0"
            style={{
              backgroundColor: colors.bgPrimary,
              borderColor: colors.border,
            }}
          >
            <div>
              {mode === 'edit' && (
                <Button variant="error" size="md" onClick={handleDelete}>
                  <Trash2 className="w-4 h-4" />
                  삭제
                </Button>
              )}
            </div>
            <div className="flex gap-2">
              <Button variant="secondary" size="md" onClick={onClose}>
                취소
              </Button>
              <Button variant="primary" size="md" onClick={handleSubmit}>
                {mode === 'create' ? '등록' : '수정'}
              </Button>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
