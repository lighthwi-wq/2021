import { X, ShieldCheck, AlertCircle, CheckCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Button } from '../common/Button';
import { Badge } from '../common/Badge';
import { InputField, SelectField, TextAreaField } from '../common/FormField';
import { useState, useEffect } from 'react';
import { colors } from '../../constants/designSystem';
import { useModal } from '../../contexts/ModalContext';

interface ViolationActionFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  violationData?: any;
  mode?: 'create' | 'edit';
  initialData?: any;
}

export function ViolationActionFormModal({ isOpen, onClose, violationData, mode = 'create', initialData }: ViolationActionFormModalProps) {
  const { setIsModalOpen } = useModal();
  const [formData, setFormData] = useState({
    tableName: initialData?.tableName || '',
    column: initialData?.column || '',
    violationType: initialData?.violationType || 'NULL 값',
    actionType: initialData?.actionType || '데이터 수정',
    assignee: initialData?.assignee || '',
    dueDate: initialData?.dueDate || '',
    description: initialData?.description || '',
    status: initialData?.status || '대기',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('조치 계획 저장:', formData);
    onClose();
  };

  const handleChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  useEffect(() => {
    setIsModalOpen(isOpen);
  }, [isOpen, setIsModalOpen]);

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          className="fixed right-0 top-[72px] h-[calc(100vh-72px)] w-[400px] z-50 shadow-2xl overflow-hidden flex flex-col border-l"
          style={{
            backgroundColor: colors.bgPrimary,
            borderColor: colors.border,
          }}
          initial={{ x: '100%' }}
          animate={{ x: 0 }}
          exit={{ x: '100%' }}
          transition={{ 
            type: 'spring',
            damping: 30,
            stiffness: 300
          }}
        >
          {/* Header */}
          <div
            className="px-8 py-6 border-b flex items-center justify-between flex-shrink-0"
            style={{
              backgroundColor: colors.bgPrimary,
              borderColor: colors.border,
            }}
          >
            <div>
              <h2 className="text-xl font-bold" style={{ color: colors.textPrimary }}>
                {mode === 'create' ? '품질 위반 조치 추가' : '품질 위반 조치 수정'}
              </h2>
              <p className="text-sm mt-1" style={{ color: colors.textSecondary }}>
                {mode === 'create'
                  ? '데이터 품질 위반에 대한 조치 계획을 수립합니다'
                  : '기존 조치 계획의 정보를 수정하고 업데이트합니다'}
              </p>
            </div>
            <button
              onClick={onClose}
              className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
              style={{ color: colors.textSecondary }}
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto px-8 py-6">
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* 헤더 정보 */}
              <div 
                className="flex items-start gap-4 p-6 rounded-xl border"
                style={{
                  backgroundColor: colors.bgSecondary,
                  borderColor: colors.border
                }}
              >
                <div 
                  className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0"
                  style={{
                    backgroundColor: colors.hover
                  }}
                >
                  <ShieldCheck className="w-6 h-6" style={{ color: colors.textSecondary }} />
                </div>
                <div className="flex-1">
                  <h3 
                    className="font-bold mb-1"
                    style={{ color: colors.textPrimary }}
                  >
                    {mode === 'create' ? '새로운 조치 계획 수립' : '조치 계획 정보 수정'}
                  </h3>
                  <p 
                    className="text-sm"
                    style={{ color: colors.textSecondary }}
                  >
                    {mode === 'create' 
                      ? '데이터 품질 위반에 대한 조치 계획을 수립합니다' 
                      : '기존 조치 계획의 정보를 수정하고 업데이트합니다'}
                  </p>
                </div>
              </div>

              {/* 위반 정보 섹션 */}
              <div 
                className="rounded-xl p-6 border space-y-5"
                style={{
                  backgroundColor: colors.bgSecondary,
                  borderColor: colors.border
                }}
              >
                <h4 
                  className="font-bold mb-4 flex items-center gap-2"
                  style={{ color: colors.textPrimary }}
                >
                  <div className="w-1.5 h-5 rounded-full" style={{ backgroundColor: colors.textSecondary }}></div>
                  위반 정보
                </h4>

                <div className="grid grid-cols-2 gap-4">
                  <InputField
                    label="테이블명"
                    required
                    type="text"
                    value={formData.tableName}
                    onChange={(e) => handleChange('tableName', e.target.value)}
                    placeholder="예: CUSTOMER"
                    className="font-mono"
                  />

                  <InputField
                    label="컬럼명"
                    required
                    type="text"
                    value={formData.column}
                    onChange={(e) => handleChange('column', e.target.value)}
                    placeholder="예: EMAIL"
                    className="font-mono"
                  />
                </div>

                <SelectField
                  label="위반 유형"
                  required
                  value={formData.violationType}
                  onChange={(e) => handleChange('violationType', e.target.value)}
                  options={[
                    { value: 'NULL 값', label: 'NULL 값 존재' },
                    { value: '형식 오류', label: '형식 오류' },
                    { value: '데이터타입', label: '데이터타입 불일치' },
                    { value: '중복 데이터', label: '중복 데이터' },
                    { value: '길이 초과', label: '길이 초과' },
                    { value: '참조 무결성', label: '참조 무결성 위반' }
                  ]}
                />
              </div>

              {/* 조치 계획 섹션 */}
              <div 
                className="rounded-xl p-6 border space-y-5"
                style={{
                  backgroundColor: colors.bgSecondary,
                  borderColor: colors.border
                }}
              >
                <h4 
                  className="font-bold mb-4 flex items-center gap-2"
                  style={{ color: colors.textPrimary }}
                >
                  <div className="w-1.5 h-5 rounded-full" style={{ backgroundColor: colors.textSecondary }}></div>
                  조치 계획
                </h4>

                <SelectField
                  label="조치 유형"
                  required
                  value={formData.actionType}
                  onChange={(e) => handleChange('actionType', e.target.value)}
                  options={[
                    { value: '데이터 수정', label: '데이터 수정' },
                    { value: '스키마 변경', label: '스키마 변경' },
                    { value: '규칙 수정', label: '규칙 수정' },
                    { value: '프로세스 개선', label: '프로세스 개선' },
                    { value: '교육 실시', label: '교육 실시' },
                    { value: '시스템 변경', label: '시스템 변경' }
                  ]}
                />

                <div className="grid grid-cols-2 gap-4">
                  <InputField
                    label="담당자"
                    required
                    type="text"
                    value={formData.assignee}
                    onChange={(e) => handleChange('assignee', e.target.value)}
                    placeholder="담당자 이름"
                  />

                  <InputField
                    label="목표 완료일"
                    required
                    type="date"
                    value={formData.dueDate}
                    onChange={(e) => handleChange('dueDate', e.target.value)}
                  />
                </div>

                <TextAreaField
                  label="조치 내용"
                  required
                  value={formData.description}
                  onChange={(e) => handleChange('description', e.target.value)}
                  rows={5}
                  placeholder="구체적인 조치 내용과 방법을 입력하세요"
                />

                {/* 상태 */}
                <div>
                  <label 
                    className="block mb-3 font-bold"
                    style={{ color: colors.textSecondary }}
                  >
                    상태
                  </label>
                  <div className="flex gap-3 flex-wrap">
                    {[
                      { value: '대기', variant: 'default' as const, color: '#9CA3AF' },
                      { value: '진행중', variant: 'warning' as const, color: '#F97316' },
                      { value: '완료', variant: 'success' as const, color: '#10B981' }
                    ].map(({ value, variant, color }) => (
                      <label 
                        key={value}
                        className="flex items-center gap-2 cursor-pointer px-4 py-2.5 rounded-lg border-2 transition-all"
                        style={{
                          borderColor: formData.status === value ? colors.border : colors.border,
                          backgroundColor: formData.status === value ? colors.hover : 'transparent'
                        }}
                        onMouseEnter={(e) => {
                          if (formData.status !== value) {
                            e.currentTarget.style.backgroundColor = colors.bgSecondary;
                          }
                        }}
                        onMouseLeave={(e) => {
                          if (formData.status !== value) {
                            e.currentTarget.style.backgroundColor = 'transparent';
                          }
                        }}
                      >
                        <input
                          type="radio"
                          name="status"
                          value={value}
                          checked={formData.status === value}
                          onChange={(e) => handleChange('status', e.target.value)}
                          className="w-4 h-4"
                        />
                        <span style={{ color: colors.textPrimary }}>{value}</span>
                      </label>
                    ))}
                  </div>
                </div>
              </div>

              {/* 안내 메시지 */}
              <div 
                className="border rounded-xl p-5"
                style={{
                  backgroundColor: colors.hover,
                  borderColor: colors.border
                }}
              >
                <div className="flex gap-3">
                  <CheckCircle className="w-5 h-5 flex-shrink-0 mt-0.5" style={{ color: colors.textSecondary }} />
                  <div className="text-sm">
                    <p className="font-bold mb-2" style={{ color: colors.textPrimary }}>
                      조치 계획 수립 가이드
                    </p>
                    <ul className="list-disc list-inside space-y-1.5" style={{ color: colors.textSecondary }}>
                      <li>구체적이고 실행 가능한 조치 방안을 작성합니다</li>
                      <li>담당자와 목표 완료일을 명확히 지정합니다</li>
                      <li>완료 후 검증 방법도 함께 계획합니다</li>
                    </ul>
                  </div>
                </div>
              </div>
            </form>
          </div>

          {/* Footer */}
          <div
            className="px-8 py-4 border-t flex items-center justify-end gap-3 flex-shrink-0"
            style={{
              backgroundColor: colors.bgPrimary,
              borderColor: colors.border,
            }}
          >
            <Button type="button" variant="secondary" onClick={onClose}>
              취소
            </Button>
            <Button type="submit" variant="primary" onClick={handleSubmit}>
              {mode === 'create' ? '등록' : '저장'}
            </Button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}