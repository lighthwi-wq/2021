import { X, Book, AlertCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Button } from '../common/Button';
import { Badge } from '../common/Badge';
import { InputField, SelectField, TextAreaField } from '../common/FormField';
import { useState, useEffect } from 'react';
import { colors } from '../../constants/designSystem';

interface BusinessTermFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  mode: 'create' | 'edit';
  initialData?: any;
}

export function BusinessTermFormModal({ isOpen, onClose, mode, initialData }: BusinessTermFormModalProps) {
  const [formData, setFormData] = useState({
    term: initialData?.term || '',
    englishName: initialData?.englishName || '',
    domain: initialData?.domain || '고객관리',
    definition: initialData?.definition || '',
    status: initialData?.status || '작성중',
    relatedTerms: initialData?.relatedTerms || '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('업무용어 저장:', formData);
    onClose();
  };

  const handleChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          className="fixed right-0 top-0 h-screen w-[600px] z-50 shadow-2xl overflow-hidden flex flex-col border-l"
          style={{
            backgroundColor: colors.bgPrimary,
            borderColor: colors.border,
          }}
          initial={{ x: '100%' }}
          animate={{ x: 0 }}
          exit={{ x: '100%' }}
          transition={{ 
            type: 'spring',
            damping: 30,
            stiffness: 300
          }}
        >
          {/* Header */}
          <div
            className="px-8 py-6 border-b flex items-center justify-between flex-shrink-0"
            style={{
              backgroundColor: colors.bgPrimary,
              borderColor: colors.border,
            }}
          >
            <div>
              <h2 className="text-xl font-bold" style={{ color: colors.textPrimary }}>
                {mode === 'create' ? '업무용어 추가' : '업무용어 수정'}
              </h2>
              <p className="text-sm mt-1" style={{ color: colors.textSecondary }}>
                {mode === 'create'
                  ? '업무에서 사용하는 용어를 정의하고 표준화합니다'
                  : '기존 업무용어의 정보를 수정하고 업데이트합니다'}
              </p>
            </div>
            <button
              onClick={onClose}
              className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
              style={{ color: colors.textSecondary }}
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto px-8 py-6">
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* 헤더 정보 */}
              <div 
                className="flex items-start gap-4 p-6 rounded-xl border"
                style={{
                  backgroundColor: colors.bgSecondary,
                  borderColor: colors.border
                }}
              >
                <div 
                  className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0"
                  style={{
                    backgroundColor: colors.hover
                  }}
                >
                  <Book className="w-6 h-6" style={{ color: colors.textSecondary }} />
                </div>
                <div className="flex-1">
                  <h3 
                    className="font-bold mb-1"
                    style={{ color: colors.textPrimary }}
                  >
                    {mode === 'create' ? '새로운 업무용어 등록' : '업무용어 정 수정'}
                  </h3>
                  <p 
                    className="text-sm"
                    style={{ color: colors.textSecondary }}
                  >
                    {mode === 'create' 
                      ? '업무에서 사용하는 용어를 정의하고 표준화합니다' 
                      : '기존 업무용어의 정보를 수정하고 업데이트합니다'}
                  </p>
                </div>
              </div>

              {/* 기본 정보 섹션 */}
              <div 
                className="rounded-xl p-6 border space-y-5"
                style={{
                  backgroundColor: colors.bgSecondary,
                  borderColor: colors.border
                }}
              >
                <h4 
                  className="font-bold mb-4 flex items-center gap-2"
                  style={{ color: colors.textPrimary }}
                >
                  <div className="w-1.5 h-5 rounded-full" style={{ backgroundColor: colors.textSecondary }}></div>
                  기본 정보
                </h4>

                <InputField
                  label="업무용어"
                  required
                  type="text"
                  value={formData.term}
                  onChange={(e) => handleChange('term', e.target.value)}
                  placeholder="예: 고객 등급"
                />

                <InputField
                  label="영문명"
                  type="text"
                  value={formData.englishName}
                  onChange={(e) => handleChange('englishName', e.target.value)}
                  placeholder="예: Customer Grade"
                />

                <SelectField
                  label="업무 도메인"
                  required
                  value={formData.domain}
                  onChange={(e) => handleChange('domain', e.target.value)}
                  options={[
                    { value: '고객관리', label: '고객관리' },
                    { value: '주문관리', label: '주문관리' },
                    { value: '상품관리', label: '상품관리' },
                    { value: '재고관리', label: '재고관리' },
                    { value: '배송관리', label: '배송관리' },
                    { value: '결제관리', label: '결제관리' },
                    { value: '정산관리', label: '정산관리' }
                  ]}
                />
              </div>

              {/* 상세 정보 섹션 */}
              <div 
                className="rounded-xl p-6 border space-y-5"
                style={{
                  backgroundColor: colors.bgSecondary,
                  borderColor: colors.border
                }}
              >
                <h4 
                  className="font-bold mb-4 flex items-center gap-2"
                  style={{ color: colors.textPrimary }}
                >
                  <div className="w-1.5 h-5 rounded-full" style={{ backgroundColor: colors.textSecondary }}></div>
                  상세 정보
                </h4>

                <TextAreaField
                  label="정의"
                  required
                  value={formData.definition}
                  onChange={(e) => handleChange('definition', e.target.value)}
                  rows={5}
                  placeholder="업무용어의 정의를 구체적으로 입력하세요"
                />

                <InputField
                  label="관련 용어"
                  type="text"
                  value={formData.relatedTerms}
                  onChange={(e) => handleChange('relatedTerms', e.target.value)}
                  placeholder="쉼표로 구분하여 입력 (예: 회원등급, VIP고객)"
                />

                {/* 상태 */}
                <div>
                  <label 
                    className="block mb-3 font-bold"
                    style={{ color: colors.textSecondary }}
                  >
                    상태
                  </label>
                  <div className="flex gap-3">
                    {[
                      { value: '작성중', variant: 'default' as const, color: '#9CA3AF' },
                      { value: '검토중', variant: 'warning' as const, color: '#F97316' },
                      { value: '승인완료', variant: 'success' as const, color: '#10B981' }
                    ].map(({ value, variant, color }) => (
                      <label 
                        key={value}
                        className="flex items-center gap-2 cursor-pointer px-4 py-2.5 rounded-lg border-2 transition-all"
                        style={{
                          borderColor: formData.status === value ? colors.border : colors.border,
                          backgroundColor: formData.status === value ? colors.hover : 'transparent'
                        }}
                        onMouseEnter={(e) => {
                          if (formData.status !== value) {
                            e.currentTarget.style.backgroundColor = colors.bgSecondary;
                          }
                        }}
                        onMouseLeave={(e) => {
                          if (formData.status !== value) {
                            e.currentTarget.style.backgroundColor = 'transparent';
                          }
                        }}
                      >
                        <input
                          type="radio"
                          name="status"
                          value={value}
                          checked={formData.status === value}
                          onChange={(e) => handleChange('status', e.target.value)}
                          className="w-4 h-4"
                        />
                        <span style={{ color: colors.textPrimary }}>{value}</span>
                      </label>
                    ))}
                  </div>
                </div>
              </div>

              {/* 안내 메시지 */}
              <div 
                className="border rounded-xl p-5"
                style={{
                  backgroundColor: colors.hover,
                  borderColor: colors.border
                }}
              >
                <div className="flex gap-3">
                  <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" style={{ color: colors.textSecondary }} />
                  <div className="text-sm">
                    <p className="font-bold mb-2" style={{ color: colors.textPrimary }}>
                      업무용어 등록 가이드
                    </p>
                    <ul className="list-disc list-inside space-y-1.5" style={{ color: colors.textSecondary }}>
                      <li>업무에서 실제 사용하는 용어를 명확하게 정의합니다</li>
                      <li>관련 업무 도메인을 정확히 선택합니다</li>
                      <li>용어의 정의는 누구나 이해할 수 있도록 작성합니다</li>
                    </ul>
                  </div>
                </div>
              </div>
            </form>
          </div>

          {/* Footer */}
          <div
            className="px-8 py-4 border-t flex items-center justify-end gap-3 flex-shrink-0"
            style={{
              backgroundColor: colors.bgPrimary,
              borderColor: colors.border,
            }}
          >
            <Button type="button" variant="secondary" onClick={onClose}>
              취소
            </Button>
            <Button type="submit" variant="primary" onClick={handleSubmit}>
              {mode === 'create' ? '등록' : '저장'}
            </Button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}