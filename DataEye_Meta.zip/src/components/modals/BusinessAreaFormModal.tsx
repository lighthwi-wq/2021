import { X, Building2, AlertCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Button } from '../common/Button';
import { Badge } from '../common/Badge';
import { InputField, TextAreaField } from '../common/FormField';
import { useState, useEffect } from 'react';
import { colors } from '../../constants/designSystem';
import { useModal } from '../../contexts/ModalContext';

interface BusinessAreaFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  mode: 'create' | 'edit';
  initialData?: any;
}

export function BusinessAreaFormModal({ isOpen, onClose, mode, initialData }: BusinessAreaFormModalProps) {
  const { setIsModalOpen } = useModal();
  const [formData, setFormData] = useState({
    name: initialData?.name || '',
    code: initialData?.code || '',
    owner: initialData?.owner || '',
    description: initialData?.description || '',
    status: initialData?.status || '활성',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('업무 영역 저장:', formData);
    onClose();
  };

  const handleChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  useEffect(() => {
    setIsModalOpen(isOpen);
  }, [isOpen, setIsModalOpen]);

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          className="fixed right-0 top-[72px] h-[calc(100vh-72px)] w-[400px] shadow-2xl overflow-hidden flex flex-col border-l"
          style={{
            backgroundColor: colors.bgPrimary,
            borderColor: colors.border,
            zIndex: 9999,
          }}
          initial={{ x: '100%' }}
          animate={{ x: 0 }}
          exit={{ x: '100%' }}
          transition={{ 
            type: 'spring',
            damping: 30,
            stiffness: 300
          }}
        >
          {/* Header */}
          <div
            className="px-8 py-6 border-b flex items-center justify-between flex-shrink-0"
            style={{
              backgroundColor: colors.bgPrimary,
              borderColor: colors.border,
            }}
          >
            <div>
              <h2 className="text-xl font-bold" style={{ color: colors.textPrimary }}>
                {mode === 'create' ? '업무 영역 추가' : '업무 영역 수정'}
              </h2>
              <p className="text-sm mt-1" style={{ color: colors.textSecondary }}>
                {mode === 'create'
                  ? '조직의 업무 영역을 정의하고 관리합니다'
                  : '기존 업무 영역의 정보를 수정하고 업데이트합니다'}
              </p>
            </div>
            <button
              onClick={onClose}
              className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
              style={{ color: colors.textSecondary }}
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto px-8 py-6">
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* 헤더 정보 */}
              <div 
                className="flex items-start gap-4 p-6 rounded-xl border"
                style={{
                  backgroundColor: colors.surface,
                  borderColor: colors.border
                }}
              >
                <div 
                  className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0"
                  style={{
                    backgroundColor: colors.hover
                  }}
                >
                  <Building2 className="w-6 h-6" style={{ color: colors.textSecondary }} />
                </div>
                <div className="flex-1">
                  <h3 
                    className="font-bold mb-1"
                    style={{ color: colors.textPrimary }}
                  >
                    {mode === 'create' ? '새로운 업무 영역 등록' : '업무 영역 정보 수정'}
                  </h3>
                  <p 
                    className="text-sm"
                    style={{ color: colors.textSecondary }}
                  >
                    {mode === 'create' 
                      ? '조직의 업무 영역을 정의하고 관리합니다' 
                      : '기존 업무 영역의 정보를 수정하고 업데이트합니다'}
                  </p>
                </div>
              </div>

              {/* 기본 정보 섹션 */}
              <div 
                className="rounded-xl p-6 border space-y-5"
                style={{
                  backgroundColor: colors.surface,
                  borderColor: colors.border
                }}
              >
                <h4 
                  className="font-bold mb-4 flex items-center gap-2"
                  style={{ color: colors.textPrimary }}
                >
                  <div className="w-1.5 h-5 rounded-full" style={{ backgroundColor: colors.textSecondary }}></div>
                  기본 정보
                </h4>

                <InputField
                  label="영역명"
                  required
                  type="text"
                  value={formData.name}
                  onChange={(e) => handleChange('name', e.target.value)}
                  placeholder="예: 고객관리"
                />

                <InputField
                  label="영역 코드"
                  required
                  type="text"
                  value={formData.code}
                  onChange={(e) => handleChange('code', e.target.value)}
                  placeholder="예: CUST"
                  className="font-mono"
                />

                <InputField
                  label="담당자"
                  required
                  type="text"
                  value={formData.owner}
                  onChange={(e) => handleChange('owner', e.target.value)}
                  placeholder="담당자 이름"
                />
              </div>

              {/* 상세 정보 섹션 */}
              <div 
                className="rounded-xl p-6 border space-y-5"
                style={{
                  backgroundColor: colors.surface,
                  borderColor: colors.border
                }}
              >
                <h4 
                  className="font-bold mb-4 flex items-center gap-2"
                  style={{ color: colors.textPrimary }}
                >
                  <div className="w-1.5 h-5 rounded-full" style={{ backgroundColor: colors.textSecondary }}></div>
                  상세 정보
                </h4>

                <TextAreaField
                  label="설명"
                  required
                  value={formData.description}
                  onChange={(e) => handleChange('description', e.target.value)}
                  rows={5}
                  placeholder="업무 영역에 대한 상세 설명을 입력하세요"
                />

                {/* 상태 */}
                <div>
                  <label 
                    className="block mb-3 font-bold"
                    style={{ color: colors.textPrimary }}
                  >
                    상태
                  </label>
                  <div className="flex gap-3">
                    {[
                      { value: '활성', variant: 'success' as const, color: '#10B981' },
                      { value: '비활성', variant: 'default' as const, color: '#9CA3AF' }
                    ].map(({ value, variant, color }) => (
                      <label 
                        key={value}
                        className="flex items-center gap-2 cursor-pointer px-4 py-2.5 rounded-lg border-2 transition-all"
                        style={{
                          borderColor: formData.status === value ? colors.border : colors.border,
                          backgroundColor: formData.status === value ? colors.hover : 'transparent'
                        }}
                        onMouseEnter={(e) => {
                          if (formData.status !== value) {
                            e.currentTarget.style.backgroundColor = colors.hover;
                          }
                        }}
                        onMouseLeave={(e) => {
                          if (formData.status !== value) {
                            e.currentTarget.style.backgroundColor = 'transparent';
                          }
                        }}
                      >
                        <input
                          type="radio"
                          name="status"
                          value={value}
                          checked={formData.status === value}
                          onChange={(e) => handleChange('status', e.target.value)}
                          className="w-4 h-4"
                        />
                        <span style={{ color: colors.textPrimary }}>{value}</span>
                      </label>
                    ))}
                  </div>
                </div>
              </div>

              {/* 안내 메시지 */}
              <div 
                className="border rounded-xl p-5"
                style={{
                  backgroundColor: colors.hover,
                  borderColor: colors.border
                }}
              >
                <div className="flex gap-3">
                  <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" style={{ color: colors.textSecondary }} />
                  <div className="text-sm">
                    <p className="font-bold mb-2" style={{ color: colors.textPrimary }}>
                      업무 영역 등록 가이드
                    </p>
                    <ul className="list-disc list-inside space-y-1.5" style={{ color: colors.textSecondary }}>
                      <li>영역 코드는 영문 대문자로 간결하게 작성합니다</li>
                      <li>담당자는 해당 업무 영역의 메타데이터를 관리합니다</li>
                      <li>활성 상태의 영역만 메타데이터 관리에 표시됩니다</li>
                    </ul>
                  </div>
                </div>
              </div>
            </form>
          </div>

          {/* Footer */}
          <div
            className="px-8 py-4 border-t flex items-center justify-end gap-3 flex-shrink-0"
            style={{
              backgroundColor: colors.bgPrimary,
              borderColor: colors.border,
            }}
          >
            <Button type="button" variant="secondary" onClick={onClose}>
              취소
            </Button>
            <Button type="submit" variant="primary" onClick={handleSubmit}>
              {mode === 'create' ? '등록' : '저장'}
            </Button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}