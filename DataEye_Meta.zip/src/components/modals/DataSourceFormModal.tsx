import { X, Database, AlertCircle, Lock } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Button } from '../common/Button';
import { InputField, SelectField, TextAreaField } from '../common/FormField';
import { useState, useEffect } from 'react';
import { colors } from '../../constants/designSystem';

interface DataSourceFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  mode: 'create' | 'edit';
  initialData?: any;
}

export function DataSourceFormModal({ isOpen, onClose, mode, initialData }: DataSourceFormModalProps) {
  const [formData, setFormData] = useState({
    name: initialData?.name || '',
    type: initialData?.type || 'PostgreSQL',
    host: initialData?.host || '',
    port: initialData?.port || '5432',
    database: initialData?.database || '',
    username: initialData?.username || '',
    password: '',
    description: initialData?.description || '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('데이터 소스 저장:', formData);
    onClose();
  };

  const handleChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleTypeChange = (value: string) => {
    const defaultPorts: Record<string, string> = {
      'PostgreSQL': '5432',
      'MySQL': '3306',
      'Oracle': '1521',
      'MSSQL': '1433',
      'MongoDB': '27017',
      'MariaDB': '3306',
    };
    setFormData(prev => ({ 
      ...prev, 
      type: value,
      port: defaultPorts[value] || '5432'
    }));
  };

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          className="fixed right-0 top-0 h-screen w-[600px] z-50 shadow-2xl overflow-hidden flex flex-col border-l"
          style={{
            backgroundColor: colors.bgPrimary,
            borderColor: colors.border,
          }}
          initial={{ x: '100%' }}
          animate={{ x: 0 }}
          exit={{ x: '100%' }}
          transition={{ 
            type: 'spring',
            damping: 30,
            stiffness: 300
          }}
        >
          {/* Header */}
          <div
            className="px-8 py-6 border-b flex items-center justify-between flex-shrink-0"
            style={{
              backgroundColor: colors.bgPrimary,
              borderColor: colors.border,
            }}
          >
            <div>
              <h2 className="text-xl font-bold" style={{ color: colors.textPrimary }}>
                {mode === 'create' ? '데이터 소스 추가' : '데이터 소스 수정'}
              </h2>
              <p className="text-sm mt-1" style={{ color: colors.textSecondary }}>
                {mode === 'create'
                  ? '메타데이터를 수집할 데이터 소스를 연결합니다'
                  : '기존 데이터 소스의 연결 정보를 업데이트합니다'}
              </p>
            </div>
            <button
              onClick={onClose}
              className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
              style={{ color: colors.textSecondary }}
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto px-8 py-6">
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* 헤더 정보 */}
              <div 
                className="flex items-start gap-4 p-6 rounded-xl border"
                style={{
                  backgroundColor: colors.bgSecondary,
                  borderColor: colors.border
                }}
              >
                <div 
                  className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0"
                  style={{
                    backgroundColor: colors.hover
                  }}
                >
                  <Database className="w-6 h-6" style={{ color: colors.textSecondary }} />
                </div>
                <div className="flex-1">
                  <h3 
                    className="font-bold mb-1"
                    style={{ color: colors.textPrimary }}
                  >
                    {mode === 'create' ? '새로운 데이터 소스 연결' : '데이터 소스 정보 수정'}
                  </h3>
                  <p 
                    className="text-sm"
                    style={{ color: colors.textSecondary }}
                  >
                    {mode === 'create' 
                      ? '메타데이터를 수집할 데이터 소스를 연결합니다' 
                      : '기존 데이터 소스의 연결 정보를 업데이트합니다'}
                  </p>
                </div>
              </div>

              {/* 기본 정보 섹션 */}
              <div 
                className="rounded-xl p-6 border space-y-5"
                style={{
                  backgroundColor: colors.bgSecondary,
                  borderColor: colors.border
                }}
              >
                <h4 
                  className="font-bold mb-4 flex items-center gap-2"
                  style={{ color: colors.textPrimary }}
                >
                  <div className="w-1.5 h-5 rounded-full" style={{ backgroundColor: colors.textSecondary }}></div>
                  기본 정보
                </h4>

                <InputField
                  label="소스 이름"
                  required
                  type="text"
                  value={formData.name}
                  onChange={(e) => handleChange('name', e.target.value)}
                  placeholder="예: 운영DB"
                />

                <div>
                  <label 
                    className="block mb-2 font-bold"
                    style={{ color: colors.textSecondary }}
                  >
                    데이터베이스 유형 <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={formData.type}
                    onChange={(e) => handleTypeChange(e.target.value)}
                    className="w-full px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent transition-all"
                    style={{
                      backgroundColor: colors.bgPrimary,
                      borderWidth: '1px',
                      borderStyle: 'solid',
                      borderColor: colors.border,
                      color: colors.textPrimary
                    }}
                    required
                  >
                    <option value="PostgreSQL">PostgreSQL</option>
                    <option value="MySQL">MySQL</option>
                    <option value="Oracle">Oracle</option>
                    <option value="MSSQL">MS SQL Server</option>
                    <option value="MongoDB">MongoDB</option>
                    <option value="MariaDB">MariaDB</option>
                  </select>
                </div>

                <TextAreaField
                  label="설명"
                  value={formData.description}
                  onChange={(e) => handleChange('description', e.target.value)}
                  rows={3}
                  placeholder="데이터 소스에 대한 설명을 입력하세요"
                />
              </div>

              {/* 연결 정보 섹션 */}
              <div 
                className="rounded-xl p-6 border space-y-5"
                style={{
                  backgroundColor: colors.bgSecondary,
                  borderColor: colors.border
                }}
              >
                <h4 
                  className="font-bold mb-4 flex items-center gap-2"
                  style={{ color: colors.textPrimary }}
                >
                  <div className="w-1.5 h-5 rounded-full" style={{ backgroundColor: colors.textSecondary }}></div>
                  연결 정보
                </h4>

                <InputField
                  label="호스트"
                  required
                  type="text"
                  value={formData.host}
                  onChange={(e) => handleChange('host', e.target.value)}
                  placeholder="예: db.example.com 또는 192.168.1.100"
                  className="font-mono"
                />

                <div className="grid grid-cols-2 gap-4">
                  <InputField
                    label="포트"
                    required
                    type="text"
                    value={formData.port}
                    onChange={(e) => handleChange('port', e.target.value)}
                    placeholder="5432"
                    className="font-mono"
                  />

                  <InputField
                    label="데이터베이스"
                    required
                    type="text"
                    value={formData.database}
                    onChange={(e) => handleChange('database', e.target.value)}
                    placeholder="예: metadata_db"
                    className="font-mono"
                  />
                </div>
              </div>

              {/* 인증 정보 섹션 */}
              <div 
                className="rounded-xl p-6 border space-y-5"
                style={{
                  backgroundColor: colors.bgSecondary,
                  borderColor: colors.border
                }}
              >
                <h4 
                  className="font-bold mb-4 flex items-center gap-2"
                  style={{ color: colors.textPrimary }}
                >
                  <div className="w-1.5 h-5 rounded-full" style={{ backgroundColor: colors.textSecondary }}></div>
                  <Lock className="w-4 h-4" />
                  인증 정보
                </h4>

                <InputField
                  label="사용자명"
                  required
                  type="text"
                  value={formData.username}
                  onChange={(e) => handleChange('username', e.target.value)}
                  placeholder="데이터베이스 사용자명"
                  className="font-mono"
                  autoComplete="username"
                />

                <div>
                  <label 
                    className="block mb-2 font-bold"
                    style={{ color: colors.textSecondary }}
                  >
                    비밀번호 <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="password"
                    value={formData.password}
                    onChange={(e) => handleChange('password', e.target.value)}
                    className="w-full px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-400 focus:border-transparent font-mono transition-all"
                    style={{
                      backgroundColor: colors.bgPrimary,
                      borderWidth: '1px',
                      borderStyle: 'solid',
                      borderColor: colors.border,
                      color: colors.textPrimary
                    }}
                    placeholder="••••••••"
                    required={mode === 'create'}
                    autoComplete="new-password"
                  />
                  {mode === 'edit' && (
                    <p className="text-xs mt-2" style={{ color: colors.textSecondary }}>
                      변경하지 않으려면 비워두세요
                    </p>
                  )}
                </div>
              </div>

              {/* 안내 메시지 */}
              <div 
                className="border rounded-xl p-5"
                style={{
                  backgroundColor: colors.hover,
                  borderColor: colors.border
                }}
              >
                <div className="flex gap-3">
                  <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" style={{ color: colors.textSecondary }} />
                  <div className="text-sm">
                    <p className="font-bold mb-2" style={{ color: colors.textPrimary }}>
                      데이터 소스 연결 가이드
                    </p>
                    <ul className="list-disc list-inside space-y-1.5" style={{ color: colors.textSecondary }}>
                      <li>데이터베이스에 대한 읽기 권한이 필요합니다</li>
                      <li>네트워크 방화벽에서 해당 포트가 허용되어야 합니다</li>
                      <li>연결 정보는 암호화되어 안전하게 저장됩니다</li>
                    </ul>
                  </div>
                </div>
              </div>
            </form>
          </div>

          {/* Footer */}
          <div
            className="px-8 py-4 border-t flex items-center justify-end gap-3 flex-shrink-0"
            style={{
              backgroundColor: colors.bgPrimary,
              borderColor: colors.border,
            }}
          >
            <Button type="button" variant="secondary" onClick={onClose}>
              취소
            </Button>
            <Button type="submit" variant="primary" onClick={handleSubmit}>
              {mode === 'create' ? '등록' : '저장'}
            </Button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}