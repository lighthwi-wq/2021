import { ReactNode } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X } from 'lucide-react';
import { colors } from '../../constants/designSystem';

interface SlideModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  description?: string;
  children: ReactNode;
  footer?: ReactNode;
  icon?: ReactNode;
  width?: string;
}

/**
 * SlideModal - 오른쪽에서 슬라이드되는 모달 컴포넌트
 * 
 * 모든 페이지에서 일관된 모달 UX를 제공하기 위한 기본 모달 컴포넌트입니다.
 * 메인 컨텐츠가 왼쪽으로 밀리는 방식으로 동작합니다.
 * 
 * @example
 * <SlideModal
 *   isOpen={isOpen}
 *   onClose={onClose}
 *   title="제목"
 *   description="설명"
 *   footer={<Button>확인</Button>}
 * >
 *   <div>모달 콘텐츠</div>
 * </SlideModal>
 */
export function SlideModal({
  isOpen,
  onClose,
  title,
  description,
  children,
  footer,
  icon,
  width = '400px'
}: SlideModalProps) {
  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          className="fixed right-0 top-0 h-screen z-50 shadow-2xl overflow-hidden flex flex-col border-l"
          style={{
            backgroundColor: colors.bgPrimary,
            borderColor: colors.border,
            width,
          }}
          initial={{ x: '100%' }}
          animate={{ x: 0 }}
          exit={{ x: '100%' }}
          transition={{
            type: 'spring',
            damping: 30,
            stiffness: 300
          }}
        >
          {/* Header */}
          <div
            className="px-8 py-6 border-b flex items-center justify-between flex-shrink-0"
            style={{
              backgroundColor: colors.bgPrimary,
              borderColor: colors.border,
            }}
          >
            <div className="flex items-center gap-4 flex-1">
              {icon && (
                <div
                  className="p-3 rounded-xl flex-shrink-0"
                  style={{
                    backgroundColor: 'rgba(43, 141, 255, 0.15)',
                  }}
                >
                  {icon}
                </div>
              )}
              <div>
                <h2 className="text-xl font-bold" style={{ color: colors.textPrimary }}>
                  {title}
                </h2>
                {description && (
                  <p className="text-sm mt-1" style={{ color: colors.textSecondary }}>
                    {description}
                  </p>
                )}
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-2 rounded-lg hover:bg-gray-100 transition-colors flex-shrink-0"
              style={{ color: colors.textSecondary }}
              aria-label="닫기"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto px-8 py-6">
            {children}
          </div>

          {/* Footer */}
          {footer && (
            <div
              className="px-8 py-4 border-t flex items-center justify-end gap-3 flex-shrink-0"
              style={{
                backgroundColor: colors.bgPrimary,
                borderColor: colors.border,
              }}
            >
              {footer}
            </div>
          )}
        </motion.div>
      )}
    </AnimatePresence>
  );
}
