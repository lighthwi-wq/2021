import { activities } from '../../constants/activityData';
import { Card } from '../common/Card';

const activityTypes = {
  upload: 'bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400',
  sync: 'bg-green-50 dark:bg-green-900/20 text-green-600 dark:text-green-400',
  error: 'bg-orange-50 dark:bg-orange-900/20 text-orange-600 dark:text-orange-400',
  update: 'bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400',
};

export function ActivityFeed() {
  return (
    <Card padding="sm" className="h-full">
      <h3 className="text-gray-900 dark:text-white mb-3 font-bold text-sm">최근 활동</h3>
      <div className="space-y-2.5">
        {activities.map((activity, index) => {
          const Icon = activity.icon;
          return (
            <div key={index} className="flex gap-2.5 pb-2.5 border-b border-gray-200 dark:border-gray-700 last:border-0 last:pb-0">
              <div className={`p-1.5 rounded-lg flex-shrink-0 shadow-sm ${activityTypes[activity.type]}`}>
                <Icon className="w-3.5 h-3.5" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-gray-900 dark:text-white mb-0.5 text-sm">
                  {activity.title}
                </p>
                <p className="text-gray-500 dark:text-gray-400 truncate mb-0.5 text-xs">
                  {activity.description}
                </p>
                <p className="text-gray-400 dark:text-gray-500 text-xs">
                  {activity.time}
                </p>
              </div>
            </div>
          );
        })}
      </div>
    </Card>
  );
}