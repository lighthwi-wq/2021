import { Card } from '../../common/Card';
import { useState } from 'react';

interface CategoryDistributionSectionProps {
  data: Array<{ name: string; value: number; color: string }>;
}

export function CategoryDistributionSection({ data }: CategoryDistributionSectionProps) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div 
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className="transition-all duration-300"
      style={{
        transform: isHovered ? 'translateY(-4px)' : 'translateY(0)',
      }}
    >
      <Card 
        padding="lg" 
        className="h-[400px] flex flex-col transition-all duration-300"
        style={{
          boxShadow: isHovered 
            ? '0 20px 40px rgba(0, 0, 0, 0.08), 0 0 0 1px rgba(43, 141, 255, 0.1)' 
            : '0 1px 3px rgba(0, 0, 0, 0.05), 0 1px 2px rgba(0, 0, 0, 0.05)',
        }}
      >
        <div className="mb-6">
          <h3 className="font-bold mb-1" style={{ color: '#202124' }}>데이터 카테고리 분포</h3>
          <p className="text-sm" style={{ color: '#5F6368' }}>테이블 수 기준 비율</p>
        </div>
        <div className="flex-1 flex flex-col relative">
          <div className="space-y-3 flex-1 overflow-y-auto">{data.map((item, idx) => {
            const total = data.reduce((acc, curr) => acc + curr.value, 0);
            const percentage = ((item.value / total) * 100).toFixed(1);
            
            return (
              <div key={idx} className="group">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-3">
                    <div 
                      className="w-3 h-3 rounded-full"
                      style={{ backgroundColor: item.color }}
                    ></div>
                    <span className="font-bold text-sm" style={{ color: '#202124' }}>{item.name}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-sm" style={{ color: '#5F6368' }}>{item.value}</span>
                    <span className="font-bold text-sm w-12 text-right" style={{ color: '#202124' }}>{percentage}%</span>
                  </div>
                </div>
                <div className="relative w-full h-2.5 rounded-full overflow-hidden" style={{ backgroundColor: '#F1F3F4' }}>
                  <div 
                    className="absolute top-0 left-0 h-full rounded-full transition-all duration-500 group-hover:opacity-80"
                    style={{ 
                      width: `${percentage}%`,
                      backgroundColor: item.color,
                      boxShadow: `0 0 10px ${item.color}40`
                    }}
                  ></div>
                </div>
              </div>
            );
          })}
          </div>
          <div className="absolute bottom-0 right-0 text-right">
            <p className="font-bold" style={{ color: '#202124' }}>1,247</p>
            <p className="text-xs" style={{ color: '#5F6368' }}>총 테이블</p>
          </div>
        </div>
      </Card>
    </div>
  );
}