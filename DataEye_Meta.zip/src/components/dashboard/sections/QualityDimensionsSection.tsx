import { Card } from '../../common/Card';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';
import { Network } from 'lucide-react';
import { useState } from 'react';

interface QualityDimension {
  dimension: string;
  score: number;
  fullMark: number;
  color: string;
}

interface QualityDimensionsSectionProps {
  data: QualityDimension[];
}

export function QualityDimensionsSection({ data }: QualityDimensionsSectionProps) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div 
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className="transition-all duration-300"
      style={{
        transform: isHovered ? 'translateY(-4px)' : 'translateY(0)',
      }}
    >
      <Card 
        padding="lg" 
        className="h-[400px] flex flex-col transition-all duration-300"
        style={{
          boxShadow: isHovered 
            ? '0 20px 40px rgba(0, 0, 0, 0.08), 0 0 0 1px rgba(43, 141, 255, 0.1)' 
            : '0 1px 3px rgba(0, 0, 0, 0.05), 0 1px 2px rgba(0, 0, 0, 0.05)',
        }}
      >
        <div className="mb-6">
          <h3 
            className="font-bold mb-1"
            style={{ color: '#111827' }}
          >
            품질 차원 분석
          </h3>
          <p 
            className="text-sm"
            style={{ color: '#6b7280' }}
          >
            6가지 품질 차원 평가
          </p>
        </div>
        <div className="flex items-center gap-8 flex-1">
          <div className="flex-shrink-0 relative">
            <ResponsiveContainer width={220} height={220}>
              <PieChart>
                <defs>
                  {data.map((item, idx) => (
                    <linearGradient key={idx} id={`pieGradient${idx}`} x1="0" y1="0" x2="1" y2="1">
                      <stop offset="0%" stopColor={item.color} stopOpacity={1}/>
                      <stop offset="100%" stopColor={item.color} stopOpacity={0.7}/>
                    </linearGradient>
                  ))}
                </defs>
                <Pie
                  data={data}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={95}
                  paddingAngle={3}
                  dataKey="score"
                  stroke="none"
                >
                  {data.map((entry, index) => (
                    <Cell 
                      key={`cell-${index}`} 
                      fill={`url(#pieGradient${index})`}
                    />
                  ))}
                </Pie>
                <Tooltip 
                  content={({ active, payload }: any) => {
                    if (active && payload && payload.length) {
                      return (
                        <div 
                          className="px-3 py-2 rounded-lg shadow-lg border"
                          style={{
                            backgroundColor: '#FFFFFF',
                            borderColor: '#DADCE0'
                          }}
                        >
                          <p 
                            className="font-bold text-sm mb-1"
                            style={{ color: '#202124' }}
                          >
                            {payload[0].payload.dimension}
                          </p>
                          <p className="text-xs">
                            <span style={{ color: '#5f6368' }}>
                              점수: 
                            </span>
                            <span className="font-bold" style={{ color: payload[0].payload.color }}>
                              {payload[0].value}
                            </span>
                          </p>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
            <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
              <Network className="w-12 h-12" style={{ color: '#D1D5DB' }} />
            </div>
          </div>
          <div className="flex-1 space-y-3">
            {data.map((item, idx) => (
              <div 
                key={idx} 
                className="flex items-center justify-between group p-1.5 rounded-lg transition-colors"
                style={{ backgroundColor: 'transparent' }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.backgroundColor = '#F1F3F4';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor = 'transparent';
                }}
              >
                <div className="flex items-center gap-3">
                  <div 
                    className="w-3 h-3 rounded-full flex-shrink-0"
                    style={{ backgroundColor: item.color }}
                  ></div>
                  <div className="flex items-center gap-2">
                    <span 
                      className="text-sm font-bold"
                      style={{ color: '#202124' }}
                    >
                      {item.dimension}
                    </span>
                    <span 
                      style={{ 
                        color: '#5F6368',
                        fontSize: '13px'
                      }}
                    >
                      {item.dimension === '완전성' && '필수 데이터 누락 여부'}
                      {item.dimension === '유효성' && '규칙 및 형식 준수도 측정'}
                      {item.dimension === '정확성' && '실제 값과의 일치도 평가'}
                      {item.dimension === '유일성' && '중복 데이터 존재 여부'}
                      {item.dimension === '일관성' && '데이터 간 모순 여부 확인'}
                      {item.dimension === '적시성' && '최신 상태 유지 정도'}
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div 
                    className="w-32 h-2 rounded-full overflow-hidden"
                    style={{ backgroundColor: '#E8EAED' }}
                  >
                    <div 
                      className="h-full rounded-full transition-all duration-500"
                      style={{ 
                        width: `${item.score}%`,
                        backgroundColor: item.color
                      }}
                    ></div>
                  </div>
                  <span 
                    className="font-bold text-sm w-8 text-right"
                    style={{ color: item.color }}
                  >
                    {item.score}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </Card>
    </div>
  );
}