import { Card } from '../../common/Card';
import { BarChart, Bar, ResponsiveContainer, XAxis, YAxis, Tooltip, CartesianGrid, Legend } from 'recharts';
import { useState } from 'react';

interface SystemStandardizationSectionProps {
  data: Array<{ name: string; value: number; standard: number; max?: number }>;
  CustomTooltip: React.ComponentType<any>;
}

export function SystemStandardizationSection({ data, CustomTooltip }: SystemStandardizationSectionProps) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div 
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className="transition-all duration-300"
      style={{
        transform: isHovered ? 'translateY(-4px)' : 'translateY(0)',
      }}
    >
      <Card 
        padding="lg" 
        className="h-[400px] flex flex-col overflow-visible transition-all duration-300"
        style={{
          boxShadow: isHovered 
            ? '0 20px 40px rgba(0, 0, 0, 0.08), 0 0 0 1px rgba(43, 141, 255, 0.1)' 
            : '0 1px 3px rgba(0, 0, 0, 0.05), 0 1px 2px rgba(0, 0, 0, 0.05)',
        }}
      >
        <div className="mb-6">
          <h3 style={{ color: '#202124' }} className="font-bold mb-1">시스템별 표준화율</h3>
          <p style={{ color: '#5F6368' }} className="text-sm">목표선 대비 현황</p>
        </div>
        <div className="flex-1">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data} barSize={20}>
              <CartesianGrid strokeDasharray="3 3" stroke="#9ca3af" opacity={0.8} />
              <XAxis 
                dataKey="name" 
                stroke="#9ca3af" 
                style={{ fontSize: '12px' }}
                tickLine={false}
              />
              <YAxis 
                stroke="#9ca3af" 
                style={{ fontSize: '12px' }}
                tickLine={false}
                axisLine={false}
              />
              <Tooltip content={<CustomTooltip />} cursor={false} offset={-80} />
              <Legend 
                wrapperStyle={{ fontSize: '12px' }}
                iconType="circle"
                formatter={(value) => {
                  if (value === '목표') {
                    return <span style={{ color: '#777' }}>{value}</span>;
                  }
                  return value;
                }}
              />
              <Bar 
                dataKey="standard" 
                fill="#E5E7EB" 
                radius={[0, 0, 0, 0]}
                name="목표"
              />
              <Bar 
                dataKey="value" 
                fill="#2B8DFF" 
                radius={[0, 0, 0, 0]}
                name="현재"
              />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Card>
    </div>
  );
}