import { Card } from '../../common/Card';
import { useState } from 'react';

interface StandardizationProgressSectionProps {
  data: Array<{ label: string; current: number; target: number }>;
}

export function StandardizationProgressSection({ data }: StandardizationProgressSectionProps) {
  const [isHovered, setIsHovered] = useState(false);

  // 각 항목별 고유 색상 정의
  const getColorByIndex = (idx: number, current: number, target: number) => {
    const colors = [
      '#2B8DFF',   // 블루 - 표준용어 적용률
      '#F59E0B',   // 골드/앰버 - 명명규칙 준수율
      '#84CC16',   // 라임/연두색 - 데이터타입 일관성
      '#9CA3AF',   // 연한 그레이 - 메타데이터 완성도
    ];
    return colors[idx] || '#2B8DFF';
  };

  return (
    <div 
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className="transition-all duration-300"
      style={{
        transform: isHovered ? 'translateY(-4px)' : 'translateY(0)',
      }}
    >
      <Card 
        padding="lg" 
        className="h-[400px] flex flex-col transition-all duration-300"
        style={{
          boxShadow: isHovered 
            ? '0 20px 40px rgba(0, 0, 0, 0.08), 0 0 0 1px rgba(43, 141, 255, 0.1)' 
            : '0 1px 3px rgba(0, 0, 0, 0.05), 0 1px 2px rgba(0, 0, 0, 0.05)',
        }}
      >
        <div className="mb-6">
          <h3 
            className="font-bold mb-1"
            style={{ color: '#111827' }}
          >
            표준화 진행 현황
          </h3>
          <p 
            className="text-sm"
            style={{ color: '#6b7280' }}
          >
            목표 대비 현재 진행률
          </p>
        </div>
        <div className="grid grid-cols-1 gap-6 flex-1 overflow-y-auto">
          {data.map((item, idx) => (
            <div key={idx}>
              <div className="flex items-center justify-between mb-3">
                <span 
                  className="font-bold"
                  style={{ color: '#111827' }}
                >
                  {item.label}
                </span>
                <div className="text-right">
                  <span 
                    className="font-bold"
                    style={{ color: '#111827' }}
                  >
                    {item.current}%
                  </span>
                  <span 
                    className="text-sm ml-2"
                    style={{ color: '#6b7280' }}
                  >
                    / {item.target}%
                  </span>
                </div>
              </div>
              <div 
                className="relative w-full h-3 rounded-full overflow-hidden"
                style={{ backgroundColor: '#e5e7eb' }}
              >
                <div 
                  className="absolute top-0 left-0 h-full rounded-full transition-all duration-500"
                  style={{ 
                    width: `${item.current}%`,
                    backgroundColor: getColorByIndex(idx, item.current, item.target)
                  }}
                ></div>
                {/* 목표선 */}
                <div 
                  className="absolute top-0 h-full w-1 opacity-50"
                  style={{ 
                    left: `${item.target}%`,
                    backgroundColor: '#111827'
                  }}
                ></div>
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}