import { Card } from '../../common/Card';
import { AreaChart, Area, ResponsiveContainer, XAxis, YAxis, Tooltip, CartesianGrid, Legend } from 'recharts';
import { useState } from 'react';

interface QualityTrendSectionProps {
  data: Array<{ date: string; score: number; standardization: number }>;
  CustomTooltip: React.ComponentType<any>;
}

export function QualityTrendSection({ data, CustomTooltip }: QualityTrendSectionProps) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div 
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className="transition-all duration-300"
      style={{
        transform: isHovered ? 'translateY(-4px)' : 'translateY(0)',
      }}
    >
      <Card 
        padding="lg" 
        className="h-[400px] flex flex-col transition-all duration-300"
        style={{
          boxShadow: isHovered 
            ? '0 20px 40px rgba(0, 0, 0, 0.08), 0 0 0 1px rgba(43, 141, 255, 0.1)' 
            : '0 1px 3px rgba(0, 0, 0, 0.05), 0 1px 2px rgba(0, 0, 0, 0.05)',
        }}
      >
        <div className="mb-6">
          <h3 style={{ color: '#202124' }} className="font-bold mb-1">품질 & 표준화 추이</h3>
          <p style={{ color: '#5F6368' }} className="text-sm">월별 추이</p>
        </div>
        <div className="flex-1">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={data}>
              <defs>
                <linearGradient id="colorScore" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#4B5563" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#4B5563" stopOpacity={0}/>
                </linearGradient>
                <linearGradient id="colorStandardization" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#F59E0B" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#F59E0B" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#d1d5db" opacity={0.6} vertical={false} />
              <XAxis 
                dataKey="date" 
                stroke="#6b7280"
                style={{ fontSize: '12px', fill: '#9ca3af' }}
                tickLine={false}
                axisLine={{ stroke: '#374151' }}
              />
              <YAxis 
                stroke="#6b7280"
                style={{ fontSize: '12px', fill: '#9ca3af' }}
                tickLine={false}
                axisLine={false}
                domain={[0, 120]}
                ticks={[0, 20, 40, 60, 80, 100, 120]}
              />
              <Tooltip content={<CustomTooltip />} />
              <Legend 
                wrapperStyle={{ fontSize: '12px', paddingTop: '20px', color: '#e5e7eb' }}
                iconType="line"
              />
              <Area 
                type="monotone" 
                dataKey="score" 
                stroke="#4B5563" 
                strokeWidth={2}
                fill="url(#colorScore)"
                dot={{ fill: '#4B5563', r: 4, strokeWidth: 0 }}
                activeDot={{ r: 6, strokeWidth: 0 }}
                name="품질점수"
              />
              <Area 
                type="monotone" 
                dataKey="standardization" 
                stroke="#F59E0B" 
                strokeWidth={2}
                fill="url(#colorStandardization)"
                dot={{ fill: '#F59E0B', r: 4, strokeWidth: 0 }}
                activeDot={{ r: 6, strokeWidth: 0 }}
                name="표준화율"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </Card>
    </div>
  );
}