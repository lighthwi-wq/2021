import { Card } from '../../common/Card';
import { useState } from 'react';

interface Activity {
  title: string;
  time: string;
  type: string;
  manager: string;
  department: string;
  datetime: string;
}

interface RecentActivitiesSectionProps {
  data: Activity[];
}

export function RecentActivitiesSection({ data }: RecentActivitiesSectionProps) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div 
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className="transition-all duration-300"
      style={{
        transform: isHovered ? 'translateY(-4px)' : 'translateY(0)',
      }}
    >
      <Card 
        padding="lg" 
        className="h-[400px] flex flex-col transition-all duration-300"
        style={{
          boxShadow: isHovered 
            ? '0 20px 40px rgba(0, 0, 0, 0.08), 0 0 0 1px rgba(43, 141, 255, 0.1)' 
            : '0 1px 3px rgba(0, 0, 0, 0.05), 0 1px 2px rgba(0, 0, 0, 0.05)',
        }}
      >
        <div className="mb-6">
          <h3 
            className="font-bold mb-1"
            style={{ 
              color: '#111827',
              WebkitTextFillColor: '#111827'
            }}
          >
            최근 활동
          </h3>
          <p 
            className="text-sm"
            style={{ 
              color: '#6b7280',
              WebkitTextFillColor: '#6b7280'
            }}
          >
            실시간 업데이트
          </p>
        </div>
        <div className="space-y-4 flex-1 overflow-y-auto">
          {data.map((activity, idx) => (
            <div 
              key={idx} 
              className="flex items-center justify-between p-3 rounded-lg transition-colors"
              style={{ backgroundColor: '#f9fafb' }}
              onMouseEnter={(e) => {
                e.currentTarget.style.backgroundColor = '#f3f4f6';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.backgroundColor = '#f9fafb';
              }}
            >
              <div className="flex items-start gap-3 flex-1 min-w-0">
                <div 
                  className="w-2 h-2 rounded-full mt-2"
                  style={{
                    backgroundColor: 
                      activity.type === 'success' ? '#10b981' :
                      activity.type === 'warning' ? '#f97316' : '#3b82f6'
                  }}
                ></div>
                <div className="flex-1 min-w-0">
                  <p 
                    className="text-sm font-bold mb-1"
                    style={{ 
                      color: '#111827',
                      WebkitTextFillColor: '#111827'
                    }}
                  >
                    {activity.title}
                  </p>
                  <p 
                    className="text-xs"
                    style={{ 
                      color: '#6b7280',
                      WebkitTextFillColor: '#6b7280'
                    }}
                  >
                    {activity.time}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-6 flex-shrink-0">
                <div className="text-left" style={{ width: '100px' }}>
                  <p 
                    className="text-sm font-bold mb-1"
                    style={{ color: '#111827' }}
                  >
                    {activity.manager}
                  </p>
                  <p 
                    className="text-xs"
                    style={{ color: '#6b7280' }}
                  >
                    담당자
                  </p>
                </div>
                <div className="text-left" style={{ width: '120px' }}>
                  <p 
                    className="text-sm font-bold mb-1"
                    style={{ color: '#111827' }}
                  >
                    {activity.department}
                  </p>
                  <p 
                    className="text-xs"
                    style={{ color: '#6b7280' }}
                  >
                    부서
                  </p>
                </div>
                <div className="text-left" style={{ width: '140px' }}>
                  <p 
                    className="text-sm font-bold mb-1"
                    style={{ color: '#111827' }}
                  >
                    {activity.datetime}
                  </p>
                  <p 
                    className="text-xs"
                    style={{ color: '#6b7280' }}
                  >
                    일시
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}