import { Filter, Download } from 'lucide-react';
import { tableData } from '../../constants/tableData';
import { DataRow } from '../../types';
import { useFilters } from '../../hooks/useFilters';
import { Button } from '../common/Button';
import { Badge } from '../common/Badge';
import { Table } from '../common/Table/Table';
import { FilterPanel } from '../features/FilterPanel/FilterPanel';
import { Card } from '../common/Card';

const statusLabels = {
  active: '활성',
  syncing: '동기화 중',
  error: '오류',
} as const;

export function DataSourceTable() {
  const filterFn = (item: DataRow, filters: any) => {
    const statusMatch = filters.status?.length === 0 || filters.status?.includes(item.status);
    const sourceMatch = filters.source?.length === 0 || filters.source?.includes(item.source);
    return statusMatch && sourceMatch;
  };

  const {
    filters,
    isOpen,
    setIsOpen,
    toggleFilter,
    clearFilters,
    activeFilterCount,
    filteredData,
  } = useFilters(tableData, filterFn);

  const getStatusVariant = (status: string) => {
    switch (status) {
      case 'active': return 'success';
      case 'syncing': return 'info';
      case 'error': return 'error';
      default: return 'default';
    }
  };

  return (
    <Card padding="sm">
      <div className="p-3 border-b border-gray-200 dark:border-gray-700">
        <div className="flex items-center justify-between">
          <h3 className="text-gray-900 dark:text-white font-bold text-sm">데이터 소스</h3>
          <div className="flex items-center gap-2">
            <div className="relative">
              <Button
                variant="ghost"
                size="sm"
                icon={<Filter className="w-4 h-4" />}
                onClick={() => setIsOpen(!isOpen)}
              >
                필터
                {activeFilterCount > 0 && (
                  <span className="ml-1 px-1.5 py-0.5 bg-blue-600 dark:bg-blue-500 text-white rounded-full text-xs">
                    {activeFilterCount}
                  </span>
                )}
              </Button>

              <FilterPanel
                isOpen={isOpen}
                onClose={() => setIsOpen(false)}
                onClear={clearFilters}
                activeFilterCount={activeFilterCount}
              >
                <FilterPanel.Group label="상태">
                  {Object.entries(statusLabels).map(([key, label]) => (
                    <FilterPanel.Checkbox
                      key={key}
                      label={label}
                      checked={filters.status?.includes(key) || false}
                      onChange={() => toggleFilter('status', key)}
                    />
                  ))}
                </FilterPanel.Group>

                <FilterPanel.Group label="소스">
                  {['PostgreSQL', 'MongoDB', 'MySQL', 'BigQuery', 'Redis'].map(source => (
                    <FilterPanel.Checkbox
                      key={source}
                      label={source}
                      checked={filters.source?.includes(source) || false}
                      onChange={() => toggleFilter('source', source)}
                    />
                  ))}
                </FilterPanel.Group>
              </FilterPanel>
            </div>
            <Button variant="primary" size="sm" icon={<Download className="w-4 h-4" />}>
              내보내기
            </Button>
          </div>
        </div>
      </div>

      <Table>
        <Table.Header>
          <Table.HeadCell>ID</Table.HeadCell>
          <Table.HeadCell>이름</Table.HeadCell>
          <Table.HeadCell>소스</Table.HeadCell>
          <Table.HeadCell>상태</Table.HeadCell>
          <Table.HeadCell>레코드</Table.HeadCell>
          <Table.HeadCell>마지막 동기화</Table.HeadCell>
        </Table.Header>
        <Table.Body>
          {filteredData.length > 0 ? (
            filteredData.map((row) => (
              <Table.Row key={row.id}>
                <Table.Cell>{row.id}</Table.Cell>
                <Table.Cell>{row.name}</Table.Cell>
                <Table.Cell className="text-gray-600 dark:text-gray-400">
                  {row.source}
                </Table.Cell>
                <Table.Cell>
                  <Badge variant={getStatusVariant(row.status)} dot>
                    {statusLabels[row.status]}
                  </Badge>
                </Table.Cell>
                <Table.Cell>{row.records}</Table.Cell>
                <Table.Cell className="text-gray-600 dark:text-gray-400">
                  {row.lastSync}
                </Table.Cell>
              </Table.Row>
            ))
          ) : (
            <Table.Empty message="필터 조건에 맞는 데이터가 없습니다" colSpan={6} />
          )}
        </Table.Body>
      </Table>
    </Card>
  );
}