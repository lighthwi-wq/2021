import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { barChartData } from '../../constants/chartData';
import { Card } from '../common/Card';

export function ApiChart() {
  return (
    <Card padding="sm">
      <h3 className="text-gray-900 dark:text-white mb-3 font-bold text-sm">주간 API 요청</h3>
      <ResponsiveContainer width="100%" height={160}>
        <BarChart data={barChartData.map(item => ({ ...item, max: 5000 }))}>
          <CartesianGrid 
            strokeDasharray="3 3" 
            stroke="#9ca3af" 
            opacity={0.8} 
          />
          <XAxis 
            dataKey="name" 
            stroke="#6b7280"
            style={{ fontSize: '12px', fill: '#6b7280' }}
          />
          <YAxis 
            stroke="#6b7280"
            style={{ fontSize: '12px', fill: '#6b7280' }}
          />
          <Tooltip 
            cursor={{ fill: 'rgba(0, 0, 0, 0.15)' }}
            contentStyle={{ 
              backgroundColor: '#ffffff', 
              border: `1px solid #e5e7eb`,
              borderRadius: '8px',
              color: '#111827'
            }}
          />
          <Bar dataKey="max" fill="#E5E7EB" radius={[0, 0, 0, 0]} />
          <Bar dataKey="value" fill="#3B82F6" radius={[0, 0, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </Card>
  );
}