import { TrendingUp, TrendingDown } from 'lucide-react';
import { StatCard as StatCardType } from '../../types';
import { IconBox } from '../common/IconBox';
import { Badge } from '../common/Badge';

interface StatCardProps {
  stat: StatCardType;
}

export function StatCard({ stat }: StatCardProps) {
  const TrendIcon = stat.trend === 'up' ? TrendingUp : TrendingDown;
  
  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl p-3 border border-gray-200 dark:border-gray-700 transition-all duration-300 hover:shadow-lg hover:shadow-gray-200/50 dark:hover:shadow-gray-900/50">
      <div className="flex items-start justify-between mb-2">
        <IconBox icon={stat.icon} color={stat.color as any} size="sm" />
        <div className={`flex items-center gap-1 px-2 py-0.5 rounded-full text-xs ${
          stat.trend === 'up' 
            ? 'bg-teal-50 dark:bg-teal-900/20 text-teal-600 dark:text-teal-400' 
            : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400'
        }`}>
          <TrendIcon className="w-3 h-3" />
          <span>{stat.change}</span>
        </div>
      </div>
      <h3 className="text-gray-900 dark:text-white mb-0.5 font-bold text-sm">
        {stat.value}
      </h3>
      <p className="text-gray-500 dark:text-gray-400 text-sm">
        {stat.label}
      </p>
    </div>
  );
}