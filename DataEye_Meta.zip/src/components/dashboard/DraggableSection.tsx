import { useRef, useState } from 'react';
import { useDrag, useDrop } from 'react-dnd';
import { GripVertical } from 'lucide-react';

interface DraggableSectionProps {
  id: string;
  index: number;
  moveSection: (dragIndex: number, hoverIndex: number) => void;
  children: React.ReactNode;
}

const ItemType = 'DASHBOARD_SECTION';

export function DraggableSection({ id, index, moveSection, children }: DraggableSectionProps) {
  const ref = useRef<HTMLDivElement>(null);
  const [isHoveringHandle, setIsHoveringHandle] = useState(false);

  const [{ isDragging }, drag, preview] = useDrag({
    type: ItemType,
    item: { id, index },
    collect: (monitor) => ({
      isDragging: monitor.isDragging(),
    }),
  });

  const [{ isOver, canDrop }, drop] = useDrop({
    accept: ItemType,
    hover(item: { id: string; index: number }, monitor) {
      if (!ref.current) {
        return;
      }
      const dragIndex = item.index;
      const hoverIndex = index;

      if (dragIndex === hoverIndex) {
        return;
      }

      const hoverBoundingRect = ref.current?.getBoundingClientRect();
      const hoverMiddleY = (hoverBoundingRect.bottom - hoverBoundingRect.top) / 2;
      const clientOffset = monitor.getClientOffset();
      const hoverClientY = clientOffset!.y - hoverBoundingRect.top;

      if (dragIndex < hoverIndex && hoverClientY < hoverMiddleY) {
        return;
      }

      if (dragIndex > hoverIndex && hoverClientY > hoverMiddleY) {
        return;
      }

      moveSection(dragIndex, hoverIndex);
      item.index = hoverIndex;
    },
    collect: (monitor) => ({
      isOver: monitor.isOver(),
      canDrop: monitor.canDrop(),
    }),
  });

  preview(drop(ref));

  return (
    <div
      ref={ref}
      className="relative"
      style={{
        opacity: isDragging ? 0.4 : 1,
        transform: isDragging ? 'scale(1.02) rotate(0.5deg)' : 'scale(1) rotate(0deg)',
        cursor: isDragging ? 'grabbing' : 'default',
        transition: isDragging 
          ? 'opacity 0.15s ease-out, transform 0.15s cubic-bezier(0.34, 1.56, 0.64, 1)' 
          : 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
        filter: isDragging ? 'drop-shadow(0 25px 50px rgba(43, 141, 255, 0.25))' : 'none',
      }}
    >
      {/* Drag Handle */}
      <div
        ref={drag}
        className="absolute top-3 right-3 z-10 p-2 rounded-lg cursor-grab active:cursor-grabbing"
        style={{
          backgroundColor: isHoveringHandle ? 'rgba(43, 141, 255, 0.12)' : isOver ? 'rgba(43, 141, 255, 0.06)' : 'transparent',
          transform: isHoveringHandle ? 'scale(1.15) rotate(90deg)' : isOver ? 'scale(1.08)' : 'scale(1)',
          transition: 'all 0.25s cubic-bezier(0.34, 1.56, 0.64, 1)',
          boxShadow: isHoveringHandle ? '0 4px 16px rgba(43, 141, 255, 0.3), 0 0 0 2px rgba(43, 141, 255, 0.1)' : 'none',
        }}
        onMouseEnter={() => setIsHoveringHandle(true)}
        onMouseLeave={() => setIsHoveringHandle(false)}
      >
        <GripVertical 
          className="w-5 h-5" 
          style={{ 
            color: isHoveringHandle ? '#2B8DFF' : isOver ? '#60A5FA' : '#9CA3AF',
            transition: 'color 0.25s ease'
          }} 
        />
      </div>
      
      {/* Border indicator when hovering */}
      {isOver && canDrop && (
        <>
          <div
            className="absolute inset-0 rounded-xl pointer-events-none"
            style={{
              border: '2px dashed rgba(43, 141, 255, 0.5)',
              backgroundColor: 'rgba(43, 141, 255, 0.04)',
              transform: 'scale(1.01)',
              transition: 'all 0.3s cubic-bezier(0.34, 1.56, 0.64, 1)',
              boxShadow: '0 16px 40px rgba(43, 141, 255, 0.15), inset 0 0 0 1px rgba(43, 141, 255, 0.08)',
              animation: 'dashAnimation 1.5s linear infinite, pulse 2s ease-in-out infinite',
            }}
          />
          
          {/* Corner indicators with improved animation */}
          {[
            { top: '-10px', left: '-10px' },
            { top: '-10px', right: '-10px' },
            { bottom: '-10px', left: '-10px' },
            { bottom: '-10px', right: '-10px' },
          ].map((position, idx) => (
            <div
              key={idx}
              className="absolute w-5 h-5 rounded-full pointer-events-none"
              style={{
                ...position,
                background: 'linear-gradient(135deg, #2B8DFF 0%, #60A5FA 100%)',
                boxShadow: '0 3px 12px rgba(43, 141, 255, 0.5), 0 0 0 3px rgba(43, 141, 255, 0.2)',
                animation: `pulse 1.5s ease-in-out infinite ${idx * 0.15}s`,
              }}
            />
          ))}
        </>
      )}

      {/* Drop zone indicator with smooth animation */}
      {isOver && canDrop && (
        <div
          className="absolute left-1/2 pointer-events-none z-30"
          style={{
            top: '50%',
            transform: 'translate(-50%, -50%)',
            animation: 'scaleInOut 1.2s ease-in-out infinite',
          }}
        >
          <div
            className="rounded-full flex items-center justify-center"
            style={{
              width: '80px',
              height: '80px',
              background: 'linear-gradient(135deg, rgba(43, 141, 255, 0.95), rgba(96, 165, 250, 0.9))',
              boxShadow: '0 12px 32px rgba(43, 141, 255, 0.6), 0 0 0 10px rgba(43, 141, 255, 0.1), 0 0 0 20px rgba(43, 141, 255, 0.05)',
            }}
          >
            <svg
              width="40"
              height="40"
              viewBox="0 0 24 24"
              fill="none"
              stroke="white"
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
              style={{
                filter: 'drop-shadow(0 3px 6px rgba(0, 0, 0, 0.25))',
              }}
            >
              <path d="M7 16V4M7 4L3 8M7 4l4 4" />
              <path d="M17 8v12M17 20l4-4M17 20l-4-4" />
            </svg>
          </div>
        </div>
      )}

      <div
        style={{
          transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
          transform: isOver ? 'translateY(-8px) scale(1.01)' : 'translateY(0) scale(1)',
        }}
      >
        {children}
      </div>

      <style>{`
        @keyframes pulse {
          0%, 100% {
            transform: scale(1);
            opacity: 1;
          }
          50% {
            transform: scale(1.4);
            opacity: 0.6;
          }
        }

        @keyframes scaleInOut {
          0%, 100% {
            transform: translate(-50%, -50%) scale(1) rotate(0deg);
            opacity: 1;
          }
          50% {
            transform: translate(-50%, -50%) scale(1.1) rotate(180deg);
            opacity: 0.95;
          }
        }

        @keyframes dashAnimation {
          0% {
            stroke-dashoffset: 0;
          }
          100% {
            stroke-dashoffset: 24;
          }
        }
      `}</style>
    </div>
  );
}