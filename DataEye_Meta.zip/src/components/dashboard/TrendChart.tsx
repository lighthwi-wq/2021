import React from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { areaChartData } from '../../constants/chartData';
import { Card } from '../common/Card';

export function TrendChart() {
  return (
    <Card padding="sm">
      <h3 className="text-gray-900 dark:text-white mb-3 font-bold text-sm">데이터 트렌드</h3>
      <ResponsiveContainer width="100%" height={180}>
        <AreaChart data={areaChartData}>
          <CartesianGrid 
            strokeDasharray="3 3" 
            stroke="#e5e7eb" 
            opacity={0.3} 
          />
          <XAxis 
            dataKey="name" 
            stroke="#6b7280"
            style={{ fontSize: '12px', fill: '#6b7280' }}
          />
          <YAxis 
            stroke="#6b7280"
            style={{ fontSize: '12px', fill: '#6b7280' }}
          />
          <Tooltip 
            contentStyle={{ 
              backgroundColor: '#ffffff', 
              border: `1px solid #e5e7eb`,
              borderRadius: '8px',
              color: '#111827'
            }}
          />
          <Area 
            type="monotone" 
            dataKey="value" 
            stackId="1" 
            stroke="#3B82F6" 
            fill="#3B82F6" 
            fillOpacity={0.6}
          />
          <Area 
            type="monotone" 
            dataKey="users" 
            stackId="2" 
            stroke="#2B8DFF" 
            fill="#2B8DFF" 
            fillOpacity={0.6}
          />
        </AreaChart>
      </ResponsiveContainer>
    </Card>
  );
}