import { Search, X } from 'lucide-react';
import { cn } from '../../../utils/cn';

interface SearchBarProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  className?: string;
}

export function SearchBar({
  value,
  onChange,
  placeholder = '검색...',
  className,
}: SearchBarProps) {
  return (
    <div
      className={cn(
        'flex items-center gap-3',
        'bg-gray-50 dark:bg-gray-700 rounded-xl px-4 py-2',
        'border border-gray-200 dark:border-gray-600',
        'transition-colors duration-300',
        className
      )}
    >
      <Search className="w-4 h-4 text-gray-400 dark:text-gray-500 flex-shrink-0" />
      <input
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="bg-transparent border-none outline-none text-gray-900 dark:text-gray-100 placeholder-gray-400 dark:placeholder-gray-500 w-full text-sm"
      />
      {value && (
        <button
          onClick={() => onChange('')}
          className="p-1 hover:bg-gray-200 dark:hover:bg-gray-600 rounded transition-colors"
        >
          <X className="w-3.5 h-3.5 text-gray-500 dark:text-gray-400" />
        </button>
      )}
    </div>
  );
}
