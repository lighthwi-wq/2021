import { ReactNode } from 'react';
import { X } from 'lucide-react';
import { cn } from '../../../utils/cn';

interface FilterPanelProps {
  isOpen: boolean;
  onClose: () => void;
  onClear: () => void;
  activeFilterCount: number;
  children: ReactNode;
  className?: string;
}

export function FilterPanel({
  isOpen,
  onClose,
  onClear,
  activeFilterCount,
  children,
  className,
}: FilterPanelProps) {
  if (!isOpen) return null;

  return (
    <div
      className={cn(
        'absolute right-0 top-full mt-2 w-72 z-50',
        'bg-white dark:bg-gray-800',
        'border border-gray-200 dark:border-gray-700',
        'rounded-xl shadow-lg p-4',
        className
      )}
    >
      <div className="flex items-center justify-between mb-4">
        <h4 className="text-gray-900 dark:text-white font-bold">필터</h4>
        <div className="flex items-center gap-2">
          {activeFilterCount > 0 && (
            <button
              onClick={onClear}
              className="text-blue-600 dark:text-blue-400 text-sm hover:underline"
            >
              초기화
            </button>
          )}
          <button
            onClick={onClose}
            className="p-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg"
          >
            <X className="w-4 h-4 text-gray-500 dark:text-gray-400" />
          </button>
        </div>
      </div>
      {children}
    </div>
  );
}

interface FilterGroupProps {
  label: string;
  children: ReactNode;
}

FilterPanel.Group = function FilterGroup({ label, children }: FilterGroupProps) {
  return (
    <div className="mb-4 last:mb-0">
      <label className="text-gray-700 dark:text-gray-300 text-sm font-bold mb-2 block">
        {label}
      </label>
      <div className="space-y-2">
        {children}
      </div>
    </div>
  );
};

interface FilterCheckboxProps {
  label: string;
  checked: boolean;
  onChange: () => void;
}

FilterPanel.Checkbox = function FilterCheckbox({ label, checked, onChange }: FilterCheckboxProps) {
  return (
    <label className="flex items-center gap-2 cursor-pointer">
      <input
        type="checkbox"
        checked={checked}
        onChange={onChange}
        className="rounded border-gray-300 dark:border-gray-600 text-blue-600 focus:ring-blue-500"
      />
      <span className="text-gray-700 dark:text-gray-300 text-sm">{label}</span>
    </label>
  );
};
