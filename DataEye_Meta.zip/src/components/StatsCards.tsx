import { TrendingUp, TrendingDown, Database, Users, Activity, Eye, Server } from 'lucide-react';

const stats = [
  { 
    label: '총 데이터 레코드', 
    value: '2.4M', 
    change: '+12.5%', 
    trend: 'up' as const, 
    icon: Database,
    color: 'blue'
  },
  { 
    label: '활성 데이터 소스', 
    value: '23', 
    change: '+3', 
    trend: 'up' as const, 
    icon: TrendingUp,
    color: 'green'
  },
  { 
    label: '처리 속도', 
    value: '98.5%', 
    change: '+2.4%', 
    trend: 'up' as const, 
    icon: Activity,
    color: 'indigo'
  },
  { 
    label: '시스템 가동률', 
    value: '99.9%', 
    change: '-0.1%', 
    trend: 'down' as const, 
    icon: Server,
    color: 'orange'
  },
];

export function StatsCards() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-2.5 mb-2.5">
      {stats.map((stat, index) => {
        const Icon = stat.icon;
        const TrendIcon = stat.trend === 'up' ? TrendingUp : TrendingDown;
        
        return (
          <div
            key={index}
            className="bg-white dark:bg-gray-800 rounded-xl p-3 border border-gray-200 dark:border-gray-700 transition-all duration-300 hover:shadow-lg hover:shadow-gray-200/50 dark:hover:shadow-gray-900/50"
          >
            <div className="flex items-start justify-between mb-2">
              <div className={`p-2 rounded-lg bg-${stat.color}-50 dark:bg-${stat.color}-900/20 shadow-sm`}>
                <Icon className={`w-4 h-4 text-${stat.color}-600 dark:text-${stat.color}-400`} />
              </div>
              <div className={`flex items-center gap-1 px-2 py-0.5 rounded-full text-xs ${
                stat.trend === 'up' ? 'bg-green-50 dark:bg-green-900/20 text-green-600 dark:text-green-400' : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400'
              }`}>
                <TrendIcon className="w-3 h-3" />
                <span>{stat.change}</span>
              </div>
            </div>
            <h3 className="text-gray-900 dark:text-white mb-0.5 font-bold text-sm">
              {stat.value}
            </h3>
            <p className="text-gray-500 dark:text-gray-400 text-sm">
              {stat.label}
            </p>
          </div>
        );
      })}
    </div>
  );
}