import { useState, useEffect } from 'react';
import { TrendingUp, TrendingDown, AlertTriangle, CheckCircle, Activity, Database } from 'lucide-react';
import { Card } from '../common/Card';
import { colors } from '../../constants/designSystem';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const dailyTrend = [
  { date: '01/20', score: 88 },
  { date: '01/21', score: 90 },
  { date: '01/22', score: 89 },
  { date: '01/23', score: 91 },
  { date: '01/24', score: 92 },
  { date: '01/25', score: 91 },
  { date: '01/26', score: 92 },
];

const errorsByType = [
  { type: 'Null', count: 12 },
  { type: 'Format', count: 8 },
  { type: 'Range', count: 5 },
  { type: 'Duplicate', count: 3 },
];

export function DQMDashboard() {
  const [gaugeProgress, setGaugeProgress] = useState(0);
  const targetScore = 92;

  useEffect(() => {
    const timer = setTimeout(() => {
      setGaugeProgress(targetScore);
    }, 300);
    return () => clearTimeout(timer);
  }, []);

  const circumference = 2 * Math.PI * 80;
  const offset = circumference - (gaugeProgress / 100) * circumference;

  const criticalErrors = [
    { id: 1, table: 'TB_CUSTOMER', issue: 'Null values in primary key', count: 45 },
    { id: 2, table: 'TB_ORDER', issue: 'Invalid date format', count: 23 },
    { id: 3, table: 'TB_PRODUCT', issue: 'Price out of range', count: 12 },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl mb-2" style={{ color: colors.textPrimary, fontWeight: 700 }}>
          Data Quality Dashboard
        </h1>
        <p style={{ color: colors.textSecondary }}>
          Real-time monitoring of data quality metrics across all domains
        </p>
      </div>

      {/* Main Gauge Chart */}
      <div className="grid grid-cols-3 gap-6">
        <Card className="col-span-2 p-8">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-xl mb-1" style={{ color: colors.textPrimary, fontWeight: 600 }}>
                Total Data Quality Score
              </h3>
              <p style={{ color: colors.textSecondary }}>
                Overall health across all datasets
              </p>
            </div>
            <div className="flex items-center gap-2 px-4 py-2 rounded-full" style={{ backgroundColor: colors.successLight }}>
              <TrendingUp className="w-4 h-4" style={{ color: colors.success }} />
              <span style={{ color: colors.success, fontWeight: 600 }}>+2.3% vs last week</span>
            </div>
          </div>

          <div className="flex items-center justify-center py-8">
            <div className="relative">
              <svg width="240" height="240" className="transform -rotate-90">
                {/* Background Circle */}
                <circle
                  cx="120"
                  cy="120"
                  r="80"
                  fill="none"
                  stroke="#F3F4F6"
                  strokeWidth="16"
                />
                {/* Progress Circle */}
                <circle
                  cx="120"
                  cy="120"
                  r="80"
                  fill="none"
                  stroke={colors.success}
                  strokeWidth="16"
                  strokeLinecap="round"
                  strokeDasharray={circumference}
                  strokeDashoffset={offset}
                  style={{
                    transition: 'stroke-dashoffset 2s ease-out',
                    filter: 'drop-shadow(0 0 10px rgba(16, 185, 129, 0.5))',
                  }}
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <div className="text-5xl mb-1" style={{ color: colors.success, fontWeight: 700 }}>
                  {gaugeProgress}%
                </div>
                <div style={{ color: colors.textSecondary }}>Quality Score</div>
              </div>
            </div>
          </div>

          {/* Sparklines */}
          <div className="grid grid-cols-3 gap-4 mt-6 pt-6 border-t" style={{ borderColor: colors.divider }}>
            <div>
              <div className="text-xs mb-2" style={{ color: colors.textSecondary }}>COMPLETENESS</div>
              <div className="flex items-center gap-2">
                <div className="text-2xl" style={{ color: colors.textPrimary, fontWeight: 600 }}>95%</div>
                <ResponsiveContainer width={60} height={30}>
                  <LineChart data={dailyTrend.slice(-5)}>
                    <Line type="monotone" dataKey="score" stroke={colors.success} strokeWidth={2} dot={false} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
            <div>
              <div className="text-xs mb-2" style={{ color: colors.textSecondary }}>ACCURACY</div>
              <div className="flex items-center gap-2">
                <div className="text-2xl" style={{ color: colors.textPrimary, fontWeight: 600 }}>93%</div>
                <ResponsiveContainer width={60} height={30}>
                  <LineChart data={dailyTrend.slice(-5)}>
                    <Line type="monotone" dataKey="score" stroke={colors.primary} strokeWidth={2} dot={false} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
            <div>
              <div className="text-xs mb-2" style={{ color: colors.textSecondary }}>CONSISTENCY</div>
              <div className="flex items-center gap-2">
                <div className="text-2xl" style={{ color: colors.textPrimary, fontWeight: 600 }}>88%</div>
                <ResponsiveContainer width={60} height={30}>
                  <LineChart data={dailyTrend.slice(-5)}>
                    <Line type="monotone" dataKey="score" stroke={colors.warning} strokeWidth={2} dot={false} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        </Card>

        {/* Quick Stats */}
        <div className="space-y-4">
          <Card className="p-5">
            <div className="flex items-center gap-3 mb-3">
              <div className="p-2 rounded-lg" style={{ backgroundColor: colors.successLight }}>
                <CheckCircle className="w-5 h-5" style={{ color: colors.success }} />
              </div>
              <div className="text-xs" style={{ color: colors.textSecondary, fontWeight: 600 }}>
                PASSED RULES
              </div>
            </div>
            <div className="text-3xl mb-1" style={{ color: colors.textPrimary, fontWeight: 700 }}>
              1,247
            </div>
            <div className="text-xs" style={{ color: colors.textSecondary }}>
              Out of 1,275 total rules
            </div>
          </Card>

          <Card className="p-5 animate-pulse-glow">
            <div className="flex items-center gap-3 mb-3">
              <div className="p-2 rounded-lg" style={{ backgroundColor: colors.errorLight }}>
                <AlertTriangle className="w-5 h-5" style={{ color: colors.error }} />
              </div>
              <div className="text-xs" style={{ color: colors.textSecondary, fontWeight: 600 }}>
                CRITICAL ISSUES
              </div>
            </div>
            <div className="text-3xl mb-1" style={{ color: colors.error, fontWeight: 700 }}>
              28
            </div>
            <div className="text-xs" style={{ color: colors.textSecondary }}>
              Requires immediate attention
            </div>
          </Card>

          <Card className="p-5">
            <div className="flex items-center gap-3 mb-3">
              <div className="p-2 rounded-lg" style={{ backgroundColor: colors.primaryLight }}>
                <Activity className="w-5 h-5" style={{ color: colors.primary }} />
              </div>
              <div className="text-xs" style={{ color: colors.textSecondary, fontWeight: 600 }}>
                ACTIVE MONITORS
              </div>
            </div>
            <div className="text-3xl mb-1" style={{ color: colors.textPrimary, fontWeight: 700 }}>
              156
            </div>
            <div className="text-xs" style={{ color: colors.textSecondary }}>
              Running continuously
            </div>
          </Card>
        </div>
      </div>

      {/* Trend Chart */}
      <div className="grid grid-cols-2 gap-6">
        <Card className="p-6">
          <h3 className="mb-4" style={{ color: colors.textPrimary, fontWeight: 600 }}>
            Quality Score Trend (Last 7 Days)
          </h3>
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={dailyTrend}>
              <CartesianGrid strokeDasharray="3 3" stroke={colors.border} />
              <XAxis dataKey="date" stroke={colors.textSecondary} style={{ fontSize: '12px' }} />
              <YAxis stroke={colors.textSecondary} style={{ fontSize: '12px' }} domain={[85, 95]} />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#FFFFFF',
                  border: `1px solid ${colors.border}`,
                  borderRadius: '8px',
                }}
              />
              <Line 
                type="monotone" 
                dataKey="score" 
                stroke={colors.primary} 
                strokeWidth={3}
                dot={{ fill: colors.primary, r: 4 }}
                activeDot={{ r: 6 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </Card>

        <Card className="p-6">
          <h3 className="mb-4" style={{ color: colors.textPrimary, fontWeight: 600 }}>
            Errors by Type
          </h3>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={errorsByType}>
              <CartesianGrid strokeDasharray="3 3" stroke={colors.border} />
              <XAxis dataKey="type" stroke={colors.textSecondary} style={{ fontSize: '12px' }} />
              <YAxis stroke={colors.textSecondary} style={{ fontSize: '12px' }} />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#FFFFFF',
                  border: `1px solid ${colors.border}`,
                  borderRadius: '8px',
                }}
              />
              <Bar dataKey="count" fill={colors.error} radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>
      </div>

      {/* Critical Errors */}
      <Card className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 style={{ color: colors.textPrimary, fontWeight: 600 }}>
            Critical Errors - Immediate Action Required
          </h3>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
            <span className="text-xs" style={{ color: colors.textSecondary }}>Live monitoring</span>
          </div>
        </div>
        <div className="space-y-3">
          {criticalErrors.map(error => (
            <div
              key={error.id}
              className="p-4 rounded-lg border-2 transition-all duration-300 hover:shadow-md cursor-pointer animate-pulse-glow"
              style={{
                backgroundColor: colors.errorLight,
                borderColor: colors.error,
              }}
            >
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-lg" style={{ backgroundColor: 'white' }}>
                  <Database className="w-6 h-6" style={{ color: colors.error }} />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span style={{ color: colors.textPrimary, fontWeight: 600 }}>{error.table}</span>
                    <span
                      className="px-2 py-0.5 rounded-full text-xs"
                      style={{
                        backgroundColor: colors.error,
                        color: 'white',
                        fontWeight: 600,
                      }}
                    >
                      {error.count} records
                    </span>
                  </div>
                  <div style={{ color: colors.textSecondary }}>{error.issue}</div>
                </div>
                <button
                  className="px-4 py-2 rounded-lg font-medium transition-all hover:shadow-md"
                  style={{
                    backgroundColor: colors.error,
                    color: 'white',
                  }}
                >
                  Fix Now
                </button>
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
