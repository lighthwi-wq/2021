import { 
  LayoutDashboard, 
  Database, 
  BarChart3, 
  FileText, 
  Users, 
  Settings,
  TrendingUp,
  Layers
} from 'lucide-react';

interface SidebarProps {
  activeMenu: string;
  setActiveMenu: (menu: string) => void;
}

const menuItems = [
  { id: 'dashboard', label: '대시보드', icon: LayoutDashboard },
  { id: 'analytics', label: '분석', icon: BarChart3 },
  { id: 'data-sources', label: '데이터 소스', icon: Database },
  { id: 'insights', label: '인사이트', icon: TrendingUp },
  { id: 'reports', label: '리포트', icon: FileText },
  { id: 'metadata', label: '메타데이터', icon: Layers },
  { id: 'users', label: '사용자', icon: Users },
  { id: 'settings', label: '설정', icon: Settings },
];

export function Sidebar({ activeMenu, setActiveMenu }: SidebarProps) {
  return (
    <aside className="w-64 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 transition-colors duration-300 rounded-xl shadow-sm flex-shrink-0 overflow-auto">
      <nav className="p-4">
        <div className="mb-4">
          <h3 className="text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-3 text-xs font-bold">메뉴</h3>
        </div>
        <div className="space-y-1">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeMenu === item.id;
            
            return (
              <button
                key={item.id}
                onClick={() => setActiveMenu(item.id)}
                className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg transition-all duration-200 text-sm ${
                  isActive
                    ? 'bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 shadow-sm border border-blue-100 dark:border-blue-800'
                    : 'text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-700/50 border border-transparent hover:border-gray-200 dark:hover:border-gray-600'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
      </nav>
    </aside>
  );
}