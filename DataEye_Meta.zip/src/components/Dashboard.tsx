import { StatsCards } from './StatsCards';
import { ChartsSection } from './ChartsSection';
import { DataTable } from './DataTable';
import { ActivityFeed } from './ActivityFeed';
import { 
  Database, 
  TrendingUp, 
  FileText, 
  Users as UsersIcon, 
  Settings as SettingsIcon,
  Layers,
  BarChart3,
  Search,
  Filter,
  Download,
  RefreshCw
} from 'lucide-react';

interface DashboardProps {
  activeMenu: string;
}

export function Dashboard({ activeMenu }: DashboardProps) {
  const renderContent = () => {
    switch (activeMenu) {
      case 'dashboard':
        return (
          <>
            <StatsCards />
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-2.5 mb-2.5">
              <div className="lg:col-span-2">
                <ChartsSection />
              </div>
              <div>
                <ActivityFeed />
              </div>
            </div>
            <DataTable />
          </>
        );

      case 'analytics':
        return (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 border border-gray-200 dark:border-gray-700">
                <div className="flex items-center gap-4 mb-4">
                  <div className="p-3 bg-indigo-50 dark:bg-indigo-900/20 rounded-xl">
                    <BarChart3 className="w-6 h-6 text-indigo-600 dark:text-indigo-400" />
                  </div>
                  <div>
                    <p className="text-gray-500 dark:text-gray-400">총 이벤트</p>
                    <h3 className="text-gray-900 dark:text-white font-bold">2.4M</h3>
                  </div>
                </div>
              </div>
              <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 border border-gray-200 dark:border-gray-700">
                <div className="flex items-center gap-4 mb-4">
                  <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-xl">
                    <TrendingUp className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                  </div>
                  <div>
                    <p className="text-gray-500 dark:text-gray-400">성장률</p>
                    <h3 className="text-gray-900 dark:text-white font-bold">+24.5%</h3>
                  </div>
                </div>
              </div>
              <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 border border-gray-200 dark:border-gray-700">
                <div className="flex items-center gap-4 mb-4">
                  <div className="p-3 bg-green-50 dark:bg-green-900/20 rounded-xl">
                    <UsersIcon className="w-6 h-6 text-green-600 dark:text-green-400" />
                  </div>
                  <div>
                    <p className="text-gray-500 dark:text-gray-400">활성 사용자</p>
                    <h3 className="text-gray-900 dark:text-white font-bold">12.8K</h3>
                  </div>
                </div>
              </div>
            </div>
            <ChartsSection />
          </div>
        );

      case 'data-sources':
        return (
          <div className="space-y-4">
            <div className="flex gap-3 mb-6">
              <button className="px-5 py-2.5 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-all duration-200 flex items-center gap-2 shadow-lg shadow-blue-500/20">
                <Database className="w-4 h-4" />
                새 소스 추가
              </button>
              <button className="px-5 py-2.5 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-xl hover:bg-gray-200 dark:hover:bg-gray-600 transition-all duration-200 flex items-center gap-2">
                <RefreshCw className="w-4 h-4" />
                전체 동기화
              </button>
            </div>
            <DataTable />
          </div>
        );

      case 'insights':
        return (
          <div className="space-y-4">
            <div className="bg-white dark:bg-gray-800 rounded-2xl p-8 border border-gray-200 dark:border-gray-700">
              <div className="flex items-center gap-4 mb-6">
                <div className="p-4 bg-orange-50 dark:bg-orange-900/20 rounded-xl">
                  <TrendingUp className="w-8 h-8 text-orange-600 dark:text-orange-400" />
                </div>
                <div>
                  <h3 className="text-gray-900 dark:text-white font-bold mb-1">AI 기반 인사이트</h3>
                  <p className="text-gray-500 dark:text-gray-400">데이터에서 트렌드와 패턴을 발견합니다</p>
                </div>
              </div>
              <div className="space-y-4">
                {[
                  { title: '사용자 참여도 피크', desc: '오후 2-4시 사이 사용자 활동이 45% 증가합니다', color: 'blue' },
                  { title: '데이터 품질 경고', desc: '고객 데이터베이스에서 누락된 값 2.3% 감지되었습니다', color: 'red' },
                  { title: '성능 개선', desc: '이번 주 API 응답 시간이 30% 개선되었습니다', color: 'green' },
                  { title: '이상 징후 감지', desc: '금요일 저녁 트랜잭션이 비정상적으로 급증했습니다', color: 'orange' },
                ].map((insight, idx) => (
                  <div key={idx} className="p-4 bg-gray-50 dark:bg-gray-700/50 rounded-xl border border-gray-200 dark:border-gray-600">
                    <h4 className="text-gray-900 dark:text-white font-bold mb-2">{insight.title}</h4>
                    <p className="text-gray-600 dark:text-gray-400">{insight.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        );

      case 'reports':
        return (
          <div className="space-y-4">
            <div className="flex justify-between items-center mb-6">
              <div className="flex gap-3">
                <button className="px-5 py-2.5 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-all duration-200 flex items-center gap-2 shadow-lg shadow-blue-500/20">
                  <FileText className="w-4 h-4" />
                  리포트 생성
                </button>
              </div>
              <div className="flex gap-3">
                <button className="px-5 py-2.5 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-xl hover:bg-gray-200 dark:hover:bg-gray-600 transition-all">
                  <Filter className="w-4 h-4" />
                </button>
                <button className="px-5 py-2.5 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-xl hover:bg-gray-200 dark:hover:bg-gray-600 transition-all">
                  <Download className="w-4 h-4" />
                </button>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[
                { title: '월간 성능 리포트', date: '2024-11-01', status: '완료' },
                { title: '사용자 분석 요약', date: '2024-11-15', status: '완료' },
                { title: '데이터 품질 감사', date: '2024-11-18', status: '처리 중' },
                { title: '주간 API 사용량', date: '2024-11-20', status: '예정' },
              ].map((report, idx) => (
                <div key={idx} className="bg-white dark:bg-gray-800 rounded-2xl p-6 border border-gray-200 dark:border-gray-700 hover:shadow-lg transition-all cursor-pointer">
                  <div className="flex items-start justify-between mb-4">
                    <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-xl">
                      <FileText className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                    </div>
                    <span className={`px-2.5 py-1 rounded-full text-xs ${
                      report.status === '완료' ? 'bg-green-50 dark:bg-green-900/20 text-green-700 dark:text-green-400' :
                      report.status === '처리 중' ? 'bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-400' :
                      'bg-gray-50 dark:bg-gray-700 text-gray-700 dark:text-gray-400'
                    }`}>
                      {report.status}
                    </span>
                  </div>
                  <h4 className="text-gray-900 dark:text-white font-bold mb-2">{report.title}</h4>
                  <p className="text-gray-500 dark:text-gray-400">{report.date}</p>
                </div>
              ))}
            </div>
          </div>
        );

      case 'metadata':
        return (
          <div className="space-y-4">
            <div className="bg-white dark:bg-gray-800 rounded-2xl p-8 border border-gray-200 dark:border-gray-700">
              <div className="flex items-center gap-4 mb-6">
                <div className="p-4 bg-indigo-50 dark:bg-indigo-900/20 rounded-xl">
                  <Layers className="w-8 h-8 text-indigo-600 dark:text-indigo-400" />
                </div>
                <div>
                  <h3 className="text-gray-900 dark:text-white font-bold mb-1">메타데이터 관리</h3>
                  <p className="text-gray-500 dark:text-gray-400">데이터 정의를 체계적으로 관리합니다</p>
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {[
                  { label: '전체 스키마', value: '24', icon: Database },
                  { label: '데이터 필드', value: '1,456', icon: Layers },
                  { label: '관계', value: '89', icon: TrendingUp },
                ].map((stat, idx) => (
                  <div key={idx} className="p-6 bg-gray-50 dark:bg-gray-700/50 rounded-xl border border-gray-200 dark:border-gray-600">
                    <stat.icon className="w-6 h-6 text-indigo-600 dark:text-indigo-400 mb-3" />
                    <p className="text-gray-500 dark:text-gray-400 mb-1">{stat.label}</p>
                    <h4 className="text-gray-900 dark:text-white font-bold">{stat.value}</h4>
                  </div>
                ))}
              </div>
            </div>
          </div>
        );

      case 'users':
        return (
          <div className="space-y-4">
            <div className="flex justify-between items-center mb-6">
              <div className="flex gap-3">
                <button className="px-5 py-2.5 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-all duration-200 flex items-center gap-2 shadow-lg shadow-blue-500/20">
                  <UsersIcon className="w-4 h-4" />
                  사용자 초대
                </button>
              </div>
              <div className="flex items-center gap-3 bg-gray-50 dark:bg-gray-700 rounded-xl px-4 py-2.5 border border-gray-200 dark:border-gray-600">
                <Search className="w-4 h-4 text-gray-400" />
                <input 
                  type="text" 
                  placeholder="사용자 검색..."
                  className="bg-transparent border-none outline-none text-gray-900 dark:text-gray-100 placeholder-gray-400 w-64"
                />
              </div>
            </div>
            <div className="bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900/50">
                    <th className="px-6 py-4 text-left text-gray-600 dark:text-gray-400">이름</th>
                    <th className="px-6 py-4 text-left text-gray-600 dark:text-gray-400">이메일</th>
                    <th className="px-6 py-4 text-left text-gray-600 dark:text-gray-400">역할</th>
                    <th className="px-6 py-4 text-left text-gray-600 dark:text-gray-400">상태</th>
                    <th className="px-6 py-4 text-left text-gray-600 dark:text-gray-400">마지막 활동</th>
                  </tr>
                </thead>
                <tbody>
                  {[
                    { name: '김민지', email: 'minji.kim@dataeye.com', role: '관리자', status: '활성', lastActive: '5분 전' },
                    { name: '이지훈', email: 'jihoon.lee@dataeye.com', role: '편집자', status: '활성', lastActive: '12분 전' },
                    { name: '박서윤', email: 'seoyoon.park@dataeye.com', role: '뷰어', status: '활성', lastActive: '1시간 전' },
                    { name: '최동현', email: 'donghyun.choi@dataeye.com', role: '편집자', status: '비활성', lastActive: '2일 전' },
                  ].map((user, idx) => (
                    <tr key={idx} className="border-b border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700/30 transition-colors">
                      <td className="px-6 py-4 text-gray-900 dark:text-gray-100">{user.name}</td>
                      <td className="px-6 py-4 text-gray-600 dark:text-gray-400">{user.email}</td>
                      <td className="px-6 py-4">
                        <span className="px-2.5 py-1 bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-400 rounded-full">
                          {user.role}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`px-2.5 py-1 rounded-full inline-flex items-center gap-1 ${
                          user.status === '활성' 
                            ? 'bg-green-50 dark:bg-green-900/20 text-green-700 dark:text-green-400' 
                            : 'bg-gray-50 dark:bg-gray-700 text-gray-700 dark:text-gray-400'
                        }`}>
                          <span className={`w-1.5 h-1.5 rounded-full ${
                            user.status === '활성' ? 'bg-green-500' : 'bg-gray-500'
                          }`}></span>
                          {user.status}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-gray-600 dark:text-gray-400">{user.lastActive}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        );

      case 'settings':
        return (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 border border-gray-200 dark:border-gray-700">
                <div className="flex items-center gap-4 mb-6">
                  <div className="p-3 bg-gray-50 dark:bg-gray-700 rounded-xl">
                    <SettingsIcon className="w-6 h-6 text-gray-600 dark:text-gray-400" />
                  </div>
                  <h3 className="text-gray-900 dark:text-white font-bold">일반 설정</h3>
                </div>
                <div className="space-y-4">
                  {[
                    { label: '애플리케이션 이름', value: 'DataEye Meta' },
                    { label: '시간대', value: '서울/아시아 (UTC+9)' },
                    { label: '언어', value: '한국어 / 영어' },
                    { label: '날짜 형식', value: 'YYYY-MM-DD' },
                  ].map((setting, idx) => (
                    <div key={idx} className="flex justify-between items-center pb-4 border-b border-gray-200 dark:border-gray-700 last:border-0">
                      <span className="text-gray-600 dark:text-gray-400">{setting.label}</span>
                      <span className="text-gray-900 dark:text-white font-bold">{setting.value}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 border border-gray-200 dark:border-gray-700">
                <div className="flex items-center gap-4 mb-6">
                  <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-xl">
                    <Database className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                  </div>
                  <h3 className="text-gray-900 dark:text-white font-bold">데이터 설정</h3>
                </div>
                <div className="space-y-4">
                  {[
                    { label: '자동 동기화', value: '활성화' },
                    { label: '동기화 주기', value: '5분마다' },
                    { label: '데이터 보관', value: '90일' },
                    { label: '백업 빈도', value: '매일' },
                  ].map((setting, idx) => (
                    <div key={idx} className="flex justify-between items-center pb-4 border-b border-gray-200 dark:border-gray-700 last:border-0">
                      <span className="text-gray-600 dark:text-gray-400">{setting.label}</span>
                      <span className="text-gray-900 dark:text-white font-bold">{setting.value}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        );

      default:
        return (
          <>
            <StatsCards />
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-4">
              <div className="lg:col-span-2">
                <ChartsSection />
              </div>
              <div>
                <ActivityFeed />
              </div>
            </div>
            <DataTable />
          </>
        );
    }
  };

  const getPageDescription = () => {
    switch (activeMenu) {
      case 'dashboard':
        return '실시간으로 데이터 성능과 인사이트를 모니터링합니다';
      case 'analytics':
        return '데이터 분석 지표를 심층적으로 확인합니다';
      case 'data-sources':
        return '데이터 소스 연결을 관리하고 구성합니다';
      case 'insights':
        return 'AI 기반 데이터 인사이트와 추천을 제공합니다';
      case 'reports':
        return '종합 데이터 리포트를 생성하고 확인합니다';
      case 'metadata':
        return '데이터 정의와 스키마를 체계적으로 관리합니다';
      case 'users':
        return '사용자 접근 권한을 관리합니다';
      case 'settings':
        return '애플리케이션 및 데이터 설정을 구성합니다';
      default:
        return '실시간으로 데이터 성능과 인사이트를 모니터링합니다';
    }
  };

  return (
    <main className="flex-1 flex flex-col overflow-hidden bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm">
      <div className="p-4 border-b border-gray-200 dark:border-gray-700 flex-shrink-0">
        <h2 className="text-gray-900 dark:text-white font-bold text-sm" style={{ marginLeft: '10px' }}>
          {activeMenu.charAt(0).toUpperCase() + activeMenu.slice(1).replace('-', ' ')}
        </h2>
        <p className="text-gray-500 dark:text-gray-400 text-sm" style={{ marginLeft: '15px' }}>
          {getPageDescription()}
        </p>
      </div>

      <div className="flex-1 overflow-auto p-4">
        {renderContent()}
      </div>
    </main>
  );
}