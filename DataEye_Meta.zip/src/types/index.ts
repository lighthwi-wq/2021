export interface StatCard {
  label: string;
  value: string;
  change: string;
  trend: 'up' | 'down';
  icon: any;
  color: string;
}

export interface Activity {
  title: string;
  description: string;
  time: string;
  type: 'upload' | 'sync' | 'error' | 'update';
  icon: any;
}

export interface DataRow {
  id: string;
  name: string;
  source: string;
  status: 'active' | 'syncing' | 'error';
  records: string;
  lastSync: string;
}

export interface MenuItem {
  id: string;
  label: string;
  icon: any;
  children?: MenuItem[];
}

export interface ChartDataPoint {
  name: string;
  value: number;
  users?: number;
}

export type MenuId = 
  | 'dashboard' 
  | 'data-standardization'
  | 'standard-term-management'
  | 'menu-management'
  | 'deployment-management'
  | 'standard-adequacy-management'
  | 'biz-meta'
  | 'business-area-management'
  | 'business-process-management'
  | 'business-term-management'
  | 'data-linkage-management'
  | 'data-quality'
  | 'quality-rule-management'
  | 'quality-diagnosis-management'
  | 'quality-violation-management'
  | 'action-management'
  | 'common-management'
  | 'settings';