export interface StatCard {
  label: string;
  value: string;
  change: string;
  trend: 'up' | 'down';
  icon: any;
  color: string;
}

export interface Activity {
  title: string;
  description: string;
  time: string;
  type: 'upload' | 'sync' | 'error' | 'update';
  icon: any;
}

export interface DataRow {
  id: string;
  name: string;
  source: string;
  status: 'active' | 'syncing' | 'error';
  records: string;
  lastSync: string;
}

export interface MenuItem {
  id: string;
  label: string;
  icon: any;
  children?: MenuItem[];
}

export interface ChartDataPoint {
  name: string;
  value: number;
  users?: number;
}

export type MenuId = 
  | 'demo'
  | 'dashboard' 
  | 'biz-meta'
  | 'business-area'
  | 'business-process'
  | 'business-term'
  | 'data-linkage'
  | 'data-standard'
  | 'standard-word'
  | 'standard-domain'
  | 'standard-term'
  | 'standard-code'
  | 'business-glossary'
  | 'data-model'
  | 'subject-area'
  | 'logical-model'
  | 'physical-model'
  | 'db-schema'
  | 'data-lineage'
  | 'impact-analysis'
  | 'data-quality'
  | 'quality-rule'
  | 'profiling'
  | 'quality-evaluation'
  | 'error-data'
  | 'improvement'
  | 'workflow'
  | 'new-request'
  | 'change-management'
  | 'admin'
  | 'user-management'
  | 'menu-management'
  | 'system-code'
  | 'notice';