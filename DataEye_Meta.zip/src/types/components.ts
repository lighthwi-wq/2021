import { ReactNode } from 'react';
import { LucideIcon } from 'lucide-react';

export type Size = 'xs' | 'sm' | 'md' | 'lg' | 'xl';
export type Variant = 'primary' | 'secondary' | 'ghost' | 'outline' | 'danger';
export type Status = 'success' | 'error' | 'warning' | 'info' | 'default';
export type ColorScheme = 'blue' | 'green' | 'purple' | 'orange' | 'red' | 'indigo' | 'gray';

export interface BaseComponentProps {
  className?: string;
  children?: ReactNode;
}

export interface IconProps {
  icon: LucideIcon;
  size?: Size;
  color?: ColorScheme;
}

export interface ButtonProps extends BaseComponentProps {
  onClick?: () => void;
  variant?: Variant;
  size?: Size;
  icon?: LucideIcon;
  disabled?: boolean;
  loading?: boolean;
  fullWidth?: boolean;
}

export interface CardProps extends BaseComponentProps {
  padding?: Size;
  hoverable?: boolean;
  bordered?: boolean;
}

export interface BadgeProps extends BaseComponentProps {
  variant?: Status;
  dot?: boolean;
  size?: Size;
}

export interface TableColumn<T> {
  key: string;
  header: string;
  render?: (item: T) => ReactNode;
  sortable?: boolean;
  width?: string;
}

export interface TableProps<T> {
  data: T[];
  columns: TableColumn<T>[];
  onRowClick?: (item: T) => void;
  loading?: boolean;
  emptyText?: string;
}
