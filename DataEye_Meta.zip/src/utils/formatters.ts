export const formatters = {
  number: (value: number): string => {
    return new Intl.NumberFormat('ko-KR').format(value);
  },

  currency: (value: number, currency = 'KRW'): string => {
    return new Intl.NumberFormat('ko-KR', {
      style: 'currency',
      currency,
    }).format(value);
  },

  date: (date: Date | string): string => {
    const d = typeof date === 'string' ? new Date(date) : date;
    return new Intl.DateTimeFormat('ko-KR').format(d);
  },

  dateTime: (date: Date | string): string => {
    const d = typeof date === 'string' ? new Date(date) : date;
    return new Intl.DateTimeFormat('ko-KR', {
      dateStyle: 'medium',
      timeStyle: 'short',
    }).format(d);
  },

  compactNumber: (value: number): string => {
    if (value >= 1000000) {
      return `${(value / 1000000).toFixed(1)}M`;
    }
    if (value >= 1000) {
      return `${(value / 1000).toFixed(1)}K`;
    }
    return value.toString();
  },

  percentage: (value: number, decimals = 1): string => {
    return `${value.toFixed(decimals)}%`;
  },
};
