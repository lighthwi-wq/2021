import { Header } from './components/layout/Header';
import { Sidebar } from './components/layout/Sidebar';
import { MainContent } from './components/layout/MainContent';
import { ErrorBoundary } from './components/common/ErrorBoundary/ErrorBoundary';
import { Chatbot } from './components/chatbot/Chatbot';
import { LoginPage } from './pages/LoginPage';
import { NavigationProvider } from './contexts/NavigationContext';
import { ThemeProvider } from './contexts/ThemeContext';
import { ModalProvider } from './contexts/ModalContext';
import { useActiveMenu } from './hooks/useActiveMenu';
import { appConfig } from './config/app.config';
import { colors } from './constants/designSystem';
import { useState } from 'react';
import './styles/globals.css';

function AppContent() {
  const { activeMenu, setActiveMenu } = useActiveMenu(appConfig.routes.defaultRoute as any);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userType, setUserType] = useState<'admin' | 'user'>('user');

  const navigationValue = {
    activeMenu,
    setActiveMenu,
    navigate: setActiveMenu,
  };

  // 로그인하지 않은 경우 로그인 페이지 표시
  if (!isLoggedIn) {
    return <LoginPage onLogin={(type) => {
      setUserType(type);
      setIsLoggedIn(true);
    }} />;
  }

  return (
    <NavigationProvider value={navigationValue}>
      <ThemeProvider>
        <ModalProvider>
          <div 
            className="h-screen flex flex-col"
            style={{
              backgroundColor: colors.background,
              color: colors.textPrimary
            }}
          >
            <Header 
              isSidebarCollapsed={isSidebarCollapsed}
              toggleSidebar={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
              onNavigate={setActiveMenu}
              onLogout={() => setIsLoggedIn(false)}
            />
            <div className="flex-1 flex gap-3 p-3 overflow-hidden">
              <Sidebar 
                activeMenu={activeMenu} 
                setActiveMenu={setActiveMenu}
                isCollapsed={isSidebarCollapsed}
                userType={userType}
              />
              <MainContent activeMenu={activeMenu} />
            </div>
            
            {/* 챗봇 */}
            <Chatbot />
          </div>
        </ModalProvider>
      </ThemeProvider>
    </NavigationProvider>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <AppContent />
    </ErrorBoundary>
  );
}
