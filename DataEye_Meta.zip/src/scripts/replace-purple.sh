#!/bin/bash
# 모든 보라색을 인디고로 교체하는 스크립트

# Tailwind 클래스 교체
find . -name "*.tsx" -type f -exec sed -i '' 's/bg-purple-/bg-indigo-/g' {} +
find . -name "*.tsx" -type f -exec sed -i '' 's/text-purple-/text-indigo-/g' {} +
find . -name "*.tsx" -type f -exec sed -i '' 's/border-purple-/border-indigo-/g' {} +
find . -name "*.tsx" -type f -exec sed -i '' 's/from-purple-/from-indigo-/g' {} +
find . -name "*.tsx" -type f -exec sed -i '' 's/to-purple-/to-indigo-/g' {} +
find . -name "*.tsx" -type f -exec sed -i '' 's/ring-purple-/ring-indigo-/g' {} +

# Hex 색상 교체
find . -name "*.tsx" -type f -exec sed -i '' 's/#8B5CF6/#4F46E5/g' {} +
find . -name "*.tsx" -type f -exec sed -i '' 's/#9C27B0/#4F46E5/g' {} +
find . -name "*.tsx" -type f -exec sed -i '' 's/#A78BFA/#4F46E5/g' {} +

# color="purple" 교체
find . -name "*.tsx" -type f -exec sed -i '' "s/color=\"purple\"/color=\"indigo\"/g" {} +
find . -name "*.tsx" -type f -exec sed -i '' "s/color: 'purple'/color: 'indigo'/g" {} +

echo "보라색을 인디고로 교체 완료!"
