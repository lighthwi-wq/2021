export const themeConfig = {
  colors: {
    primary: {
      50: '#EEF6FF',
      100: '#DCEEFF',
      200: '#B8DCFF',
      300: '#85C5FF',
      400: '#4AA8FF',
      500: '#2B8DFF',
      600: '#1A6FDB',
      700: '#1557B0',
    },
    secondary: {
      50: '#F5F3FF',
      100: '#EDE9FE',
      200: '#DDD6FE',
      300: '#C4B5FD',
      400: '#A78BFA',
      500: '#8B5CF6',
      600: '#7C3AED',
      700: '#6D28D9',
    },
    success: {
      50: '#ECFDF5',
      100: '#D1FAE5',
      200: '#A7F3D0',
      300: '#6EE7B7',
      400: '#34D399',
      500: '#10B981',
      600: '#059669',
    },
    neutral: {
      50: '#F8FAFC',
      100: '#F1F5F9',
      200: '#E2E8F0',
      300: '#CBD5E1',
      400: '#94A3B8',
      500: '#64748B',
      600: '#475569',
    },
    accent: {
      teal: {
        300: '#5DD4C8',
        400: '#3CC7BA',
        500: '#1AB6A8',
      },
      indigo: {
        300: '#A5B4FC',
        400: '#818CF8',
        500: '#6366F1',
      },
    },
  },
  spacing: {
    xs: '0.25rem',
    sm: '0.5rem',
    md: '1rem',
    lg: '1.5rem',
    xl: '2rem',
    '2xl': '3rem',
  },
  borderRadius: {
    sm: '0.5rem',
    md: '0.75rem',
    lg: '1rem',
    xl: '1.25rem',
  },
  shadows: {
    sm: '0 1px 3px 0 rgb(0 0 0 / 0.05)',
    md: '0 2px 8px 0 rgb(0 0 0 / 0.06)',
    lg: '0 4px 12px 0 rgb(0 0 0 / 0.08)',
  },
} as const;

export type ThemeConfig = typeof themeConfig;