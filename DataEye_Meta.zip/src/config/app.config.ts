export const appConfig = {
  app: {
    name: 'DataEye Meta',
    version: '1.0.0',
    description: '데이터 분석 대시보드',
  },
  features: {
    darkMode: false,
    notifications: true,
    search: true,
  },
  storage: {
    darkModeKey: 'dataeye-dark-mode',
    activeMenuKey: 'dataeye-active-menu',
  },
  routes: {
    defaultRoute: 'dashboard',
  },
} as const;

export type AppConfig = typeof appConfig;